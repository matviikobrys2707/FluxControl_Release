﻿#requires -Version 5.1
<#
.SYNOPSIS
    Auto-Deploy.ps1 — ОДИН скрипт: версія -> збірка застосунку -> публікація
    на GitHub (реліз: 1 exe; робочі файли + манифест: у головній гілці).

.DESCRIPTION
    АРХІТЕКТУРА (ТЗ «1 файл + динамічна загрузка»):
      Користувач качає FluxControl.exe з релізу — це САМЕ ЗАСТОСУНOK
      (framework-dependent single-file, ~5 МБ). Файл розтаутно-незалежний:
      його можна тримати на робочому столі чи в Downloads — при запуску всі
      робочі файли (UI, іконка) живуть у %AppData%\FluxControl і підтягуються
      звідти; оновлюються з files/ головної гілки по манифесту version.json
      (звірка sha256). Оновлення самого exe — теж автоматичне.

    Що робить цей скрипт:
      1. FluxControl.Agent -> FluxControl.exe (single-file) — ЄДИНИЙ файл
         у релізі v<версія> (та його копія у files/ для самооновлення);
      2. files/ -> головна гілка репозиторію: FluxControl.exe,
         UI/agent_ui.html, logo.ico;
      3. version.json — манифест: {latest_version, files[] з sha256,
         download_url -> files/FluxControl.exe} у корінь main;
      4. GitHub Release v<версія> з гарним описом.

    Способи деплою (визначаються автоматично):
      • gh CLI (https://cli.github.com)               — повний автомат (рекомендовано)
      • змінна середовища GITHUB_TOKEN (repo scope)   — публікація через REST + git
      • ні того, ні іншого                            — файли готуються в Installer\_deploy

    Після роботи в Installer\_deploy лишається рівно три елементи:
      FluxControl.exe   files\   version.json

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File Auto-Deploy.ps1
    powershell -ExecutionPolicy Bypass -File Auto-Deploy.ps1 -Version 1.0.3
    powershell -ExecutionPolicy Bypass -File Auto-Deploy.ps1 -Version 1.0.3 -NoDeploy
    powershell -ExecutionPolicy Bypass -File Auto-Deploy.ps1 -Version 1.0.3 -Notes "Фікс підключення"
#>

param(
    [string]$Version = '',
    [string]$Repo = 'matviikobrys2707/FluxControl_Release',
    [string]$Notes = '',
    [switch]$NoBuild,
    [switch]$NoDeploy
)

$ErrorActionPreference = 'Stop'

# GitHub (raw/api/uploads) вимагає TLS 1.2 — PS 5.1 на старих збірках Win10
# за замовчуванням його не вмикає, і Invoke-WebRequest тихо падає в 404/помилку
# («version.json недоступний»). Вмикаємо явно.
try {
    [Net.ServicePointManager]::SecurityProtocol =
        [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
} catch { }

$InstallerDir   = $PSScriptRoot
$SrcDir         = (Resolve-Path (Join-Path $InstallerDir '..')).Path
$AgentCsproj    = Join-Path $SrcDir 'FluxControl.Agent\FluxControl.Agent.csproj'
$AgentDir       = Join-Path $SrcDir 'FluxControl.Agent'
$OutDir         = Join-Path $InstallerDir '_deploy'
$FilesDir       = Join-Path $OutDir 'files'
$PublishDir     = Join-Path $OutDir '.publish'   # тимчасовий вивід dotnet, видаляється
$UserExe        = Join-Path $OutDir 'FluxControl.exe'
$JsonOut        = Join-Path $OutDir 'version.json'
$VersionJsonUrl = "https://raw.githubusercontent.com/$Repo/main/version.json"

function Write-Step { param([string]$t) Write-Host ''; Write-Host "  $t" -ForegroundColor Cyan }
function Write-Ok   { param([string]$t) Write-Host "    [OK] $t" -ForegroundColor Green }
function Write-Fail { param([string]$t) Write-Host "    [X]  $t" -ForegroundColor Red }
function Write-MB   { param([string]$p) [math]::Round((Get-Item -LiteralPath $p).Length / 1MB, 2) }

# Надійне прибирання: файли в _deploy може тримати запущений з них процес
# або антивірус (Access denied). Спочатку прибиваємо процеси, запущені з
# _deploy, потім видаляємо ВМІСТО з кількома спробами (сам каталог може
# тримати чиясь відкрита консоль — це не заважає, він переиспользується).
function Reset-DeployDir {
    $locked = @()
    foreach ($p in Get-Process -ErrorAction SilentlyContinue) {
        try {
            if ($p.MainModule -and $p.MainModule.FileName -and
                $p.MainModule.FileName.StartsWith($OutDir, [StringComparison]::OrdinalIgnoreCase)) {
                $locked += $p
            }
        } catch { }
    }
    foreach ($p in $locked) {
        Write-Host "    [!] Завершую процес, що тримає файли _deploy: $($p.ProcessName) (pid $($p.Id))" -ForegroundColor Yellow
        try { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue } catch { }
    }
    if ($locked.Count -gt 0) { Start-Sleep -Milliseconds 800 }

    New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
    for ($i = 1; $i -le 5; $i++) {
        $left = Get-ChildItem -LiteralPath $OutDir -Force -ErrorAction SilentlyContinue
        if (-not $left) { return $true }
        foreach ($item in $left) {
            Remove-Item -LiteralPath $item.FullName -Recurse -Force -ErrorAction SilentlyContinue
        }
        Start-Sleep -Milliseconds (300 * $i)
    }
    $left = Get-ChildItem -LiteralPath $OutDir -Force -ErrorAction SilentlyContinue
    if ($left) {
        Write-Fail 'Не вдалося очистити _deploy (файли зайняті). Закрий програми/консолі, відкриті в _deploy, і запусти ще раз.'
        return $false
    }
    return $true
}

Write-Host ''
Write-Host '  ==========================================' -ForegroundColor Magenta
Write-Host '   FluxControl - Auto Deploy (single v4)'      -ForegroundColor Magenta
Write-Host '  ==========================================' -ForegroundColor Magenta

if (-not (Test-Path -LiteralPath $AgentCsproj)) { Write-Fail "Не знайдено $AgentCsproj"; exit 1 }

# ------------------------------------------------- крок 1: версія на GitHub ---
Write-Step 'Крок 1/4 — поточна версія на GitHub'
$current = $null
try {
    # ВАЖЛИВО: не писати "$VersionJsonUrl?t=" — у PowerShell '?' входить в ім'я
    # змінної, і URL схлопується у "=<timestamp>" (Invalid URI). Лише конкатенація.
    $probe = $VersionJsonUrl + "?t=" + [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    $resp  = Invoke-WebRequest -UseBasicParsing -Uri $probe -Headers @{ 'User-Agent' = 'FluxControl-Deploy' } -TimeoutSec 15
    $meta  = $resp.Content | ConvertFrom-Json
    $current = [string]$meta.latest_version
} catch {
    # 404 = репозиторій/гілка/файл ще не існує — нормально для першого релізу
    $code = 0
    if ($_.Exception.Response -and $_.Exception.Response.StatusCode) {
        $code = [int]$_.Exception.Response.StatusCode
    }
    if ($code -eq 404) {
        Write-Host '    [i] version.json ще не існує в main — це перший реліз.' -ForegroundColor Yellow
    } else {
        Write-Host "    [i] GitHub недоступний ($($_.Exception.Message)) — продовжую без перевірки версії." -ForegroundColor Yellow
    }
}

if ($current) {
    Write-Ok "Поточна версія на GitHub: v$current"
}

# ------------------------------------------------- крок 2: нова версія ---
Write-Step 'Крок 2/4 — версія нового релізу'
$suggested = '1.0.0'
if ($current -match '^\d+(\.\d+)*$') {
    $parts = $current.Split('.')
    $parts[-1] = [string]([int]$parts[-1] + 1)
    $suggested = $parts -join '.'
}
if (-not $Version) {
    $typed = Read-Host "    Нова версія [Enter = $suggested]"
    if ([string]::IsNullOrWhiteSpace($typed)) { $Version = $suggested } else { $Version = $typed.Trim() }
}
if ($Version -notmatch '^\d+(\.\d+)*$') { Write-Fail "Невірний формат версії: '$Version' (очікується 1.2.3)"; exit 1 }
Write-Ok "Реліз: v$Version  (був: $(if ($current) { "v$current" } else { '-' }))"

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { Write-Fail 'dotnet SDK не знайдено'; exit 1 }

if (-not $NoBuild) {
    # -------------------------------------------- крок 3: збірка ---
    Write-Step 'Крок 3/4 — FluxControl.exe (framework-dependent single-file)'
    if (-not (Reset-DeployDir)) { exit 1 }
    New-Item -ItemType Directory -Force -Path $FilesDir, $PublishDir | Out-Null

    & dotnet publish $AgentCsproj -c Release -r win-x64 --self-contained false `
        -p:PublishSingleFile=true `
        -p:IncludeNativeLibrariesForSelfExtract=true `
        -p:DebugType=none -p:DebugSymbols=false `
        -p:EnableWindowsTargeting=true `
        -p:Version=$Version `
        -o $PublishDir
    if ($LASTEXITCODE -ne 0) { Write-Fail "dotnet publish завершився з кодом $LASTEXITCODE"; exit 1 }

    $builtExe = Join-Path $PublishDir 'FluxControl.exe'
    if (-not (Test-Path -LiteralPath $builtExe)) { Write-Fail 'FluxControl.exe не знайдено після publish'; exit 1 }

    # релізний файл (єдиний ассет релізу)
    Copy-Item -LiteralPath $builtExe -Destination $UserExe -Force
    Write-Ok ("FluxControl.exe (застосунок): {0} МБ" -f (Write-MB $UserExe))

    # files/ — те, що їде у головну гілку репозиторію
    # (сам exe — для самооновлення; UI та іконка — «не обов'язкові для запуску»
    # робочі файли, які програма тримає у %AppData%\FluxControl)
    Copy-Item -LiteralPath $builtExe -Destination (Join-Path $FilesDir 'FluxControl.exe') -Force
    New-Item -ItemType Directory -Force -Path (Join-Path $FilesDir 'UI') | Out-Null
    Copy-Item (Join-Path $AgentDir 'UI\agent_ui.html') (Join-Path $FilesDir 'UI\agent_ui.html') -Force
    Copy-Item (Join-Path $AgentDir 'logo.ico') (Join-Path $FilesDir 'logo.ico') -Force
    Write-Ok ("files/: FluxControl.exe ({0} МБ) + UI\agent_ui.html + logo.ico" -f (Write-MB $builtExe))

    # прибираємо тимчасовий publish — у _deploy лишається рівно 3 елементи
    Remove-Item -LiteralPath $PublishDir -Recurse -Force -ErrorAction SilentlyContinue
} else {
    if (-not (Test-Path -LiteralPath $UserExe)) { Write-Fail '-NoBuild: у _deploy немає FluxControl.exe'; exit 1 }
    if (-not (Test-Path -LiteralPath $FilesDir)) { Write-Fail '-NoBuild: у _deploy немає папки files'; exit 1 }
    Write-Ok 'Пропускаю збірку (-NoBuild) — беру готові файли з _deploy'
}

# ------------------------------------------- крок 3.5: манифест version.json ---
$downloadUrl = "https://raw.githubusercontent.com/$Repo/main/files/FluxControl.exe"
$filesList = @()
# у files[] перелічуємо тільки Робочі файли (UI/іконка) — сам exe туди НЕ
# входить: він у користувача вже запущений, а його оновленням керує
# download_url + InstallWindow (exe-swap по фактичному шляху запуску)
Get-ChildItem -LiteralPath $FilesDir -File -Recurse | ForEach-Object {
    if ($_.Name -eq 'FluxControl.exe') { return }
    $rel = [IO.Path]::GetFullPath($_.FullName).Substring([IO.Path]::GetFullPath($FilesDir).Length + 1).Replace('\', '/')
    $h = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    $filesList += @{ name = $rel; sha256 = $h }
}
$manifest = [ordered]@{
    latest_version = $Version
    files          = $filesList
    download_url   = $downloadUrl
}
$json = $manifest | ConvertTo-Json -Depth 4 -Compress
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($JsonOut, $json + "`r`n", $utf8NoBom)
Write-Ok "version.json (манифест): $json"

if ($NoDeploy) {
    Write-Host ''
    Write-Ok "Деплой пропущено (-NoDeploy). Файли готові:"
    Write-Host "      $UserExe    <- єдиний файл релізу v$Version"       -ForegroundColor Gray
    Write-Host "      $FilesDir   <- робочі файли + exe у головну гілку"  -ForegroundColor Gray
    Write-Host "      $JsonOut"                                             -ForegroundColor Gray
    exit 0
}

# ------------------------------------------------- крок 4: деплой ---
Write-Step 'Крок 4/4 — публікація: реліз (1 exe) + files/ у головну гілку'
$gh     = Get-Command gh -ErrorAction SilentlyContinue
$token  = $env:GITHUB_TOKEN
$relUrl = "https://github.com/$Repo/releases/new?tag=v$Version&title=FluxControl%20v$Version"
$today  = Get-Date -Format 'dd.MM.yyyy'

# Гарний опис релізу (markdown)
$notes = @"
## 🚀 Нова версія FluxControl — **v$Version**

**Дата релізу:** $today

---

### ⬇️ Встановлення — один файл
1. Завантаж **FluxControl.exe** нижче і запусти — місце розташування значення не має
   (робочий стіл, Downloads — де завгодно)
2. Усе інше програма зробить сама:
   - ✔ робочі файли (інтерфейс, іконка) — у %AppData%\FluxControl
   - ✔ .NET 8 Runtime — знайде в системі або підкаже, якщо відсутній
   - ✔ при кожному старті — перевірка манифеста version.json

### 🔄 Оновлення
Вже встановлений FluxControl оновиться автоматично при наступному запуску —
нічого робити не треба: новий exe підміниться на місці, робочі файли
синхронізуються за sha256.

---
📦 Робочі файли (files/) та манифест version.json лежать у головній гілці
цього репозиторію — саме звідти програма їх підтягує і оновлює.
"@
if ($Notes -and $Notes.Trim()) {
    $notes += "`n`n### 📝 Що нового`n`n" + $Notes.Trim()
}

# Оновлення головної гілки репозиторію: files/ + манифест version.json.
function Update-RepoMain([string]$cloneUrl) {
    $repoDir = Join-Path $OutDir '.repo'
    if (Test-Path -LiteralPath $repoDir) { Remove-Item -LiteralPath $repoDir -Recurse -Force -ErrorAction SilentlyContinue }
    Write-Host '    [-] Клоную репозиторій релізів…'
    & git clone --depth 1 $cloneUrl $repoDir *>$null
    if ($LASTEXITCODE -ne 0) { throw "git clone не вдався ($Repo)" }

    # files/ — повна заміна на свіжий набір
    $repoFiles = Join-Path $repoDir 'files'
    if (Test-Path -LiteralPath $repoFiles) { Remove-Item -LiteralPath $repoFiles -Recurse -Force }
    Copy-Item -LiteralPath $FilesDir -Destination $repoFiles -Recurse -Force
    Copy-Item -LiteralPath $JsonOut -Destination (Join-Path $repoDir 'version.json') -Force
    # легасі-файли попередніх схем деплою більше не потрібні
    Get-ChildItem -LiteralPath $repoDir -Filter 'FluxControl-app-*.zip' -ErrorAction SilentlyContinue |
        Remove-Item -Force -ErrorAction SilentlyContinue

    & git -C $repoDir add -A
    $null = & git -C $repoDir -c user.name='FluxControl Deploy' -c user.email='deploy@users.noreply.github.com' commit -m "Release v$Version" 2>&1
    if ($LASTEXITCODE -ne 0) {
        $staged = & git -C $repoDir status --porcelain
        if ($staged) { throw "git commit не вдався" }
        Write-Ok 'У головній гілці вже актуальний вміст'
    }
    & git -C $repoDir push origin HEAD:main *>$null
    if ($LASTEXITCODE -ne 0) { throw "git push не вдався ($Repo)" }
    Remove-Item -LiteralPath $repoDir -Recurse -Force -ErrorAction SilentlyContinue
    Write-Ok 'Головну гілку оновлено: files/ + version.json у корені main'
}

if ($gh) {
    # ---------------------------------------------------------- gh CLI ---
    # gh пише прогрес у stderr: за $ErrorActionPreference='Stop' PS 5.1
    # вбиває скрипт (NativeCommandError). Для gh-секції вимикаємо Stop —
    # помилки контролюємо через $LASTEXITCODE.
    $ErrorActionPreference = 'Continue'

    & gh auth status *>$null
    if ($LASTEXITCODE -ne 0) {
        Write-Host ''
        Write-Host '    [!] gh не авторизовано. Зараз відкриється вхід у GitHub.' -ForegroundColor Yellow
        Write-Host '        Оберіть: GitHub.com → HTTPS → Login with a web browser,' -ForegroundColor Yellow
        Write-Host '        потім введіть код у браузері.' -ForegroundColor Yellow
        & gh auth login --hostname github.com --git-protocol https --web
        & gh auth status *>$null
        if ($LASTEXITCODE -ne 0) {
            Write-Fail 'Авторизація не завершена. Виконай вручну:  gh auth login  — і запусти скрипт знову.'
            Start-Process $relUrl
            exit 1
        }
        Write-Ok 'gh авторизовано'
    }
    & gh auth setup-git *>$null   # git push використає облікові дані gh

    # репозиторій релізів міг бути видалений — створюємо при потребі
    & gh repo view $Repo *>$null
    if ($LASTEXITCODE -ne 0) {
        Write-Host '    [-] Репозиторій не знайдено — створюю…'
        & gh repo create $Repo --public --confirm *>$null
        if ($LASTEXITCODE -ne 0) {
            Write-Fail "Не вдалося створити репозиторій $Repo"
            exit 1
        }
        Write-Ok 'Репозиторій релізів створено'
    }
    Write-Ok 'GitHub CLI готовий — повний автомат'

    try { Update-RepoMain "https://github.com/$Repo.git" }
    catch {
        Write-Fail $_.Exception.Message
        Write-Fail 'Файли НЕ завантажено у головну гілку — реліз краще не публікувати.'
        exit 1
    }

    & gh release view "v$Version" --repo $Repo *>$null
    if ($LASTEXITCODE -eq 0) {
        Write-Ok "Реліз v$Version вже існує — замінюю FluxControl.exe"
        & gh release upload "v$Version" $UserExe --repo $Repo --clobber
    } else {
        & gh release create "v$Version" $UserExe --repo $Repo `
            --title "FluxControl v$Version" `
            --notes $notes
    }
    if ($LASTEXITCODE -ne 0) {
        Write-Fail "Не вдалося опублікувати реліз v$Version."
        Start-Process $relUrl
        exit 1
    }
    Write-Ok 'Реліз опубліковано: єдиний файл FluxControl.exe'
}
elseif ($token) {
    # ---------------------------------------------------- GITHUB_TOKEN ---
    Write-Ok 'GITHUB_TOKEN знайдено — публікація через git + REST API'
    $H = @{
        Authorization = "Bearer $token"
        'User-Agent'  = 'FluxControl-Deploy'
        Accept        = 'application/vnd.github+json'
    }

    try { Update-RepoMain "https://x-access-token:$token@github.com/$Repo.git" }
    catch {
        Write-Fail $_.Exception.Message
        Write-Fail 'Файли НЕ завантажено у головну гілку — реліз краще не публікувати.'
        exit 1
    }

    $rel = $null
    try {
        $body = @{
            tag_name         = "v$Version"
            name             = "FluxControl v$Version"
            body             = $notes
            target_commitish = 'main'
        } | ConvertTo-Json
        $rel = Invoke-RestMethod -Headers $H -Method Post -ContentType 'application/json' `
               -Uri "https://api.github.com/repos/$Repo/releases" -Body $body
        Write-Ok "Створено реліз v$Version"
    } catch {
        try { $rel = Invoke-RestMethod -Headers $H -Uri "https://api.github.com/repos/$Repo/releases/tags/v$Version" }
        catch {
            Write-Fail "Не вдалося створити реліз: $($_.Exception.Message). Чи існує репозиторій $Repo?"
            exit 1
        }
    }

    try {
        $uploadUri = "https://uploads.github.com/repos/$Repo/releases/$($rel.id)/assets?name=FluxControl.exe"
        $bytes = [System.IO.File]::ReadAllBytes($UserExe)
        Invoke-RestMethod -Headers ($H + @{ 'Content-Type' = 'application/octet-stream' }) `
            -Method Post -Uri $uploadUri -Body $bytes | Out-Null
        Write-Ok 'FluxControl.exe завантажено як актив релізу'
    } catch {
        Write-Fail "Помилка завантаження активу: $($_.Exception.Message)"
        Start-Process $relUrl
        exit 1
    }
}
else {
    # ---------------------------------------------------------- вручну ---
    Write-Host ''
    Write-Host '  Автодеплой недоступний (немає gh CLI і GITHUB_TOKEN).' -ForegroundColor Yellow
    Write-Host '  Файли вже готові в Installer\_deploy:'                  -ForegroundColor Yellow
    Write-Host "    • FluxControl.exe — прикріпи єдиним активом до релізу v$Version" -ForegroundColor Yellow
    Write-Host "    • files\ — завантаж у папку files/ у корені main ('Add file → Upload files')" -ForegroundColor Yellow
    Write-Host '    • version.json (вміст нижче) — заміни у корені main' -ForegroundColor Yellow
    Write-Host "        $json" -ForegroundColor Gray
    Write-Host ''
    Write-Host '  Щоб наступні деплої були повністю автоматичними:' -ForegroundColor DarkGray
    Write-Host '    варіант А: winget install GitHub.cli   потім   gh auth login' -ForegroundColor DarkGray
    Write-Host '    варіант Б: setx GITHUB_TOKEN "<токен з правами repo>"' -ForegroundColor DarkGray
    Start-Process $relUrl
}

# ------------------------------------------------- фінал ---
Write-Host ''
Write-Host '  ГОТОВО. Як це працює у користувача:' -ForegroundColor Green
Write-Host '    1. Качає єдиний файл релізу — FluxControl.exe (де завгодно зберігає)' -ForegroundColor Green
Write-Host '    2. Запускає — робочі файли живуть у %AppData%\FluxControl' -ForegroundColor Green
Write-Host '    3. При кожному старті — звірка манифеста version.json (sha256)' -ForegroundColor Green
Write-Host '    4. Нова версія? exe сам себе оновлює і перезапускається' -ForegroundColor Green
Write-Host ''
Write-Host "    реліз         : https://github.com/$Repo/releases/tag/v$Version" -ForegroundColor Green
Write-Host "    манифест      : $VersionJsonUrl" -ForegroundColor Green
Write-Host "    самооновлення : $downloadUrl"  -ForegroundColor Green
Write-Host ''
exit 0
