# FluxControl — Remote PC Controller

> **Кроссплатформенная система безопасного удаленного управления ПК из любой точки мира через https://fluxcontrol.pages.dev/ по 16-значному коду компьютера.**

---

## 📁 Структура проекта

Репозиторий очищен от старых файлов и временных установщиков. Вся система состоит из двух чистых компонентов:

1. **`FluxControl.Agent/`** — Настольное приложение для Windows (.NET, WPF + WebView2 Fluent UI):
   - Исполняемый файл: `FluxControl.Agent/bin/Release/net8.0-windows/FluxControl.exe`.
   - Запуск в 1 клик: `Start-FluxControl.bat`.
   - Автозагрузка официального Cloudflare Tunnel (`cloudflared.exe`) при его отсутствии.
   - Минимизация в системный трей при закрытии.
   - Поддержка автозапуска с Windows через реестр (`HKCU\...\Run`).
   - Отображение 16-значного кода, QR-кода и ссылки для сопряжения со смартфоном.

2. **`FluxControl.Web/`** — Клиентское веб-приложение (PWA) для браузера и смартфона:
   - Стек: React 19, TypeScript, Tailwind CSS, Vite.
   - Серверные функции Cloudflare Pages в `functions/api/`:
     - `/api/auth/profile` — сохранение и вход пользователя по **Email и Имени** в базу Cloudflare D1.
     - `/api/devices` — привязка и синхронизация компьютеров пользователя в таблице `user_computers`.
     - `/api/agent/register` — регистрация актуального HTTPS адреса туннеля ПК с регулярным Heartbeat.
     - `/api/resolve` — резолв актуального онлайн-адреса ПК по 16-значному коду.
   - Локальный запуск dev-сервера: `Start-Web-Dev.bat`.
   - Сборка продакшен-бандла: `npm run build` (вывод в `FluxControl.Web/dist`).

---

## 🔑 Вход в аккаунт и синхронизация (Email + Имя / Google)

- При открытии сайта пользователь может войти, указав свое **Имя и Email** (или воспользовавшись кнопкой Google).
- Профиль сохраняется в облачной базе данных Cloudflare D1 (`users`).
- Все добавленные компьютеры автоматически привязываются к профилю (`user_computers`). При входе с любого смартфона или планшета по вашему Email список ПК загружается мгновенно.

---

## 🌐 Глобальный доступ через Cloudflare Tunnel

1. При запуске Агента на ПК поднимается зашифрованный туннель `https://*.trycloudflare.com`.
2. Адрес туннеля регистрируется в базе данных каждые 25 секунд.
3. Веб-клиент подключается напрямую через безопасный WebSocket `wss://*.trycloudflare.com/ws`.
4. Локальные IP-адреса не используются — управление работает через мобильный интернет (4G/5G) и из любой точки мира.

---

## 🚀 Быстрый запуск

### Запуск Агента на ПК:
Дважды щелкните:
```cmd
Start-FluxControl.bat
```
Либо напрямую запустите:
```cmd
FluxControl.Agent\bin\Release\net8.0-windows\FluxControl.exe
```

### Развертывание сайта на Cloudflare Pages:
В каталоге `FluxControl.Web`:
```cmd
npm run build
npx wrangler pages deploy dist --project-name=fluxcontrol
```
После развертывания веб-панель доступна по постоянному адресу `https://fluxcontrol.pages.dev/`.
