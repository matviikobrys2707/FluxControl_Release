# FluxControl Web (Production Deployment)

Офіційний веб-клієнт системи віддаленого керування комп'ютером **FluxControl 3.0**.

- **URL**: [https://fluxcontrol.pages.dev/](https://fluxcontrol.pages.dev/)
- **Особливості**:
  - Інтерфейс у стилі **Dynamic Island** (лендінг, список пристроїв, інструкція)
  - Безпечна авторизація через Google Auth
  - Суворе обмеження на підключення до ПК офлайн
  - Вбудований `_worker.js` (Cloudflare Pages Advanced Worker) для обробки `/api/*` та виключення помилок 405
