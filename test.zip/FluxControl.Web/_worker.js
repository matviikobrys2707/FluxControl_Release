// Cloudflare Pages Advanced Mode Worker: _worker.js
// Handles all /api/* routes backed by Cloudflare D1 (fluxcontrol)
// and delegates static assets to env.ASSETS with SPA routing

const CLOUDFLARE_D1_CONFIG = {
  accountId: '959f0a3b73e2617a7204d8f6dc1dc8aa',
  databaseId: '7c290aee-b48e-463d-8b97-d8d571c2d986',
  authToken: 'cfut_jgPntIOZrQEpH6ZDcC3ilNnSJw7hF43tvEhHWLBO3f856805',
  endpoint: 'https://api.cloudflare.com/client/v4/accounts/959f0a3b73e2617a7204d8f6dc1dc8aa/d1/database/7c290aee-b48e-463d-8b97-d8d571c2d986/query'
};

async function executeSql(env, sql, params = []) {
  if (env && env.DB) {
    try {
      if (params.length > 0) {
        return await env.DB.prepare(sql).bind(...params).all();
      } else {
        return await env.DB.prepare(sql).all();
      }
    } catch (e) {
      console.error('[D1 Binding Error]', e.message);
    }
  }

  // Fallback to D1 REST API
  try {
    const postData = JSON.stringify({ sql, params });
    const response = await fetch(CLOUDFLARE_D1_CONFIG.endpoint, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${CLOUDFLARE_D1_CONFIG.authToken}`,
        'Content-Type': 'application/json'
      },
      body: postData
    });
    const data = await response.json();
    return { results: data.result?.[0]?.results || [] };
  } catch (e) {
    console.error('[D1 REST Error]', e.message);
    return { results: [] };
  }
}

function generateLicenseKeyCode() {
  const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
  const getChunk = (len) => {
    let res = '';
    for (let i = 0; i < len; i++) {
      res += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return res;
  };
  return `FC-${getChunk(4)}-${getChunk(4)}-${getChunk(4)}-${getChunk(4)}`;
}

function getDurationMs(type) {
  switch (type) {
    case '1m': return 60 * 1000;
    case '5m': return 5 * 60 * 1000;
    case '1h': return 60 * 60 * 1000;
    case '1d': return 24 * 60 * 60 * 1000;
    case '7d': return 7 * 24 * 60 * 60 * 1000;
    case '30d': return 30 * 24 * 60 * 60 * 1000;
    case '90d': return 90 * 24 * 60 * 60 * 1000;
    case '1y': return 365 * 24 * 60 * 60 * 1000;
    case 'lifetime': return 0;
    default: return 30 * 24 * 60 * 60 * 1000;
  }
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    const corsHeaders = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, PATCH, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization"
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders });
    }

    // 1. Health & Server Info
    if (url.pathname === "/api/ping" || url.pathname === "/api/health") {
      return new Response(JSON.stringify({ status: "ok", time: Date.now() }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }

    // 2. Auth Endpoint: Google & Email login
    if ((url.pathname === "/api/auth/google" || url.pathname === "/api/auth/profile") && request.method === "POST") {
      try {
        const body = await request.json();
        const u = body.user || body;
        const uid = String(u.sub || u.id || u.uid || '').trim();
        const email = String(u.email || '').trim().toLowerCase();

        if (!uid && !email) {
          return new Response(JSON.stringify({ error: "User ID or Email missing" }), { status: 400, headers: corsHeaders });
        }

        const finalId = uid || `usr_${Date.now().toString(36)}`;
        
        // Check existing user in D1
        const res = await executeSql(env, "SELECT * FROM users WHERE id = ? OR email = ? LIMIT 1;", [finalId, email]);
        let existingUser = res.results?.[0];

        let role = existingUser?.role || 'user';
        if (email.includes('blazix') || email.includes('admin@')) {
          role = 'admin';
        }

        const subscriptionExpiresAt = role === 'admin' 
          ? -1 
          : (existingUser?.subscription_expires_at !== undefined ? existingUser.subscription_expires_at : null);

        const userData = {
          id: existingUser ? existingUser.id : finalId,
          email: email || existingUser?.email || '',
          name: u.name || u.displayName || existingUser?.name || (email ? email.split('@')[0] : 'Користувач'),
          picture: u.picture || u.photoURL || existingUser?.picture || '',
          role,
          subscriptionExpiresAt
        };

        await executeSql(env, `
          INSERT INTO users (id, email, name, picture, role, subscription_expires_at)
          VALUES (?, ?, ?, ?, ?, ?)
          ON CONFLICT(id) DO UPDATE SET
            email=excluded.email,
            name=excluded.name,
            picture=excluded.picture,
            role=excluded.role,
            subscription_expires_at=excluded.subscription_expires_at;
        `, [userData.id, userData.email, userData.name, userData.picture, userData.role, userData.subscriptionExpiresAt]);

        return new Response(JSON.stringify({ success: true, user: userData }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });
      } catch (err) {
        return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: corsHeaders });
      }
    }

    // 3. Verify Code
    if (url.pathname === "/api/devices/verify-code" && request.method === "GET") {
      try {
        const rawCode = String(url.searchParams.get("code") || '').replace(/[^A-Za-z0-9]/g, '').trim().toUpperCase();
        if (!rawCode) {
          return new Response(JSON.stringify({ success: false, message: "Введіть код підключення" }), { status: 400, headers: corsHeaders });
        }

        const res = await executeSql(env, "SELECT * FROM computers WHERE code = ? OR hwid = ? OR id = ? LIMIT 1;", [rawCode, rawCode, rawCode]);
        const comp = res.results?.[0];

        if (!comp) {
          return new Response(JSON.stringify({ success: false, message: "Комп'ютер не знайдено в базі даних" }), { status: 404, headers: corsHeaders });
        }

        // Runtime reachability can only be proven by a fresh agent heartbeat.
        // The D1 `status` column used to stay 'online' forever after the first
        // registration, which made this fallback report every PC as online.
        const lastSeenMs = comp.last_seen ? new Date(comp.last_seen).getTime() : 0;
        const isOnline = lastSeenMs > 0 && (Date.now() - lastSeenMs < 120000);

        return new Response(JSON.stringify({
          success: true,
          data: {
            hwid: comp.hwid || comp.id,
            code: comp.code || comp.id,
            name: comp.name || "Мій ПК",
            os: comp.os_info || "Windows",
            cpu: comp.cpu_info || "CPU",
            gpu: comp.gpu || "GPU",
            ram: comp.ram_info || "8 GB",
            isOnline
          }
        }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
      } catch (err) {
        return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: corsHeaders });
      }
    }

    // 4. Link Computer to User
    if ((url.pathname === "/api/user/computers/link" || url.pathname === "/api/devices") && request.method === "POST") {
      try {
        const body = await request.json();
        const { userId, hwid, code, computerId, connectionCode, customName, name } = body;
        const targetId = hwid || computerId || code || connectionCode;
        const finalName = customName || name;

        if (!userId || !targetId) {
          return new Response(JSON.stringify({ success: false, message: "User ID and Target ID required" }), { status: 400, headers: corsHeaders });
        }

        // Safe upsert: read-then-write (works even without UNIQUE constraints in D1)
        const existing = await executeSql(env,
          "SELECT rowid FROM users_computers WHERE user_id = ? AND computer_id = ? LIMIT 1;",
          [userId, targetId]
        );
        if (existing.results && existing.results.length > 0) {
          await executeSql(env,
            "UPDATE users_computers SET custom_name = ? WHERE user_id = ? AND computer_id = ?;",
            [finalName || null, userId, targetId]
          );
        } else {
          await executeSql(env,
            "INSERT INTO users_computers (user_id, computer_id, custom_name) VALUES (?, ?, ?);",
            [userId, targetId, finalName || null]
          );
        }

        return new Response(JSON.stringify({ success: true, message: "Пристрій успішно додано" }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });
      } catch (err) {
        return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: corsHeaders });
      }
    }

    // 4.1 Get User Computers
    if ((url.pathname === "/api/user/computers" || url.pathname === "/api/devices") && request.method === "GET") {
      try {
        const userId = url.searchParams.get("userId");
        if (!userId) {
          return new Response(JSON.stringify({ error: "Missing userId" }), { status: 400, headers: corsHeaders });
        }

        // LEFT JOIN: show linked devices even if the computers row is missing/stale
        const res = await executeSql(env, `
          SELECT uc.computer_id AS link_id, uc.custom_name, c.*
          FROM users_computers uc
          LEFT JOIN computers c ON (uc.computer_id = c.id OR uc.computer_id = c.hwid OR uc.computer_id = c.code)
          WHERE uc.user_id = ?;
        `, [userId]);

        const computers = (res.results || []).map(c => {
          const lastSeen = c.last_seen ? new Date(c.last_seen).getTime() : 0;
          // Same rule as verify-code: only a fresh last_seen proves the agent is
          // alive. A stale 'status' column must never claim online.
          const isOnline = c.id ? (lastSeen > 0 && (Date.now() - lastSeen < 120000)) : false;
          return {
            id: c.id || c.link_id,
            hwid: c.hwid || c.id || c.link_id,
            code: c.code || c.link_id,
            name: c.custom_name || c.name || "Мій ПК",
            os: c.os_info || "Windows",
            osInfo: c.os_info || "Windows",
            cpu: c.cpu_info || "",
            cpuInfo: c.cpu_info || "",
            gpu: c.gpu || "",
            gpuInfo: c.gpu || "",
            ram: c.ram_info || "",
            ramInfo: c.ram_info || "",
            username: c.username || "Адміністратор",
            status: c.status || "offline",
            isOnline,
            lastSeen
          };
        });

        return new Response(JSON.stringify({ success: true, devices: computers, computers }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });
      } catch (err) {
        return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: corsHeaders });
      }
    }

    // 4.2 Delete User Computer
    if (url.pathname === "/api/devices" && request.method === "DELETE") {
      try {
        const body = await request.json();
        const { userId, computerId, deviceId } = body || {};
        const targetId = computerId || deviceId;
        if (!userId || !targetId) {
          return new Response(JSON.stringify({ success: false, message: "Missing params" }), { status: 400, headers: corsHeaders });
        }

        await executeSql(env, "DELETE FROM users_computers WHERE user_id = ? AND (computer_id = ? OR computer_id LIKE ?);", [userId, targetId, `%${targetId}%`]);
        return new Response(JSON.stringify({ success: true, message: "Пристрій від'єднано" }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
      } catch (err) {
        return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: corsHeaders });
      }
    }

    // 4.3 Rename User Computer
    if ((url.pathname === "/api/devices" || url.pathname === "/api/devices/rename") && request.method === "PATCH") {
      try {
        const body = await request.json();
        const { userId, computerId, deviceId, newName, name, customName } = body || {};
        const targetId = computerId || deviceId;
        const targetName = (newName || name || customName || '').trim();

        if (!userId || !targetId || !targetName) {
          return new Response(JSON.stringify({ success: false, message: "Missing params" }), { status: 400, headers: corsHeaders });
        }

        await executeSql(env, `
          UPDATE users_computers 
          SET custom_name = ? 
          WHERE user_id = ? AND (computer_id = ? OR computer_id LIKE ?);
        `, [targetName, userId, targetId, `%${targetId}%`]);

        return new Response(JSON.stringify({ success: true, message: "Назву оновлено", name: targetName }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
      } catch (err) {
        return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: corsHeaders });
      }
    }

    // 5. License Keys API
    if (url.pathname === "/api/admin/keys" && request.method === "GET") {
      try {
        const res = await executeSql(env, "SELECT * FROM license_keys ORDER BY created_at DESC;");
        const keys = (res.results || []).map(k => ({
          id: k.id,
          keyCode: k.key,
          key: k.key,
          durationType: k.type,
          durationMs: k.duration_ms,
          createdAt: k.created_at,
          expiresAt: k.expires_at,
          isUsed: Boolean(k.used),
          used: Boolean(k.used),
          usedBy: k.used_by_user_id,
          usedByEmail: k.used_by_user_name,
          usedAt: k.used_at
        }));
        return new Response(JSON.stringify({ success: true, keys }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
      } catch (err) {
        return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: corsHeaders });
      }
    }

    if (url.pathname === "/api/admin/keys/generate" && request.method === "POST") {
      try {
        const body = await request.json();
        const { durationType, count = 1 } = body;
        const type = durationType || "30d";
        const durationMs = getDurationMs(type);

        const generated = [];
        for (let i = 0; i < Math.min(Math.max(Number(count) || 1, 1), 50); i++) {
          const keyId = `key_${Math.random().toString(36).substring(2, 10)}`;
          const keyCode = generateLicenseKeyCode();
          const createdAt = Date.now();

          await executeSql(env, `
            INSERT INTO license_keys (id, key, type, duration_ms, created_at, expires_at, used)
            VALUES (?, ?, ?, ?, ?, ?, 0);
          `, [keyId, keyCode, type, durationMs, createdAt, null]);

          generated.push({ id: keyId, keyCode, key: keyCode, durationType: type, durationMs, createdAt, isUsed: false });
        }

        return new Response(JSON.stringify({ success: true, count: generated.length, keys: generated }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });
      } catch (err) {
        return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: corsHeaders });
      }
    }

    if (url.pathname.startsWith("/api/admin/keys/") && request.method === "DELETE") {
      try {
        const id = url.pathname.split("/").pop();
        await executeSql(env, "DELETE FROM license_keys WHERE id = ? OR key = ?;", [id, id]);
        return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
      } catch (err) {
        return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: corsHeaders });
      }
    }

    // 5.1 Activate Key
    if (url.pathname === "/api/license/activate" && request.method === "POST") {
      try {
        const body = await request.json();
        const userId = String(body.userId || '').trim();
        const rawKey = String(body.keyCode || body.key || '').trim().toUpperCase();

        if (!userId || !rawKey) {
          return new Response(JSON.stringify({ success: false, message: "Вкажіть ID користувача та ліцензійний ключ" }), { status: 400, headers: corsHeaders });
        }

        const keyRes = await executeSql(env, "SELECT * FROM license_keys WHERE key = ? LIMIT 1;", [rawKey]);
        const foundKey = keyRes.results?.[0];

        if (!foundKey) {
          return new Response(JSON.stringify({ success: false, message: "Ліцензійний ключ не знайдено або він недійсний" }), { status: 404, headers: corsHeaders });
        }

        if (foundKey.used) {
          return new Response(JSON.stringify({ success: false, message: "Цей ключ вже був активований раніше" }), { status: 400, headers: corsHeaders });
        }

        const userRes = await executeSql(env, "SELECT * FROM users WHERE id = ? LIMIT 1;", [userId]);
        const user = userRes.results?.[0];

        if (!user) {
          return new Response(JSON.stringify({ success: false, message: "Користувача не знайдено" }), { status: 404, headers: corsHeaders });
        }

        const now = Date.now();
        let newExpiresAt = null;

        if (foundKey.type === 'lifetime' || foundKey.duration_ms === 0) {
          newExpiresAt = -1;
        } else {
          const currentExpiry = user.subscription_expires_at && user.subscription_expires_at > now 
            ? user.subscription_expires_at 
            : now;
          newExpiresAt = currentExpiry + foundKey.duration_ms;
        }

        await executeSql(env, "UPDATE license_keys SET used = 1, used_by_user_id = ?, used_by_user_name = ?, used_at = ? WHERE id = ?;", [user.id, user.email, now, foundKey.id]);
        await executeSql(env, "UPDATE users SET subscription_expires_at = ? WHERE id = ?;", [newExpiresAt, user.id]);

        return new Response(JSON.stringify({
          success: true,
          message: "Підписку успішно активовано!",
          expiresAt: newExpiresAt,
          durationType: foundKey.type
        }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
      } catch (err) {
        return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: corsHeaders });
      }
    }

    // 5.2 Users Management (Admin)
    if (url.pathname === "/api/admin/users" && request.method === "GET") {
      try {
        const res = await executeSql(env, "SELECT * FROM users ORDER BY created_at DESC;");
        const users = (res.results || []).map(u => ({
          id: u.id,
          email: u.email,
          name: u.name,
          picture: u.picture,
          role: u.role || 'user',
          subscriptionExpiresAt: u.subscription_expires_at,
          createdAt: u.created_at
        }));
        return new Response(JSON.stringify({ success: true, users }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
      } catch (err) {
        return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: corsHeaders });
      }
    }

    if (url.pathname === "/api/admin/users/role" && request.method === "POST") {
      try {
        const body = await request.json();
        const { userId, role, subscriptionExpiresAt } = body;
        if (!userId) return new Response(JSON.stringify({ error: "Missing userId" }), { status: 400, headers: corsHeaders });

        await executeSql(env, "UPDATE users SET role = ?, subscription_expires_at = ? WHERE id = ?;", [role, subscriptionExpiresAt, userId]);
        return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
      } catch (err) {
        return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: corsHeaders });
      }
    }

    // 6. Device Auth Session API (backed by D1 auth_sessions)
    if (url.pathname === "/api/auth/device-session/create" && request.method === "POST") {
      try {
        const body = await request.json();
        const computerName = body.computerName || "Комп'ютер";
        const hwid = body.hwid || "";
        const code = body.code || "";
        const token = `auth_req_${Math.random().toString(36).substring(2, 10)}${Date.now().toString(36)}`;
        const now = Date.now();
        const expiresAt = now + 15 * 60 * 1000;

        await executeSql(env, `
          INSERT INTO auth_sessions (token, computer_name, hwid, code, status, created_at, expires_at)
          VALUES (?, ?, ?, ?, 'pending', ?, ?);
        `, [token, computerName, hwid, code, now, expiresAt]);

        return new Response(JSON.stringify({
          success: true,
          token,
          authUrl: `https://fluxcontrol.pages.dev/auth/device?token=${token}&pc=${encodeURIComponent(computerName)}`
        }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
      } catch (err) {
        return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: corsHeaders });
      }
    }

    if (url.pathname === "/api/auth/device-session/status" && request.method === "GET") {
      try {
        const token = url.searchParams.get("token");
        if (!token) return new Response(JSON.stringify({ error: "Missing token" }), { status: 400, headers: corsHeaders });

        const res = await executeSql(env, "SELECT * FROM auth_sessions WHERE token = ? LIMIT 1;", [token]);
        const session = res.results?.[0];

        if (!session) {
          return new Response(JSON.stringify({ error: "Session not found" }), { status: 404, headers: corsHeaders });
        }

        return new Response(JSON.stringify({
          success: true,
          status: session.status,
          computerName: session.computer_name,
          user: session.user_json ? JSON.parse(session.user_json) : null
        }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
      } catch (err) {
        return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: corsHeaders });
      }
    }

    if (url.pathname === "/api/auth/device-session/approve" && request.method === "POST") {
      try {
        const body = await request.json();
        const { token, userId, user: providedUser, action } = body;

        if (!token) return new Response(JSON.stringify({ error: "Missing token" }), { status: 400, headers: corsHeaders });

        if (action === "reject") {
          await executeSql(env, "UPDATE auth_sessions SET status = 'rejected' WHERE token = ?;", [token]);
          return new Response(JSON.stringify({ success: true, status: "rejected" }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
        }

        let user = providedUser;
        if (!user && userId) {
          const uRes = await executeSql(env, "SELECT * FROM users WHERE id = ? LIMIT 1;", [userId]);
          user = uRes.results?.[0];
        }

        const approvedUser = {
          id: user?.id || userId,
          email: user?.email || "",
          name: user?.name || "Користувач",
          picture: user?.picture || user?.photoURL || "",
          role: user?.role || "user",
          subscriptionExpiresAt: user?.subscriptionExpiresAt !== undefined ? user.subscriptionExpiresAt : (user?.subscription_expires_at ?? null)
        };

        await executeSql(env, `
          UPDATE auth_sessions 
          SET status = 'approved', user_id = ?, user_json = ? 
          WHERE token = ?;
        `, [approvedUser.id, JSON.stringify(approvedUser), token]);

        return new Response(JSON.stringify({ success: true, status: "approved", user: approvedUser }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });
      } catch (err) {
        return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: corsHeaders });
      }
    }

    // 7. Delegate all static assets to env.ASSETS (SPA Fallback)
    if (env.ASSETS) {
      const response = await env.ASSETS.fetch(request);
      if (response.status === 404) {
        const accept = request.headers.get("accept") || "";
        if (accept.includes("text/html") || !url.pathname.includes(".")) {
          return env.ASSETS.fetch(new URL("/", request.url));
        }
      }
      return response;
    }

    return new Response("Not Found", { status: 404 });
  }
};
