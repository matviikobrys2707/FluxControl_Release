import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { User } from '../types';
import { showGlobalToast } from '../utils/toast';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  isAdmin: boolean;
  isSubscribed: boolean;
  /** false = новий/заблокований акаунт: усе, крім профіля, закрито до видачі доступу. */
  hasAccess: boolean;
  subscriptionExpiresAt: number | null | undefined;
  loginWithGoogle: () => void;
  loginWithEmail: (email: string, name?: string) => Promise<boolean>;
  updateProfile: (name: string, photoURL?: string) => void;
  activateKey: (keyCode: string) => Promise<{ success: boolean; message: string }>;
  refreshProfile: () => Promise<void>;
  logout: () => void;
}

const GOOGLE_CLIENT_ID = "991063783947-j503r6e24vndk2i6nl9ba6vpqv7hpsjj.apps.googleusercontent.com";

const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  isAdmin: false,
  isSubscribed: false,
  hasAccess: true,
  subscriptionExpiresAt: null,
  loginWithGoogle: () => {},
  loginWithEmail: async () => false,
  updateProfile: () => {},
  activateKey: async () => ({ success: false, message: '' }),
  refreshProfile: async () => {},
  logout: () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  // Derive admin & subscription status
  const isAdmin = user?.role === 'admin' || (user?.email ? user.email.includes('blazix') : false);

  // Доступ до функціоналу: адміни — завжди; для решти поле accessEnabled
  // віддає сервер. undefined (старі акаунти, кеш без поля) = доступ відкрито,
  // щоб раптовий редеплой не заблокував наявних користувачів.
  const hasAccess = isAdmin || user?.accessEnabled !== false;
  
  const isSubscribed = Boolean(
    isAdmin || 
    user?.subscriptionExpiresAt === -1 || 
    (user?.subscriptionExpiresAt && user.subscriptionExpiresAt > Date.now())
  );

  const subscriptionExpiresAt = isAdmin ? -1 : user?.subscriptionExpiresAt;

  const refreshProfile = useCallback(async () => {
    if (!user?.id && !user?.email) return;
    try {
      // 1. Try Render Backend
      let res = await fetch(`https://fluxcontrol-backend.onrender.com/api/auth/profile?id=${encodeURIComponent(user?.id || '')}&email=${encodeURIComponent(user?.email || '')}`, {
        signal: AbortSignal.timeout(3500)
      }).catch(() => null);

      // 2. Try local Pages fallback
      if (!res || !res.ok) {
        res = await fetch(`/api/auth/profile?id=${encodeURIComponent(user?.id || '')}&email=${encodeURIComponent(user?.email || '')}`, {
          signal: AbortSignal.timeout(3500)
        }).catch(() => null);
      }

      if (res && res.ok && String(res.headers.get('content-type') || '').includes('application/json')) {
        const data = await res.json();
        if (data.success && data.user) {
          const updated: User = {
            ...user,
            ...data.user,
            role: data.user.role || (data.user.email?.includes('blazix') ? 'admin' : user.role || 'user'),
            subscriptionExpiresAt: data.user.subscriptionExpiresAt
          };
          setUser(updated);
          localStorage.setItem('fluxcontrol_user', JSON.stringify(updated));
        }
      }
    } catch (e) {
      console.warn('[AuthContext] Refresh profile notice:', e);
    }
  }, [user?.id, user?.email]);

  useEffect(() => {
    // 1. Check local storage
    const saved = localStorage.getItem('fluxcontrol_user');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.id && !parsed.isDemo && parsed.id !== 'usr_flux_demo') {
          if (parsed.email?.includes('blazix')) {
            parsed.role = 'admin';
          }
          setUser(parsed);
        } else {
          localStorage.removeItem('fluxcontrol_user');
          setUser(null);
        }
      } catch {
        localStorage.removeItem('fluxcontrol_user');
        setUser(null);
      }
    } else {
      setUser(null);
    }
    setLoading(false);

    // 2. Load Google Identity Services script
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.defer = true;
    document.head.appendChild(script);

    return () => {
      if (document.head.contains(script)) {
        document.head.removeChild(script);
      }
    };
  }, []);

  // Periodic profile refresh to keep subscription & role synced. The profile
  // changes rarely (license activation, role edits), so a 30s cadence is plenty
  // and stops hammering the backend every 5 seconds.
  useEffect(() => {
    if (user?.id || user?.email) {
      refreshProfile();
      const interval = setInterval(refreshProfile, 30000);
      return () => clearInterval(interval);
    }
  }, [user?.id, user?.email, refreshProfile]);

  const syncUserToBackend = async (userData: User) => {
    try {
      const payload = {
        user: {
          sub: userData.id,
          id: userData.id,
          uid: userData.id,
          email: userData.email,
          name: userData.name,
          displayName: userData.name,
          picture: userData.photoURL || userData.picture || '',
          photoURL: userData.photoURL || userData.picture || '',
          role: userData.role || (userData.email?.includes('blazix') ? 'admin' : 'user'),
          subscriptionExpiresAt: userData.subscriptionExpiresAt
        }
      };

      // Sync with Render Backend directly
      try {
        const res = await fetch('https://fluxcontrol-backend.onrender.com/api/auth/google', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        if (res.ok) {
          const data = await res.json();
          if (data.user) {
            setUser(prev => prev ? { ...prev, ...data.user } : data.user);
          }
        }
      } catch {}

      // Sync with Cloudflare Pages / D1
      try {
        await fetch('/api/auth/google', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      } catch {}
    } catch (e) {
      console.warn('[AuthContext] Backend sync notice:', e);
    }
  };

  const loginWithGoogle = () => {
    const google = (window as any).google;
    if (!google?.accounts?.oauth2) {
      showGlobalToast("Сервіс авторизації Google завантажується. Будь ласка, зачекайте 1-2 секунди або оновіть сторінку.");
      return;
    }

    try {
      const client = google.accounts.oauth2.initTokenClient({
        client_id: GOOGLE_CLIENT_ID,
        scope: 'https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email',
        callback: async (tokenResp: any) => {
          if (tokenResp.access_token) {
            try {
              const res = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
                headers: { Authorization: `Bearer ${tokenResp.access_token}` }
              });
              const data = await res.json();
              const isDefaultAdmin = Boolean(data.email && (data.email.includes('blazix') || data.email.includes('admin@')));
              const newUser: User = {
                id: data.sub || `usr_${Date.now()}`,
                email: data.email,
                name: data.name || data.given_name || data.email.split('@')[0],
                photoURL: data.picture,
                picture: data.picture,
                role: isDefaultAdmin ? 'admin' : 'user',
                subscriptionExpiresAt: isDefaultAdmin ? -1 : null,
                createdAt: new Date().toISOString(),
                isDemo: false,
              };
              setUser(newUser);
              localStorage.setItem('fluxcontrol_user', JSON.stringify(newUser));
              await syncUserToBackend(newUser);
            } catch (err) {
              console.error('[AuthContext] Failed to fetch Google profile:', err);
            }
          }
        }
      });
      client.requestAccessToken({ prompt: 'select_account' });
    } catch (err) {
      console.error('[AuthContext] Google auth initialization error:', err);
    }
  };

  const loginWithEmail = async (email: string, name?: string): Promise<boolean> => {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@')) return false;

    // 1. Try local/Pages endpoint
    try {
      const res = await fetch('/api/auth/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: cleanEmail, name: name?.trim() })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.user) {
          const loggedUser: User = {
            id: data.user.id,
            email: data.user.email,
            name: data.user.name,
            photoURL: data.user.picture || '',
            picture: data.user.picture || '',
            role: data.user.role || (cleanEmail.includes('blazix') ? 'admin' : 'user'),
            subscriptionExpiresAt: data.user.subscriptionExpiresAt,
            createdAt: new Date().toISOString(),
            isDemo: false
          };
          setUser(loggedUser);
          localStorage.setItem('fluxcontrol_user', JSON.stringify(loggedUser));
          await syncUserToBackend(loggedUser);
          return true;
        }
      }
    } catch (e) {}

    // 2. Try Render relay backend
    try {
      const res = await fetch('https://fluxcontrol-backend.onrender.com/api/auth/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: cleanEmail, name: name?.trim() })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.user) {
          const loggedUser: User = {
            id: data.user.id,
            email: data.user.email,
            name: data.user.name,
            photoURL: data.user.picture || '',
            picture: data.user.picture || '',
            role: data.user.role || (cleanEmail.includes('blazix') ? 'admin' : 'user'),
            subscriptionExpiresAt: data.user.subscriptionExpiresAt,
            createdAt: new Date().toISOString(),
            isDemo: false
          };
          setUser(loggedUser);
          localStorage.setItem('fluxcontrol_user', JSON.stringify(loggedUser));
          await syncUserToBackend(loggedUser);
          return true;
        }
      }
    } catch (e) {}

    return false;
  };

  const activateKey = async (keyCode: string): Promise<{ success: boolean; message: string }> => {
    if (!user) {
      return { success: false, message: 'Будь ласка, увійдіть у свій акаунт перед активацією' };
    }

    const clean = keyCode.trim().toUpperCase();
    if (!clean) {
      return { success: false, message: 'Введіть ліцензійний ключ' };
    }

    const payload = { userId: user.id, keyCode: clean };

    // 1. Try Render Backend
    try {
      const res = await fetch('https://fluxcontrol-backend.onrender.com/api/license/activate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.success) {
        await refreshProfile();
        return { success: true, message: data.message || 'Підписку успішно активовано!' };
      }
      if (res.status === 400 || res.status === 404) {
        return { success: false, message: data.message || 'Ключ недійсний' };
      }
    } catch {}

    // 2. Try Pages fallback
    try {
      const res = await fetch('/api/license/activate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.success) {
        await refreshProfile();
        return { success: true, message: data.message || 'Підписку успішно активовано!' };
      }
      return { success: false, message: data.message || 'Ключ недійсний або сталася помилка' };
    } catch {}

    return { success: false, message: 'Помилка зв\'язку із сервером активації' };
  };

  const updateProfile = (name: string, photoURL?: string) => {
    if (!user) return;
    const updated = {
      ...user,
      name,
      photoURL: photoURL || user.photoURL,
      picture: photoURL || user.picture
    };
    setUser(updated);
    localStorage.setItem('fluxcontrol_user', JSON.stringify(updated));
    syncUserToBackend(updated);
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('fluxcontrol_user');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        isAdmin,
        isSubscribed,
        hasAccess,
        subscriptionExpiresAt,
        loginWithGoogle,
        loginWithEmail,
        updateProfile,
        activateKey,
        refreshProfile,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
