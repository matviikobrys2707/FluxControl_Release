import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Device } from '../types';
import { useAuth } from './AuthContext';

interface DeviceContextType {
  devices: Device[];
  loading: boolean;
  /** True once the first device-list fetch attempt for the current user finished.
   *  Direct-link flows must wait for it before deciding a device is missing. */
  devicesReady: boolean;
  selectedDevice: Device | null;
  setSelectedDevice: (device: Device | null) => void;
  refreshDevices: () => Promise<void>;
  addDevice: (code: string, customName: string, specs?: any) => Promise<{ success: boolean; error?: string }>;
  removeDevice: (deviceId: string) => Promise<void>;
  renameDevice: (deviceId: string, newName: string) => Promise<{ success: boolean }>;
  verifyCode: (code: string) => Promise<{ success: boolean; data?: any; message?: string }>;
  updateDeviceStatus: (deviceId: string, state: NonNullable<Device['connectionState']>) => void;
}

const DeviceContext = createContext<DeviceContextType>({
  devices: [],
  loading: false,
  devicesReady: false,
  selectedDevice: null,
  setSelectedDevice: () => {},
  refreshDevices: async () => {},
  addDevice: async () => ({ success: false }),
  removeDevice: async () => {},
  renameDevice: async () => ({ success: false }),
  verifyCode: async () => ({ success: false }),
  updateDeviceStatus: () => {},
});

export const DeviceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading: authLoading } = useAuth();
  const STATUS_GRACE_MS = 12_000;
  
  // Clean initialization: purge any legacy mock devices (e.g. FLUX-9842-PC, FLUX-HOME-PC)
  const [devices, setDevices] = useState<Device[]>(() => {
    const saved = localStorage.getItem('fluxcontrol_devices');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const clean = parsed.filter(d => 
            d.id !== 'FLUX-9842-PC' && 
            d.id !== 'FLUX-HOME-PC' && 
            d.code !== 'FLUX-9842-PC' && 
            d.code !== 'FLUX-HOME-PC' &&
            !d.id?.includes('Flux-9842')
          );
          return clean;
        }
      } catch { }
    }
    return [];
  });

  const [loading, setLoading] = useState(false);
  const [devicesReady, setDevicesReady] = useState(false);
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('fluxcontrol_devices', JSON.stringify(devices));
  }, [devices]);

  // When the user logs out, clear devices. The authLoading guard is critical:
  // on the very first mount AuthContext has not restored the saved user yet,
  // and without it this effect wiped the locally stored device list on every
  // page reload before the user was restored.
  useEffect(() => {
    if (!authLoading && !user) {
      setDevices([]);
      setSelectedDevice(null);
      setDevicesReady(false);
    }
  }, [user, authLoading]);

  // Персональні назви ПК: localStorage-оверлей `${userId}||${deviceId}` → name.
  // Гарантує, що перейменування НІКОЛИ не відкочується, навіть поки на Render
  // ще не задеплоєний виправлений бекенд (server.js 5.7.0), і переживає F5.
  const customNamesKey = (userId?: string) => `fluxcontrol_custom_names_${userId || 'anon'}`;
  const readCustomNames = (userId?: string): Record<string, string> => {
    if (!userId) return {};
    try {
      const raw = localStorage.getItem(customNamesKey(userId));
      const parsed = raw ? JSON.parse(raw) : {};
      return parsed && typeof parsed === 'object' ? parsed : {};
    } catch { return {}; }
  };
  const writeCustomName = (userId: string | undefined, deviceId: string, name: string) => {
    if (!userId) return;
    try {
      const all = readCustomNames(userId);
      all[deviceId] = name;
      // однаковий deviceId під різними ключами (id/code) — пишемо обидва
      localStorage.setItem(customNamesKey(userId), JSON.stringify(all));
    } catch {}
  };

  // Merge server devices with local ones so freshly-added devices never
  // disappear while the backend/database is still catching up.
  const updateDeviceStatus = useCallback((deviceId: string, state: NonNullable<Device['connectionState']>) => {
    const now = Date.now();
    const matches = (device: Device) => device.id === deviceId || device.code === deviceId;
    const online = state === 'online' || state === 'connected' || state === 'degraded';
    const apply = (device: Device) => matches(device) ? { ...device, isOnline: online, connectionState: state, statusUpdatedAt: now, lastSeen: online ? now : device.lastSeen } : device;
    setDevices(current => current.map(apply));
    setSelectedDevice(current => current && matches(current) ? apply(current) : current);
  }, []);

  const mergeWithLocal = (serverDevices: Device[]) => {
    const custom = readCustomNames(user?.id);
    setDevices(prev => {
      const merged = new Map<string, Device>();
      const keyOf = (d: Device) => String(d.id || d.code || '').toUpperCase();
      const codeOf = (d: Device) => String(d.code || '').toUpperCase();

      for (const d of prev) {
        if (keyOf(d)) merged.set(keyOf(d), d);
        if (codeOf(d) && codeOf(d) !== keyOf(d)) merged.set(codeOf(d), d);
      }

      const result: Device[] = [];
      for (const sd of serverDevices) {
        const local = merged.get(keyOf(sd)) || (codeOf(sd) ? merged.get(codeOf(sd)) : undefined);
        const locallyConfirmed = local &&
          ['online', 'connected', 'degraded'].includes(local.connectionState || '') &&
          Date.now() - Number(local.statusUpdatedAt || 0) < STATUS_GRACE_MS;
        // A recent live reply beats a late REST response once. After the grace
        // period, REST becomes authoritative again and can mark the device off.
        const keepLiveStatus = Boolean(locallyConfirmed && !sd.isOnline);
        // Персональна назва: локальний оверлей → локальний стан → сервер.
        // Серверна назва НЕ МОЖЕ перетерти перейменування користувача.
        const serverName = String(sd.name || '');
        const mergedName = custom[String(sd.id)] || custom[String(sd.code || '')] || local?.name || serverName;
        result.push({
          ...local,
          ...sd,
          name: mergedName || serverName,
          isOnline: keepLiveStatus ? true : sd.isOnline,
          connectionState: keepLiveStatus ? local!.connectionState : (sd.isOnline ? 'online' : 'offline'),
          statusUpdatedAt: keepLiveStatus ? local!.statusUpdatedAt : Date.now()
        });
        if (keyOf(sd)) merged.delete(keyOf(sd));
        if (codeOf(sd)) merged.delete(codeOf(sd));
      }

      // Keep devices that the server does not know about yet (just added).
      // The same local device can sit in the map under both its id and code —
      // deduplicate by object identity so it is never rendered twice.
      const seenObjects = new Set<Device>();
      for (const d of merged.values()) {
        if (seenObjects.has(d)) continue;
        seenObjects.add(d);
        result.push(d);
      }
      return result;
    });
  };

  const refreshDevices = useCallback(async () => {
    if (!user?.id) {
      setDevices([]);
      return;
    }

    // Direct-link auto-add (and any similar flow) needs to know whether the
    // list we are looking at already reflects the server — mark readiness on
    // the FIRST completed attempt, success or not.
    let ready = false;

    // 1. Try Render relay backend first (live online status)
    try {
      const res = await fetch(`https://fluxcontrol-backend.onrender.com/api/devices?userId=${encodeURIComponent(user.id)}`, {
        signal: AbortSignal.timeout(4000)
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.devices)) {
          mergeWithLocal(data.devices);
          ready = true;
        }
      }
    } catch {}

    // 2. Fallback to Cloudflare Pages D1
    if (!ready) {
      try {
        const res = await fetch(`/api/devices?userId=${encodeURIComponent(user.id)}`, {
          signal: AbortSignal.timeout(4000)
        });
        if (res.ok && String(res.headers.get('content-type') || '').includes('application/json')) {
          const data = await res.json();
          if (data.success && Array.isArray(data.devices)) {
            mergeWithLocal(data.devices);
            ready = true;
          }
        }
      } catch (e) {
        console.warn('[DeviceContext] Refresh devices notice:', e);
      }
    }

    // The attempt itself counts as ready — a dead network must not block the
    // direct-link modal forever (the merge keeps local devices anyway).
    setDevicesReady(true);
  }, [user?.id]);

  useEffect(() => {
    if (user?.id) {
      refreshDevices();
      const interval = setInterval(refreshDevices, 8000);
      return () => clearInterval(interval);
    }
  }, [user?.id, refreshDevices]);

  // Real device verification via API
  const verifyCode = async (code: string) => {
    const cleanCode = code.replace(/[^A-Za-z0-9]/g, '').trim().toUpperCase();
    if (!cleanCode) {
      return { success: false, message: 'Будь ласка, введіть 16-значний код підключення' };
    }

    // Render relay owns the live agent socket. Pages/D1 is metadata fallback.
    try {
      const res = await fetch(`https://fluxcontrol-backend.onrender.com/api/devices/verify-code?code=${encodeURIComponent(cleanCode)}`, {
        signal: AbortSignal.timeout(4000)
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.data?.isOnline) {
          return { success: true, data: data.data };
        }
      }
    } catch {}

    // Metadata fallback can only confirm a positive live answer, never invent it.
    try {
      const res = await fetch(`/api/devices/verify-code?code=${encodeURIComponent(cleanCode)}`, {
        signal: AbortSignal.timeout(4000)
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.data?.isOnline) {
          return { success: true, data: data.data };
        }
      }
    } catch {}

    // No simulation! Honestly inform user that code was not found
    return {
      success: false,
      message: 'Комп\'ютер з таким кодом не знайдено або він офлайн. Переконайтеся, що програма FluxControl запущена на ПК.'
    };
  };

  const addDevice = async (code: string, customName: string, specs?: any) => {
    const cleanCode = code.replace(/[^A-Za-z0-9]/g, '').trim().toUpperCase();
    const name = customName.trim() || specs?.name || 'Мій ПК';

    if (!cleanCode) {
      return { success: false, error: 'Введіть код підключення з програми FluxControl' };
    }

    const computerId = specs?.hwid || cleanCode;
    const newDevice: Device = {
      id: computerId,
      code: cleanCode,
      name: name,
      osInfo: specs?.osInfo || specs?.os || 'Windows 11',
      cpuInfo: specs?.cpuInfo || specs?.cpu || 'Процесор',
      gpuInfo: specs?.gpuInfo || specs?.gpu || '',
      ramInfo: specs?.ramInfo || specs?.ram || '',
      isOnline: specs?.isOnline ?? false,
      connectionState: specs?.isOnline ? 'online' : 'offline',
      lastSeen: Date.now(),
      lanIp: '',
      wanIp: '',
      ip: ''
    };

    setDevices(prev => {
      const filtered = prev.filter(d => d.id !== computerId && d.code !== cleanCode);
      return [newDevice, ...filtered];
    });

    // Save to user_computers in Cloudflare Pages D1 & Render
    if (user?.id) {
      const payload = {
        userId: user.id,
        computerId: computerId,
        connectionCode: cleanCode,
        customName: name
      };

      try {
        await fetch('/api/devices', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      } catch {}

      try {
        await fetch('https://fluxcontrol-backend.onrender.com/api/devices', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      } catch {}
    }

    return { success: true };
  };

  const removeDevice = async (deviceId: string) => {
    setDevices(prev => prev.filter(d => d.id !== deviceId && d.code !== deviceId));
    if (selectedDevice?.id === deviceId || selectedDevice?.code === deviceId) {
      setSelectedDevice(null);
    }

    if (user?.id) {
      const payload = { userId: user.id, computerId: deviceId };
      try {
        await fetch('/api/devices', {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      } catch {}

      try {
        await fetch('https://fluxcontrol-backend.onrender.com/api/devices', {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      } catch {}
    }
  };

  const renameDevice = async (deviceId: string, newName: string) => {
    const trimmed = newName.trim();
    if (!trimmed) return { success: false };

    setDevices(prev => prev.map(d => (d.id === deviceId || d.code === deviceId) ? { ...d, name: trimmed } : d));
    if (selectedDevice && (selectedDevice.id === deviceId || selectedDevice.code === deviceId)) {
      setSelectedDevice({ ...selectedDevice, name: trimmed });
    }

    // Оверлей імен: переживає F5, refresh-цикли та старий бекенд.
    if (user?.id) {
      writeCustomName(user.id, deviceId, trimmed);
    }

    if (user?.id) {
      const payload = { userId: user.id, computerId: deviceId, newName: trimmed };
      try {
        await fetch('/api/devices/rename', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      } catch {}

      try {
        await fetch('https://fluxcontrol-backend.onrender.com/api/devices/rename', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      } catch {}
    }

    return { success: true };
  };

  return (
    <DeviceContext.Provider
      value={{
        devices,
        loading,
        devicesReady,
        selectedDevice,
        setSelectedDevice,
        refreshDevices,
        addDevice,
        removeDevice,
        renameDevice,
        verifyCode,
        updateDeviceStatus
      }}
    >
      {children}
    </DeviceContext.Provider>
  );
};

export const useDevices = () => useContext(DeviceContext);
