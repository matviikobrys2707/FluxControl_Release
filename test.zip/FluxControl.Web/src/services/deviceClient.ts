/**
 * FluxControl Live Remote Device Client Service
 * Pure WebSocket communication with real desktop agents via Render Relay & Direct sockets.
 * No fake data or mock hardware simulation.
 */

import { DeviceMetrics, ProcessItem, FileItem, FileDirectoryListing } from '../types';

type EventCallback = (data: any) => void;

class DeviceClientService {
  private ws: WebSocket | null = null;
  private listeners: Map<string, Set<EventCallback>> = new Map();
  public currentCode: string = '';
  private reconnectTimer: any = null;
  public shouldReconnect: boolean = false;
  private customWsUrl: string = '';

  connect(code: string, customUrl?: string) {
    this.currentCode = code.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
    this.customWsUrl = customUrl || '';
    this.shouldReconnect = true;

    // A pending reconnect timer from a previous session must never fire on top
    // of the fresh connection — otherwise the socket gets torn down and
    // duplicated a few seconds later.
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }

    this._doConnect();
  }

  private _doConnect() {
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      this.ws.close();
    }

    // Connect to Render relay or direct tunnel
    let wsUrl = this.customWsUrl;
    if (!wsUrl) {
      wsUrl = `wss://fluxcontrol-backend.onrender.com/ws?role=client&code=${encodeURIComponent(this.currentCode)}`;
    } else if (!wsUrl.startsWith('ws://') && !wsUrl.startsWith('wss://')) {
      wsUrl = wsUrl.replace('https://', 'wss://').replace('http://', 'ws://');
      if (!wsUrl.includes('/ws')) {
        wsUrl = `${wsUrl.replace(/\/+$/, '')}/ws?role=client&code=${encodeURIComponent(this.currentCode)}`;
      }
    }

    try {
      const socket = new WebSocket(wsUrl);
      this.ws = socket;

      socket.onopen = () => {
        // Ignore a late open from a socket that was already replaced.
        if (this.ws !== socket) return;
        this.emit('connected', { success: true });
        // Request initial live state.
        // ВАЖЛИВО: camera_list/volume_get запитуються і тут — вызовы из
        // mount-эффектов компонентов часто уходят ДО открытия сокета и
        // молча терялись (плитка камеры не видела список камер).
        this.send('ping', {});
        this.send('process_list', {});
        this.send('fs_drives', {});
        this.send('get_network_info', {});
        this.send('camera_list', {});
        this.send('volume_get', {});
      };

      socket.onmessage = async (event) => {
        try {
          let rawText = '';
          if (typeof event.data === 'string') {
            rawText = event.data;
          } else if (event.data instanceof Blob) {
            rawText = await event.data.text();
          } else if (event.data instanceof ArrayBuffer) {
            rawText = new TextDecoder().decode(event.data);
          } else if (event.data && typeof event.data.toString === 'function') {
            rawText = event.data.toString();
          }

          if (!rawText) return;
          const data = JSON.parse(rawText);
          if (data && data.type) {
            // Unpack payload if nested in data property
            const payload = data.data !== undefined ? data.data : data;
            this.emit(data.type, payload);

            // Forward telemetry to metrics listener
            if (data.type === 'telemetry') {
              this.emit('metrics', payload);
            }
          }
        } catch (e) {
          console.error('[DeviceClient] JSON parse error:', e);
        }
      };

      socket.onerror = (err) => {
        this.emit('error', err);
      };

      socket.onclose = () => {
        // Only the active socket may trigger reconnection bookkeeping; a stale
        // replaced socket closing must not fire duplicate events or timers.
        if (this.ws !== socket) return;
        this.ws = null;
        this.emit('disconnected', {});
        if (this.shouldReconnect) {
          if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
          this.reconnectTimer = setTimeout(() => {
            this.reconnectTimer = null;
            if (this.shouldReconnect) this._doConnect();
          }, 3500);
        }
      };
    } catch (e) {
      this.emit('error', e);
    }
  }

  disconnect() {
    this.shouldReconnect = false;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.emit('disconnected', {});
  }

  send(type: string, payload: any = {}) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type, ...payload }));
    }
  }

  // File system live actions
  requestDrives() {
    this.send('fs_drives', {});
  }

  requestDirectory(path: string) {
    this.send('fs_list', { path });
  }

  readFile(path: string) {
    this.send('fs_read_file', { path });
  }

  saveFile(path: string, content: string) {
    this.send('fs_save_file', { path, content });
  }

  deleteFile(path: string) {
    this.send('fs_delete', { path });
  }

  createFolder(path: string, name: string) {
    this.send('fs_create_folder', { path, name });
  }

  createFile(path: string, name: string) {
    this.send('fs_create_file', { path, name });
  }

  requestFolderSize(path: string) {
    this.send('fs_folder_size', { path });
  }

  downloadFile(path: string) {
    this.send('fs_download_file', { path });
  }

  downloadFolderZip(path: string) {
    this.send('fs_download_folder_zip', { path });
  }

  openFileOnPC(path: string) {
    this.send('fs_open_on_pc', { path });
  }

  renameItem(oldPath: string, newName: string) {
    this.send('fs_rename', { oldPath, newName });
  }

  // Process manager live actions
  requestProcessList() {
    this.send('process_list', {});
  }

  sendKillProcess(pid: number) {
    this.send('process_kill', { pid });
  }

  // Terminal live actions
  sendTerminalInput(input: string) {
    this.send('terminal_input', { data: input });
  }

  killTerminal() {
    this.send('terminal_kill', {});
  }

  // Power actions
  sendPowerAction(action: 'shutdown' | 'restart' | 'sleep' | 'hibernate' | 'lock') {
    this.send('power', { action });
  }

  /** Єдиний таймер: будь-яка дія (вимкнення/перезавантаження/сон/гібернація/блокування). */
  startPowerTimer(action: 'shutdown' | 'restart' | 'sleep' | 'hibernate' | 'lock', seconds: number) {
    this.send('timer_start', { action, seconds });
  }

  cancelPowerTimer() {
    this.send('timer_cancel', {});
  }

  // Input & Media
  sendMouseMove(dx: number, dy: number) {
    this.send('mouse_move', { dx, dy });
  }

  /** AI-агент: абсолютне позиціювання; nx/ny нормалізовані 0..1000 до екрана ПК. */
  sendMouseMoveAbs(nx: number, ny: number) {
    this.send('mouse_move_abs', { nx, ny });
  }

  /** Скриншот із параметрами стиснення (для AI-зору), сумісно зі старим API. */
  captureScreenshotEx(quality = 80, maxWidth = 0) {
    this.send('capture_screenshot', { quality, maxWidth });
  }

  sendMouseClick(button: 'left' | 'right' | 'middle' = 'left', isDouble: boolean = false) {
    this.send('mouse_click', { button, double: isDouble });
  }

  sendMouseDown(button: 'left' | 'right' | 'middle' = 'left') {
    this.send('mouse_down', { button });
  }

  sendMouseUp(button: 'left' | 'right' | 'middle' = 'left') {
    this.send('mouse_up', { button });
  }

  sendMouseScroll(dx: number, dy: number) {
    this.send('mouse_scroll', { dx, dy });
  }

  sendKeyPress(key: string, modifiers: string[] = []) {
    this.send('key_press', { key, modifiers });
  }

  sendText(text: string) {
    this.send('key_text', { text });
  }

  sendMediaControl(command: string) {
    this.send('media_control', { command });
  }

  sendVolume(value: number) {
    this.send('volume', { value });
  }

  captureScreenshot() {
    this.send('capture_screenshot', {});
  }

  startScreenStream(fps = 60, quality = 80, maxWidth = 1920) {
    this.send('screen_stream_start', { fps, quality, maxWidth });
  }

  stopScreenStream() {
    this.send('screen_stream_stop', {});
  }

  sendScreenStreamFeedback(fps: number) {
    this.send('screen_stream_feedback', { fps: Math.max(0, Math.round(fps)) });
  }

  sendPower(action: 'shutdown' | 'restart' | 'sleep' | 'hibernate' | 'lock') {
    this.send('power', { action });
  }

  // ================= WinLock (remote PC lockdown) =================
  sendWinLockLock(mode: 'code' | 'site', code?: string) {
    this.send('winlock_lock', { mode, code });
  }

  sendWinLockUnlock(code?: string) {
    this.send('winlock_unlock', { code });
  }

  sendWinLockGet() {
    this.send('winlock_get', {});
  }

  // ================= Cameras & volume =================
  listCameras() {
    this.send('camera_list', {});
  }

  captureWebcam(camera?: string, delaySeconds?: number) {
    this.send('capture_webcam', { camera, delaySeconds });
  }

  requestVolumeState() {
    this.send('volume_get', {});
  }

  /** direction 'set' uses value; 'up'/'down' use step (default 2). */
  sendVolumeEx(direction: 'set' | 'up' | 'down', value?: number, step?: number) {
    this.send('volume', { direction, value, step });
  }

  sendKeyText(text: string) {
    this.send('key_text', { text });
  }

  sendShortcut(shortcut: string) {
    this.send('shortcut', { shortcut });
  }

  openUrl(url: string) {
    this.send('open_url', { url });
  }

  sendOpenUrl(url: string) {
    this.send('open_url', { url });
  }

  sendPing() {
    this.send('ping', { timestamp: Date.now() });
  }

  on(event: string, callback: EventCallback): () => void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(callback);

    return () => {
      const set = this.listeners.get(event);
      if (set) {
        set.delete(callback);
      }
    };
  }

  emit(event: string, data: any) {
    const set = this.listeners.get(event);
    if (set) {
      set.forEach(cb => {
        try {
          cb(data);
        } catch (err) {
          console.error(`[DeviceClient] Callback error for event ${event}:`, err);
        }
      });
    }
  }

  isOpen(): boolean {
    return this.ws?.readyState === WebSocket.OPEN;
  }
}

export const deviceClient = new DeviceClientService();
