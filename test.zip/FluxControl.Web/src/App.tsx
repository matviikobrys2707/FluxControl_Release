import React, { useState, useEffect, useCallback } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { DeviceProvider, useDevices } from './context/DeviceContext';
import { Navbar } from './components/Navbar';
import { HomePage } from './components/HomePage';
import { DevicesPage } from './components/DevicesPage';
import { GuidePage } from './components/GuidePage';
import { ProfilePage } from './components/ProfilePage';
import { AdminPage } from './components/AdminPage';
import { DeviceAuthPage } from './components/DeviceAuthPage';
import { AgentHostedUiPage } from './components/AgentHostedUiPage';
import { DeviceSessionView } from './components/device/DeviceSessionView';
import { DownloadModal } from './components/DownloadModal';
import { DirectLinkAddModal } from './components/DirectLinkAddModal';
import { RecordingBadge } from './components/device/RecordingBadge';
import { AppRoute, SessionTab, Device } from './types';
import { ShieldAlert, LogOut, KeyRound, MessageCircleQuestion } from 'lucide-react';

/** Екран блокування для нових акаунтів без доступу: тільки профіль/вихід. */
const AccessGateScreen: React.FC<{ onProfile: () => void; onLogout: () => void }> = ({ onProfile, onLogout }) => (
  <div className="min-h-screen w-full flex items-center justify-center px-4 py-10 relative overflow-hidden">
    <div className="fixed top-0 left-1/4 w-[500px] h-[500px] bg-indigo-600/10 rounded-full blur-[140px] pointer-events-none -z-10" />
    <div className="fixed bottom-0 right-1/4 w-[600px] h-[600px] bg-violet-600/10 rounded-full blur-[160px] pointer-events-none -z-10" />

    <div className="w-full max-w-md glass-card rounded-3xl border border-amber-500/25 bg-[#090b14]/95 p-8 text-center shadow-2xl">
      <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-3xl border border-amber-500/30 bg-amber-500/15 text-amber-300">
        <ShieldAlert className="h-8 w-8" />
      </div>
      <h1 className="text-xl font-black text-white tracking-tight">Функціонал поки що обмежено</h1>
      <p className="mt-3 text-[13px] leading-relaxed text-gray-400">
        Ваш акаунт створено, але доступ до керування пристроями ще не відкрито.
        <br />
        <strong className="text-amber-200">Зверніться до адміністратора</strong>, щоб отримати доступ,
        або активуйте ключ доступу у профілі.
      </p>

      <div className="mt-6 space-y-2.5">
        <button
          onClick={onProfile}
          className="flex w-full cursor-pointer items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-indigo-600 to-violet-600 py-3.5 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 transition-all hover:brightness-110 active:scale-[0.98]"
        >
          <KeyRound className="h-4 w-4" />
          <span>Перейти в профіль та активувати ключ</span>
        </button>
        <a
          href="https://t.me/fluxcontrol_support"
          target="_blank"
          rel="noreferrer"
          className="flex w-full items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/5 py-3 text-xs font-semibold text-gray-300 transition-colors hover:bg-white/10 hover:text-white"
        >
          <MessageCircleQuestion className="h-4 w-4" />
          <span>Написати адміністратору</span>
        </a>
        <button
          onClick={onLogout}
          className="flex w-full cursor-pointer items-center justify-center gap-2 rounded-2xl py-2.5 text-[11px] font-semibold text-red-400/80 transition-colors hover:text-red-300"
        >
          <LogOut className="h-3.5 w-3.5" />
          <span>Вийти з акаунта</span>
        </button>
      </div>
    </div>
  </div>
);

function AppContent() {
  const { devices, selectedDevice, setSelectedDevice } = useDevices();
  const { user, hasAccess, logout } = useAuth();
  const gated = Boolean(user && !hasAccess);

  // The initial route MUST be derived from the URL synchronously (lazy
  // initializer). With a hardcoded '/' the agent window and every deep link
  // rendered the home page for one frame before the effect corrected the
  // route — the “главный экран сайта мелькает при запуске” bug.
  const resolveRoute = (pathname: string): AppRoute => {
    if (pathname.startsWith('/agent-ui')) return '/agent-ui';
    if (pathname.startsWith('/auth/device')) return '/auth/device';
    if (pathname === '/admin') return '/admin';
    if (pathname === '/profile') return '/profile';
    if (pathname === '/guide') return '/guide';
    if (pathname === '/devices' || pathname.startsWith('/device/')) return '/devices';
    return '/';
  };

  const [currentRoute, setCurrentRoute] = useState<AppRoute>(() => resolveRoute(window.location.pathname));
  const [activeSessionTab, setActiveSessionTab] = useState<SessionTab>(() => {
    const parts = window.location.pathname.split('/').filter(Boolean);
    return parts[0] === 'device' && parts[2] ? (parts[2] as SessionTab) : 'info';
  });
  const [downloadModalOpen, setDownloadModalOpen] = useState(false);

  // Parse path and query parameters
  const parseCurrentUrl = useCallback(() => {
    const pathname = window.location.pathname;

    if (pathname.startsWith('/agent-ui')) {
      setCurrentRoute('/agent-ui');
      return;
    }

    if (pathname.startsWith('/auth/device')) {
      setCurrentRoute('/auth/device');
      return;
    }

    if (pathname === '/admin') {
      setCurrentRoute('/admin');
      setSelectedDevice(null);
      return;
    }

    if (pathname === '/profile') {
      setCurrentRoute('/profile');
      setSelectedDevice(null);
      return;
    }

    if (pathname === '/guide') {
      setCurrentRoute('/guide');
      setSelectedDevice(null);
      return;
    }

    if (pathname === '/devices') {
      setCurrentRoute('/devices');
      setSelectedDevice(null);
      return;
    }

    // Check device direct link: /device/:id/:tab?
    if (pathname.startsWith('/device/')) {
      const parts = pathname.split('/').filter(Boolean);
      // parts[0] = 'device', parts[1] = deviceId/code, parts[2] = tab (optional)
      const deviceId = parts[1];
      const tabName = (parts[2] as SessionTab) || 'info';

      if (deviceId) {
        // Re-running this parser on every devices-list refresh must NOT
        // rebuild the placeholder: that wiped the live online status the
        // running session had just reported (navbar Offline while the
        // session worked). Only resolve the device when it actually differs.
        const currentMatches = selectedDevice &&
          (selectedDevice.id === deviceId || selectedDevice.code === deviceId);
        if (!currentMatches) {
          const found = devices.find(d => d.id === deviceId || d.code === deviceId);
          if (found) {
            setSelectedDevice(found);
          } else {
            setSelectedDevice({
              id: deviceId,
              code: deviceId,
              name: `ПК ${deviceId.slice(0, 4)}`,
              // A device from a bare link is NOT proven online until the live
              // session confirms it — never seed fake “online” states.
              isOnline: false
            });
          }
        }
        setActiveSessionTab(tabName);
        setCurrentRoute('/devices');
        return;
      }
    }

    setCurrentRoute('/');
    setSelectedDevice(null);
  }, [devices, selectedDevice, setSelectedDevice]);

  // Initial URL parsing
  useEffect(() => {
    parseCurrentUrl();
  }, [parseCurrentUrl]);

  // Listen to browser Back/Forward navigation
  useEffect(() => {
    const handlePopState = () => {
      parseCurrentUrl();
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [parseCurrentUrl]);

  // Navigate to top-level routes
  const handleNavigate = (route: AppRoute) => {
    setSelectedDevice(null);
    setCurrentRoute(route);
    try {
      window.history.pushState(null, '', route);
    } catch {
      window.location.hash = route;
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Connect to device & update URL
  const handleSelectDevice = (device: Device, initialTab: SessionTab = 'info') => {
    setSelectedDevice(device);
    setActiveSessionTab(initialTab);
    const targetUrl = `/device/${device.code || device.id}/${initialTab}`;
    try {
      window.history.pushState(null, '', targetUrl);
    } catch {}
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Change tab inside active device session & sync URL
  const handleSessionTabChange = (tab: SessionTab) => {
    setActiveSessionTab(tab);
    if (selectedDevice) {
      const targetUrl = `/device/${selectedDevice.code || selectedDevice.id}/${tab}`;
      try {
        window.history.pushState(null, '', targetUrl);
      } catch {}
    }
  };

  // Disconnect active session
  const handleDisconnectSession = () => {
    setSelectedDevice(null);
    handleNavigate('/devices');
  };

  const [sessionConnectState, setSessionConnectState] = useState<'connecting' | 'connected' | 'error'>('connecting');

  // Dedicated full-screen route for Desktop Agent Hosted UI
  if (currentRoute === '/agent-ui') {
    return <AgentHostedUiPage />;
  }

  // Dedicated route for Desktop Auth Approval
  if (currentRoute === '/auth/device') {
    return <DeviceAuthPage onNavigate={handleNavigate} />;
  }

  // Гейт доступу: заблокований акаунт бачить тільки екран-попередження або профіль.
  if (gated) {
    if (currentRoute === '/profile') {
      return (
        <div className="relative min-h-screen flex flex-col bg-[#050508] text-gray-100 font-sans selection:bg-indigo-600 selection:text-white overflow-x-hidden">
          <Navbar
            currentRoute={currentRoute}
            onNavigate={handleNavigate}
            activeDevice={null}
            activeSessionTab={activeSessionTab}
            onSessionTabChange={handleSessionTabChange}
            onDisconnectSession={handleDisconnectSession}
            onDownloadClient={() => setDownloadModalOpen(true)}
            gated
          />
          <main className="flex-1 flex flex-col">
            <ProfilePage
              onNavigate={handleNavigate}
              onDownloadClient={() => setDownloadModalOpen(true)}
            />
          </main>
        </div>
      );
    }
    return (
      <div className="min-h-screen bg-[#050508] text-gray-100 font-sans">
        <AccessGateScreen onProfile={() => handleNavigate('/profile')} onLogout={logout} />
      </div>
    );
  }

  // The top navigation pill is hidden only while a connection attempt is in
  // progress (the session view has its own header with the same controls).
  const shouldShowNavbar = !selectedDevice || sessionConnectState === 'connected';

  return (
    <div className="min-h-screen flex flex-col bg-[#050508] text-gray-100 font-sans selection:bg-indigo-600 selection:text-white relative overflow-x-hidden">

      {/* Subtle Ambiance Glow Backdrops */}
      <div className="fixed top-0 left-1/4 w-[500px] h-[500px] bg-indigo-600/10 rounded-full blur-[140px] pointer-events-none -z-10" />
      <div className="fixed bottom-0 right-1/4 w-[600px] h-[600px] bg-violet-600/10 rounded-full blur-[160px] pointer-events-none -z-10" />

      {/* Global Navigation Bar - Hidden during connection attempt */}
      {shouldShowNavbar && (
        <Navbar
          currentRoute={currentRoute}
          onNavigate={handleNavigate}
          activeDevice={selectedDevice}
          activeSessionTab={activeSessionTab}
          onSessionTabChange={handleSessionTabChange}
          onDisconnectSession={handleDisconnectSession}
          onDownloadClient={() => setDownloadModalOpen(true)}
        />
      )}

      {/* Main View Area */}
      <main className="flex-1 flex flex-col">
        {selectedDevice ? (
          <DeviceSessionView
            device={selectedDevice}
            activeTab={activeSessionTab}
            onTabChange={handleSessionTabChange}
            onDisconnect={handleDisconnectSession}
            onConnectStateChange={setSessionConnectState}
          />
        ) : (
          <>
            {currentRoute === '/' && (
              <HomePage 
                onNavigate={handleNavigate} 
                onDownloadClient={() => setDownloadModalOpen(true)}
                onSelectDevice={handleSelectDevice}
              />
            )}

            {currentRoute === '/devices' && (
              <DevicesPage 
                onSelectDevice={handleSelectDevice}
                onNavigate={handleNavigate}
                onDownloadClient={() => setDownloadModalOpen(true)}
              />
            )}

            {currentRoute === '/guide' && (
              <GuidePage 
                onNavigate={handleNavigate}
                onDownloadClient={() => setDownloadModalOpen(true)}
              />
            )}

            {currentRoute === '/profile' && (
              <ProfilePage 
                onNavigate={handleNavigate}
                onDownloadClient={() => setDownloadModalOpen(true)}
              />
            )}

            {currentRoute === '/admin' && (
              <AdminPage 
                onNavigate={handleNavigate}
              />
            )}
          </>
        )}
      </main>

      {/* Client Download Modal */}
      <DownloadModal
        isOpen={downloadModalOpen}
        onClose={() => setDownloadModalOpen(false)}
      />

      {/* Direct-link auto-add: opening /device/CODE for an unbound PC offers
          to bind it to the account (name prompt, default on close). */}
      <DirectLinkAddModal />

      {/* Глобальний індикатор запису екрана/камери — видно на будь-якій сторінці */}
      <RecordingBadge />

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <DeviceProvider>
        <AppContent />
      </DeviceProvider>
    </AuthProvider>
  );
}
