import React, { useEffect, useRef, useState } from 'react';
import { MonitorSmartphone, Loader2, X, MonitorUp } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useDevices } from '../context/DeviceContext';
import { toast } from '../utils/toast';

/**
 * Direct-link auto-add flow.
 *
 * When a person opens a share link like https://fluxcontrol.pages.dev/device/CODE
 * and that computer is NOT yet attached to their account, this modal asks for a
 * name for the PC and binds it automatically. Closing the modal (X, backdrop,
 * Esc) still binds the device — with the default name — exactly as requested:
 * the link itself is the consent to add this computer.
 *
 * Shows only when: direct /device/ URL + authenticated user + device list for
 * that user has been fetched at least once + code is genuinely missing.
 */
export const DirectLinkAddModal: React.FC = () => {
  const { user } = useAuth();
  const { devices, devicesReady, selectedDevice, addDevice, verifyCode } = useDevices();

  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [defaultName, setDefaultName] = useState('');
  const [specs, setSpecs] = useState<any>(null);
  const [checking, setChecking] = useState(false);
  const [saving, setSaving] = useState(false);

  const handledCodesRef = useRef<Set<string>>(new Set());
  const activeCodeRef = useRef<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const cleanCode = (raw: string) => raw.replace(/[^A-Za-z0-9]/g, '').trim().toUpperCase();

  useEffect(() => {
    // Only direct /device/ links trigger the flow (never the internal
    // /devices page navigation).
    const pathname = window.location.pathname;
    if (!pathname.startsWith('/device/')) return;

    const parts = pathname.split('/').filter(Boolean);
    const code = parts[1] ? cleanCode(parts[1]) : '';
    if (!code || !user || !devicesReady || !selectedDevice) return;

    const alreadyBound = devices.some(
      (d) => cleanCode(String(d.code || '')) === code || cleanCode(String(d.id || '')) === code
    );
    if (alreadyBound) return;
    if (handledCodesRef.current.has(code)) return;
    // Do not fight an existing modal for the same code.
    if (activeCodeRef.current === code) return;

    activeCodeRef.current = code;
    handledCodesRef.current.add(code);
    setChecking(true);
    setOpen(true);

    // Prefill with the real computer name when the agent answers the
    // verification probe; fall back to a friendly default.
    (async () => {
      let fallback = `ПК ${code.slice(0, 4)}`;
      try {
        const res = await verifyCode(code);
        if (res.success && res.data?.name) {
          fallback = String(res.data.name);
          setSpecs(res.data);
        }
      } catch {}
      setDefaultName(fallback);
      setName(fallback);
      setChecking(false);
      setTimeout(() => inputRef.current?.select(), 80);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, devicesReady, selectedDevice?.id, devices.length]);

  const finishAdd = async (finalName: string) => {
    const code = activeCodeRef.current;
    if (!code) return;
    setSaving(true);
    try {
      const res = await addDevice(code, finalName.trim() || defaultName, specs);
      if (res.success) {
        toast.success(`Пристрій «${finalName.trim() || defaultName}» додано до вашого акаунта`, { title: 'Пристрій додано' });
      } else {
        toast.error(res.error || 'Не вдалося додати пристрій');
      }
    } catch {
      toast.error("Помилка з'єднання із сервером");
    } finally {
      setSaving(false);
      setOpen(false);
      activeCodeRef.current = null;
    }
  };

  const handleClose = () => {
    // Closing still adds the device with the default name (link = consent).
    if (activeCodeRef.current && !saving) {
      finishAdd(defaultName || `ПК ${activeCodeRef.current.slice(0, 4)}`);
      return;
    }
    setOpen(false);
    activeCodeRef.current = null;
  };

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') handleClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, saving, defaultName]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[10060] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-150"
      role="dialog"
      aria-modal="true"
      aria-label="Додати пристрій за прямим посиланням"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) handleClose();
      }}
    >
      <div className="w-full max-w-[420px] rounded-3xl bg-[#0c0b16]/97 border border-white/10 shadow-2xl shadow-black/70 p-6 relative animate-in zoom-in-95 fade-in duration-200">
        <button
          onClick={handleClose}
          aria-label="Закрити"
          className="absolute top-4 right-4 w-8 h-8 grid place-items-center rounded-xl text-gray-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-3 mb-4 pr-8">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 grid place-items-center shadow-lg shadow-indigo-600/30 flex-shrink-0">
            <MonitorUp className="w-5 h-5 text-white" />
          </div>
          <div className="min-w-0">
            <h3 className="text-sm font-black text-white leading-tight">Додати цей комп&apos;ютер?</h3>
            <p className="text-[11px] text-gray-400 font-mono truncate">код {activeCodeRef.current}</p>
          </div>
        </div>

        <p className="text-xs text-gray-400 leading-relaxed mb-4">
          Ви перейшли за прямим посиланням, тому цей ПК буде прив&apos;язано до вашого акаунта.
          Введіть назву, під якою він з&apos;явиться у списку пристроїв.
        </p>

        <label className="block text-[10.5px] font-extrabold uppercase tracking-wider text-gray-500 mb-1.5">
          Назва комп&apos;ютера
        </label>
        {checking ? (
          <div className="h-11 rounded-2xl bg-white/[0.04] border border-white/10 flex items-center px-3.5 text-gray-500 text-xs gap-2">
            <Loader2 className="w-3.5 h-3.5 animate-spin text-indigo-400" />
            <span>Отримуємо дані комп&apos;ютера…</span>
          </div>
        ) : (
          <input
            ref={inputRef}
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !saving) finishAdd(name);
            }}
            placeholder={defaultName || 'Мій ПК'}
            maxLength={40}
            autoFocus
            className="w-full h-11 rounded-2xl bg-white/[0.04] border border-white/10 focus:border-indigo-400/60 focus:bg-white/[0.06] outline-none px-3.5 text-sm font-semibold text-white placeholder:text-gray-600 transition-colors"
          />
        )}

        <button
          onClick={() => finishAdd(name)}
          disabled={checking || saving}
          className="mt-5 w-full h-11 rounded-2xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 text-sm font-bold text-white shadow-lg shadow-indigo-600/30 transition-all active:scale-[.98] cursor-pointer flex items-center justify-center gap-2"
        >
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <MonitorUp className="w-4 h-4" />}
          <span>{saving ? 'Додаємо…' : 'Додати пристрій'}</span>
        </button>

        <p className="mt-3 text-[10.5px] text-gray-500 text-center">
          Якщо закрити це вікно — пристрій буде додано з назвою «{defaultName || 'Мій ПК'}».
        </p>
      </div>
    </div>
  );
};
