import React, { useState, useLayoutEffect, useRef } from 'react';
import { 
  Plus, 
  Monitor, 
  Trash2, 
  Activity, 
  Wifi, 
  WifiOff, 
  Cpu, 
  ArrowRight, 
  X, 
  Check, 
  AlertCircle,
  Clock,
  LogIn,
  ShieldCheck,
  Crown,
  Lock,
  Key,
  Edit3,
  User as UserIcon,
  HardDrive
} from 'lucide-react';
import { useDevices } from '../context/DeviceContext';
import { useAuth } from '../context/AuthContext';
import { Device, AppRoute } from '../types';
import { ConfirmDialog } from './ConfirmDialog';
import { toast } from '../utils/toast';

/**
 * Текст, який САМ зменшує шрифт (11px → 7px), щоб влізти в один рядок —
 * жодних обрізань довгої назви ОС («Windows 11 Pro для слабких ПК…»).
 */
const AutoFitRow: React.FC<{ value: string; tone?: string }> = ({ value, tone = 'text-white' }) => {
  const boxRef = useRef<HTMLSpanElement>(null);
  const textRef = useRef<HTMLSpanElement>(null);
  const [size, setSize] = useState(11);

  useLayoutEffect(() => {
    const box = boxRef.current;
    const el = textRef.current;
    if (!box || !el) return;
    // Спочатку даємо тексту природну ширину (без переносу), потім стискаємо.
    for (const s of [11, 10.5, 10, 9.5, 9, 8.5, 8, 7.5, 7]) {
      el.style.fontSize = `${s}px`;
      if (el.scrollWidth <= box.clientWidth) {
        setSize(s);
        return;
      }
    }
    setSize(7);
  }, [value]);

  return (
    <span ref={boxRef} className="relative block min-w-0 flex-1 overflow-hidden text-right" title={value}>
      <span
        ref={textRef}
        className={`inline-block max-w-full whitespace-nowrap font-semibold leading-tight ${tone}`}
        style={{ fontSize: `${size}px` }}
      >
        {value}
      </span>
    </span>
  );
};

interface DevicesPageProps {
  onSelectDevice: (device: Device) => void;
  onNavigate: (route: AppRoute) => void;
  onDownloadClient: () => void;
}

export const DevicesPage: React.FC<DevicesPageProps> = ({ 
  onSelectDevice, 
  onNavigate,
  onDownloadClient 
}) => {
  const { devices, addDevice, removeDevice, renameDevice, verifyCode, updateDeviceStatus } = useDevices();
  const { user, loginWithGoogle, isSubscribed, isAdmin } = useAuth();

  const [modalOpen, setModalOpen] = useState(false);
  const [subModalOpen, setSubModalOpen] = useState(false);
  const [step, setStep] = useState<1 | 2>(1);
  const [code, setCode] = useState('');
  const [customName, setCustomName] = useState('');
  const [verifiedSpecs, setVerifiedSpecs] = useState<any>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [checkingDeviceId, setCheckingDeviceId] = useState<string | null>(null);

  const [editingDeviceId, setEditingDeviceId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState<string>('');
  const [deviceToRemove, setDeviceToRemove] = useState<Device | null>(null);

  const handleOpenModal = () => {
    if (!user) {
      loginWithGoogle();
      return;
    }
    if (!isSubscribed) {
      setSubModalOpen(true);
      return;
    }
    setStep(1);
    setCode('');
    setCustomName('');
    setVerifiedSpecs(null);
    setErrorMsg(null);
    setModalOpen(true);
  };

  const handleVerifyCode = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = code.replace(/[^A-Za-z0-9]/g, '').trim().toUpperCase();
    if (!clean) {
      setErrorMsg('Будь ласка, введіть 16-значний код підключення з програми FluxControl на ПК');
      return;
    }

    setIsVerifying(true);
    setErrorMsg(null);

    try {
      const res = await verifyCode(clean);
      if (res.success && res.data) {
        setVerifiedSpecs(res.data);
        setCustomName(res.data.name || 'Мій ПК');
        setStep(2);
      } else {
        setErrorMsg(res.message || 'Комп\'ютер не знайдено в базі або він офлайн. Переконайтеся, що програма запущена.');
      }
    } catch {
      setErrorMsg("Помилка з'єднання із сервером перевірки");
    } finally {
      setIsVerifying(false);
    }
  };

  const handleSaveDevice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim()) return;

    setIsSaving(true);
    setErrorMsg(null);

    try {
      const res = await addDevice(code.trim(), customName.trim() || 'Мій ПК', verifiedSpecs);
      if (res.success) {
        setModalOpen(false);
        toast.success(`Пристрій «${customName.trim() || 'Мій ПК'}» успішно прив'язано до вашого акаунта!`, { title: 'Пристрій додано' });
      } else {
        setErrorMsg(res.error || 'Помилка збереження пристрою');
      }
    } catch {
      setErrorMsg("Помилка з'єднання із сервером");
    } finally {
      setIsSaving(false);
    }
  };

  const handleConnect = async (device: Device) => {
    if (!isSubscribed) {
      setSubModalOpen(true);
      return;
    }
    if (!device.isOnline) {
      setCheckingDeviceId(device.id);
      try {
        const live = await verifyCode(device.code || device.id);
        if (live.success) {
          updateDeviceStatus(device.id, 'online');
          onSelectDevice({ ...device, isOnline: true, lastSeen: Date.now() });
          return;
        }
      } finally { setCheckingDeviceId(null); }
      toast.warn(`Пристрій «${device.name}» не відповідає. Перевірте, що FluxControl запущено на ПК.`, { title: 'ПК недоступний' });
      return;
    }
    onSelectDevice(device);
  };

  const handleStartRename = (device: Device) => {
    setEditingDeviceId(device.id);
    setEditingName(device.name);
  };

  const handleConfirmRename = async (deviceId: string) => {
    const trimmed = editingName.trim();
    if (trimmed) {
      await renameDevice(deviceId, trimmed);
    }
    setEditingDeviceId(null);
  };

  const formatLastActivity = (isOnline: boolean, timestamp?: number | string) => {
    if (isOnline) return 'Зараз в мережі';
    if (!timestamp) return 'Невідомо';
    const ts = typeof timestamp === 'string' ? new Date(timestamp).getTime() : Number(timestamp);
    if (isNaN(ts) || ts <= 0) return 'Невідомо';
    const diff = Date.now() - ts;
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'Щойно';
    if (mins < 60) return `${mins} хв тому`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours} год тому`;
    const d = new Date(ts);
    const months = ['січ', 'лют', 'бер', 'кві', 'тра', 'чер', 'лип', 'сер', 'вер', 'жов', 'лис', 'гру'];
    return `${d.getDate()} ${months[d.getMonth()]}, ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  };

  // СОРТУВАННЯ: спочатку всі ОНЛАЙН, потім офлайн; всередині груп — за
  // останньою активністю (свіжіші вище: «місяць тому» перед «рік тому»).
  const lastSeenMs = (d: Device): number => {
    if (!d.lastSeen) return 0;
    const ts = typeof d.lastSeen === 'string' ? new Date(d.lastSeen).getTime() : Number(d.lastSeen);
    return isNaN(ts) ? 0 : ts;
  };
  const sortedDevices = [...devices].sort((a, b) => {
    if (a.isOnline !== b.isOnline) return a.isOnline ? -1 : 1;
    return lastSeenMs(b) - lastSeenMs(a);
  });
  const onlineCount = devices.filter(d => d.isOnline).length;
  const offlineCount = devices.length - onlineCount;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-28 pb-20 w-full animate-in fade-in duration-300">
      
      {/* Header Bar — чисто і сучасно: заголовок + живе зведення, БЕЗ
          «прив'язано до акаунта …» під текстом */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-7">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Мої Пристрої
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-600/20 text-indigo-300 border border-indigo-500/30">
              {devices.length}
            </span>
          </div>
          <div className="mt-1.5 flex flex-wrap items-center gap-2">
            {onlineCount > 0 && (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-1 text-[11px] font-bold text-emerald-300">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
                {onlineCount} в мережі
              </span>
            )}
            {offlineCount > 0 && (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-[11px] font-bold text-zinc-400">
                <WifiOff className="h-3 w-3" />
                {offlineCount} офлайн
              </span>
            )}
            {isAdmin && (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-500/30 bg-amber-500/10 px-2.5 py-1 text-[11px] font-bold text-amber-300">
                <Crown className="h-3 w-3" /> Admin
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          {user ? (
            <button
              id="btn-add-device-main"
              onClick={handleOpenModal}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 active:scale-95 text-white rounded-2xl font-bold transition-all shadow-lg shadow-indigo-600/30 text-xs cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Додати пристрій</span>
            </button>
          ) : (
            <button
              onClick={loginWithGoogle}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white rounded-2xl font-bold transition-all shadow-lg shadow-indigo-600/30 text-xs cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              <span>Увійти через Google</span>
            </button>
          )}
        </div>
      </div>

      {/* Subscription Required Banner (if user has no subscription) */}
      {user && !isSubscribed && (
        <div className="mb-8 p-5 rounded-3xl bg-gradient-to-r from-indigo-950/60 via-purple-950/40 to-black/80 border border-indigo-500/30 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
          <div className="flex items-center gap-3.5">
            <div className="p-3 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <Lock className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Для керування ПК потрібна активна підписка</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-semibold">Лише 1 ліцензія</span>
              </h3>
              <p className="text-xs text-gray-400 mt-0.5">
                Активуйте ліцензійний ключ у вкладці «Профіль», щоб розблокувати віддалений доступ, передачу файлів та термінал.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('/profile')}
            className="px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white rounded-2xl font-bold text-xs shadow-lg shadow-indigo-600/30 whitespace-nowrap cursor-pointer flex items-center gap-1.5"
          >
            <Key className="w-3.5 h-3.5" />
            <span>Активувати ключ у Профілі</span>
          </button>
        </div>
      )}

      {/* Devices Grid List: онлайн зверху, офлайн знизу, за активністю */}
      {devices.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {sortedDevices.map((device) => (
            <div
              key={device.id}
              className={`glass-card rounded-3xl p-5 border transition-all duration-300 relative overflow-hidden flex flex-col justify-between group ${
                device.isOnline
                  ? 'border-indigo-500/30 hover:border-indigo-400/60 bg-gradient-to-b from-[#0e0e1c] to-[#070711] shadow-xl hover:shadow-indigo-600/10'
                  : 'border-white/10 hover:border-white/20 bg-[#080810]/70'
              }`}
            >
              {/* Subtle accent glow */}
              {device.isOnline && (
                <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none group-hover:bg-indigo-500/20 transition-colors" />
              )}

              <div>
                {/* Card Top: Status & Name & Unlink */}
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <div className={`relative p-2.5 rounded-2xl border flex-shrink-0 transition-colors ${
                      device.isOnline 
                        ? 'bg-indigo-600/20 border-indigo-500/40 text-indigo-300' 
                        : 'bg-white/5 border-white/10 text-gray-500'
                    }`}>
                      <Monitor className="w-5 h-5" />
                      <span className={`absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full ring-2 ring-[#0b0b13] ${
                        device.isOnline ? 'bg-emerald-400' : 'bg-zinc-600'
                      }`} />
                    </div>

                    <div className="min-w-0 flex-1">
                      {editingDeviceId === device.id ? (
                        <div className="flex items-center gap-1.5">
                          <input
                            type="text"
                            value={editingName}
                            onChange={(e) => setEditingName(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleConfirmRename(device.id);
                              if (e.key === 'Escape') setEditingDeviceId(null);
                            }}
                            autoFocus
                            className="bg-black/80 border border-indigo-500/50 rounded-xl px-2.5 py-1 text-xs sm:text-sm font-bold text-white focus:outline-none focus:border-indigo-400 w-full max-w-[180px]"
                          />
                          <button
                            onClick={() => handleConfirmRename(device.id)}
                            className="p-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-colors cursor-pointer"
                            title="Зберегти назву"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setEditingDeviceId(null)}
                            className="p-1.5 bg-white/10 hover:bg-white/15 text-gray-400 hover:text-white rounded-lg transition-colors cursor-pointer"
                            title="Скасувати"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5">
                          <h3 className="font-extrabold text-base text-white truncate leading-tight">
                            {device.name}
                          </h3>
                          <button
                            onClick={() => handleStartRename(device)}
                            className="p-1 text-gray-500 hover:text-indigo-300 rounded-lg hover:bg-white/5 transition-colors cursor-pointer flex-shrink-0"
                            title="Перейменувати пристрій"
                          >
                            <Edit3 className="w-3 h-3" />
                          </button>
                        </div>
                      )}

                      <div className="mt-0.5 flex items-center gap-1.5">
                        {device.isOnline ? (
                          <span className="fc-badge fc-badge-ok">
                            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" /> В мережі
                          </span>
                        ) : (
                          <span className="fc-badge fc-badge-muted">
                            <WifiOff className="h-2.5 w-2.5" /> Не запущено
                          </span>
                        )}
                        {!device.isOnline && lastSeenMs(device) > 0 && (
                          <span className="truncate font-mono text-[10px] text-zinc-500">
                            · був {formatLastActivity(device.isOnline, device.lastSeen)}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => setDeviceToRemove(device)}
                    className="p-1.5 text-gray-500 hover:text-red-400 rounded-xl hover:bg-red-500/10 transition-colors flex-shrink-0 cursor-pointer"
                    title="Відв'язати пристрій"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Specs: ОС (завжди — жива або збережена в БД) + користувач.
                    Компактно: зменшені відступи, без «рядочних» банерів. */}
                <div className="space-y-1.5 rounded-2xl border border-white/5 bg-black/30 px-3 py-2.5 text-[11px]">
                  <div className="flex items-center gap-2">
                    <Cpu className="h-3 w-3 flex-none text-indigo-400" />
                    <span className="flex-none text-zinc-500">ОС:</span>
                    <AutoFitRow value={device.osInfo || device.os || 'Windows'} />
                  </div>
                  <div className="flex items-center gap-2">
                    <UserIcon className="h-3 w-3 flex-none text-indigo-400" />
                    <span className="flex-none text-zinc-500">Користувач:</span>
                    <AutoFitRow value={device.username || 'Адміністратор'} tone="text-indigo-300" />
                  </div>
                </div>
              </div>

              {/* Connect Action Button */}
              <div className="pt-3.5">
                <button
                  id={`btn-connect-device-${device.id}`}
                  onClick={() => handleConnect(device)}
                  disabled={checkingDeviceId === device.id}
                  className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-2xl font-bold text-xs transition-all ${
                    device.isOnline || checkingDeviceId === device.id
                      ? 'bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 active:scale-[0.98] text-white shadow-lg shadow-indigo-600/30 cursor-pointer'
                      : 'bg-white/[.04] text-zinc-500 border border-white/10 cursor-not-allowed'
                  }`}
                >
                  {device.isOnline ? (
                    <>
                      <Wifi className="w-3.5 h-3.5" />
                      <span>Підключитись до ПК</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  ) : (
                    <>
                      <WifiOff className="w-3.5 h-3.5" />
                      <span>Офлайн · ПК не запущено</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Empty State */
        <div className="glass-card rounded-3xl p-12 text-center max-w-xl mx-auto border border-white/10 bg-[#090b14]/80">
          <div className="w-16 h-16 bg-indigo-600/20 border border-indigo-500/30 rounded-3xl flex items-center justify-center text-indigo-400 mx-auto mb-4">
            <Monitor className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-white mb-2">Немає доданих комп'ютерів</h2>
          <p className="text-xs text-gray-400 max-w-md mx-auto mb-6 leading-relaxed">
            Запустіть <span className="text-indigo-300 font-semibold">«FluxControl.exe»</span> на вашому комп'ютері, візьміть 16-значний код та прив'яжіть його тут.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={handleOpenModal}
              className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white rounded-2xl font-bold text-xs transition-all shadow-lg shadow-indigo-600/30 cursor-pointer"
            >
              Додати перший ПК
            </button>
            <button
              onClick={onDownloadClient}
              className="px-5 py-2.5 bg-white/5 hover:bg-white/10 text-indigo-300 hover:text-white rounded-2xl font-semibold text-xs border border-white/10 hover:border-indigo-500/30 transition-all cursor-pointer"
            >
              Завантажити клієнт (.exe)
            </button>
          </div>
        </div>
      )}

      {/* Add Device Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className="glass-panel w-full max-w-md rounded-3xl p-6 border border-white/15 shadow-2xl relative bg-[#090b14]">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-5">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-indigo-600/20 text-indigo-400">
                  <Monitor className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Додати новий пристрій</h3>
                  <p className="text-[11px] text-indigo-300/80">Крок {step} з 2</p>
                </div>
              </div>
              <button
                onClick={() => setModalOpen(false)}
                className="p-1.5 text-gray-400 hover:text-white rounded-xl hover:bg-white/5 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Error banner */}
            {errorMsg && (
              <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Step 1: Input Connection Code */}
            {step === 1 && (
              <form onSubmit={handleVerifyCode} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-300 mb-1.5">
                    16-значний код підключення з програми
                  </label>
                  <input
                    type="text"
                    required
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder="Наприклад: 59F5PWDG7KEPBW7B"
                    className="w-full bg-black/60 border border-white/10 focus:border-indigo-500 rounded-2xl px-4 py-3 text-sm text-white font-mono placeholder:text-gray-600 focus:outline-none transition-colors uppercase tracking-wider"
                  />
                  <p className="text-[11px] text-gray-400 mt-2 leading-relaxed">
                    Запустіть <span className="text-indigo-300 font-semibold">FluxControl.exe</span> на ПК, і у вікні відобразиться 16-символьний код.
                  </p>
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setModalOpen(false)}
                    className="flex-1 py-3 bg-white/5 hover:bg-white/10 text-gray-300 rounded-2xl font-bold text-xs transition-colors cursor-pointer"
                  >
                    Скасувати
                  </button>
                  <button
                    type="submit"
                    disabled={isVerifying}
                    className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-bold text-xs transition-all shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {isVerifying ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>Пошук ПК...</span>
                      </>
                    ) : (
                      <>
                        <span>Перевірити</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}

            {/* Step 2: Name Device & Confirm Specs */}
            {step === 2 && (
              <form onSubmit={handleSaveDevice} className="space-y-4">
                {verifiedSpecs && (
                  <div className="p-4 bg-gradient-to-br from-[#0e1022] to-[#080812] border border-indigo-500/30 rounded-2xl space-y-3 text-xs shadow-xl">
                    <div className="flex items-center gap-3 pb-2.5 border-b border-white/10">
                      <div className="p-2.5 rounded-xl bg-indigo-600/20 border border-indigo-500/40 text-indigo-300">
                        <Monitor className="w-5 h-5 text-indigo-300" />
                      </div>
                      <div>
                        <p className="text-[10px] uppercase font-bold text-indigo-300 tracking-wider">Знайдено комп'ютер</p>
                        <h4 className="text-sm font-black text-white">{verifiedSpecs.name || 'Мій ПК'}</h4>
                      </div>
                    </div>

                    <div className="space-y-1.5 text-[11px]">
                      <div className="flex items-center justify-between">
                        <span className="text-gray-400">Операційна система:</span>
                        <span className="font-semibold text-white truncate max-w-[210px] text-right">
                          {verifiedSpecs.os || verifiedSpecs.osInfo || 'Windows 11'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-gray-400">Процесор:</span>
                        <span className="font-semibold text-indigo-200 truncate max-w-[210px] text-right" title={verifiedSpecs.cpu || verifiedSpecs.cpuInfo}>
                          {verifiedSpecs.cpu || verifiedSpecs.cpuInfo || 'Процесор'}
                        </span>
                      </div>
                      {(verifiedSpecs.gpu || verifiedSpecs.gpuInfo) && (
                        <div className="flex items-center justify-between">
                          <span className="text-gray-400">Відеокарта:</span>
                          <span className="font-semibold text-emerald-400 truncate max-w-[210px] text-right" title={verifiedSpecs.gpu || verifiedSpecs.gpuInfo}>
                            {verifiedSpecs.gpu || verifiedSpecs.gpuInfo}
                          </span>
                        </div>
                      )}
                      {verifiedSpecs.username && (
                        <div className="flex items-center justify-between">
                          <span className="text-gray-400">Користувач ОС:</span>
                          <span className="font-semibold text-gray-300">{verifiedSpecs.username}</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-gray-300 mb-1.5">
                    Власна назва для пристрою
                  </label>
                  <input
                    type="text"
                    required
                    value={customName}
                    onChange={(e) => setCustomName(e.target.value)}
                    placeholder="Наприклад: Мій Ноутбук, Робочий ПК..."
                    className="w-full bg-black/60 border border-white/10 focus:border-indigo-500 rounded-2xl px-4 py-3 text-sm text-white focus:outline-none transition-colors"
                  />
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="flex-1 py-3 bg-white/5 hover:bg-white/10 text-gray-300 rounded-2xl font-bold text-xs transition-colors cursor-pointer"
                  >
                    Назад
                  </button>
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="flex-1 py-3 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white rounded-2xl font-bold text-xs transition-all shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {isSaving ? 'Збереження...' : 'Зберегти та прив\'язати'}
                  </button>
                </div>
              </form>
            )}

          </div>
        </div>
      )}

      {/* Subscription Guard Modal */}
      {subModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className="glass-panel w-full max-w-md rounded-3xl p-6 sm:p-8 border border-white/15 shadow-2xl relative bg-[#090b14] text-center">
            <button
              onClick={() => setSubModalOpen(false)}
              className="absolute top-5 right-5 p-1.5 text-gray-400 hover:text-white rounded-xl hover:bg-white/5"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-16 h-16 rounded-3xl bg-amber-500/20 border border-amber-500/30 text-amber-400 flex items-center justify-center mx-auto mb-4">
              <Crown className="w-8 h-8" />
            </div>

            <h3 className="text-xl font-bold text-white mb-2">Потрібна підписка PRO</h3>
            <p className="text-xs text-gray-400 leading-relaxed mb-6">
              Для додавання та підключення комп'ютерів необхідно мати активну підписку. Ви можете активувати ліцензійний ключ у вкладці «Профіль».
            </p>

            <div className="space-y-3">
              <button
                onClick={() => {
                  setSubModalOpen(false);
                  onNavigate('/profile');
                }}
                className="w-full py-3.5 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white rounded-2xl font-bold text-xs sm:text-sm shadow-lg shadow-indigo-600/30 cursor-pointer flex items-center justify-center gap-2"
              >
                <Key className="w-4 h-4" />
                <span>Перейти до активації ключа</span>
              </button>
              <button
                onClick={() => setSubModalOpen(false)}
                className="w-full py-2.5 text-gray-400 hover:text-white text-xs font-semibold"
              >
                Закрити
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Unlink Device Confirmation (styled, replaces native confirm) */}
      <ConfirmDialog
        isOpen={Boolean(deviceToRemove)}
        title="Відв'язати пристрій?"
        message={`Ви дійсно бажаєте відв'язати «${deviceToRemove?.name ?? ''}»? Пристрій зникне зі списку, але його можна додати знову за кодом підключення.`}
        confirmLabel="Відв'язати"
        onCancel={() => setDeviceToRemove(null)}
        onConfirm={() => {
          if (deviceToRemove) removeDevice(deviceToRemove.id);
          setDeviceToRemove(null);
        }}
      />

    </div>
  );
};
