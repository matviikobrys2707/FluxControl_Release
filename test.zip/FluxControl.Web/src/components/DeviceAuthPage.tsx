import React, { useState, useEffect } from 'react';
import { 
  Monitor, 
  ShieldCheck, 
  Check, 
  X, 
  AlertCircle, 
  LogIn, 
  ArrowRight,
  Crown,
  Lock
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { AppRoute } from '../types';

interface DeviceAuthPageProps {
  onNavigate: (route: AppRoute) => void;
}

export const DeviceAuthPage: React.FC<DeviceAuthPageProps> = ({ onNavigate }) => {
  const { user, loginWithGoogle } = useAuth();

  const [token, setToken] = useState<string>('');
  const [computerName, setComputerName] = useState<string>('Мій Комп\'ютер');
  const [status, setStatus] = useState<'idle' | 'approving' | 'approved' | 'rejected' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const t = params.get('token') || '';
    const pc = params.get('pc') || 'Мій Комп\'ютер';
    setToken(t);
    setComputerName(pc);

    if (!t) {
      setErrorMsg('Не вказано токен сесії авторизації');
      setStatus('error');
    }
  }, []);

  const handleApprove = async () => {
    if (!user) {
      loginWithGoogle();
      return;
    }

    if (!token) return;
    setStatus('approving');
    setErrorMsg(null);

    try {
      const payload = { 
        token, 
        userId: user.id, 
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          picture: user.photoURL || user.picture,
          role: user.role || 'user',
          subscriptionExpiresAt: user.subscriptionExpiresAt
        },
        action: 'approve' 
      };
      
      // Approve in parallel to both Cloudflare D1 Worker and Render Relay
      const [resPages, resRender] = await Promise.allSettled([
        fetch('/api/auth/device-session/approve', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
        fetch('https://fluxcontrol-backend.onrender.com/api/auth/device-session/approve', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        })
      ]);

      const successPages = resPages.status === 'fulfilled' && resPages.value.ok;
      const successRender = resRender.status === 'fulfilled' && resRender.value.ok;

      if (successPages || successRender) {
        setStatus('approved');
      } else {
        setStatus('error');
        setErrorMsg('Не вдалося підтвердити сесію або термін дії токена минув.');
      }
    } catch (e) {
      setStatus('error');
      setErrorMsg('Помилка підключення до сервера');
    }
  };

  const handleReject = async () => {
    if (!token) return;
    try {
      const payload = { token, action: 'reject' };
      await Promise.allSettled([
        fetch('/api/auth/device-session/approve', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
        fetch('https://fluxcontrol-backend.onrender.com/api/auth/device-session/approve', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        })
      ]);
      setStatus('rejected');
    } catch {}
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-[#050508] relative overflow-hidden selection:bg-indigo-600 selection:text-white">
      
      {/* Background ambient lighting */}
      <div className="fixed top-1/4 left-1/3 w-[500px] h-[500px] bg-indigo-600/15 rounded-full blur-[140px] pointer-events-none -z-10" />
      <div className="fixed bottom-1/4 right-1/3 w-[500px] h-[500px] bg-violet-600/15 rounded-full blur-[160px] pointer-events-none -z-10" />

      <div className="glass-card w-full max-w-md rounded-3xl p-8 border border-white/10 bg-[#090b14]/90 backdrop-blur-2xl relative overflow-hidden shadow-2xl text-center">
        
        {/* Subtle decorative glow header */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-48 h-48 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Brand Icon Header */}
        <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-indigo-500/20 to-violet-600/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400 mx-auto mb-6 shadow-lg shadow-indigo-600/20">
          <Monitor className="w-10 h-10 text-indigo-300" />
        </div>

        {status === 'idle' && (
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight mb-2">
              Підтвердження входу
            </h2>
            <p className="text-xs text-gray-400 leading-relaxed mb-6">
              Програма <span className="text-indigo-300 font-semibold">FluxControl Agent</span> на комп'ютері{' '}
              <span className="text-white font-bold font-mono">«{computerName}»</span> запитує авторизацію у вашому акаунті.
            </p>

            {user ? (
              <div className="p-4 rounded-2xl bg-black/60 border border-white/10 mb-6 flex items-center gap-3.5 text-left">
                <div className="w-11 h-11 rounded-2xl bg-indigo-600/30 border border-indigo-500/30 overflow-hidden flex items-center justify-center text-white font-bold flex-shrink-0">
                  {user.photoURL || user.picture ? (
                    <img src={user.photoURL || user.picture} alt="" className="w-full h-full object-cover" />
                  ) : (
                    user.name?.charAt(0) || 'U'
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold text-white truncate leading-tight">{user.name}</p>
                  <p className="text-xs text-gray-400 truncate mt-0.5">{user.email}</p>
                  <div className="mt-1.5 flex items-center gap-1.5">
                    {user.role === 'admin' ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 text-[10px] font-bold">
                        <Crown className="w-3 h-3 text-purple-400" />
                        <span>Admin (Безліміт)</span>
                      </span>
                    ) : user.subscriptionExpiresAt === -1 || (user.subscriptionExpiresAt && user.subscriptionExpiresAt > Date.now()) ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                        <ShieldCheck className="w-3 h-3 text-emerald-400" />
                        <span>PRO Активна</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-semibold">
                        <Lock className="w-3 h-3 text-amber-400" />
                        <span>Без підписки</span>
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs mb-6 flex items-center gap-2.5 text-left">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>Будь ласка, спочатку увійдіть у свій акаунт, щоб надати доступ цій програмі.</span>
              </div>
            )}

            <div className="flex flex-col gap-3">
              {user ? (
                <>
                  <button
                    onClick={handleApprove}
                    className="w-full py-3.5 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white rounded-2xl font-bold shadow-lg shadow-indigo-600/30 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <ShieldCheck className="w-5 h-5" />
                    <span>Підтвердити вхід на ПК</span>
                  </button>
                  <button
                    onClick={handleReject}
                    className="w-full py-3 bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white rounded-2xl text-xs font-semibold border border-white/5 transition-all cursor-pointer"
                  >
                    Відхилити запит
                  </button>
                </>
              ) : (
                <button
                  onClick={loginWithGoogle}
                  className="w-full py-3.5 bg-white text-gray-900 hover:bg-gray-100 rounded-2xl font-bold shadow-lg shadow-white/10 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <LogIn className="w-5 h-5" />
                  <span>Увійти через Google</span>
                </button>
              )}
            </div>
          </div>
        )}

        {status === 'approving' && (
          <div className="py-8 flex flex-col items-center">
            <div className="w-12 h-12 rounded-full border-2 border-indigo-500 border-t-transparent animate-spin mb-4" />
            <p className="text-sm font-bold text-white mb-1">Підтвердження входу...</p>
            <p className="text-xs text-gray-400">Надання доступу десктопній програмі</p>
          </div>
        )}

        {status === 'approved' && (
          <div className="py-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-emerald-500/20">
              <Check className="w-8 h-8" />
            </div>
            <h2 className="text-xl font-black text-white tracking-tight mb-2">
              Вхід успішно підтверджено!
            </h2>
            <p className="text-xs text-gray-400 leading-relaxed mb-6">
              Програма на комп'ютері <span className="text-white font-bold">«{computerName}»</span> успішно підключена до вашого акаунта. Тепер ви можете керувати цим ПК зі списку пристроїв.
            </p>
            <button
              onClick={() => onNavigate('/devices')}
              className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-bold shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Перейти до моїх пристроїв</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {status === 'rejected' && (
          <div className="py-4">
            <div className="w-16 h-16 rounded-full bg-red-500/20 text-red-400 border border-red-500/30 flex items-center justify-center mx-auto mb-4">
              <X className="w-8 h-8" />
            </div>
            <h2 className="text-xl font-black text-white tracking-tight mb-2">
              Запит відхилено
            </h2>
            <p className="text-xs text-gray-400 leading-relaxed mb-6">
              Сесію для комп'ютера <span className="text-white font-bold">«{computerName}»</span> було скасовано.
            </p>
            <button
              onClick={() => onNavigate('/')}
              className="w-full py-3 bg-white/5 hover:bg-white/10 text-gray-300 rounded-2xl text-xs font-semibold transition-all cursor-pointer"
            >
              Повернутися на головну
            </button>
          </div>
        )}

        {status === 'error' && (
          <div className="py-4">
            <div className="w-16 h-16 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center mx-auto mb-4">
              <AlertCircle className="w-8 h-8" />
            </div>
            <h2 className="text-xl font-black text-white tracking-tight mb-2">
              Помилка авторизації
            </h2>
            <p className="text-xs text-red-400 leading-relaxed mb-6">
              {errorMsg || 'Не вдалося підтвердити сесію або термін дії токена минув.'}
            </p>
            <button
              onClick={() => onNavigate('/')}
              className="w-full py-3 bg-white/5 hover:bg-white/10 text-gray-300 rounded-2xl text-xs font-semibold transition-all cursor-pointer"
            >
              Повернутися на головну
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
