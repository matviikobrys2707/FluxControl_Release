import React from 'react';
import { 
  Monitor, 
  ArrowRight, 
  FolderTree, 
  Activity, 
  Terminal, 
  Gauge, 
  Download, 
  Sparkles,
  Sliders,
  Shield,
  Zap,
  LogIn
} from 'lucide-react';
import { AppRoute, Device, SessionTab } from '../types';
import { useDevices } from '../context/DeviceContext';
import { useAuth } from '../context/AuthContext';

interface HomePageProps {
  onNavigate: (route: AppRoute) => void;
  onDownloadClient: () => void;
  onSelectDevice?: (device: Device, initialTab?: SessionTab) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ 
  onNavigate, 
  onDownloadClient,
  onSelectDevice 
}) => {
  const { devices } = useDevices();
  const { user, loginWithGoogle } = useAuth();
  // Only an actually reachable PC may be auto-opened from the home cards.
  // Falling back to devices[0] used to drop the user on a full-screen
  // connection error when every device was offline.
  const onlineDevice = devices.find(d => d.isOnline) || null;

  const handleCardClick = (_tab: SessionTab) => {
    // ГОСТЕВОЙ РЕЖИМ: никаких действий до авторизации — только кнопка входа.
    if (!user) {
      loginWithGoogle();
      return;
    }
    if (onlineDevice && onSelectDevice) {
      onSelectDevice(onlineDevice, _tab);
    } else {
      onNavigate('/devices');
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 pt-32 pb-24">
      
      {/* Background radial ambiance (black + violet/indigo) */}
      <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[600px] h-[350px] bg-indigo-600/10 blur-[140px] rounded-full pointer-events-none -z-10" />
      <div className="absolute top-80 right-1/4 w-[400px] h-[250px] bg-violet-600/10 blur-[120px] rounded-full pointer-events-none -z-10" />

      {/* Hero Section */}
      <div className="text-center max-w-3xl mx-auto space-y-6">
        
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-semibold backdrop-blur-md shadow-inner">
          <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
          <span>FluxControl Web Console</span>
        </div>

        {/* Main Title */}
        <h1 className="text-4xl sm:text-6xl font-black text-white tracking-tight leading-[1.15]">
          Віддалене керування <br />
          <span className="bg-gradient-to-r from-indigo-200 via-indigo-400 to-violet-300 bg-clip-text text-transparent">
            вашим комп'ютером
          </span>
        </h1>

        {/* Description */}
        <p className="text-zinc-300 text-sm sm:text-base leading-relaxed max-w-2xl mx-auto">
          Отримуйте швидкий та безпечний доступ до робочого ПК або домашнього комп'ютера з будь-якого пристрою: моніторинг температури та навантаження заліза, провідник файлів, керування звуком, диспетчер процесів та PowerShell термінал.
        </p>

        {/* Action CTA Buttons.
            ГОСТЕВОЙ РЕЖИМ: до авторизації на головній є ОДНА кнопка — «Увійти».
            Всі інші дії (пристрої, завантаження, картки) відкриваються лише
            після входу. */}
        <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
          {!user ? (
            <button
              id="hero-btn-login"
              onClick={loginWithGoogle}
              className="flex items-center gap-2.5 px-8 py-4 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white rounded-full font-bold text-sm shadow-xl shadow-indigo-600/30 hover:shadow-indigo-600/50 hover:scale-[1.03] active:scale-[0.98] transition-all cursor-pointer"
            >
              <LogIn className="w-4.5 h-4.5" />
              <span>Авторизуватись</span>
              <ArrowRight className="w-4 h-4 ml-1" />
            </button>
          ) : (
            <>
              {/* Button: Мої Пристрої */}
              <button
                id="hero-btn-devices"
                onClick={() => onNavigate('/devices')}
                className="flex items-center gap-2 px-7 py-3.5 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white rounded-full font-bold text-sm shadow-xl shadow-indigo-600/30 hover:shadow-indigo-600/50 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
              >
                <Monitor className="w-4 h-4" />
                <span>Мої Пристрої</span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </button>

              {/* Button: Підключити ПК / Завантажити клієнт */}
              <button
                id="hero-btn-download"
                onClick={onDownloadClient}
                className="flex items-center gap-2 px-6 py-3.5 bg-white/5 hover:bg-white/10 text-indigo-200 hover:text-white rounded-full font-semibold text-sm border border-white/10 hover:border-indigo-500/30 backdrop-blur-xl transition-all cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
                title="Завантажити клієнт Flux control.exe"
              >
                <Download className="w-4 h-4 text-indigo-400" />
                <span>Підключити ПК / Завантажити клієнт</span>
              </button>
            </>
          )}


        </div>
      </div>

      {/* Feature Sections Cards Grid — доступні лише авторизованим */}
      {user && (
      <div className="mt-20">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            Повний контроль над системою у браузері
          </h2>
          <p className="text-xs sm:text-sm text-zinc-400 mt-2">
            Усі необхідні інструменти для моніторингу та адміністрування завжди під рукою.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          
          {/* Card 1: Моніторинг Заліза */}
          <div 
            onClick={() => handleCardClick('info')}
            className="glass-card rounded-3xl p-6 border border-white/10 space-y-4 hover:border-indigo-500/40 hover:bg-white/[0.03] transition-all cursor-pointer group"
          >
            <div className="w-12 h-12 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 group-hover:scale-110 transition-transform">
              <Gauge className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white group-hover:text-indigo-200 transition-colors">
              Моніторинг Заліза
            </h3>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Температура CPU та GPU, тактові частоти, ядра, використання RAM та стан дисків у реальному часі.
            </p>
          </div>

          {/* Card 2: Файли */}
          <div 
            onClick={() => handleCardClick('files')}
            className="glass-card rounded-3xl p-6 border border-white/10 space-y-4 hover:border-indigo-500/40 hover:bg-white/[0.03] transition-all cursor-pointer group"
          >
            <div className="w-12 h-12 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 group-hover:scale-110 transition-transform">
              <FolderTree className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white group-hover:text-indigo-200 transition-colors">
              Провідник Файлів
            </h3>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Зручна навігація дисками C:\ та D:\, швидке завантаження файлів, створення та видалення документів.
            </p>
          </div>

          {/* Card 3: Диспетчер Процесів */}
          <div 
            onClick={() => handleCardClick('processes')}
            className="glass-card rounded-3xl p-6 border border-white/10 space-y-4 hover:border-indigo-500/40 hover:bg-white/[0.03] transition-all cursor-pointer group"
          >
            <div className="w-12 h-12 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 group-hover:scale-110 transition-transform">
              <Activity className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white group-hover:text-indigo-200 transition-colors">
              Диспетчер Процесів
            </h3>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Відстеження активних програм, споживання пам'яті та процесора із можливістю закриття завислих задач.
            </p>
          </div>

          {/* Card 4: PowerShell Термінал */}
          <div 
            onClick={() => handleCardClick('terminal')}
            className="glass-card rounded-3xl p-6 border border-white/10 space-y-4 hover:border-indigo-500/40 hover:bg-white/[0.03] transition-all cursor-pointer group"
          >
            <div className="w-12 h-12 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 group-hover:scale-110 transition-transform">
              <Terminal className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white group-hover:text-indigo-200 transition-colors">
              PowerShell Консоль
            </h3>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Інтерактивний командний рядок для виконання діагностики, системних команд та автоматизації.
            </p>
          </div>

        </div>
      </div>
      )}

    </div>
  );
};
