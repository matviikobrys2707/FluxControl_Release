import React from 'react';
import { 
  Download, 
  Terminal, 
  KeyRound, 
  Monitor, 
  CheckCircle2, 
  HelpCircle, 
  ArrowRight, 
  ShieldCheck, 
  Cpu, 
  Wifi,
  Sparkles,
  ExternalLink,
  LogIn,
  Lock
} from 'lucide-react';
import { AppRoute } from '../types';
import { useAuth } from '../context/AuthContext';

interface GuidePageProps {
  onNavigate: (route: AppRoute) => void;
  onDownloadClient: () => void;
}

export const GuidePage: React.FC<GuidePageProps> = ({ onNavigate, onDownloadClient }) => {
  const { user, loginWithGoogle } = useAuth();

  // ПРАВИЛО ДОСТУПУ: інструкція (і всі завантаження з неї) — тільки для
  // авторизованих користувачів. Гість бачить красивий екран-замок.
  if (!user) {
    return (
      <div className="max-w-lg mx-auto px-4 pt-36 pb-24 text-center animate-in fade-in duration-300">
        <div className="glass-card rounded-3xl border border-amber-500/25 bg-[#090b14]/95 p-10 relative overflow-hidden">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-72 h-72 bg-indigo-600/10 blur-3xl rounded-full pointer-events-none" />
          <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-3xl border border-amber-500/30 bg-amber-500/15 text-amber-300">
            <Lock className="h-8 w-8" />
          </div>
          <h1 className="text-xl font-black text-white">Інструкція доступна після авторизації</h1>
          <p className="mt-3 text-[13px] leading-relaxed text-gray-400">
            Щоб переглянути інструкцію з підключення та завантажити клієнт
            <span className="font-semibold text-indigo-300"> Flux control.exe</span>, увійдіть у свій акаунт.
          </p>
          <button
            id="guide-login-btn"
            onClick={loginWithGoogle}
            className="mt-7 flex w-full cursor-pointer items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-indigo-600 to-violet-600 py-3.5 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 transition-all hover:brightness-110 active:scale-[0.98]"
          >
            <LogIn className="h-4 w-4" />
            <span>Авторизуватись через Google</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 pt-32 pb-24">
      
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto mb-14 space-y-4">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-semibold backdrop-blur-md">
          <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
          <span>Швидкий старт за 2 хвилини</span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
          Інструкція з підключення
        </h1>

        <p className="text-gray-300 text-sm sm:text-base leading-relaxed">
          Покрокове керівництво з налаштування віддаленого доступу до вашого комп'ютера через програму <span className="font-semibold text-indigo-300">Flux control.exe</span>.
        </p>
      </div>

      {/* Main Steps Grid */}
      <div className="space-y-6 mb-16">
        
        {/* Step 1 */}
        <div className="glass-card rounded-3xl p-6 sm:p-8 border border-white/10 hover:border-indigo-500/40 transition-all relative overflow-hidden flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 bg-[#090b14]/80">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white font-black text-lg flex items-center justify-center flex-shrink-0 shadow-lg shadow-indigo-600/30">
              1
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Download className="w-4 h-4 text-indigo-400" />
                <h3 className="text-lg font-bold text-white">Завантажте Flux control.exe</h3>
              </div>
              <p className="text-xs sm:text-sm text-gray-300 leading-relaxed max-w-xl">
                Завантажте офіційний клієнт для Windows. Програма не вимагає складного встановлення, є портативною та готовою до роботи відразу після завантаження.
              </p>
            </div>
          </div>

          <button
            id="guide-step1-download-btn"
            onClick={onDownloadClient}
            className="flex items-center gap-2 px-5 py-3 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white rounded-2xl font-bold text-xs transition-all shadow-lg shadow-indigo-600/30 cursor-pointer flex-shrink-0"
          >
            <Download className="w-4 h-4" />
            <span>Завантажити клієнт</span>
          </button>
        </div>

        {/* Step 2 */}
        <div className="glass-card rounded-3xl p-6 sm:p-8 border border-white/10 hover:border-indigo-500/40 transition-all flex items-start gap-4 bg-[#090b14]/80">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white font-black text-lg flex items-center justify-center flex-shrink-0 shadow-lg shadow-indigo-600/30">
            2
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <KeyRound className="w-4 h-4 text-indigo-400" />
              <h3 className="text-lg font-bold text-white">Запустіть Flux control.exe та отримайте код</h3>
            </div>
            <p className="text-xs sm:text-sm text-gray-300 leading-relaxed max-w-xl">
              Запустіть файл <span className="text-indigo-300 font-semibold font-mono">Flux control.exe</span> на комп'ютері. У вікні програми згенерується ваш унікальний код підключення.
            </p>
            <div className="mt-3 inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-indigo-950/40 border border-indigo-500/20 text-xs text-indigo-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Код створюється автоматично при кожному запуску агента</span>
            </div>
          </div>
        </div>

        {/* Step 3 */}
        <div className="glass-card rounded-3xl p-6 sm:p-8 border border-white/10 hover:border-indigo-500/40 transition-all relative overflow-hidden flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 bg-[#090b14]/80">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white font-black text-lg flex items-center justify-center flex-shrink-0 shadow-lg shadow-indigo-600/30">
              3
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Monitor className="w-4 h-4 text-indigo-400" />
                <h3 className="text-lg font-bold text-white">Прив'яжіть ПК у веб-інтерфейсі</h3>
              </div>
              <p className="text-xs sm:text-sm text-gray-300 leading-relaxed max-w-xl">
                На цьому сайті відкрийте вкладку <span className="text-white font-semibold">«Пристрої»</span>, натисніть кнопку <span className="text-indigo-300 font-semibold">«+ Додати пристрій»</span> та введіть отриманий код і назву комп'ютера.
              </p>
            </div>
          </div>

          <button
            id="guide-step3-devices-btn"
            onClick={() => onNavigate('/devices')}
            className="flex items-center gap-2 px-5 py-3 bg-white/5 hover:bg-white/10 text-indigo-200 hover:text-white rounded-2xl font-semibold text-xs border border-white/10 hover:border-indigo-500/30 transition-all cursor-pointer flex-shrink-0"
          >
            <span>Вкладка Пристрої</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Step 4 */}
        <div className="glass-card rounded-3xl p-6 sm:p-8 border border-white/10 hover:border-indigo-500/40 transition-all flex items-start gap-4 bg-[#090b14]/80">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white font-black text-lg flex items-center justify-center flex-shrink-0 shadow-lg shadow-indigo-600/30">
            4
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <h3 className="text-lg font-bold text-white">Керуйте ПК звідусіль</h3>
            </div>
            <p className="text-xs sm:text-sm text-gray-300 leading-relaxed max-w-xl">
              Натисніть «Підключитись» на картці вашого ПК: переглядайте диски та завантажуйте файли, виконуйте команди в PowerShell консолі, контролюйте гучність, процеси та живлення комп'ютера.
            </p>
          </div>
        </div>

      </div>

      {/* Frequently Asked Questions */}
      <div className="glass-panel rounded-3xl p-6 sm:p-8 border border-white/10 bg-[#090b14]/90">
        <h3 className="text-xl font-bold text-white mb-5 flex items-center gap-2.5">
          <HelpCircle className="w-5 h-5 text-indigo-400" />
          <span>Часті запитання та безпека</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs text-gray-300">
          <div className="p-4 rounded-2xl bg-black/40 border border-white/10">
            <h4 className="font-bold text-white mb-1.5 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Чи потрібно відкривати порти на роутері?</span>
            </h4>
            <p className="leading-relaxed text-gray-400">
              Ні. З'єднання встановлюється через захищений вихідний WebSocket тунель на наш захищений реле-сервер, тому працює навіть за NAT та мобільним інтернетом.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-black/40 border border-white/10">
            <h4 className="font-bold text-white mb-1.5 flex items-center gap-2">
              <Cpu className="w-4 h-4 text-indigo-400" />
              <span>Чи навантажує клієнт комп'ютер?</span>
            </h4>
            <p className="leading-relaxed text-gray-400">
              Flux control.exe споживає менше 0.5% CPU та лише 40-50 МБ оперативної пам'яті, перебуваючи у системному треї.
            </p>
          </div>
        </div>
      </div>

    </div>
  );
};
