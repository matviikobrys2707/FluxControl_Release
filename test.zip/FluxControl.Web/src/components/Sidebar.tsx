import React, { useEffect, useRef, useState } from 'react';
import {
  Zap,
  Home,
  Monitor,
  BookOpen,
  User as UserIcon,
  LogOut,
  ChevronDown,
  Sliders,
  FolderTree,
  Activity,
  Terminal,
  Gauge,
  Crown,
  Wifi,
  WifiOff,
  Loader2,
  ArrowLeft,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Device, AppRoute, SessionTab } from '../types';

interface SidebarProps {
  currentRoute: AppRoute;
  onNavigate: (route: AppRoute) => void;
  activeDevice: Device | null;
  activeSessionTab: SessionTab;
  onSessionTabChange: (tab: SessionTab) => void;
  onDisconnectSession: () => void;
  /** Live end-to-end session state used for the honest connection badge. */
  sessionLive: boolean;
  sessionConnecting: boolean;
}

type NavItem = {
  id: string;
  label: string;
  icon: React.FC<{ className?: string }>;
  route: AppRoute;
  match: (route: AppRoute) => boolean;
};

const MAIN_NAV: NavItem[] = [
  { id: 'home', label: 'Головна', icon: Home, route: '/', match: (r) => r === '/' },
  { id: 'devices', label: 'Пристрої', icon: Monitor, route: '/devices', match: (r) => r === '/devices' },
  { id: 'guide', label: 'Інструкція', icon: BookOpen, route: '/guide', match: (r) => r === '/guide' },
];

const SESSION_NAV: { id: SessionTab; label: string; icon: React.FC<{ className?: string }> }[] = [
  { id: 'info', label: 'Інфо', icon: Gauge },
  { id: 'control', label: 'Управління', icon: Sliders },
  { id: 'files', label: 'Файли', icon: FolderTree },
  { id: 'processes', label: 'Процеси', icon: Activity },
  { id: 'terminal', label: 'Термінал', icon: Terminal },
];

/**
 * FluxControl app shell. One component renders BOTH layouts:
 *  - Desktop (lg+): a fixed left sidebar — logo top, navigation middle,
 *    account + connection status pinned to the bottom.
 *  - Mobile: a compact top bar (brand + connection + avatar) and a fixed
 *    bottom tab bar (main nav, or the 5 session tabs while connected).
 */
export const Sidebar: React.FC<SidebarProps> = ({
  currentRoute,
  onNavigate,
  activeDevice,
  activeSessionTab,
  onSessionTabChange,
  onDisconnectSession,
  sessionLive,
  sessionConnecting,
}) => {
  const { user, logout, isAdmin, isSubscribed } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Grace window for short relay drops: never flash "Офлайн" on a blip.
  const [displayedOnline, setDisplayedOnline] = useState(Boolean(activeDevice?.isOnline));
  useEffect(() => {
    if (!activeDevice) return;
    if (activeDevice.isOnline || sessionLive) {
      setDisplayedOnline(true);
      return;
    }
    if (sessionConnecting) return;
    const t = window.setTimeout(() => setDisplayedOnline(false), 4000);
    return () => window.clearTimeout(t);
  }, [activeDevice?.id, activeDevice?.isOnline, sessionLive, sessionConnecting]);

  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, []);

  const go = (route: AppRoute) => {
    setMenuOpen(false);
    onNavigate(route);
  };

  const statusDot = activeDevice
    ? displayedOnline ? 'bg-emerald-400' : 'bg-red-400'
    : null;
  const statusLabel = activeDevice
    ? displayedOnline ? 'Онлайн' : 'Офлайн'
    : null;

  // ---------- Shared account block ----------
  const AccountBlock = (
    <div className="relative" ref={menuRef}>
      {user ? (
        <>
          <button
            type="button"
            onClick={() => setMenuOpen((v) => !v)}
            className="flex w-full items-center gap-2.5 rounded-2xl border border-white/[0.08] bg-white/[0.04] p-2.5 text-left transition-colors hover:border-indigo-400/40 hover:bg-white/[0.07]"
            aria-haspopup="menu"
            aria-expanded={menuOpen}
          >
            {user.photoURL || user.picture ? (
              <img src={user.photoURL || user.picture} alt="" className="h-8 w-8 shrink-0 rounded-full border border-indigo-400/50 object-cover" />
            ) : (
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full border border-indigo-400/50 bg-indigo-600/40 text-xs font-bold text-indigo-100">
                {user.name.charAt(0).toUpperCase()}
              </span>
            )}
            <span className="min-w-0 flex-1">
              <span className="block truncate text-xs font-bold text-white">{user.name}</span>
              <span className="block truncate text-[10px] font-semibold text-zinc-400">
                {isAdmin ? 'Адміністратор' : isSubscribed ? 'PRO' : 'Без підписки'}
              </span>
            </span>
            <ChevronDown className={`h-3.5 w-3.5 flex-none text-zinc-500 transition-transform ${menuOpen ? 'rotate-180' : ''}`} />
          </button>

          {menuOpen && (
            <div
              role="menu"
              className="absolute bottom-full left-0 z-50 mb-2 w-full animate-in fade-in zoom-in-95 overflow-hidden rounded-2xl border border-white/10 bg-black/95 p-1.5 shadow-2xl shadow-black/60 duration-150"
            >
              <button
                type="button"
                onClick={() => go('/profile')}
                className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-semibold text-zinc-300 transition-colors hover:bg-white/10 hover:text-white"
              >
                <UserIcon className="h-3.5 w-3.5 text-indigo-400" />
                <span>Мій профіль</span>
              </button>
              <button
                type="button"
                onClick={() => { setMenuOpen(false); logout(); }}
                className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-semibold text-red-400 transition-colors hover:bg-red-500/10 hover:text-red-300"
              >
                <LogOut className="h-3.5 w-3.5" />
                <span>Вийти з акаунта</span>
              </button>
            </div>
          )}
        </>
      ) : (
        <button
          type="button"
          onClick={() => go('/')}
          className="flex w-full items-center justify-center gap-2 rounded-2xl bg-indigo-600 px-3 py-2.5 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 transition-all hover:bg-indigo-500 active:scale-[0.98]"
        >
          <UserIcon className="h-3.5 w-3.5" />
          <span>Увійти через Google</span>
        </button>
      )}
    </div>
  );

  // ---------- Main nav list (reused by desktop + mobile) ----------
  const mainNavButtons = (compact: boolean) => (
    <>
      {MAIN_NAV.map((item) => {
        const active = item.match(currentRoute) && !activeDevice;
        return (
          <button
            key={item.id}
            type="button"
            onClick={() => go(item.route)}
            aria-current={active ? 'page' : undefined}
            className={`flex items-center rounded-xl font-semibold transition-all ${
              compact
                ? `flex-1 flex-col gap-0.5 px-1 py-1.5 text-[9px] ${active ? 'text-indigo-300' : 'text-zinc-500 hover:text-white'}`
                : `w-full gap-2.5 px-3 py-2.5 text-xs ${active ? 'bg-indigo-600/25 text-white shadow-md shadow-indigo-600/10' : 'text-zinc-400 hover:bg-white/[0.05] hover:text-white'}`
            }`}
          >
            <item.icon className={compact ? 'h-4.5 w-4.5' : 'h-4 w-4'} />
            <span className={compact ? 'whitespace-nowrap' : ''}>{item.label}</span>
          </button>
        );
      })}
      {isAdmin && (
        <button
          type="button"
          onClick={() => go('/admin')}
          className={`flex items-center rounded-xl font-semibold transition-all ${
            compact
              ? `flex-1 flex-col gap-0.5 px-1 py-1.5 text-[9px] ${currentRoute === '/admin' && !activeDevice ? 'text-amber-300' : 'text-amber-500/60 hover:text-amber-300'}`
              : `w-full gap-2.5 px-3 py-2.5 text-xs ${currentRoute === '/admin' && !activeDevice ? 'bg-amber-500/15 text-amber-200' : 'text-amber-300/70 hover:bg-amber-500/10 hover:text-amber-200'}`
          }`}
        >
          <Crown className="h-4 w-4 text-amber-400" />
          <span className={compact ? 'whitespace-nowrap' : ''}>Адмін</span>
        </button>
      )}
    </>
  );

  // ---------- Session nav (bottom bar on mobile) ----------
  const sessionNavButtons = (
    <>
      {SESSION_NAV.map((item) => {
        const active = activeSessionTab === item.id;
        return (
          <button
            key={item.id}
            type="button"
            onClick={() => onSessionTabChange(item.id)}
            aria-current={active ? 'page' : undefined}
            className={`flex flex-1 flex-col items-center gap-0.5 rounded-xl px-1 py-1.5 text-[9px] font-semibold transition-all ${
              active ? 'text-indigo-300' : 'text-zinc-500 hover:text-white'
            }`}
          >
            <item.icon className="h-4.5 w-4.5" />
            <span className="whitespace-nowrap">{item.label}</span>
          </button>
        );
      })}
    </>
  );

  return (
    <>
      {/* =================== DESKTOP SIDEBAR =================== */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[248px] flex-col border-r border-white/[0.07] bg-[#07070d]/95 backdrop-blur-xl lg:flex">
        {/* Brand */}
        <button
          type="button"
          onClick={() => go('/')}
          className="flex items-center gap-2.5 px-5 pb-2 pt-5 text-left"
        >
          <span className="grid h-9 w-9 flex-none place-items-center rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 shadow-lg shadow-indigo-600/30">
            <Zap className="h-4.5 w-4.5 fill-white text-white" />
          </span>
          <span className="bg-gradient-to-r from-white via-indigo-100 to-indigo-400 bg-clip-text text-lg font-extrabold tracking-tight text-transparent">
            FluxControl
          </span>
        </button>

        {/* Main navigation */}
        <nav className="mt-4 flex flex-col gap-1 px-3" aria-label="Основна навігація">
          {mainNavButtons(false)}
        </nav>

        {/* Active device session */}
        {activeDevice && (
          <div className="mx-3 mt-5 rounded-2xl border border-indigo-500/20 bg-indigo-950/20 p-2.5">
            <div className="mb-2 flex items-center gap-2 px-1">
              <Monitor className="h-3.5 w-3.5 flex-none text-indigo-300" />
              <span className="min-w-0 flex-1 truncate text-[11px] font-bold text-indigo-100" title={activeDevice.name}>
                {activeDevice.name}
              </span>
              <span className={`h-1.5 w-1.5 flex-none rounded-full ${statusDot} ${displayedOnline ? 'animate-pulse' : ''}`} />
            </div>
            <div className="flex flex-col gap-0.5">
              {SESSION_NAV.map((item) => {
                const active = activeSessionTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => onSessionTabChange(item.id)}
                    aria-current={active ? 'page' : undefined}
                    className={`flex items-center gap-2.5 rounded-xl px-2.5 py-2 text-xs font-semibold transition-all ${
                      active ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/25' : 'text-zinc-400 hover:bg-white/[0.06] hover:text-white'
                    }`}
                  >
                    <item.icon className="h-3.5 w-3.5 flex-none" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
            <button
              type="button"
              onClick={onDisconnectSession}
              className="mt-2 flex w-full items-center gap-2.5 rounded-xl border border-red-500/20 px-2.5 py-2 text-xs font-semibold text-red-400 transition-all hover:border-red-500/40 hover:bg-red-500/10 hover:text-red-300"
            >
              <ArrowLeft className="h-3.5 w-3.5 flex-none" />
              <span>Відключитись</span>
            </button>
          </div>
        )}

        {/* Bottom: connection status + account */}
        <div className="mt-auto space-y-2.5 px-4 pb-4 pt-3">
          {activeDevice ? (
            <div className="flex items-center gap-2 rounded-2xl border border-white/[0.07] bg-white/[0.03] px-3 py-2">
              {displayedOnline ? (
                <Wifi className="h-3.5 w-3.5 flex-none text-emerald-400" />
              ) : (
                <WifiOff className="h-3.5 w-3.5 flex-none text-red-400" />
              )}
              <span className="min-w-0 flex-1 truncate text-[10px] font-semibold text-zinc-400">
                {statusLabel}
                {sessionConnecting && displayedOnline ? ' · синхронізація…' : ''}
              </span>
              <span className={`h-1.5 w-1.5 flex-none rounded-full ${statusDot} ${displayedOnline ? 'animate-pulse' : ''}`} />
            </div>
          ) : (
            <div className="flex items-center gap-2 rounded-2xl border border-white/[0.07] bg-white/[0.03] px-3 py-2">
              <span className="h-1.5 w-1.5 flex-none rounded-full bg-indigo-400/70" />
              <span className="text-[10px] font-semibold text-zinc-500">Готово до роботи</span>
            </div>
          )}
          {AccountBlock}
        </div>
      </aside>

      {/* =================== MOBILE TOP BAR =================== */}
      <header className="fixed inset-x-0 top-0 z-50 flex h-14 items-center justify-between border-b border-white/[0.07] bg-[#07070d]/90 px-3 backdrop-blur-xl lg:hidden">
        <button type="button" onClick={() => go('/')} className="flex items-center gap-2">
          <span className="grid h-8 w-8 place-items-center rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600">
            <Zap className="h-4 w-4 fill-white text-white" />
          </span>
          <span className="text-sm font-extrabold tracking-tight text-white">FluxControl</span>
        </button>

        {activeDevice ? (
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5 rounded-full border border-white/10 bg-black/50 px-2.5 py-1">
              <span className={`h-1.5 w-1.5 rounded-full ${statusDot} ${displayedOnline ? 'animate-pulse' : ''}`} />
              <span className="max-w-[92px] truncate text-[10px] font-bold text-zinc-200">{activeDevice.name}</span>
              <span className="text-[10px] font-semibold text-zinc-500">{statusLabel}</span>
            </span>
            <button
              type="button"
              onClick={onDisconnectSession}
              title="Відключитись"
              aria-label="Відключитись від ПК"
              className="grid h-8 w-8 place-items-center rounded-xl border border-red-500/25 text-red-400 transition-colors hover:bg-red-500/10"
            >
              <LogOut className="h-3.5 w-3.5" />
            </button>
          </div>
        ) : user ? (
          <button type="button" onClick={() => go('/profile')} aria-label="Мій профіль" className="shrink-0">
            {user.photoURL || user.picture ? (
              <img src={user.photoURL || user.picture} alt="" className="h-8 w-8 rounded-full border border-indigo-400/50 object-cover" />
            ) : (
              <span className="grid h-8 w-8 place-items-center rounded-full border border-indigo-400/50 bg-indigo-600/40 text-xs font-bold text-indigo-100">
                {user.name.charAt(0).toUpperCase()}
              </span>
            )}
          </button>
        ) : (
          <button
            type="button"
            onClick={() => go('/')}
            className="rounded-full bg-indigo-600 px-3 py-1.5 text-[11px] font-bold text-white"
          >
            Увійти
          </button>
        )}
      </header>

      {/* =================== MOBILE BOTTOM TAB BAR =================== */}
      <nav
        className="fixed inset-x-0 bottom-0 z-50 border-t border-white/[0.07] bg-[#07070d]/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl lg:hidden"
        aria-label="Навігація"
      >
        <div className="flex items-stretch gap-0.5 px-2 py-1.5">
          {activeDevice ? sessionNavButtons : mainNavButtons(true)}
        </div>
      </nav>
    </>
  );
};
