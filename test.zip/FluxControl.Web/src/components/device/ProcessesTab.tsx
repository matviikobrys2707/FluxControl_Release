import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity,
  ArrowDown,
  ArrowUp,
  ArrowDownUp,
  Cpu,
  Loader2,
  MemoryStick,
  RefreshCw,
  Search,
  XCircle
} from 'lucide-react';
import { Device } from '../../types';
import { deviceClient } from '../../services/deviceClient';
import { toast } from '../../utils/toast';
import { ProcInfo, formatMemoryMb } from './fcHelpers';
import { FcConfirmModal } from './fcModals';

interface ProcessesTabProps {
  device: Device;
}

const AVATAR_STYLES = [
  'border-violet-400/30 bg-violet-500/15 text-violet-300',
  'border-emerald-400/30 bg-emerald-500/15 text-emerald-300',
  'border-amber-400/30 bg-amber-500/15 text-amber-300',
  'border-rose-400/30 bg-rose-500/15 text-rose-300',
  'border-cyan-400/30 bg-cyan-500/15 text-cyan-300',
];

function avatarStyle(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i += 1) hash = (hash * 31 + name.charCodeAt(i)) % 997;
  return AVATAR_STYLES[hash % AVATAR_STYLES.length];
}

// Task-Manager-like grouping. ЗА УМОЛЧАННЯМ — «Програми»: юзер відкриває таб,
// щоб побачити свої програми, а не 200 системних процесів.
type ProcCategory = 'all' | 'app' | 'background' | 'system';

const CATEGORY_META: { id: ProcCategory; label: string }[] = [
  { id: 'app', label: 'Програми' },
  { id: 'background', label: 'Фонові' },
  { id: 'system', label: 'Системні' },
  { id: 'all', label: 'Усі' },
];

type SortKey = 'cpu' | 'memory' | 'name' | 'pid';

function cpuColor(v: number): string {
  if (v >= 50) return 'text-rose-400';
  if (v >= 15) return 'text-amber-300';
  if (v > 0) return 'text-emerald-300';
  return 'text-zinc-500';
}

// ================= Memoized process row =================

interface ProcRowProps {
  proc: ProcInfo;
  icon: string | undefined;
  onKill: (proc: ProcInfo) => void;
}

const ProcRowView = React.memo<ProcRowProps>(({ proc, icon, onKill }) => (
  <div className="proc-row flex items-center gap-3 px-4 py-2.5">
    {icon ? (
      <img
        src={icon}
        alt=""
        loading="lazy"
        className="h-8 w-8 shrink-0 rounded-lg border border-white/10 bg-black/40 object-contain p-0.5"
      />
    ) : (
      <span
        className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg border text-xs font-black ${avatarStyle(proc.name)}`}
        aria-hidden="true"
      >
        {(proc.name || '?').charAt(0).toUpperCase()}
      </span>
    )}
    <div className="min-w-0 flex-1">
      <div className="truncate text-xs font-bold text-zinc-100">{proc.name}</div>
      {proc.exePath && <div className="truncate font-mono text-[10px] text-zinc-500">{proc.exePath}</div>}
    </div>
    <span className="hidden w-14 shrink-0 text-right font-mono text-[11px] text-violet-300/80 sm:block">
      {proc.pid}
    </span>
    <span className={`w-14 shrink-0 text-right font-mono text-[11px] font-semibold ${cpuColor(proc.cpuPercent ?? 0)}`}>
      {(proc.cpuPercent ?? 0) > 0 ? `${(proc.cpuPercent ?? 0).toFixed(1)}%` : '0%'}
    </span>
    <span className="w-20 shrink-0 text-right font-mono text-[11px] text-zinc-300">
      {formatMemoryMb(proc.memoryMb)}
    </span>
    <button
      type="button"
      title="Завершити процес"
      aria-label={`Завершити процес ${proc.name}`}
      onClick={() => onKill(proc)}
      className="proc-kill"
    >
      <XCircle className="h-4 w-4" />
    </button>
  </div>
));
ProcRowView.displayName = 'ProcRowView';

// ================= ProcessesTab =================

export const ProcessesTab: React.FC<ProcessesTabProps> = ({ device }) => {
  const [processes, setProcesses] = useState<ProcInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState<ProcCategory>('app');
  const [sortKey, setSortKey] = useState<SortKey>('memory');
  const [sortDesc, setSortDesc] = useState(true);
  const [killTarget, setKillTarget] = useState<ProcInfo | null>(null);
  // bump кожного разу, коли приходять нові іконки, щоб рядки перечитали кеш
  const [iconsBump, setIconsBump] = useState(0);

  // Icons arrive PARTIALLY (only newly extracted ones) — accumulate across
  // events in a ref, keyed by exePath (lowercase) or process name.
  const iconsRef = useRef<Record<string, string>>({});
  const gotListRef = useRef(false);
  // The very first list after agent start has no CPU baseline yet (all 0) —
  // ONE silent follow-up request 1.3s later fills the real deltas.
  const cpuRetryDoneRef = useRef(false);
  const cpuRetryTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const mergeIcons = useCallback((icons: Record<string, string> | undefined) => {
    if (icons && typeof icons === 'object' && Object.keys(icons).length) {
      Object.assign(iconsRef.current, icons);
      setIconsBump((b) => b + 1);
    }
  }, []);

  const refresh = useCallback(() => {
    setLoading(true);
    deviceClient.requestProcessList();
  }, []);

  useEffect(() => {
    const offList = deviceClient.on('process_list', (payload: any) => {
      // Backward compat: a bare array payload means no icons.
      const data = Array.isArray(payload) ? { processes: payload, icons: {} } : payload;
      const list = data && Array.isArray(data.processes)
        ? data.processes
        : data && Array.isArray(data.list)
          ? data.list
          : null;
      if (!list) {
        setLoading(false);
        return;
      }
      gotListRef.current = true;
      mergeIcons(data.icons);
      const mapped: ProcInfo[] = list.map((p: any) => ({
        pid: Number(p?.pid ?? p?.id ?? 0) || 0,
        name: String(p?.name ?? p?.processName ?? 'process'),
        exePath: p?.exePath ? String(p.exePath) : undefined,
        memoryMb: Number(p?.memoryMb ?? 0) || 0,
        cpuPercent: Number(p?.cpuPercent ?? 0) || 0,
        category: typeof p?.category === 'string' ? p.category : 'background'
      }));
      setProcesses(mapped);
      setLoading(false);

      // One silent re-request so per-process CPU% (a delta between two
      // samples) has real values instead of the initial zeros.
      if (!cpuRetryDoneRef.current && mapped.length > 0) {
        cpuRetryDoneRef.current = true;
        const hasCpu = mapped.some((p) => (p.cpuPercent ?? 0) > 0);
        if (!hasCpu) {
          if (cpuRetryTimer.current) clearTimeout(cpuRetryTimer.current);
          cpuRetryTimer.current = setTimeout(() => {
            if (gotListRef.current) deviceClient.requestProcessList();
          }, 1300);
        }
      }
    });

    // Фоновий потік іконок від агента (партіями по N штук).
    const offIcons = deviceClient.on('process_icons', (payload: any) => {
      const icons = payload && typeof payload === 'object' && !Array.isArray(payload)
        ? (payload.icons ?? payload)
        : null;
      mergeIcons(icons);
    });

    const offKill = deviceClient.on('process_kill_result', (payload: any) => {
      if (payload?.success) toast.success(`Процес (PID ${payload.pid}) завершено`, { title: 'Процес зупинено' });
      else toast.error(payload?.error || `Не вдалося завершити процес (PID ${payload?.pid ?? '?'})`);
    });

    // Request once on mount; fresh lists are pushed by the agent (e.g. after
    // a kill) or fetched manually — no polling loop.
    refresh();

    // The tab may mount before the relay socket is open (the first request is
    // then dropped) — retry once when the connection comes up.
    const offConnected = deviceClient.on('connected', () => {
      if (!gotListRef.current) refresh();
    });

    return () => {
      offList();
      offIcons();
      offKill();
      offConnected();
      if (cpuRetryTimer.current) clearTimeout(cpuRetryTimer.current);
    };
  }, [refresh, mergeIcons]);

  const getIcon = useCallback((proc: ProcInfo): string | undefined => {
    void iconsBump; // зависимость, чтобы строки перечитывали кеш после новых иконок
    const map = iconsRef.current;
    if (proc.exePath) {
      const byPath = map[proc.exePath.toLowerCase()];
      if (byPath) return byPath;
    }
    return map[proc.name.toLowerCase()];
  }, [iconsBump]);

  const requestKill = useCallback((proc: ProcInfo) => setKillTarget(proc), []);

  const confirmKill = useCallback(() => {
    const target = killTarget;
    setKillTarget(null);
    if (!target) return;
    deviceClient.sendKillProcess(target.pid);
  }, [killTarget]);

  // Counts per category for the segmented control.
  const counts = useMemo(() => {
    const c = { all: processes.length, app: 0, background: 0, system: 0 } as Record<ProcCategory, number>;
    for (const p of processes) {
      const cat = (p.category as ProcCategory) ?? 'background';
      if (cat === 'app' || cat === 'background' || cat === 'system') c[cat] += 1;
    }
    return c;
  }, [processes]);

  // Сводка по ТЕКУЩЕЙ категории: суммарный CPU и память.
  const summary = useMemo(() => {
    let cpu = 0;
    let ram = 0;
    for (const p of processes) {
      const cat = (p.category as ProcCategory) ?? 'background';
      if (category !== 'all' && cat !== category) continue;
      cpu += p.cpuPercent ?? 0;
      ram += p.memoryMb;
    }
    return { cpu: Math.min(100, Math.round(cpu)), ram };
  }, [processes, category]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    let list = processes;
    if (category !== 'all') list = list.filter((p) => (p.category ?? 'background') === category);
    if (q) list = list.filter((p) => p.name.toLowerCase().includes(q) || String(p.pid).includes(q) || (p.exePath ?? '').toLowerCase().includes(q));

    const dir = sortDesc ? -1 : 1;
    const sorted = [...list].sort((a, b) => {
      switch (sortKey) {
        case 'cpu': return ((a.cpuPercent ?? 0) - (b.cpuPercent ?? 0)) * dir;
        case 'memory': return (a.memoryMb - b.memoryMb) * dir;
        case 'name': return a.name.localeCompare(b.name, 'uk') * -dir;
        case 'pid': return (a.pid - b.pid) * dir;
        default: return 0;
      }
    });
    return sorted;
  }, [processes, search, category, sortKey, sortDesc]);

  const applySort = useCallback((key: SortKey) => {
    setSortKey((prev) => {
      if (prev === key) {
        setSortDesc((d) => !d);
        return prev;
      }
      setSortDesc(true);
      return key;
    });
  }, []);

  const SortHeader: React.FC<{ id: SortKey; label: string; className?: string }> = ({ id, label, className }) => (
    <button type="button" onClick={() => applySort(id)} className={`sort-th ${sortKey === id ? 'on' : ''} ${className ?? ''}`}>
      {label}
      {sortKey === id && (sortDesc ? <ArrowDown /> : <ArrowUp />)}
    </button>
  );

  return (
    <div className="space-y-4">
      {/* Header + toolbar */}
      <section className="fc-card-static p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="fc-section-head">
            <span className="fc-section-icon">
              <Activity className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <h3>Процеси</h3>
              <p className="truncate">{device.name}</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="fc-badge fc-badge-info"><Cpu className="h-3 w-3" /> {summary.cpu}% ЦП</span>
            <span className="fc-badge fc-badge-info"><MemoryStick className="h-3 w-3" /> {formatMemoryMb(summary.ram)}</span>
            <button type="button" className="fc-btn fc-btn-ghost fc-btn-sm" onClick={refresh} aria-label="Оновити список процесів">
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">Оновити</span>
            </button>
          </div>
        </div>
        <div className="relative mt-3.5">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
          <input
            className="fc-input pl-9"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Пошук за назвою або PID…"
            aria-label="Пошук процесу"
          />
        </div>

        {/* Category segmented control — за замовчуванням «Програми» */}
        <div className="seg-tabs mt-3" role="tablist" aria-label="Категорії процесів">
          {CATEGORY_META.map((c) => (
            <button
              key={c.id}
              role="tab"
              aria-selected={category === c.id}
              onClick={() => setCategory(c.id)}
              className={`seg-tab ${category === c.id ? 'active' : ''}`}
            >
              <span>{c.label}</span>
              <span className="seg-count">{counts[c.id]}</span>
            </button>
          ))}
        </div>
      </section>

      {/* Process list */}
      <section className="fc-card-static overflow-hidden">
        <div className="hidden items-center gap-3 border-b border-white/5 bg-black/30 px-4 py-2 sm:flex">
          <span className="h-8 w-8 shrink-0" />
          <SortHeader id="name" label="Процес" className="flex-1 !justify-start" />
          <SortHeader id="pid" label="PID" className="w-14" />
          <SortHeader id="cpu" label="ЦП" className="w-14" />
          <SortHeader id="memory" label="Пам'ять" className="w-20" />
          <span className="h-8 w-8 shrink-0" />
        </div>

        {/* Mobile sort chips (columns are hidden on phones) */}
        <div className="flex items-center gap-1.5 overflow-x-auto border-b border-white/5 bg-black/30 px-3 py-2 text-[11px] text-zinc-500 sm:hidden">
          <ArrowDownUp className="h-3.5 w-3.5 flex-none" />
          {([
            { id: 'memory', label: "Пам'ять" },
            { id: 'cpu', label: 'ЦП' },
            { id: 'name', label: "Ім'я" },
            { id: 'pid', label: 'PID' },
          ] as { id: SortKey; label: string }[]).map((s) => (
            <button
              key={s.id}
              onClick={() => applySort(s.id)}
              aria-pressed={sortKey === s.id}
              className={`flex-none rounded-lg border px-2.5 py-1 font-bold transition-all ${
                sortKey === s.id
                  ? 'border-violet-400/50 bg-violet-600/25 text-white'
                  : 'border-white/10 bg-white/[0.03] text-zinc-400'
              }`}
            >
              {s.label}
              {sortKey === s.id && <span className="ml-1">{sortDesc ? '↓' : '↑'}</span>}
            </button>
          ))}
        </div>

        {loading && processes.length === 0 ? (
          <div className="divide-y divide-white/[0.04]">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="flex animate-pulse items-center gap-3 px-4 py-3">
                <div className="h-8 w-8 rounded-lg bg-white/5" />
                <div className="h-3 max-w-[35%] flex-1 rounded bg-white/5" />
                <div className="h-3 w-12 rounded bg-white/5" />
                <div className="h-3 w-10 rounded bg-white/5" />
                <div className="h-3 w-12 rounded bg-white/5" />
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center gap-3 px-6 py-14 text-center">
            <span className="grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-black/40 text-zinc-500">
              <Activity className="h-6 w-6" />
            </span>
            <p className="text-xs font-semibold text-zinc-400">
              {processes.length === 0
                ? 'Список процесів порожній або ПК не відповідає'
                : category !== 'all' && !search.trim()
                  ? `У категорії «${CATEGORY_META.find((c) => c.id === category)?.label}» нічого немає — переключіть фільтр`
                  : `Нічого не знайдено за запитом «${search.trim()}»`}
            </p>
            {processes.length === 0 && (
              <Loader2 className="h-4 w-4 animate-spin text-violet-300" />
            )}
          </div>
        ) : (
          <div className="max-h-[32rem] divide-y divide-white/[0.04] overflow-y-auto">
            {filtered.map((proc) => (
              <ProcRowView key={`${proc.pid}|${proc.name}`} proc={proc} icon={getIcon(proc)} onKill={requestKill} />
            ))}
          </div>
        )}
      </section>

      {/* Kill confirmation */}
      <FcConfirmModal
        open={!!killTarget}
        title="Завершити процес?"
        message={
          killTarget
            ? `Процес «${killTarget.name}» (PID ${killTarget.pid}) буде примусово завершено на віддаленому ПК.`
            : ''
        }
        confirmLabel="Завершити"
        onConfirm={confirmKill}
        onCancel={() => setKillTarget(null)}
      />
    </div>
  );
};
