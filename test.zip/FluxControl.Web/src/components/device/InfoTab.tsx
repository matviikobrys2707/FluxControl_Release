import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Activity,
  Clock,
  Cpu,
  Disc3,
  Download,
  Gauge,
  Globe,
  HardDrive,
  Layers,
  Monitor,
  RefreshCw,
  Server,
  Timer,
  Upload,
  Usb,
  Wifi,
  Zap
} from 'lucide-react';
import { Device, DeviceMetrics, DiskInfo, SpeedTestResult } from '../../types';
import { deviceClient } from '../../services/deviceClient';
import { toast } from '../../utils/toast';
import { pick } from './fcEvents';

interface InfoTabProps {
  device: Device;
  /** Live metrics accessor — telemetry is stored in a ref up the tree to keep this tab the only re-rendering part. */
  getMetrics: () => DeviceMetrics | null;
  hasTelemetry?: boolean;
  /** Live end-to-end session status from the WebSocket client. */
  sessionLive?: boolean;
}

/** Smart size formatting: small drives must show MB, not “0.05 GB”. */
export const formatSmartSize = (bytes?: number, fallbackGb?: number): string => {
  if (bytes !== undefined && bytes !== null && bytes > 0) {
    if (bytes >= 1024 ** 4) return `${(bytes / 1024 ** 4).toFixed(2)} ТБ`;
    if (bytes >= 1024 ** 3) return `${(bytes / 1024 ** 3).toFixed(bytes >= 10 * 1024 ** 3 ? 0 : 1)} ГБ`;
    if (bytes >= 1024 ** 2) return `${(bytes / 1024 ** 2).toFixed(0)} МБ`;
    if (bytes >= 1024) return `${(bytes / 1024).toFixed(0)} КБ`;
    return `${bytes} Б`;
  }
  if (fallbackGb !== undefined && fallbackGb > 0) {
    if (fallbackGb < 0.01) return `${Math.round(fallbackGb * 1024 * 1024)} МБ`;
    if (fallbackGb < 1) return `${Math.round(fallbackGb * 1024)} МБ`;
    return `${Number(fallbackGb.toFixed(fallbackGb >= 10 ? 0 : 1))} ГБ`;
  }
  return '—';
};

/** "Останній тест: сьогодні о 09:24" — людський час останнього заміру. */
const formatSpeedTestTime = (ts?: number): string => {
  if (!ts) return '';
  const d = new Date(ts);
  const now = new Date();
  const time = d.toLocaleTimeString('uk-UA', { hour: '2-digit', minute: '2-digit' });
  const sameDay = d.toDateString() === now.toDateString();
  if (sameDay) return `сьогодні о ${time}`;
  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  if (d.toDateString() === yesterday.toDateString()) return `вчора о ${time}`;
  const date = d.toLocaleDateString('uk-UA', { day: 'numeric', month: 'short' });
  return `${date} о ${time}`;
};

const formatDuration = (ms?: number): string => {
  if (!ms || ms <= 0) return '';
  const total = Math.round(ms / 1000);
  return ` · ${Math.floor(total / 60)} хв ${total % 60} с`;
};

const tempColor = (t: number): string => (t >= 85 ? 'text-rose-400' : t >= 70 ? 'text-amber-300' : 'text-emerald-300');

const DiskIcon: React.FC<{ disk: DiskInfo }> = ({ disk }) => {
  if (disk.driveType === 'removable') return <Usb className="h-5 w-5 text-cyan-300" />;
  if (disk.driveType === 'network') return <Server className="h-5 w-5 text-amber-300" />;
  return <HardDrive className="h-5 w-5 text-indigo-300" />;
};

const MetricRow: React.FC<{ label: string; children: React.ReactNode }> = ({ label, children }) => (
  <div className="flex justify-between gap-3 text-xs text-zinc-400">
    <span className="flex-none">{label}</span>
    <span className="min-w-0 break-words text-right font-medium text-zinc-200">{children}</span>
  </div>
);

export const InfoTab: React.FC<InfoTabProps> = React.memo(({ device, getMetrics, hasTelemetry, sessionLive = true }) => {
  const [metrics, setMetrics] = useState<DeviceMetrics | null>(() => getMetrics?.() ?? null);
  const [networkInfo, setNetworkInfo] = useState<any>(null);
  const [speedTest, setSpeedTest] = useState<SpeedTestResult | null>(() => getMetrics?.()?.speedTest ?? null);
  const [speedRunning, setSpeedRunning] = useState(false);
  const [speedStage, setSpeedStage] = useState<string>('');
  const mountedRef = useRef(true);
  // Distinguish a manual run (button) from the automatic startup run so the
  // completion toast fires only for user-initiated tests.
  const manualRunRef = useRef(false);

  // Subscribe to live telemetry. Metrics flow through a ref in the parent, so
  // this setState re-renders ONLY this tab (about once per second), never the
  // whole session view — that was the lag source on the Control tab.
  useEffect(() => {
    mountedRef.current = true;
    const applyMetrics = (raw: any) => {
      const m = (pick<any>(raw) ?? undefined) as DeviceMetrics | undefined;
      if (!mountedRef.current || !m) return;
      setMetrics(m);
      if (m.speedTest !== undefined) setSpeedTest(m.speedTest ?? null);
    };
    const unsubMetrics = deviceClient.on('metrics', applyMetrics);
    const unsubTelemetry = deviceClient.on('telemetry', applyMetrics);
    const unsubNet = deviceClient.on('network_info', (n) => {
      if (mountedRef.current) setNetworkInfo(pick<any>(n));
    });
    const unsubSpeed = deviceClient.on('speedtest_result', (r: any) => {
      if (!mountedRef.current) return;
      const data = pick<any>(r);
      if (data?.running) {
        setSpeedRunning(true);
        setSpeedStage(data.stage || '');
        return;
      }
      setSpeedRunning(false);
      setSpeedStage('');
      if (data && !data.error) {
        setSpeedTest(data);
        if (manualRunRef.current) {
          manualRunRef.current = false;
          const dl = typeof data.downloadMbps === 'number' ? `${data.downloadMbps.toFixed(1)} Мбіт/с ↓` : '—';
          const ul = typeof data.uploadMbps === 'number' ? `${data.uploadMbps.toFixed(1)} Мбіт/с ↑` : '—';
          const ping = typeof data.pingMs === 'number' ? ` · ${data.pingMs} мс` : '';
          toast.success(`Speedtest: ${dl} / ${ul}${ping}`);
        }
      } else if (data?.error) {
        if (manualRunRef.current) {
          manualRunRef.current = false;
          toast.error(`Speedtest не вдався: ${data.error}`);
        }
        setSpeedTest(data);
      }
    });
    const unsubProgress = deviceClient.on('speedtest_progress', (r: any) => {
      if (!mountedRef.current) return;
      const data = pick<any>(r);
      setSpeedRunning(true);
      setSpeedStage(data?.stage || '');
    });

    deviceClient.send('ping', {});
    deviceClient.send('get_network_info', {});

    return () => {
      mountedRef.current = false;
      unsubMetrics();
      unsubTelemetry();
      unsubNet();
      unsubSpeed();
      unsubProgress();
    };
  }, []);

  const handleRunSpeedTest = useCallback(() => {
    if (speedRunning) return;
    setSpeedRunning(true);
    setSpeedStage('підготовка…');
    manualRunRef.current = true;
    deviceClient.send('run_speedtest', {});
    // Safety: if the agent never answers, unlock the button again.
    setTimeout(() => {
      if (mountedRef.current) {
        setSpeedRunning(current => {
          if (current) manualRunRef.current = false;
          return current ? false : current;
        });
      }
    }, 75000);
  }, [speedRunning]);

  // Real CPU data from agent
  const cpuVal = Math.min(100, Math.max(0, Math.round(metrics?.cpuUsage ?? metrics?.cpuPercent ?? 0)));
  // Full model name — never truncated (the user could not read long names).
  const cpuModel = metrics?.cpuName || metrics?.cpuModel || device.cpuInfo || 'Процесор ПК';
  const rawCpuTemp = metrics?.cpuTempC ?? metrics?.cpuTemp ?? null;
  // TEMPERATURE RULE: no sensor / zero reading → the row is not rendered at all.
  const cpuTemp = typeof rawCpuTemp === 'number' && rawCpuTemp > 0 ? rawCpuTemp : null;
  const cpuCores = metrics?.cpuCores ?? null;
  const cpuThreads = metrics?.cpuThreads ?? null;

  // Real GPU data from agent
  const gpuVal = Math.min(100, Math.max(0, Math.round(metrics?.gpuUsage ?? 0)));
  const gpuModel = metrics?.gpuName || metrics?.gpuModel || device.gpuInfo || 'Графічний процесор';
  const rawGpuTemp = metrics?.gpuTemp ?? null;
  const gpuTemp = typeof rawGpuTemp === 'number' && rawGpuTemp > 0 ? rawGpuTemp : null;
  const gpuVramUsed = metrics?.gpuVramUsedGb ?? null;
  const gpuVramTotal = metrics?.gpuVramTotalGb ?? null;
  const gpuSharedUsed = metrics?.gpuSharedUsedGb ?? null;
  const gpuSharedTotal = metrics?.gpuSharedTotalGb ?? null;
  const gpuCoreClock = metrics?.gpuClockCoreMhz ?? null;
  const gpuMemoryClock = metrics?.gpuClockMemMhz ?? null;

  // Real RAM data from agent
  const ramVal = Math.min(100, Math.max(0, Math.round(metrics?.ramUsage ?? metrics?.ramPercent ?? 0)));
  const ramTotal = metrics?.ramTotalGb ?? (device.ramInfo ? parseFloat(device.ramInfo) : 0);
  const ramUsed = metrics?.ramUsedGb ?? (ramTotal > 0 && ramVal > 0 ? Number(((ramTotal * ramVal) / 100).toFixed(1)) : 0);
  const ramSpeed = metrics?.ramSpeed || '';
  // Тип і частота ОЗУ окремо. Нові агенти шлють RamType/RamFreqMhz; для
  // старих агентів розпарсимо «DDR4 @ 1600 MHz» з ramSpeed.
  const parsedSpeed = ramSpeed.match(/^(.*?DDR\d*)\s*@\s*(\d+)\s*MHz/i);
  const ramType = metrics?.ramType || (parsedSpeed?.[1]?.trim() || (/DDR\d/.test(ramSpeed) ? ramSpeed.match(/DDR\d/i)?.[0] : '')) || '';
  const ramFreq = metrics?.ramFreqMhz || (parsedSpeed ? Number(parsedSpeed[2]) : 0);

  // Real Disks from agent
  const disks: DiskInfo[] = Array.isArray(metrics?.disks) ? metrics!.disks! : [];
  const lanIp = networkInfo?.lanIp || metrics?.lanIp || device.lanIp || '';
  const wanIp = networkInfo?.wanIp || metrics?.wanIp || device.wanIp || '';

  const getDiskBarColor = (pct: number) => {
    if (pct >= 85) return 'from-rose-500 to-red-600';
    if (pct >= 60) return 'from-amber-500 to-yellow-500';
    return 'from-indigo-500 to-purple-600';
  };

  return (
    <div className="space-y-6">

      {/* Top PC Overview Banner */}
      <div className="fc-card flex flex-col items-start justify-between gap-4 bg-[#090b14]/90 p-6 sm:flex-row sm:items-center">
        <div className="flex items-center gap-4">
          <div className="grid place-items-center rounded-2xl border border-indigo-500/30 bg-indigo-600/20 p-3.5 text-indigo-400">
            <Monitor className="h-7 w-7" />
          </div>
          <div>
            <h2 className="text-xl font-black text-white sm:text-2xl">
              {device.name || metrics?.machineName || 'Мій ПК'}
            </h2>
            <p className="mt-0.5 font-mono text-xs text-zinc-400">
              {metrics?.userName || 'Користувач'} • {device.osInfo || metrics?.osVersion || 'Windows'}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {sessionLive ? (
            <span className="flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/15 px-3 py-1 text-xs font-bold text-emerald-400">
              <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-400" />
              <span>В мережі</span>
            </span>
          ) : (
            <span className="flex items-center gap-1.5 rounded-full border border-amber-500/30 bg-amber-500/15 px-3 py-1 text-xs font-bold text-amber-400">
              <span className="h-2 w-2 animate-pulse rounded-full bg-amber-400" />
              <span>З&apos;єднання втрачено — перепідключення…</span>
            </span>
          )}
          {metrics?.uptime && (
            <span className="flex items-center gap-1.5 rounded-full border border-white/10 bg-black/60 px-3 py-1 text-xs font-bold text-zinc-300">
              <Clock className="h-3.5 w-3.5 text-indigo-400" />
              <span>Аптайм: {metrics.uptime}</span>
            </span>
          )}
        </div>
      </div>

      {/* Hardware Cards Grid */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">

        {/* 1. CPU Card */}
        <div className="fc-card flex flex-col justify-between bg-[#090b14]/80 p-6">
          <div>
            <div className="fc-section-head mb-4">
              <div className="fc-section-icon"><Cpu className="h-5 w-5" /></div>
              <div className="min-w-0">
                <h3>Процесор (CPU)</h3>
                <p className="break-words leading-snug" title={cpuModel}>{cpuModel}</p>
              </div>
              <span className="ml-auto flex-none font-mono text-2xl font-black text-white">{cpuVal}%</span>
            </div>

            <div className="mb-4 h-2.5 w-full overflow-hidden rounded-full border border-white/10 bg-black/70 p-0.5">
              <div
                className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 transition-all duration-700"
                style={{ width: `${cpuVal}%` }}
              />
            </div>
          </div>

          <div className="space-y-1.5 border-t border-white/10 pt-3">
            {(cpuCores !== null || cpuThreads !== null) && (
              <MetricRow label="Ядра / Потоки:">{cpuCores ?? '—'} / {cpuThreads ?? '—'}</MetricRow>
            )}
            {/* Temperature row is rendered ONLY when a real sensor value exists. */}
            {cpuTemp !== null && (
              <MetricRow label="Температура:">
                <span className={`font-mono ${tempColor(cpuTemp)}`}>~{cpuTemp}°C</span>
              </MetricRow>
            )}
          </div>
        </div>

        {/* 2. GPU Card */}
        <div className="fc-card flex flex-col justify-between bg-[#090b14]/80 p-6">
          <div>
            <div className="fc-section-head mb-4">
              <div className="fc-section-icon"><Zap className="h-5 w-5" /></div>
              <div className="min-w-0">
                <h3>Відеокарта (GPU)</h3>
                <p className="break-words leading-snug" title={gpuModel}>{gpuModel}</p>
              </div>
              <span className="ml-auto flex-none font-mono text-2xl font-black text-white">{gpuVal}%</span>
            </div>

            <div className="mb-4 h-2.5 w-full overflow-hidden rounded-full border border-white/10 bg-black/70 p-0.5">
              <div
                className="h-full rounded-full bg-gradient-to-r from-purple-500 to-pink-600 transition-all duration-700"
                style={{ width: `${gpuVal}%` }}
              />
            </div>
          </div>

          <div className="space-y-1.5 border-t border-white/10 pt-3">
            {gpuTemp !== null && (
              <MetricRow label="Температура:">
                <span className={`font-mono ${gpuTemp >= 85 ? 'text-rose-400' : gpuTemp >= 70 ? 'text-amber-300' : 'text-purple-300'}`}>~{gpuTemp}°C</span>
              </MetricRow>
            )}
            {/* Dedicated VRAM (discrete cards) */}
            {gpuVramTotal !== null && gpuVramTotal > 0 && (
              <MetricRow label="Відеопам&apos;ять:">
                {formatSmartSize(undefined, gpuVramUsed ?? 0)} з {formatSmartSize(undefined, gpuVramTotal)}
              </MetricRow>
            )}
            {!gpuVramTotal && metrics?.gpuVram && (
              <MetricRow label="Відеопам&apos;ять:">{metrics.gpuVram}</MetricRow>
            )}
            {gpuCoreClock ? (
              <MetricRow label="Частота ядра:"><span className="font-mono">{gpuCoreClock} MHz</span></MetricRow>
            ) : null}
            {gpuMemoryClock ? (
              <MetricRow label="Частота пам&apos;яті:"><span className="font-mono">{gpuMemoryClock} MHz</span></MetricRow>
            ) : null}
          </div>
        </div>

        {/* 3. RAM Card */}
        <div className="fc-card flex flex-col justify-between bg-[#090b14]/80 p-6">
          <div>
            <div className="fc-section-head mb-4">
              <div className="fc-section-icon"><Layers className="h-5 w-5" /></div>
              <div>
                <h3>Пам&apos;ять (RAM)</h3>
                <p>{ramTotal > 0 ? `${ramUsed} ГБ з ${ramTotal} ГБ` : 'Оперативна пам&apos;ять'}</p>
              </div>
              <span className="ml-auto flex-none font-mono text-2xl font-black text-white">{ramVal}%</span>
            </div>

            <div className="mb-4 h-2.5 w-full overflow-hidden rounded-full border border-white/10 bg-black/70 p-0.5">
              <div
                className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 transition-all duration-700"
                style={{ width: `${ramVal}%` }}
              />
            </div>
          </div>

          <div className="space-y-1.5 border-t border-white/10 pt-3">
            {/* ЗА ФІДБЕКОМ: без «Всього/Використано/Відсоток» — це видно на
                шапці картки та прогрес-барі. Замість них частота і тип. */}
            {ramFreq > 0 && (
              <MetricRow label="Частота пам&apos;яті:"><span className="font-mono text-emerald-300">{ramFreq} МГц</span></MetricRow>
            )}
            {ramType && (
              <MetricRow label="Тип пам&apos;яті:">
                <span className="rounded-lg border border-emerald-500/25 bg-emerald-500/10 px-2 py-0.5 font-mono text-[10px] font-bold text-emerald-300">{ramType}</span>
              </MetricRow>
            )}
            {!ramFreq && !ramType && ramSpeed && (
              <MetricRow label="Пам&apos;ять:"><span className="font-mono text-emerald-300">{ramSpeed}</span></MetricRow>
            )}
          </div>
        </div>

      </div>

      {/* Network & Speedtest Card */}
      <div className="fc-card bg-[#090b14]/80 p-6">
        <div className="fc-section-head mb-5 flex-wrap gap-3">
          <div className="fc-section-icon"><Wifi className="h-5 w-5" /></div>
          <div>
            <h3>Мережа та Інтернет</h3>
            <p>IP-адреси та швидкість з&apos;єднання</p>
          </div>
          <button
            onClick={handleRunSpeedTest}
            disabled={speedRunning || !sessionLive}
            className="fc-btn fc-btn-primary ml-auto disabled:cursor-not-allowed disabled:opacity-50"
          >
            {speedRunning ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Gauge className="h-3.5 w-3.5" />}
            <span>{speedRunning ? 'Вимірювання…' : 'Запустити Speedtest'}</span>
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-5">
          <div className="fc-card-static space-y-1 p-4">
            <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wide text-zinc-400">
              <Globe className="h-3.5 w-3.5 text-cyan-300" /> Внутрішній IP
            </div>
            <p className="break-all font-mono text-sm text-white">{lanIp || '—'}</p>
          </div>
          <div className="fc-card-static space-y-1 p-4">
            <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wide text-zinc-400">
              <Server className="h-3.5 w-3.5 text-cyan-300" /> Зовнішній IP
            </div>
            <p className="break-all font-mono text-sm text-white">{wanIp || '—'}</p>
          </div>
          <div className="fc-card-static space-y-1 p-4">
            <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wide text-zinc-400">
              <Download className="h-3.5 w-3.5 text-emerald-400" /> Завантаження
            </div>
            <p className="font-mono text-sm text-white">
              {speedTest?.downloadMbps !== undefined ? `${speedTest.downloadMbps.toFixed(1)} Мбіт/с` : '—'}
            </p>
          </div>
          <div className="fc-card-static space-y-1 p-4">
            <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wide text-zinc-400">
              <Upload className="h-3.5 w-3.5 text-indigo-300" /> Віддача
            </div>
            <p className="font-mono text-sm text-white">
              {speedTest?.uploadMbps !== undefined ? `${speedTest.uploadMbps.toFixed(1)} Мбіт/с` : '—'}
            </p>
          </div>
          <div className="fc-card-static space-y-1 p-4">
            <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wide text-zinc-400">
              <Activity className="h-3.5 w-3.5 text-cyan-300" /> Пінг
            </div>
            <p className="font-mono text-sm text-white">
              {speedTest?.pingMs !== undefined ? `${speedTest.pingMs} мс` : '—'}
            </p>
          </div>
        </div>

        {speedRunning && (
          <div className="mt-4 flex items-center gap-2 rounded-2xl border border-cyan-500/25 bg-cyan-950/30 p-3 text-xs text-cyan-200">
            <Activity className="h-4 w-4 animate-pulse" />
            <span>Тестування швидкості: {speedStage || 'вимірювання каналу…'}</span>
          </div>
        )}
        {!speedRunning && speedTest?.timestamp && !speedTest.error && (
          <div className="mt-4 flex flex-wrap items-center gap-2 text-[11px] text-zinc-500">
            <Timer className="h-3.5 w-3.5" />
            <span>Останній тест: {formatSpeedTestTime(speedTest.timestamp)}{formatDuration(speedTest.durationMs)}</span>
            {/* Режим запуску: manually pressed button vs the automatic startup test. */}
            {speedTest.mode === 'manual' ? (
              <span className="fc-badge fc-badge-ok">
                <Gauge className="h-3 w-3" /> запущено вручну
              </span>
            ) : speedTest.mode === 'auto' ? (
              <span className="fc-badge fc-badge-info">
                <Zap className="h-3 w-3" /> автоматично при підключенні
              </span>
            ) : null}
          </div>
        )}
        {speedTest?.error && (
          <div className="mt-4 text-[11px] text-amber-300">{speedTest.error}</div>
        )}
      </div>

      {/* Disks Real Storage Grid */}
      {disks.length > 0 && (
        <div className="fc-card bg-[#090b14]/80 p-6">
          <div className="fc-section-head mb-5">
            <div className="fc-section-icon"><Disc3 className="h-5 w-5" /></div>
            <div>
              <h3>Накопичувачі та диски</h3>
              <p>Фактичний обсяг пам&apos;яті на машині</p>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
            {disks.map((d, i) => (
              <div key={i} className="fc-card-static space-y-2 p-4">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex min-w-0 items-center gap-2.5">
                    <div className="flex-none rounded-lg border border-white/10 bg-white/5 p-1.5">
                      <DiskIcon disk={d} />
                    </div>
                    <div className="min-w-0">
                      <span className="flex items-center gap-1.5">
                        <span className="truncate font-mono font-bold text-white">{d.name}</span>
                        {d.mediaType && (
                          <span className={`flex-none rounded-md px-1.5 py-0.5 text-[9px] font-black uppercase tracking-wide ${
                            d.mediaType === 'SSD' || d.mediaType === 'NVMe'
                              ? 'border border-emerald-500/25 bg-emerald-500/10 text-emerald-300'
                              : d.mediaType === 'HDD'
                                ? 'border border-amber-500/25 bg-amber-500/10 text-amber-300'
                                : 'border border-white/10 bg-white/5 text-zinc-300'
                          }`}>{d.mediaType}</span>
                        )}
                      </span>
                      {d.model || d.label ? (
                        <span className="block max-w-full truncate text-[10px] text-zinc-500" title={d.model || d.label}>
                          {d.model || d.label}
                        </span>
                      ) : null}
                    </div>
                  </div>
                  <span className="flex-none font-mono text-xs text-zinc-300">{d.percentUsed}%</span>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
                  <div
                    className={`h-full rounded-full bg-gradient-to-r ${getDiskBarColor(d.percentUsed)}`}
                    style={{ width: `${d.percentUsed}%` }}
                  />
                </div>
                <div className="flex justify-between text-[11px] text-zinc-400">
                  {/* Smart units: a 50 MB test drive shows “50 МБ”, not “0,05 ГБ” */}
                  <span>Вільно: {formatSmartSize(d.freeBytes, d.freeGb)}</span>
                  <span>Всього: {formatSmartSize(d.totalBytes, d.totalGb)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
});
