import React, { useEffect, useRef, useState } from 'react';
import {
  Clock,
  Globe,
  KeyRound,
  Lock,
  Shield,
  ShieldAlert,
  Unlock,
  Loader2
} from 'lucide-react';
import { WinLockMode, WinLockState } from '../../types';
import { deviceClient } from '../../services/deviceClient';
import { toast } from '../../utils/toast';
import { pick } from './fcEvents';

/**
 * WinLock — remote PC lockdown.
 *
 * Unlocked: a card with a big "Заблокувати ПК" button that opens a modal
 * with two unlock modes (unlock code / site-only).
 * Locked: a red-tinted card with the mode label, time since lock and a
 * danger "Розблокувати" button behind a confirmation modal.
 *
 * The agent is the source of truth: every `winlock_state` event updates
 * the card, even when the state changes while the user is on another tab.
 */

const MIN_CODE_LEN = 4;

const formatElapsed = (from: number, now: number): string => {
  const mins = Math.max(0, Math.floor((now - from) / 60000));
  if (mins < 1) return 'щойно';
  if (mins < 60) return `${mins} хв тому`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} год ${mins % 60} хв тому`;
  return `${Math.floor(hours / 24)} дн тому`;
};

export const WinLockCard: React.FC = React.memo(() => {
  const [state, setState] = useState<WinLockState | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [mode, setMode] = useState<WinLockMode>('code');
  const [code, setCode] = useState('');
  const [repeat, setRepeat] = useState('');
  const [unlockConfirm, setUnlockConfirm] = useState(false);
  const [now, setNow] = useState(() => Date.now());

  // Read inside the socket handler without re-subscribing on dialog changes.
  const dialogOpenRef = useRef(false);
  useEffect(() => { dialogOpenRef.current = dialogOpen; }, [dialogOpen]);

  // Initial state request + live state subscription.
  useEffect(() => {
    let alive = true;
    const unsub = deviceClient.on('winlock_state', (raw: any) => {
      if (!alive) return;
      const s = pick<WinLockState>(raw);
      if (s && typeof s === 'object' && typeof s.locked === 'boolean') {
        setState(s);
        // The PC got locked while the dialog was open — nothing to configure.
        if (s.locked && dialogOpenRef.current) {
          setDialogOpen(false);
          setCode('');
          setRepeat('');
        }
        // It got unlocked meanwhile — drop any pending confirmation.
        if (!s.locked) setUnlockConfirm(false);
      }
    });
    deviceClient.sendWinLockGet();
    return () => { alive = false; unsub(); };
  }, []);

  // "Time since locked" ticks once per 30 s ONLY while it is displayed.
  useEffect(() => {
    if (!state?.locked || !state.lockedAt) return;
    setNow(Date.now());
    const t = window.setInterval(() => setNow(Date.now()), 30000);
    return () => window.clearInterval(t);
  }, [state?.locked, state?.lockedAt]);

  // Escape closes any open dialog.
  useEffect(() => {
    if (!dialogOpen && !unlockConfirm) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { setDialogOpen(false); setUnlockConfirm(false); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [dialogOpen, unlockConfirm]);

  const codeValid = mode === 'site' || (code.trim().length >= MIN_CODE_LEN && code === repeat);

  const confirmLock = () => {
    deviceClient.sendWinLockLock(mode, mode === 'code' ? code.trim() : undefined);
    toast.info('Блокування надіслано…');
    setDialogOpen(false);
    setCode('');
    setRepeat('');
  };

  const confirmUnlock = () => {
    deviceClient.sendWinLockUnlock();
    toast.success('Команду розблокування надіслано');
    setUnlockConfirm(false);
  };

  const locked = state?.locked === true;
  const modeLabel = (state?.mode === 'site' || state?.unlockViaSite)
    ? 'лише сайт'
    : 'код';

  return (
    <section className={locked
      ? 'relative overflow-hidden rounded-3xl border border-rose-500/45 bg-gradient-to-br from-rose-950/60 via-[#150a10] to-[#0a0a12] p-5 shadow-[0_18px_60px_-16px_rgba(225,29,72,.65)]'
      : 'fc-card p-5'}>
      {/* мягкое свечение в заблокированном состоянии */}
      {locked && (
        <>
          <div className="pointer-events-none absolute -right-14 -top-14 h-44 w-44 rounded-full bg-rose-600/25 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-16 -left-10 h-36 w-36 rounded-full bg-rose-700/15 blur-3xl" />
        </>
      )}

      {/* Header */}
      <div className="fc-section-head relative">
        <div className={locked
          ? 'grid h-[2.35rem] w-[2.35rem] flex-none place-items-center rounded-[.85rem] border border-rose-400/45 bg-rose-500/25 text-rose-300 shadow-[0_0_30px_-6px_rgba(225,29,72,.8)]'
          : 'fc-section-icon fc-icon-cyan'}>
          {locked ? <ShieldAlert className="h-5 w-5" /> : <Shield className="h-5 w-5" />}
        </div>
        <div className="min-w-0">
          <h3>WinLock — блокування ПК</h3>
          <p>Повноекранне блокування; розблокування кодом або лише з сайту</p>
        </div>
        <span className="ml-auto flex-none">
          {state === null ? (
            <span className="fc-badge fc-badge-info"><Loader2 className="h-3 w-3 animate-spin" /> стан…</span>
          ) : locked ? (
            <span className="fc-badge fc-badge-err"><ShieldAlert className="h-3 w-3" /> ПК заблоковано</span>
          ) : (
            <span className="fc-badge fc-badge-ok"><Shield className="h-3 w-3" /> розблоковано</span>
          )}
        </span>
      </div>

      {!locked ? (
        <div className="relative mt-4 space-y-3">
          {/* Режими — клікабельні картки, вибір запам'ятовується для діалогу */}
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
            <button
              type="button"
              onClick={() => setMode('code')}
              aria-pressed={mode === 'code'}
              className={`fc-radio-card ${mode === 'code' ? 'active' : ''}`}
            >
              <span className="flex items-center gap-3">
                <span className="grid h-10 w-10 flex-none place-items-center rounded-xl border border-indigo-400/30 bg-indigo-500/15 text-indigo-300">
                  <KeyRound className="h-[18px] w-[18px]" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-[11px] font-extrabold text-white">Код розблокування</span>
                  <span className="mt-0.5 block text-[10px] leading-snug text-zinc-400">Код вводиться на заблокованому ПК</span>
                </span>
                <span className={`fc-radio-dot ${mode === 'code' ? 'on' : ''}`} />
              </span>
            </button>
            <button
              type="button"
              onClick={() => setMode('site')}
              aria-pressed={mode === 'site'}
              className={`fc-radio-card ${mode === 'site' ? 'active' : ''}`}
            >
              <span className="flex items-center gap-3">
                <span className="grid h-10 w-10 flex-none place-items-center rounded-xl border border-cyan-400/30 bg-cyan-500/15 text-cyan-300">
                  <Globe className="h-[18px] w-[18px]" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-[11px] font-extrabold text-white">Тільки через сайт</span>
                  <span className="mt-0.5 block text-[10px] leading-snug text-zinc-400">Розблокування можливе лише тут</span>
                </span>
                <span className={`fc-radio-dot ${mode === 'site' ? 'on' : ''}`} />
              </span>
            </button>
          </div>
          <button
            onClick={() => { setCode(''); setRepeat(''); setDialogOpen(true); }}
            className="pwr-tile fc-shine w-full !py-3.5 wl-lock-btn"
          >
            <span className="pwr-ico !h-10 !w-10"><Lock className="h-[18px] w-[18px]" /></span>
            <span className="min-w-0 flex-1">
              <b className="!text-[13px]">Заблокувати ПК</b>
              <small>{mode === 'code' ? 'з кодом розблокування' : 'розблокування лише з сайту'}</small>
            </span>
          </button>
        </div>
      ) : (
        <div className="relative mt-4 space-y-3">
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="fc-badge fc-badge-info"><Lock className="h-3 w-3" /> розблокування: {modeLabel}</span>
            {state?.lockedAt ? (
              <span className="fc-badge fc-badge-warn"><Clock className="h-3 w-3" /> заблоковано {formatElapsed(state.lockedAt, now)}</span>
            ) : null}
          </div>
          <p className="rounded-2xl border border-rose-500/25 bg-rose-950/35 px-3.5 py-3 text-[11px] leading-relaxed text-rose-100/85">
            Робочий стіл віддаленого ПК накрито блокувальним екраном.
            {modeLabel === 'код'
              ? ' На ПК вводиться код розблокування, або розблокуйте кнопкою нижче.'
              : ' Розблокування можливе лише з цього сайту.'}
          </p>
          <button
            onClick={() => setUnlockConfirm(true)}
            className="pwr-tile pwr-shutdown fc-shine !py-3.5"
          >
            <span className="pwr-ico !h-10 !w-10"><Unlock className="h-[18px] w-[18px]" /></span>
            <span className="min-w-0 flex-1">
              <b className="!text-[13px]">Розблокувати ПК</b>
              <small>зняти блокувальний екран</small>
            </span>
          </button>
        </div>
      )}

      {/* Lock dialog */}
      {dialogOpen && (
        <div className="fc-modal-backdrop" role="dialog" aria-modal="true" aria-label="Заблокувати ПК" onClick={() => setDialogOpen(false)}>
          <div className="fc-modal" onClick={(e) => e.stopPropagation()}>
            <div className="fc-section-head">
              <div className="fc-section-icon fc-icon-cyan"><Lock className="h-5 w-5" /></div>
              <div>
                <h3>Заблокувати ПК</h3>
                <p>Виберіть спосіб розблокування</p>
              </div>
            </div>

            <div className="mt-4 space-y-2.5">
              {/* Mode A: unlock code */}
              <button
                type="button"
                onClick={() => setMode('code')}
                aria-pressed={mode === 'code'}
                className={`fc-radio-card ${mode === 'code' ? 'active' : ''}`}
              >
                <span className="flex items-center gap-2.5">
                  <KeyRound className={`h-4 w-4 flex-none ${mode === 'code' ? 'text-indigo-300' : 'text-zinc-500'}`} />
                  <span className="flex-1 text-xs font-extrabold text-white">Код розблокування</span>
                  <span className={`fc-radio-dot ${mode === 'code' ? 'on' : ''}`} />
                </span>
                <span className="mt-1 block pl-[1.65rem] text-[10px] leading-snug text-zinc-400">
                  Ввести код на заблокованому ПК, щоб розблокувати
                </span>
              </button>

              {mode === 'code' && (
                <div className="space-y-2 rounded-2xl border border-indigo-400/25 bg-black/35 p-3">
                  <input
                    type="text"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder="Код (мінімум 4 символи)"
                    autoComplete="off"
                    spellCheck={false}
                    className="fc-input"
                  />
                  <input
                    type="text"
                    value={repeat}
                    onChange={(e) => setRepeat(e.target.value)}
                    placeholder="Повторіть код"
                    autoComplete="off"
                    spellCheck={false}
                    className="fc-input"
                  />
                  {repeat.length > 0 && code !== repeat && (
                    <p className="text-[10px] font-bold text-rose-300">Коди не співпадають</p>
                  )}
                  {code.trim().length > 0 && code.trim().length < MIN_CODE_LEN && (
                    <p className="text-[10px] font-bold text-amber-300">Код закороткий — мінімум {MIN_CODE_LEN} символи</p>
                  )}
                </div>
              )}

              {/* Mode B: site only */}
              <button
                type="button"
                onClick={() => setMode('site')}
                aria-pressed={mode === 'site'}
                className={`fc-radio-card ${mode === 'site' ? 'active' : ''}`}
              >
                <span className="flex items-center gap-2.5">
                  <Globe className={`h-4 w-4 flex-none ${mode === 'site' ? 'text-cyan-300' : 'text-zinc-500'}`} />
                  <span className="flex-1 text-xs font-extrabold text-white">Тільки через сайт</span>
                  <span className={`fc-radio-dot ${mode === 'site' ? 'on' : ''}`} />
                </span>
                <span className="mt-1 block pl-[1.65rem] text-[10px] leading-snug text-zinc-400">
                  Розблокувати можна ЛИШЕ тут, з сайту
                </span>
              </button>
            </div>

            <div className="mt-4 flex items-center gap-3">
              <button onClick={() => setDialogOpen(false)} className="fc-btn fc-btn-ghost flex-1">Скасувати</button>
              <button
                onClick={confirmLock}
                disabled={!codeValid}
                className="fc-btn fc-btn-primary fc-shine flex-1 disabled:cursor-not-allowed disabled:opacity-40"
              >
                <Lock className="h-3.5 w-3.5" />
                <span>Заблокувати</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Unlock confirmation */}
      {unlockConfirm && (
        <div className="fc-modal-backdrop" role="dialog" aria-modal="true" aria-label="Розблокувати ПК" onClick={() => setUnlockConfirm(false)}>
          <div className="fc-modal text-center" onClick={(e) => e.stopPropagation()}>
            <div className="mx-auto grid h-16 w-16 place-items-center rounded-[1.25rem] border border-emerald-400/35 bg-emerald-500/15 text-emerald-300 shadow-[0_0_44px_-8px_rgba(16,185,129,.7)]">
              <Unlock className="h-7 w-7" />
            </div>
            <h3 className="mt-3.5 text-base">Розблокувати цей ПК?</h3>
            <p className="mt-1.5 text-xs leading-relaxed text-zinc-400">
              Блокувальний екран на віддаленому комп&apos;ютері буде знято.
            </p>
            <div className="mt-5 flex items-center gap-2.5">
              <button onClick={() => setUnlockConfirm(false)} className="fc-btn fc-btn-ghost flex-1">Скасувати</button>
              <button onClick={confirmUnlock} className="fc-btn fc-btn-success fc-shine flex-1">
                <Unlock className="h-3.5 w-3.5" />
                <span>Розблокувати</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
});

WinLockCard.displayName = 'WinLockCard';
