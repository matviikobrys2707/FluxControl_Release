/**
 * Shared helpers for device event handling (used only by the device tabs).
 */

/**
 * Unwrap an event payload to its data object.
 *
 * `deviceClient` already strips ONE `data` level from incoming messages
 * (`{ type, data: {... } }` → emits `{...}`). But some agents emit flat
 * messages (`{ type, imageBase64, success }`) which arrive as the whole
 * message object — and a few double-nest (`{ type, data: { data: {...} } }`).
 * This helper normalises all of those shapes to "the object with fields".
 */
export function pick<T = Record<string, any>>(raw: any): T {
  if (raw && typeof raw === 'object' && raw.data !== undefined && !(raw instanceof Array)) {
    return raw.data as T;
  }
  return raw as T;
}

/** Clamp a number into [0, 100] — volume / percent guard. */
export function clampPercent(value: number): number {
  if (Number.isNaN(value)) return 0;
  return Math.min(100, Math.max(0, value));
}

/** Safe localStorage read with fallback. */
export function loadStoredNumber(key: string, allowed: number[], fallback: number): number {
  try {
    const parsed = Number(window.localStorage.getItem(key));
    return allowed.includes(parsed) ? parsed : fallback;
  } catch {
    return fallback;
  }
}

/** Safe localStorage write (never throws in private mode etc.). */
export function storeValue(key: string, value: string): void {
  try {
    window.localStorage.setItem(key, value);
  } catch {
    /* ignore */
  }
}

/** Seconds → "4:59" or "1:01:01". */
export function formatSeconds(total: number): string {
  const s = Math.max(0, Math.floor(total));
  const hh = Math.floor(s / 3600);
  const mm = Math.floor((s % 3600) / 60);
  const ss = s % 60;
  const pad = (n: number) => String(n).padStart(2, '0');
  return hh > 0 ? `${hh}:${pad(mm)}:${pad(ss)}` : `${mm}:${pad(ss)}`;
}

/** Ukrainian plural for "камера/камери/камер". */
export function cameraWord(n: number): string {
  if (n % 10 === 1 && n % 100 !== 11) return 'камера';
  const small = n % 10 >= 2 && n % 10 <= 4;
  const teen = n % 100 >= 12 && n % 100 <= 14;
  return small && !teen ? 'камери' : 'камер';
}
