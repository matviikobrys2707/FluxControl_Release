import React, { CSSProperties, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Keyboard, X } from 'lucide-react';
import { deviceClient } from '../../services/deviceClient';

type KeyTone = 'modifier' | 'action' | 'function' | 'navigation' | 'numpad' | 'danger';
type KeyItem = { label: string; code?: string; ru?: string; width?: number; tone?: KeyTone; style?: CSSProperties };
const key = (label: string, code?: string, ru?: string, width?: number, tone?: KeyTone): KeyItem => ({ label, code, ru, width, tone });
const ru: Record<string, string> = { '`': 'Ё', q: 'Й', w: 'Ц', e: 'У', r: 'К', t: 'Е', y: 'Н', u: 'Г', i: 'Ш', o: 'Щ', p: 'З', '[': 'Х', ']': 'Ъ', a: 'Ф', s: 'Ы', d: 'В', f: 'А', g: 'П', h: 'Р', j: 'О', k: 'Л', l: 'Д', ';': 'Ж', "'": 'Э', z: 'Я', x: 'Ч', c: 'С', v: 'М', b: 'И', n: 'Т', m: 'Ь', ',': 'Б', '.': 'Ю', '/': '.' };
const letters = (items: string[]) => items.map(value => key(value.toUpperCase(), value, ru[value]));
const mainRows: KeyItem[][] = [
  [key('Esc', 'esc', undefined, 1, 'danger'), ...Array.from({ length: 12 }, (_, index) => key(`F${index + 1}`, `f${index + 1}`, undefined, 1, 'function'))],
  [key('`', '`', ru['`']), key('1'), key('2'), key('3'), key('4'), key('5'), key('6'), key('7'), key('8'), key('9'), key('0'), key('-'), key('='), key('Backspace', 'backspace', undefined, 2, 'action')],
  [key('Tab', 'tab', undefined, 1.55, 'modifier'), ...letters(['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']']), key('\\', '\\', '\\', 1.45)],
  [key('Caps', 'capslock', undefined, 1.85, 'modifier'), ...letters(['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', "'"]), key('Enter', 'enter', undefined, 2.15, 'action')],
  [key('Shift', 'shift', undefined, 2.25, 'modifier'), ...letters(['z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/']), key('Shift', 'shift', undefined, 2.65, 'modifier')],
  [key('Ctrl', 'ctrl', undefined, 1.35, 'modifier'), key('Win', 'win', undefined, 1.2, 'modifier'), key('Alt', 'alt', undefined, 1.2, 'modifier'), key('Space', 'space', undefined, 6.2), key('Alt', 'alt', undefined, 1.2, 'modifier'), key('Win', 'win', undefined, 1.2, 'modifier'), key('Menu', 'apps', undefined, 1.2, 'modifier'), key('Ctrl', 'ctrl', undefined, 1.35, 'modifier')]
];
const navRows: KeyItem[][] = [[key('PrtSc', 'printscreen', undefined, 1, 'function'), key('ScrLk', 'scrolllock', undefined, 1, 'function'), key('Pause', 'pause', undefined, 1, 'function')], [key('Ins', 'insert', undefined, 1, 'navigation'), key('Home', 'home', undefined, 1, 'navigation'), key('PgUp', 'pageup', undefined, 1, 'navigation')], [key('Del', 'delete', undefined, 1, 'navigation'), key('End', 'end', undefined, 1, 'navigation'), key('PgDn', 'pagedown', undefined, 1, 'navigation')]];
const arrows = [key('↑', 'up', undefined, 1, 'navigation'), key('←', 'left', undefined, 1, 'navigation'), key('↓', 'down', undefined, 1, 'navigation'), key('→', 'right', undefined, 1, 'navigation')];
const pad: KeyItem[] = [
  { ...key('Num Lock', 'numlock', undefined, 1, 'numpad'), style: { gridColumn: '1', gridRow: '1' } }, { ...key('/', 'divide', undefined, 1, 'numpad'), style: { gridColumn: '2', gridRow: '1' } }, { ...key('*', 'multiply', undefined, 1, 'numpad'), style: { gridColumn: '3', gridRow: '1' } }, { ...key('-', 'subtract', undefined, 1, 'numpad'), style: { gridColumn: '4', gridRow: '1' } },
  { ...key('7', 'num7', 'Home', 1, 'numpad'), style: { gridColumn: '1', gridRow: '2' } }, { ...key('8', 'num8', '↑', 1, 'numpad'), style: { gridColumn: '2', gridRow: '2' } }, { ...key('9', 'num9', 'PgUp', 1, 'numpad'), style: { gridColumn: '3', gridRow: '2' } }, { ...key('+', 'add', undefined, 1, 'action'), style: { gridColumn: '4', gridRow: '2 / span 2' } },
  { ...key('4', 'num4', '←', 1, 'numpad'), style: { gridColumn: '1', gridRow: '3' } }, { ...key('5', 'num5', undefined, 1, 'numpad'), style: { gridColumn: '2', gridRow: '3' } }, { ...key('6', 'num6', '→', 1, 'numpad'), style: { gridColumn: '3', gridRow: '3' } },
  { ...key('1', 'num1', 'End', 1, 'numpad'), style: { gridColumn: '1', gridRow: '4' } }, { ...key('2', 'num2', '↓', 1, 'numpad'), style: { gridColumn: '2', gridRow: '4' } }, { ...key('3', 'num3', 'PgDn', 1, 'numpad'), style: { gridColumn: '3', gridRow: '4' } }, { ...key('Enter', 'enter', undefined, 1, 'action'), style: { gridColumn: '4', gridRow: '4 / span 2' } },
  { ...key('0', 'num0', 'Ins', 1, 'numpad'), style: { gridColumn: '1 / span 2', gridRow: '5' } }, { ...key('.', 'decimal', 'Del', 1, 'numpad'), style: { gridColumn: '3', gridRow: '5' } }
];

const LONG_PRESS_MS = 450;

export const VirtualKeyboardLauncher: React.FC = () => {
  const [open, setOpen] = useState(false);
  // A combination is a LIST, not a set: the same key may be added several
  // times (Ctrl + Ctrl + Ctrl …) — that is the documented behaviour.
  const [combo, setCombo] = useState<KeyItem[]>([]);
  const [pressed, setPressed] = useState<string | null>(null);
  const holdTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  // True when the current gesture already added the key via long-press, so
  // the follow-up click and the native contextmenu do not add it twice.
  const longPressConsumed = useRef(false);

  useEffect(() => { if (!open) return; const prior = document.body.style.overflow; document.body.style.overflow = 'hidden'; return () => { document.body.style.overflow = prior; }; }, [open]);

  const id = (item: KeyItem, index: number) => `${item.code || item.label}-${index}`;
  const codeOf = (item: KeyItem) => item.code || item.label.toLowerCase();

  // ---------- Combo building ----------
  const addToCombo = (item: KeyItem) => setCombo(current => [...current, item]);

  // ---------- Simple press (ЛКМ / короткий тап) ----------
  const simplePress = (item: KeyItem) => {
    const code = codeOf(item);
    if (combo.length > 0) {
      // A combination is already being assembled: EVERY further simple
      // click appends to it — no special button needed anymore.
      addToCombo(item);
      return;
    }
    // No combination in progress: the key simply presses itself on the PC.
    deviceClient.sendKeyPress(code);
  };

  const release = () => {
    if (holdTimer.current) { clearTimeout(holdTimer.current); holdTimer.current = null; }
    setPressed(null);
  };

  const execute = () => {
    if (!combo.length) return;
    deviceClient.sendShortcut(combo.map(codeOf).join('+'));
    setCombo([]);
  };

  const renderKey = (item: KeyItem, index: number) => {
    const identity = id(item, index);
    const active = pressed === identity;
    return (
      <button
        key={identity}
        style={{ flexGrow: item.width || 1, ...item.style }}
        className={`remote-key ${item.tone || ''} ${active ? 'selected' : ''}`}
        onPointerDown={event => {
          setPressed(identity);
          longPressConsumed.current = false;
          if (event.pointerType === 'touch') {
            // Phone: holding a key starts/composes the combination.
            holdTimer.current = setTimeout(() => {
              longPressConsumed.current = true;
              addToCombo(item);
            }, LONG_PRESS_MS);
          }
        }}
        onPointerUp={release}
        onPointerLeave={release}
        onPointerCancel={release}
        onClick={() => {
          if (longPressConsumed.current) { longPressConsumed.current = false; return; }
          simplePress(item);
        }}
        onContextMenu={event => {
          event.preventDefault();
          release();
          // PC: right click adds the key to the combination. After a touch
          // long-press the gesture is already consumed — skip the double add.
          if (!longPressConsumed.current) addToCombo(item);
          longPressConsumed.current = false;
        }}
      >
        <span>{item.label}</span>
        {item.ru && <small>{item.ru}</small>}
      </button>
    );
  };

  const comboLabels = combo.map(item => item.label).join(' + ');

  return (
    <>
      <button onClick={() => setOpen(true)} className="input-tool-button"><Keyboard className="h-4 w-4" />Клавіатура</button>
      {open && createPortal(
        <div className="fc-fullscreen-modal keyboard-overlay keyboard-overlay-centered" role="dialog" aria-modal="true">
          <header className="keyboard-modal-header">
            <div className="keyboard-combo-panel">
              <p>ПОТОЧНА КОМБІНАЦІЯ</p>
              <div className="keyboard-combo">{comboLabels || '—'}</div>
            </div>
            <div className="keyboard-toolbar">
              {combo.length > 0 && (
                <>
                  <button onClick={() => setCombo([])} className="keyboard-secondary">Скасувати</button>
                  <button onClick={execute} className="keyboard-execute">Виконати</button>
                </>
              )}
              <button onClick={() => { release(); setCombo([]); setOpen(false); }} className="keyboard-close" aria-label="Закрити клавіатуру"><X className="h-5 w-5" /></button>
            </div>
          </header>
          <main className="keyboard-modal-body">
            {/* Interaction rules are always visible so the gesture model is discoverable. */}
            <p className="keyboard-hint"><b>ЛКМ / тап</b> — натиснути клавішу &nbsp;·&nbsp; <b>ПКМ / довге натискання</b> — додати до комбінації &nbsp;·&nbsp; одну клавішу можна додати кілька разів</p>
            <div className="keyboard-frame">
              <section className="keyboard-cluster keyboard-main">{mainRows.map((row, rowIndex) => <div className="keyboard-row" key={rowIndex}>{row.map((item, index) => renderKey(item, rowIndex * 30 + index))}</div>)}</section>
              <section className="keyboard-cluster keyboard-navigation">{navRows.map((row, rowIndex) => <div className="keyboard-row" key={rowIndex}>{row.map((item, index) => renderKey(item, 200 + rowIndex * 10 + index))}</div>)}<div className="keyboard-arrow-grid">{arrows.map((item, index) => renderKey(item, 300 + index))}</div></section>
              <section className="keyboard-cluster keyboard-numpad"><div className="keyboard-numpad-grid">{pad.map((item, index) => renderKey(item, 400 + index))}</div></section>
            </div>
          </main>
        </div>,
        // Portal to <body>: the launcher sits inside a .glass-card whose
        // backdrop-filter creates a containing block, which otherwise traps the
        // fixed fullscreen overlay inside the card and lets the rest of the site
        // render on top of the keyboard.
        document.body
      )}
    </>
  );
};
