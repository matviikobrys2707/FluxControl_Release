import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Bot, Loader2, SendHorizonal, Square, Eraser, ChevronDown,
  MousePointer2, Keyboard, Camera, ScrollText, Clock, Link as LinkIcon,
  TerminalSquare, MousePointerClick, CheckCircle2, AlertTriangle, Eye,
  ClipboardPaste, Database, FileDown,
} from 'lucide-react';
import { Device } from '../../types';
import { deviceClient } from '../../services/deviceClient';
import { base64ToBlob, formatBytes, mediaKindOf, mimeFor, samePath } from './fcHelpers';

interface AITabProps {
  device: Device;
}

/** Інструмент, який модель просить виконати на ПК. */
type AiTool = {
  type: 'shell' | 'screenshot' | 'mouse' | 'click' | 'type' | 'key' | 'scroll' | 'shortcut' | 'open' | 'wait' | 'paste' | 'memory' | 'file_to_chat';
  command?: string;
  nx?: number;
  ny?: number;
  text?: string;
  key?: string;
  modifiers?: string[];
  button?: string;
  double?: boolean;
  combo?: string;
  url?: string;
  dy?: number;
  ms?: number;
  path?: string;    // для file_to_chat: шлях до файлу на ПК
  shot?: boolean;   // для shell: додати скриншот до результату
  data?: string;    // для memory: повний JSON пам'яті ПК
};

type MsgKind = 'user' | 'ai' | 'tool' | 'sys' | 'attach';

interface AiMsg {
  id: number;
  kind: MsgKind;
  text: string;
  tool?: AiTool | null;
  toolLabel?: string;
  output?: string;
  image?: string;      // dataURL/base64 скриншота
  status?: 'run' | 'ok' | 'err' | 'timeout';
  // Вкладення (file_to_chat): файл, завантажений з ПК прямо в чат
  attach?: { name: string; url: string; mime: string; size: number; kind: 'image' | 'video' | 'audio' | 'file' };
}

/** Ліміти агента: блоки кроків. Коли блок вичерпано — АВТОМАТИЧНО продовжуємо
 *  наступним блоком (юзер просив, щоб агент не зупинявся на півдороги).
 *  Зупинки лише три: «Стоп» від юзера, помилка зв'язку або done:true. */
const SEGMENT_STEPS = [22, 16, 16]; // разом до 54 кроків на задачу
const CMD_TIMEOUT_MS = 45000;
const SHOT_TIMEOUT_MS = 12000;
const MAX_CMD_OUTPUT = 3500;
const MEMORY_TIMEOUT_MS = 4000;   // чекаємо відповідь агента про пам'ять
const MEMORY_MAX_CHARS = 32000;   // захист від роздутого файлу пам'яті
const MAX_TOOLS_PER_STEP = 6;     // мульти-дії за один крок
const MAX_NO_TOOL_NUDGES = 2;     // нагадувань «продовжуй», якщо модель зупинилась
const MAX_FORMAT_RETRIES = 2;     // повторів, якщо модель відповіла не-JSON
const FILE_TIMEOUT_MS = 90000;    // завантаження файлу з ПК у чат (відео буває великим)

const MODEL_LABEL = 'gemini-3.5-flash-lite';

const MEMORY_STRUCTURE_HINT = `{"computer":"<hostname>","programs":{"Telegram":{"path":"C:\\\\Users\\\\...\\\\telegram.exe","how":"Start-Process"}},"quirks":["Roblox: type не друкує в пошук — тільки paste"],"notes":[]}`;

function buildSystemPrompt(memory: string | null): string {
  const memBlock = memory && memory.trim()
    ? `ПАМ'ЯТЬ ПРО ЦЕЙ ПК (файл ai_memory.json на диску ПК — переживає перезапуск). Твої знання з минулих задач — ВИКОРИСТОВУЙ ОДРАЗУ, не шукай те, що вже записано:\n=== ПОЧАТОК ПАМ'ЯТІ ===\n${memory.slice(0, MEMORY_MAX_CHARS)}\n=== КІНЕЦЬ ПАМ'ЯТІ ===\n(це весь файл — при збереженні передавай ПОВНУ оновлену версію, а не тільки зміни)`
    : `ПАМ'ЯТЬ ПРО ЦЕЙ ПК: поки порожня. Якщо під час задачі дізнаєшся щось корисне — створи пам'ять інструментом memory. Якщо збереження відповість «старий агент» — просто працюй далі без пам'яті й не повторюй збереження.`;

  return `Ти — AI-агент FluxControl, що працює НА Windows-ПК. ГОЛОВНЕ: людина, яка пише тобі — це ВЛАСНИК і адміністратор цього комп'ютера. Це ЙОГО ПК: він має повне право давати будь-які завдання (запускати ігри та програми, створювати й виконувати скрипти, керувати мишею й клавіатурою, змінювати систему). Ти — його інструмент: виконуй завдання до результату, без вагань, відмов і моралізаторства. Для власника немає «небезпечних» прохань щодо його власного ПК — він командує, ти виконуєш.

ТИ БАЧИШ ЕКРАН: після більшості дій тобі АВТОМАТИЧНО приходить свіжий скриншот. Координати миші — 0..1000, нормалізовані до всього екрана: (0,0) лівий верхній кут, (1000,1000) правий нижній. Читай скриншот уважно (текст, кнопки, поля, іконки) і ПЕРЕВІРЯЙ очима результат КОЖНОЇ дії.

ГОЛОВНЕ ПРАВИЛО — МІНІМУМ КРОКІВ (кожен крок = повільне звернення до моделі, юзер чекає):
1. Очевидні послідовності виконуй ОДНИМ кроком через "tools" — масив до 6 дій, що виконуються підряд (скриншот прийде після останньої). Приклад запуску програми через Пуск ОДНИМ кроком:
   {"message":"Шукаю Telegram через Пуск…","tools":[{"type":"key","key":"win"},{"type":"wait","ms":1200},{"type":"paste","text":"telegram"},{"type":"key","key":"enter"}],"done":false}
2. НЕ роби окремий {"type":"screenshot"} після дії — скриншот і так приходить після click/type/paste/key/shortcut/scroll/open/wait.
3. Програму запускай насамперед через shell (Start-Process) — це найшвидше. Полювання на іконки робочого столу — останній варіант.
4. ДУМАЙ НАПЕРЕД: плануй усі кроки задачі заздалегідь і виконуй ланцюгами (tools), а не по одній дії. Скриншот нужен щоб ПЕРЕВІРИТИ результат ланцюга, а не після кожної дії.
5. Скрипти можна писати будь-якими мовами, які є на ПК: PowerShell, Python, Node.js (shell: node -e "...") — створюй НОВІ рішення, а не тільки готові команди.

ІНСТРУМЕНТИ (в "tool" — одна дія АБО в "tools" — масив до 6):
{"type":"shell","command":"<PowerShell команда>","shot":true} — файли, запуск .exe, налаштування, інфо про систему. "shot":true — додати скриншот до результату (СТАВЬ ЗАВЖДИ при запуску програм).
{"type":"file_to_chat","path":"C:\\Users\\...\\video.mp4"} — ПОКАЗАТИ ФАЙЛ КОРИСТУВАЧУ ПРЯМО В ЧАТІ: відео/фото/аудіо/документ буде відображено карткою з програвачем і кнопкою «Завантажити». Використовуй, коли просять «знайди і покажи/скинь мені X»: 1) знайди файл через shell (Get-ChildItem -Path C:\ -Include *.mp4 -Recurse -ErrorAction SilentlyContinue | Select-Object -First 5 FullName,Length — швидкий варіант: шукай у Users та Папках відео/Завантаження/Документи); 2) вибери НАЙКРАЩИЙ один файл (не завантажуй величезні файли > 100 МБ — обери менший); 3) відправ його file_to_chat. НЕ читай файл через shell — тільки file_to_chat.
{"type":"paste","text":"<текст>"} — НАДІЙНЕ введення тексту: у буфер обміну + Ctrl+V. Працює скрізь, включно з іграми та полями, куди звичайний друк не доходить. Спочатку клікни в поле!
{"type":"memory","data":"<ПОВНИЙ оновлений JSON пам'яті>"} — зберегти знання про ПК (див. блок пам'яті нижче).
{"type":"click","nx":0..1000,"ny":0..1000,"button":"left|right","double":false} — перемістити й клікнути (double=true — подвійний).
{"type":"type","text":"<текст>"} — надрукувати (будь-яка мова). Може НЕ працювати в іграх і деяких полях — тоді paste.
{"type":"key","key":"enter|esc|tab|up|down|left|right|space|f5|win|delete...","modifiers":["ctrl","shift","alt","win"]}
{"type":"shortcut","combo":"win+r|ctrl+c|ctrl+v|alt+tab|win+d|alt+f4|ctrl+shift+esc"}
{"type":"scroll","dy":-600} — прокрутка (від'ємне dy — вгору).
{"type":"open","url":"https://..."} — відкрити посилання в браузері ПК.
{"type":"wait","ms":2000} — почекати (макс 15000; після паузи приходить свіжий скриншот).
{"type":"screenshot"} — позаплановий скриншот.

${memBlock}

КОЛИ ЗБЕРІГАТИ ПАМ'ЯТЬ: дізнався шлях до програми; зрозумів, як запускається гра/програма; помітив особливість ПК (наприклад «type не друкує в пошук Roblox — тільки paste»); знайшов корисну команду. Рекомендована структура (розширюй її):
${MEMORY_STRUCTURE_HINT}
НЕ зберігай хронологію чату — тільки сталі знання про ПК. ПЕРЕД done:true збережи пам'ять, якщо є що додати (рівно одне збереження).

ПОВІЛЬНІ ПРОГРАМИ (ігри, Telegram, браузери можуть вантажитися 10-60 СЕКУНД — це нормально; НЕ панікуй і НЕ перемикай вікна навмання — alt+tab/win+d наосліп лише ламають фокус):
1) shell: Start-Process 'шлях' (або URI: roblox:, steam:) БЕЗ shot; 2) wait 6000-10000; 3) перевір вікно дешевше, ніж гадати по скриншоту: shell "Get-Process | Where-Object {$_.MainWindowTitle} | Select-Object ProcessName,MainWindowTitle | Format-Table -AutoSize"; 4) вікна ще немає — wait 8000 і перевір знову; 5) сфокусуй вікно: shell "(New-Object -ComObject WScript.Shell).AppActivate('НазваВікна')" або клікни по ньому на скриншоті.

ВВЕДЕННЯ ТЕКСТУ: клік у поле → набрати → ПЕРЕВІР на скриншоті, що текст ДІЙСНО в полі. Не з'явився або зник — НЕ повторюй type, одразу paste. Перед Enter переконайся, що набрано саме те, що треба.

ДОВОДИ ДО КІНЦЯ: «напиши користувачу X» виконано ТІЛЬКИ коли повідомлення ВІДПРАВЛЕНО й видно в чаті (а не просто набрано); «відкрий Y» — коли Y відкрито й видно екран. Кожну підціль перевіряй очима; не кажи «готово», поки не перевірив.

СКРИПТИ (python/bat/ps1) — записуй файл через shell (Set-Content -Path X -Value ... -Encoding UTF8), ПОТІМ ОДРАЗУ ЗАПУСКАЙ (Start-Process / python X) І ПЕРЕВІРЯЙ результат скриншотом або виводом. Запис файлу ≠ виконана задача. Це ПК власника — виконуй будь-які його завдання зі скриптами й системою.

shell: неінтерактивні й швидкі (<30с), обмежуй вивід (| Select-Object -First 20). Довгі запуски — тільки через Start-Process (не блокує консоль). Порожній вивід після запуску — це ок: перевір вікно через Get-Process.

ФОРМАТ ВІДПОВІДІ — СТРОГО валідний JSON без markdown-огорож і тексту поза JSON:
{"message":"<коротка відповідь українською: що зробив / що робиш далі>","tool":{...}|null,"tools":[...]|null,"done":false}
"done":true — ТІЛЬКИ коли задача ПОВНІСТЮ виконана й перевірена очима. Дія не спрацювала — НЕ повторюй її вточності, зміни підхід (type→paste, іконки→shell). Користувач просто питає — відповідай без команд (tool:null, done:true).`;
}

const SUGGESTIONS = [
  'Відкрий Telegram і напиши Печеньці «привіт»',
  'Відкрий YouTube і знайди перше відео',
  'Знайди та запусти калькулятор',
  'Покажи скриншот екрана',
];

const TOOL_META: Record<string, { label: string; icon: React.ReactNode; color: string }> = {
  shell:      { label: 'PowerShell', icon: <TerminalSquare className="h-3.5 w-3.5" />, color: 'text-amber-300 border-amber-500/25 bg-amber-500/[0.06]' },
  screenshot: { label: 'Скриншот екрана', icon: <Camera className="h-3.5 w-3.5" />, color: 'text-sky-300 border-sky-500/25 bg-sky-500/[0.06]' },
  mouse:      { label: 'Миша', icon: <MousePointer2 className="h-3.5 w-3.5" />, color: 'text-violet-300 border-violet-500/25 bg-violet-500/[0.06]' },
  click:      { label: 'Клік', icon: <MousePointerClick className="h-3.5 w-3.5" />, color: 'text-fuchsia-300 border-fuchsia-500/25 bg-fuchsia-500/[0.06]' },
  type:       { label: 'Ввід тексту', icon: <Keyboard className="h-3.5 w-3.5" />, color: 'text-emerald-300 border-emerald-500/25 bg-emerald-500/[0.06]' },
  key:        { label: 'Клавіша', icon: <Keyboard className="h-3.5 w-3.5" />, color: 'text-emerald-300 border-emerald-500/25 bg-emerald-500/[0.06]' },
  shortcut:   { label: 'Сполучення', icon: <Keyboard className="h-3.5 w-3.5" />, color: 'text-emerald-300 border-emerald-500/25 bg-emerald-500/[0.06]' },
  scroll:     { label: 'Прокрутка', icon: <ScrollText className="h-3.5 w-3.5" />, color: 'text-indigo-300 border-indigo-500/25 bg-indigo-500/[0.06]' },
  open:       { label: 'Відкрити URL', icon: <LinkIcon className="h-3.5 w-3.5" />, color: 'text-blue-300 border-blue-500/25 bg-blue-500/[0.06]' },
  wait:       { label: 'Пауза', icon: <Clock className="h-3.5 w-3.5" />, color: 'text-zinc-300 border-white/15 bg-white/[0.05]' },
  paste:      { label: 'Вставка з буфера', icon: <ClipboardPaste className="h-3.5 w-3.5" />, color: 'text-teal-300 border-teal-500/25 bg-teal-500/[0.06]' },
  memory:     { label: 'Пам\'ять ПК', icon: <Database className="h-3.5 w-3.5" />, color: 'text-cyan-300 border-cyan-500/25 bg-cyan-500/[0.06]' },
  file_to_chat: { label: 'Файл у чат', icon: <FileDown className="h-3.5 w-3.5" />, color: 'text-fuchsia-300 border-fuchsia-500/25 bg-fuchsia-500/[0.06]' },
};

function toolLabel(t: AiTool): string {
  switch (t.type) {
    case 'shell': return 'PowerShell';
    case 'screenshot': return 'Скриншот екрана';
    case 'mouse': return `Миша → (${Math.round(t.nx ?? 0)}, ${Math.round(t.ny ?? 0)})`;
    case 'click': {
      const b = t.button === 'right' ? 'ПКМ' : t.button === 'middle' ? 'СКМ' : 'ЛКМ';
      const nx = t.nx != null ? ` → (${Math.round(t.nx)}, ${Math.round(t.ny ?? 0)})` : '';
      return `Клік ${b}${nx}${t.double ? ' ×2' : ''}`;
    }
    case 'type': return `Друк: «${(t.text || '').slice(0, 40)}${(t.text || '').length > 40 ? '…' : ''}»`;
    case 'key': return `Клавіша: ${(t.modifiers || []).map(m => m + '+').join('')}${t.key || ''}`.toUpperCase();
    case 'shortcut': return `Сполучення: ${(t.combo || '').toUpperCase()}`;
    case 'scroll': return `Прокрутка ${t.dy != null && t.dy < 0 ? 'вгору' : 'вниз'}`;
    case 'open': return `Відкрити: ${(t.url || '').slice(0, 48)}`;
    case 'wait': return `Пауза ${((t.ms ?? 0) / 1000).toFixed(1)}с`;
    case 'paste': return `Вставка з буфера: «${(t.text || '').slice(0, 40)}${(t.text || '').length > 40 ? '…' : ''}»`;
    case 'memory': return `Пам'ять ПК → ai_memory.json`;
    case 'file_to_chat': return `Файл у чат: ${(t.path || '').slice(0, 48)}${(t.path || '').length > 48 ? '…' : ''}`;
    default: return 'Дія';
  }
}

/** Витягує JSON-об'єкт з відповіді моделі (стійко до ```-огорож і сміття). */
function extractJson(raw: string): { message?: string; tool?: AiTool | null; tools?: AiTool[] | null; command?: string | null; done?: boolean } | null {
  if (!raw) return null;
  let text = raw.trim();
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) text = fence[1].trim();
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start === -1 || end === -1 || end <= start) return null;
  try {
    return JSON.parse(text.slice(start, end + 1));
  } catch {
    return null;
  }
}

/** UTF-8 → base64 (для paste: безпечна передача будь-якого тексту в PowerShell). */
function b64Utf8(s: string): string {
  try {
    const bytes = new TextEncoder().encode(s);
    let bin = '';
    for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin);
  } catch {
    return '';
  }
}

/** Сигнатура дії для guard від повторів однієї й тієї ж команди підряд. */
function toolSig(t: AiTool): string {
  try { return JSON.stringify({ ...t, shot: undefined }); } catch { return ''; }
}

export const AITab: React.FC<AITabProps> = ({ device }) => {
  const [messages, setMessages] = useState<AiMsg[]>([]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [shellReady, setShellReady] = useState(false);
  const [modelUsed, setModelUsed] = useState<string | null>(null);
  const [stepInfo, setStepInfo] = useState<string>('');
  const [viewImage, setViewImage] = useState<string | null>(null);
  // Готовність AI на бекенді: 'ok' — оновлений server.js приймає скриншоти;
  // 'old' — роуту /api/ai/status немає (старий деплой); 'fail' — недоступний.
  const [aiStatus, setAiStatus] = useState<'checking' | 'ok' | 'old' | 'fail'>('checking');
  // Пам'ять ПК: короткий підпис у шапці («1.2 КБ пам'яті») або null.
  const [memInfo, setMemInfo] = useState<string | null>(null);

  const idRef = useRef(1);
  const busyRef = useRef(false);
  const abortRef = useRef(false);
  const shellStartedRef = useRef(false);
  const sawOutputRef = useRef(false);
  const startGuardRef = useRef<number | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const atBottomRef = useRef(true);
  const collectorRef = useRef<{ buf: string; done: boolean } | null>(null);
  // Активний очікувач скриншота (screenshot_response / screenshot).
  const shotWaiterRef = useRef<{ resolve: (b64: string | null) => void } | null>(null);
  // Очікувачі пам'яті ПК (новий агент відповідає ai_memory_data / ai_memory_saved).
  const memoryWaiterRef = useRef<{ resolve: (v: string | null) => void } | null>(null);
  const memorySavedRef = useRef<{ resolve: (v: string) => void } | null>(null);
  // Очікувач файлу з ПК для file_to_chat (fs_download_file_result).
  const fileWaiterRef = useRef<{ path: string; resolve: (v: { ok: boolean; name?: string; base64?: string; mime?: string; error?: string }) => void } | null>(null);

  const push = useCallback((m: Omit<AiMsg, 'id'>) => {
    setMessages(prev => {
      const next = [...prev, { ...m, id: (idRef.current += 1) }];
      return next.length > 300 ? next.slice(next.length - 300) : next;
    });
  }, []);

  const patchLastTool = useCallback((patch: Partial<AiMsg>) => {
    setMessages(prev => {
      for (let i = prev.length - 1; i >= 0; i--) {
        if (prev[i].kind === 'tool') {
          const next = [...prev];
          next[i] = { ...next[i], ...patch };
          return next;
        }
      }
      return prev;
    });
  }, []);

  // ================= Потік виводу терміналу =================
  useEffect(() => {
    const off = deviceClient.on('terminal_output', (payload: any) => {
      const text =
        typeof payload === 'string'
          ? payload
          : String(payload?.data ?? payload?.output ?? payload?.text ?? '');
      if (!text) return;

      if (!sawOutputRef.current) {
        sawOutputRef.current = true;
        setShellReady(true);
      }

      const collector = collectorRef.current;
      if (!collector || collector.done) return;

      const lines = text.replace(/\r/g, '').split('\n');
      for (const raw of lines) {
        if (/^FLUX_CWD::.+?(::END|>)\s*$/.test(raw.trim())) {
          collector.done = true;
          continue;
        }
        const cleaned = raw.replace(/FLUX_CWD::.*?(::END|>)/g, '').trimEnd();
        if (cleaned.trim()) {
          collector.buf += (collector.buf ? '\n' : '') + cleaned;
          if (collector.buf.length > MAX_CMD_OUTPUT) {
            collector.buf = collector.buf.slice(0, MAX_CMD_OUTPUT) + '\n… (вивід обрізано)';
            collector.done = true;
          }
        }
      }
    });
    return off;
  }, []);

  // ================= Потік скриншотів (для зору агента) =================
  useEffect(() => {
    const offShot = deviceClient.on('screenshot_response', (payload: any) => {
      const b64 = typeof payload === 'string' ? payload : payload?.imageBase64 ?? null;
      if (shotWaiterRef.current) {
        shotWaiterRef.current.resolve(b64);
        shotWaiterRef.current = null;
      }
    });
    const offShot2 = deviceClient.on('screenshot', (payload: any) => {
      const b64 = typeof payload === 'string' ? payload : payload?.data ?? null;
      if (shotWaiterRef.current) {
        shotWaiterRef.current.resolve(b64);
        shotWaiterRef.current = null;
      }
    });
    const offErr = deviceClient.on('media_error', () => {
      if (shotWaiterRef.current) {
        shotWaiterRef.current.resolve(null);
        shotWaiterRef.current = null;
      }
    });
    return () => { offShot(); offShot2(); offErr(); };
  }, []);

  // ================= Події пам'яті ПК =================
  useEffect(() => {
    const offData = deviceClient.on('ai_memory_data', (payload: any) => {
      const d = typeof payload === 'string' ? payload : payload?.data ?? null;
      if (memoryWaiterRef.current) {
        memoryWaiterRef.current.resolve(typeof d === 'string' && d.trim() ? d : null);
        memoryWaiterRef.current = null;
      }
    });
    const offSaved = deviceClient.on('ai_memory_saved', (payload: any) => {
      if (memorySavedRef.current) {
        memorySavedRef.current.resolve(
          payload?.success === false
            ? `(збереження пам'яті не вдалося: ${payload?.error || 'невідома помилка'})`
            : "(пам'ять ПК збережено в ai_memory.json)"
        );
        memorySavedRef.current = null;
      }
    });
    // Файл з ПК для file_to_chat.
    const offFile = deviceClient.on('fs_download_file_result', (d: any) => {
      const w = fileWaiterRef.current;
      if (!w) return;
      if (d?.path && !samePath(d.path, w.path)) return;
      fileWaiterRef.current = null;
      if (d?.success === false || !d?.base64) {
        w.resolve({ ok: false, error: d?.error || 'агент не повернув вміст файлу' });
      } else {
        w.resolve({
          ok: true,
          name: String(d?.name || (String(d?.path || '').split('\\').pop()) || 'file'),
          base64: String(d.base64),
          mime: d?.mime ? String(d.mime) : undefined
        });
      }
    });
    return () => { offData(); offSaved(); offFile(); };
  }, []);

  /** Попросити агента прочитати пам'ять ПК (null — старий агент або порожньо). */
  const loadMemory = useCallback((): Promise<string | null> => {
    return new Promise((resolve) => {
      if (memoryWaiterRef.current) memoryWaiterRef.current.resolve(null);
      const waiter = { resolve };
      memoryWaiterRef.current = waiter;
      try {
        deviceClient.send('ai_memory_get', {});
      } catch {
        memoryWaiterRef.current = null;
        resolve(null);
        return;
      }
      window.setTimeout(() => {
        if (memoryWaiterRef.current === waiter) {
          memoryWaiterRef.current = null;
          resolve(null);
        }
      }, MEMORY_TIMEOUT_MS);
    });
  }, []);

  /** Зберегти пам'ять на ПК. Повертає текст-підсумок для моделі. */
  const saveMemory = useCallback((data: string): Promise<string> => {
    return new Promise((resolve) => {
      if (memorySavedRef.current) memorySavedRef.current.resolve('(попереднє збереження не підтверджено)');
      const waiter = { resolve };
      memorySavedRef.current = waiter;
      try {
        deviceClient.send('ai_memory_set', { data: data.slice(0, MEMORY_MAX_CHARS) });
      } catch {
        memorySavedRef.current = null;
        resolve("(пам'ять не надіслана на ПК — працюй далі без збереження)");
        return;
      }
      window.setTimeout(() => {
        if (memorySavedRef.current === waiter) {
          memorySavedRef.current = null;
          resolve("(старий агент не підтримує пам'ять — оновіть exe агента; далі працюй без збереження)");
        }
      }, MEMORY_TIMEOUT_MS);
    });
  }, []);

  /** Зробити скриншот екрана ПК і повернути base64 (або null). */
  const takeScreenshot = useCallback((): Promise<string | null> => {
    return new Promise((resolve) => {
      if (shotWaiterRef.current) shotWaiterRef.current.resolve(null);
      const waiter = { resolve };
      shotWaiterRef.current = waiter;
      deviceClient.send('capture_screenshot', { quality: 65, maxWidth: 1280 });
      window.setTimeout(() => {
        if (shotWaiterRef.current === waiter) {
          shotWaiterRef.current = null;
          resolve(null);
        }
      }, SHOT_TIMEOUT_MS);
    });
  }, []);

  /** Завантажити файл з ПК у чат (file_to_chat): через fs_download_file. */
  const downloadFileToChat = useCallback((path: string): Promise<{ ok: boolean; name?: string; base64?: string; mime?: string; error?: string }> => {
    return new Promise((resolve) => {
      if (fileWaiterRef.current) fileWaiterRef.current.resolve({ ok: false, error: 'скасовано (новий запит)' });
      const waiter = { path, resolve };
      fileWaiterRef.current = waiter;
      try {
        deviceClient.downloadFile(path);
      } catch (e: any) {
        fileWaiterRef.current = null;
        resolve({ ok: false, error: String(e?.message || e) });
        return;
      }
      window.setTimeout(() => {
        if (fileWaiterRef.current === waiter) {
          fileWaiterRef.current = null;
          resolve({ ok: false, error: 'ПК не відповів вчасно (файл занадто великий або повільний канал)' });
        }
      }, FILE_TIMEOUT_MS);
    });
  }, []);

  // ================= Життєвий цикл оболонки =================
  const ensureShell = useCallback(() => {
    if (shellStartedRef.current) return;
    shellStartedRef.current = true;
    deviceClient.send('terminal_start', { shell: 'powershell' });
    if (startGuardRef.current) window.clearTimeout(startGuardRef.current);
    startGuardRef.current = window.setTimeout(() => {
      if (!sawOutputRef.current) {
        deviceClient.send('terminal_start', { shell: 'powershell' });
      }
    }, 2500);
  }, []);

  useEffect(() => {
    ensureShell();
    const offConnected = deviceClient.on('connected', () => {
      if (!sawOutputRef.current) {
        deviceClient.send('terminal_start', { shell: 'powershell' });
      }
    });
    return () => {
      offConnected();
      if (startGuardRef.current) window.clearTimeout(startGuardRef.current);
      deviceClient.killTerminal();
      shellStartedRef.current = false;
      sawOutputRef.current = false;
      setShellReady(false);
    };
  }, [ensureShell]);

  // Stick-to-bottom + Esc закриває переглядач скриншотів
  useEffect(() => {
    const el = scrollRef.current;
    if (el && atBottomRef.current) el.scrollTop = el.scrollHeight;
  }, [messages]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setViewImage(null);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  // ================= Перевірка готовності бекенда (раз/2 хв) =================
  useEffect(() => {
    let alive = true;
    const check = async () => {
      try {
        const res = await fetch('https://fluxcontrol-backend.onrender.com/api/ai/status', { signal: AbortSignal.timeout(45000) });
        const data = await res.json().catch(() => null);
        if (alive) setAiStatus(res.ok && data?.ai && Number(data?.maxBodyMb) >= 20 ? 'ok' : 'old');
      } catch {
        if (alive) setAiStatus('fail');
      }
    };
    check();
    const iv = window.setInterval(check, 120000);
    return () => { alive = false; window.clearInterval(iv); };
  }, []);

  const handleScroll = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    atBottomRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 48;
  }, []);

  // ================= Виконання PowerShell-команди =================
  const runShell = useCallback((cmd: string): Promise<string> => {
    return new Promise((resolve) => {
      ensureShell();
      const collector = { buf: '', done: false };
      collectorRef.current = collector;

      const finish = (timeout: boolean) => {
        collectorRef.current = null;
        let out = collector.buf.trim();
        if (timeout && !out) out = '(ПК не повернув вивід у час — можливо, команда ще виконується)';
        resolve(out || '(порожній вивід)');
      };

      const timer = window.setTimeout(() => {
        if (!collector.done) {
          collector.done = true;
          finish(true);
        }
      }, CMD_TIMEOUT_MS);

      const waitLoop = window.setInterval(() => {
        if (collector.done) {
          window.clearInterval(waitLoop);
          window.clearTimeout(timer);
          finish(false);
        }
      }, 120);

      const send = () => deviceClient.sendTerminalInput(cmd);
      if (sawOutputRef.current) send();
      else window.setTimeout(send, 600);
    });
  }, [ensureShell]);

  const sleep = (ms: number) => new Promise<void>(r => window.setTimeout(r, ms));

  // ================= Виконання одного інструмента =================
  const executeTool = useCallback(async (tool: AiTool): Promise<{ output?: string; image?: string; status: 'ok' | 'err' | 'timeout' }> => {
    try {
      switch (tool.type) {
        case 'shell': {
          const out = await runShell((tool.command || '').trim());
          // shot:true — модель хоче одразу побачити екран після команди
          // (зекономлений окремий крок "screenshot" — головна економія при запуску програм).
          if (tool.shot) {
            const b64 = await takeScreenshot();
            return { output: out, image: b64 ?? undefined, status: 'ok' };
          }
          return { output: out, status: 'ok' };
        }
        case 'paste': {
          const text = tool.text || '';
          if (!text) return { output: '(порожній текст для paste)', status: 'err' };
          // Надійне введення: текст → буфер обміну ПК (base64, щоб не ламати
          // лапки/кодування) → Ctrl+V у активне поле. Працює навіть в іграх,
          // куди SendInput-друк (type) не доходить.
          const b64 = b64Utf8(text);
          if (!b64) return { output: '(не вдалося закодувати текст)', status: 'err' };
          const setRes = await runShell(`Set-Clipboard -Value ([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${b64}'))); Write-Output 'CLIP_OK'`);
          if (!/CLIP_OK/.test(setRes)) {
            return { output: `(не вдалося записати в буфер обміну: ${setRes.slice(0, 160)})`, status: 'err' };
          }
          await sleep(150);
          deviceClient.sendShortcut('ctrl+v');
          await sleep(500);
          const b64shot = await takeScreenshot();
          return b64shot ? { image: b64shot, status: 'ok' } : { status: 'ok' };
        }
        case 'memory': {
          const data = (tool.data || '').trim();
          if (!data) return { output: '(порожня пам\'ять — передай повний JSON у полі "data")', status: 'err' };
          const res = await saveMemory(data);
          setMemInfo(`${(Math.min(data.length, MEMORY_MAX_CHARS) / 1024).toFixed(1)} КБ пам'яті`);
          return { output: res, status: /збережено/.test(res) ? 'ok' : 'err' };
        }
        case 'file_to_chat': {
          const path = (tool.path || '').trim();
          if (!path) return { output: '(не вказано "path" — шлях до файлу на ПК)', status: 'err' };
          const res = await downloadFileToChat(path);
          if (!res.ok || !res.base64) {
            return { output: `(не вдалося показати файл у чаті: ${res.error || 'невідома помилка'}). Спробуй інший файл — менший за розміром.`, status: 'err' };
          }
          const name = res.name || path.split('\\').pop() || 'file';
          const mime = res.mime || mimeFor(name);
          const blob = base64ToBlob(res.base64, mime);
          const url = URL.createObjectURL(blob);
          const kind = mediaKindOf(name) ?? 'file';
          push({ kind: 'attach', text: '', attach: { name, url, mime, size: blob.size, kind } });
          return { output: `Файл «${name}» (${formatBytes(blob.size)}) показано користувачу в чаті карткою з програвачем і кнопкою «Завантажити».`, status: 'ok' };
        }
        case 'screenshot': {
          const b64 = await takeScreenshot();
          return b64 ? { image: b64, status: 'ok' } : { output: '(скриншот не отримано)', status: 'err' };
        }
        case 'mouse': {
          deviceClient.sendMouseMoveAbs(tool.nx ?? 0, tool.ny ?? 0);
          await sleep(90);
          const b64 = await takeScreenshot();
          return b64 ? { image: b64, status: 'ok' } : { status: 'ok' };
        }
        case 'click': {
          if (tool.nx != null) {
            deviceClient.sendMouseMoveAbs(tool.nx, tool.ny ?? 0);
            await sleep(140);
          }
          deviceClient.sendMouseClick((tool.button as any) || 'left', Boolean(tool.double));
          await sleep(380);
          const b64 = await takeScreenshot();
          return b64 ? { image: b64, status: 'ok' } : { status: 'ok' };
        }
        case 'type': {
          const text = tool.text || '';
          // Довгий текст шлемо частинами — буфер вводу на ПК обмежений.
          const CHUNK = 180;
          for (let i = 0; i < Math.max(1, Math.ceil(text.length / CHUNK)); i++) {
            deviceClient.sendText(text.slice(i * CHUNK, (i + 1) * CHUNK));
            await sleep(35);
          }
          await sleep(250);
          const b64 = await takeScreenshot();
          return b64 ? { image: b64, status: 'ok' } : { status: 'ok' };
        }
        case 'key': {
          deviceClient.sendKeyPress(tool.key || '', tool.modifiers || []);
          await sleep(300);
          const b64 = await takeScreenshot();
          return b64 ? { image: b64, status: 'ok' } : { status: 'ok' };
        }
        case 'shortcut': {
          deviceClient.sendShortcut(tool.combo || '');
          await sleep(450);
          const b64 = await takeScreenshot();
          return b64 ? { image: b64, status: 'ok' } : { status: 'ok' };
        }
        case 'scroll': {
          deviceClient.sendMouseScroll(0, Math.round(tool.dy ?? 0));
          await sleep(300);
          const b64 = await takeScreenshot();
          return b64 ? { image: b64, status: 'ok' } : { status: 'ok' };
        }
        case 'open': {
          deviceClient.sendOpenUrl(tool.url || '');
          await sleep(1100);
          const b64 = await takeScreenshot();
          return b64 ? { image: b64, status: 'ok' } : { status: 'ok' };
        }
        case 'wait': {
          // Макс піднято до 15с: ігри/браузери вантажаться довго. Скриншот після
          // паузи — щоб не витрачати окремий крок на "screenshot".
          const ms = Math.min(Math.max(tool.ms ?? 1500, 200), 15000);
          await sleep(ms);
          const b64 = await takeScreenshot();
          return b64 ? { image: b64, status: 'ok' } : { status: 'ok' };
        }
        default:
          return { output: '(невідомий інструмент)', status: 'err' };
      }
    } catch (e: any) {
      return { output: `(помилка виконання: ${e?.message || e})`, status: 'err' };
    }
  }, [runShell, takeScreenshot, saveMemory, downloadFileToChat, push]);

  // ================= Виклик AI через сервер-проксі =================
  type ChatTurn = { role: 'user' | 'model'; text: string; image?: string };

  const aiCall = useCallback(async (chat: ChatTurn[], systemText: string): Promise<{ ok: boolean; message?: string; tool?: AiTool | null; tools?: AiTool[] | null; done?: boolean; error?: string; model?: string; unparsed?: boolean }> => {
    // Слім-пейлоад: лишаємо тільки ОСТАННІЙ скриншот в історії — інакше тіло
    // запиту росте з кожним кроком циклу (по сотнях КБ на кадр) → 413/таймаути.
    let lastImgIdx = -1;
    for (let i = 0; i < chat.length; i++) if (chat[i].image) lastImgIdx = i;
    const slim = chat.map((t, i) => (t.image && i !== lastImgIdx ? { role: t.role, text: t.text } : t));
    const body = JSON.stringify({ messages: slim, system: systemText });
    const endpoints = [
      'https://fluxcontrol-backend.onrender.com/api/ai/chat',
      '/api/ai/chat'
    ];
    let lastErr = 'Немає з’єднання з бекендом';
    for (const url of endpoints) {
      try {
        const res = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body,
          signal: AbortSignal.timeout(90000)
        });
        // Людські пояснення замість «Помилка з’єднання» для типових кодів:
        if (res.status === 413) {
          lastErr = 'Запит зі скриншотами завеликий для бекенда — на Render працює стара версія server.js (ліміт 100KB). Задеплойте оновлений FluxControl.Server (ліміт 30MB).';
          continue;
        }
        if (res.status === 404) {
          lastErr = 'На бекенді немає /api/ai/chat — задеплойте оновлений FluxControl.Server (server.js) на Render.';
          continue;
        }
        if (res.status === 401 || res.status === 403) {
          lastErr = 'Gemini відхилив API-ключ — перевірте GEMINI_API_KEY на Render.';
          continue;
        }
        if (res.status === 429) {
          lastErr = 'Gemini: перевищено ліміт запитів — спробуйте за хвилину.';
          continue;
        }
        const data = await res.json().catch(() => null);
        if (data?.success && typeof data.text === 'string') {
          const parsed = extractJson(data.text);
          if (parsed) {
            if (data.model) setModelUsed(data.model);
            const tool = parsed.tool ?? (parsed.command ? { type: 'shell' as const, command: parsed.command } : null);
            const tools = Array.isArray(parsed.tools) ? parsed.tools : null;
            return { ok: true, message: parsed.message, tool, tools, done: parsed.done ?? true, model: data.model };
          }
          // Модель відповіла текстом, але не валідним JSON — маркуємо, цикл
          // переспробує з виправною підказкою (раніше це виглядало як «зависання»).
          return { ok: true, message: data.text.slice(0, 300), tool: null, done: false, unparsed: true, model: data.model };
        }
        if (data?.error) lastErr = String(data.error);
        else if (!res.ok) lastErr = `Помилка бекенда (HTTP ${res.status})`;
      } catch (e: any) {
        const msg = String(e?.message || e);
        lastErr = /timeout|abort/i.test(msg)
          ? 'Бекенд не відповів вчасно (холодний старт Render або Gemini довго думає) — спробуйте ще раз.'
          : `Немає з’єднання з fluxcontrol-backend.onrender.com (${msg})`;
      }
    }
    return { ok: false, error: lastErr };
  }, []);

  // ================= Головний цикл агента =================
  const runAgent = useCallback(async (userText: string) => {
    if (busyRef.current) return;
    busyRef.current = true;
    abortRef.current = false;
    setBusy(true);
    push({ kind: 'user', text: userText });

    const chat: ChatTurn[] = [];

    try {
      // Пам'ять про ПК: тягнемо з агента (новий exe відповідає ai_memory_data;
      // старий мовчить — через 4с просто працюємо без пам'яті).
      setStepInfo('читаю пам\'ять про ПК…');
      const memory = await loadMemory();
      if (memory) setMemInfo(`${(memory.length / 1024).toFixed(1)} КБ пам'яті`);
      const system = buildSystemPrompt(memory);

      // Перший кадр: даємо моделі побачити екран одразу.
      setStepInfo('дивлюсь на екран…');
      const firstShot = await takeScreenshot();

      let currentUser: ChatTurn = { role: 'user', text: userText, ...(firstShot ? { image: firstShot } : {}) };
      let noToolNudges = 0;
      let formatRetries = 0;
      let lastSig = '';
      // Захист від зациклення на дії, що постійно падає: після 2 однакових
      // невдач підряд вона більше НЕ виконується (модель отримує помилку
      // «дія пропущена» і мусить змінити підхід).
      let lastFailSig = '';
      let failStreak = 0;
      let stopped = false;   // Стоп / помилка / інша причина негайного виходу
      let finished = false;  // задача завершена (done:true)

      // Блоки кроків з авто-продовженням: агент більше не зупиняється на
      // півдороги («Досягнуто ліміту кроків» лякало юзера і ламало задачі).
      for (let seg = 0; seg < SEGMENT_STEPS.length && !stopped && !finished; seg++) {
        if (seg > 0) {
          push({ kind: 'sys', text: `Автоматично продовжую — додатковий блок ${seg} (ще ${SEGMENT_STEPS[seg]} кроків). «Стоп» перериває в будь-який момент.` });
          currentUser = { role: 'user', text: 'ПРОДОВЖУЙ задачу з того місця, де зупинився. Якщо дія не спрацьовує — зміни підхід (type → paste, пошук по іконках → shell + Get-Process). Якщо задача вже виконана — одразу done:true.' };
        }
        const maxSteps = SEGMENT_STEPS[seg];

        for (let step = 0; step < maxSteps; step++) {
          if (abortRef.current) {
            push({ kind: 'sys', text: 'Зупинено користувачем.' });
            stopped = true;
            break;
          }

          setStepInfo(`крок ${step + 1}/${maxSteps} — думаю…`);
          chat.push(currentUser);
          let reply = await aiCall(chat, system);
          if (!reply.ok) {
            // Одна автоматична повторна спроба — мережа/Gemini іноді збоїть
            // на живому Render (холодний старт), раніше це вбивало задачу.
            await sleep(1500);
            if (abortRef.current) {
              push({ kind: 'sys', text: 'Зупинено користувачем.' });
              stopped = true;
              break;
            }
            setStepInfo(`крок ${step + 1}/${maxSteps} — повторна спроба…`);
            reply = await aiCall(chat, system);
          }
          if (!reply.ok) {
            const hint = /Render|бекенд|server\.js|GEMINI/i.test(reply.error || '') ? '' : ' Якщо повторюється — перевірте, чи на Render задеплоєний оновлений server.js.';
            push({ kind: 'sys', text: `Помилка AI: ${reply.error}.${hint}` });
            stopped = true;
            break;
          }
          if (abortRef.current) {
            push({ kind: 'sys', text: 'Зупинено користувачем.' });
            stopped = true;
            break;
          }

          chat.push({ role: 'model', text: JSON.stringify({ message: reply.message || '', tool: reply.tool || null, tools: reply.tools || null, done: reply.done ?? true }) });

          // Відповідь не в JSON — даємо моделі шанс виправитись (лишилися спроби).
          if (reply.unparsed) {
            if (formatRetries < MAX_FORMAT_RETRIES) {
              formatRetries += 1;
              push({ kind: 'sys', text: 'Відповідь прийшла не в JSON-форматі — прошу переформатувати…' });
              currentUser = { role: 'user', text: 'Твоя попередня відповідь — НЕ валідний JSON. Відповісь РІВНО ОДНИМ JSON-об\'єктом без markdown-огорож: {"message":"...","tool":{...}|null,"tools":[...]|null,"done":false}' };
              continue;
            }
            push({ kind: 'sys', text: 'Агент кілька разів відповів поза JSON-форматом. Спробуйте переформулювати запит.' });
            stopped = true;
            break;
          }

          if (reply.message) push({ kind: 'ai', text: reply.message });

          // Одна дія (tool) АБО мульти-дії одним кроком (tools, до 4).
          const toolsToRun: AiTool[] = reply.tools && reply.tools.length
            ? reply.tools.filter((t: AiTool) => t && t.type).slice(0, MAX_TOOLS_PER_STEP)
            : (reply.tool && reply.tool.type ? [reply.tool] : []);

          if (!toolsToRun.length) {
            // Сталося «думало і перестало»: done:false без команди — штовхаємо далі.
            if (reply.done === false && noToolNudges < MAX_NO_TOOL_NUDGES) {
              noToolNudges += 1;
              push({ kind: 'sys', text: 'Агент зупинився без команди — прошу продовжити задачу…' });
              currentUser = { role: 'user', text: 'Ти повернув done:false без інструмента — цикл зупинився. Продовжуй РЕАЛЬНІ дії: поверни "tool" або "tools" з наступним кроком задачі.' };
              continue;
            }
            if (reply.done === false) {
              push({ kind: 'sys', text: 'Агент зупинився без завершення задачі. Дайте йому наступну вказівку, щоб продовжити.' });
              stopped = true;
              break;
            }
            finished = true; // штатне done:true
            stopped = true;
            break;
          }

          // Виконання: одна дія або ланцюг до 4 підряд БЕЗ звернень до моделі.
          const outs: string[] = [];
          let lastImage: string | undefined;
          let lastStatus: 'ok' | 'err' | 'timeout' = 'ok';
          for (const tool of toolsToRun) {
            if (abortRef.current) {
              push({ kind: 'sys', text: 'Зупинено користувачем.' });
              stopped = true;
              break;
            }
            const sigPre = toolSig(tool);
            if (sigPre && sigPre === lastFailSig && failStreak >= 2) {
              push({ kind: 'tool', text: '', tool, toolLabel: toolLabel(tool), status: 'err', output: '(авто-пропуск: ця дія вже двічі поспіль завершилась помилкою)' });
              outs.push(`Дію «${toolLabel(tool)}» пропущено автоматично: вона вже двічі поспіль не спрацювала. НЕ викликай її знову в тому самому вигляді — зміни підхід (інший шлях/менший файл/інший спосіб).`);
              continue;
            }
            push({ kind: 'tool', text: '', tool, toolLabel: toolLabel(tool), status: 'run' });
            setStepInfo(`крок ${step + 1}/${maxSteps} — ${toolLabel(tool)}…`);
            const result = await executeTool(tool);
            patchLastTool({
              output: result.output,
              image: result.image,
              status: result.status === 'ok' ? 'ok' : result.status,
            });
            if (result.image) lastImage = result.image;
            if (result.status !== 'ok') lastStatus = result.status;
            // Оновлюємо лічильник серії однакових невдач.
            if (result.status !== 'ok') {
              if (sigPre && sigPre === lastFailSig) failStreak += 1;
              else { lastFailSig = sigPre; failStreak = 1; }
            } else if (sigPre === lastFailSig) {
              lastFailSig = ''; failStreak = 0;
            }
            if (tool.type === 'shell') {
              outs.push(`РЕЗУЛЬТАТ КОМАНДИ "${(tool.command || '').trim()}":\n${result.output || '(порожній вивід)'}`);
            } else if (result.output) {
              outs.push(`${toolLabel(tool)}: ${result.output}`);
            }

            // Guard від зациклення: та сама дія підряд.
            const sig = toolSig(tool);
            if (sig && sig === lastSig) {
              outs.push(`УВАГА: дію "${toolLabel(tool)}" виконано двічі підряд. Якщо вона не дала результату — НЕ повторюй її втретє: зміни підхід (для тексту — paste, для запуску програм — shell Start-Process, для пошуку вікон — Get-Process).`);
            }
            if (sig) lastSig = sig;
          }
          if (stopped) break;

          const resultParts: string[] = [];
          if (outs.length) resultParts.push(outs.join('\n\n'));
          else resultParts.push(`РЕЗУЛЬТАТ ДІЇ (${toolsToRun.map(toolLabel).join(' → ')}): виконано.`);
          if (lastImage) resultParts.push('Свіжий скриншот екрана додано нижче — проаналізуй очима: чи досягнуто очікуваного результату?');
          if (lastStatus !== 'ok') resultParts.push('Статус останньої дії: помилка — не вважай її успішною, перевір і виправ.');

          currentUser = { role: 'user', text: resultParts.join('\n\n'), ...(lastImage ? { image: lastImage } : {}) };

          if (seg === SEGMENT_STEPS.length - 1 && step === maxSteps - 1) {
            push({ kind: 'sys', text: 'Вичерпано всі кроки автоматичного продовження. Дайте агенту наступну вказівку, щоб продовжити.' });
          }
        }
      }
    } catch (e: any) {
      push({ kind: 'sys', text: `Несподівана помилка: ${e?.message || e}` });
    } finally {
      busyRef.current = false;
      setBusy(false);
      setStepInfo('');
    }
  }, [aiCall, push, executeTool, patchLastTool, takeScreenshot, loadMemory]);

  const submit = useCallback(() => {
    const text = input.trim();
    if (!text || busyRef.current) return;
    setInput('');
    atBottomRef.current = true;
    void runAgent(text);
  }, [input, runAgent]);

  const clearChat = useCallback(() => {
    if (busyRef.current) return;
    setMessages([]);
  }, []);

  return (
    <div className="fc-card-static relative flex h-[calc(100vh-15rem)] min-h-[30rem] flex-col overflow-hidden border border-fuchsia-500/20">
      {/* Header */}
      <div className="flex shrink-0 items-center justify-between gap-3 border-b border-white/10 bg-black/50 px-3.5 py-2.5">
        <div className="flex min-w-0 items-center gap-2.5">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-violet-600 to-fuchsia-600 text-white shadow-lg shadow-fuchsia-600/25">
            <Bot className="h-4.5 w-4.5" />
          </span>
          <div className="min-w-0">
            <p className="truncate text-[13px] font-black text-white">AI-агент на ПК</p>
            <p className="truncate text-[10px] font-semibold text-fuchsia-300/80">
              {busy ? stepInfo : `${modelUsed || MODEL_LABEL}${memInfo ? ` · ${memInfo}` : ''} · бачить екран · мінімум кроків`}
            </p>
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-1.5">
          {aiStatus !== 'ok' && (
            <span
              title={aiStatus === 'old' ? 'На бекенді старий server.js: задеплойте оновлений FluxControl.Server на Render' : 'fluxcontrol-backend.onrender.com не відповідає'}
              className={`hidden sm:flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-bold ${
                aiStatus === 'checking'
                  ? 'border-white/15 bg-white/5 text-zinc-400'
                  : aiStatus === 'old'
                    ? 'border-amber-500/30 bg-amber-500/10 text-amber-300'
                    : 'border-red-500/30 bg-red-500/10 text-red-300'
              }`}
            >
              <span className={`h-1.5 w-1.5 rounded-full ${aiStatus === 'checking' ? 'bg-zinc-500 animate-pulse' : aiStatus === 'old' ? 'bg-amber-400' : 'bg-red-400'}`} />
              {aiStatus === 'checking' ? 'Перевірка бекенда…' : aiStatus === 'old' ? 'Бекенд застарілий' : 'Бекенд недоступний'}
            </span>
          )}
          {busy && (
            <button
              type="button"
              onClick={() => { abortRef.current = true; }}
              className="flex cursor-pointer items-center gap-1.5 rounded-lg border border-red-500/30 bg-red-500/10 px-2.5 py-1.5 text-[11px] font-bold text-red-300 transition-colors hover:bg-red-500/20"
            >
              <Square className="h-3 w-3" />
              <span>Стоп</span>
            </button>
          )}
          <button
            type="button"
            onClick={clearChat}
            title="Очистити чат"
            aria-label="Очистити чат"
            disabled={busy}
            className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 bg-white/5 text-zinc-400 transition-colors hover:bg-white/10 hover:text-white disabled:opacity-40"
          >
            <Eraser className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Stream */}
      <div
        ref={scrollRef}
        onScroll={handleScroll}
        className="flex-1 space-y-2.5 overflow-y-auto bg-black px-3.5 py-3.5"
        aria-live="polite"
      >
        {messages.length === 0 && (
          <div className="flex h-full flex-col items-center justify-center px-4 text-center">
            <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-2xl border border-fuchsia-500/30 bg-gradient-to-br from-violet-600/30 to-fuchsia-600/30 text-fuchsia-300">
              <Bot className="h-7 w-7" />
            </div>
            <p className="text-[13px] font-bold text-white">Постав задачу — агент виконає її сам</p>
            <p className="mt-1.5 max-w-sm text-[11px] leading-relaxed text-gray-500">
              Бачить екран «{device.name}», керує мишею й клавіатурою, виконує PowerShell,
              створює й запускає скрипти, вводить текст навіть там, де друк не працює (через буфер обміну),
              показує відео/фото/файли з ПК прямо в чаті (з кнопкою «Завантажити») і пам'ятає ваш ПК між задачами — щоб виконувати швидше.
            </p>
            <div className="mt-4 flex flex-wrap justify-center gap-1.5">
              {SUGGESTIONS.map(s => (
                <button
                  key={s}
                  type="button"
                  onClick={() => { if (!busyRef.current) { atBottomRef.current = true; void runAgent(s); } }}
                  className="cursor-pointer rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-[10.5px] font-semibold text-gray-300 transition-colors hover:border-fuchsia-500/40 hover:bg-fuchsia-500/10 hover:text-white"
                >
                  {s}
                </button>
              ))}
            </div>
            {!shellReady && (
              <p className="mt-3 flex items-center gap-1.5 text-[10px] font-semibold text-violet-300/70">
                <Loader2 className="h-3 w-3 animate-spin" />
                готуємо оболонку на ПК…
              </p>
            )}
          </div>
        )}

        {messages.map(m => {
          if (m.kind === 'user') {
            return (
              <div key={m.id} className="flex justify-end">
                <div className="max-w-[85%] rounded-2xl rounded-br-md bg-gradient-to-br from-indigo-600 to-violet-600 px-3.5 py-2 text-[12px] font-semibold text-white shadow-lg shadow-indigo-600/20">
                  {m.text}
                </div>
              </div>
            );
          }
          if (m.kind === 'ai') {
            return (
              <div key={m.id} className="flex items-start gap-2">
                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-violet-600 to-fuchsia-600 text-white">
                  <Bot className="h-3.5 w-3.5" />
                </span>
                <div className="max-w-[85%] whitespace-pre-wrap break-words rounded-2xl rounded-tl-md border border-fuchsia-500/20 bg-[#120f1c] px-3.5 py-2 text-[12px] leading-relaxed text-gray-100">
                  {m.text}
                </div>
              </div>
            );
          }
          if (m.kind === 'attach' && m.attach) {
            const a = m.attach;
            return (
              <div key={m.id} className="flex items-start gap-2">
                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-violet-600 to-fuchsia-600 text-white">
                  <FileDown className="h-3.5 w-3.5" />
                </span>
                <div className="ai-attach">
                  <div className="ai-attach-head">
                    <FileDown />
                    <b>{a.name}</b>
                    <small>{formatBytes(a.size)}</small>
                  </div>
                  {a.kind === 'video' && <video src={a.url} controls preload="metadata" playsInline />}
                  {a.kind === 'image' && <img src={a.url} alt={a.name} loading="lazy" />}
                  {a.kind === 'audio' && <audio src={a.url} controls />}
                  {a.kind === 'file' && (
                    <p className="px-3.5 py-2.5 text-[11px] text-zinc-400">Файл з ПК — можна завантажити нижче.</p>
                  )}
                  <div className="ai-attach-foot">
                    <a href={a.url} download={a.name} className="fc-btn fc-btn-primary fc-shine w-full">
                      <FileDown className="h-3.5 w-3.5" />
                      <span>Завантажити</span>
                    </a>
                  </div>
                </div>
              </div>
            );
          }
          if (m.kind === 'tool') {
            const meta = TOOL_META[m.tool?.type || 'shell'] || TOOL_META.shell;
            return (
              <div key={m.id} className="pl-6">
                <div className={`rounded-xl border px-3 py-2 ${meta.color}`}>
                  <div className="flex items-center gap-2">
                    <span className="shrink-0">{meta.icon}</span>
                    <span className="min-w-0 flex-1 truncate font-mono text-[11px] font-bold">{m.toolLabel}</span>
                    {m.status === 'run' && <Loader2 className="h-3.5 w-3.5 shrink-0 animate-spin opacity-80" />}
                    {m.status === 'ok' && <CheckCircle2 className="h-3.5 w-3.5 shrink-0 opacity-80" />}
                    {(m.status === 'err' || m.status === 'timeout') && <AlertTriangle className="h-3.5 w-3.5 shrink-0 opacity-90" />}
                  </div>
                  {m.tool?.type === 'shell' && m.tool.command && (
                    <p className="mt-1.5 break-all whitespace-pre-wrap border-t border-white/10 pt-1.5 font-mono text-[10.5px] leading-relaxed opacity-90">
                      {m.tool.command}
                    </p>
                  )}
                  {m.output && (
                    <p className="mt-1.5 max-h-24 overflow-y-auto break-words whitespace-pre-wrap border-t border-white/10 pt-1.5 font-mono text-[10.5px] leading-relaxed opacity-75 fcx-scroll">
                      {m.output}
                    </p>
                  )}
                  {m.image && (
                    <button
                      type="button"
                      onClick={() => setViewImage(m.image!)}
                      className="mt-2 block cursor-zoom-in overflow-hidden rounded-lg border border-white/15 transition-opacity hover:opacity-90"
                      title="Дивитись на весь екран"
                    >
                      <img src={`data:image/jpeg;base64,${m.image}`} alt="Скриншот екрана ПК" className="h-28 w-auto max-w-full object-cover" />
                    </button>
                  )}
                </div>
              </div>
            );
          }
          return (
            <div key={m.id} className="pl-6 text-[10.5px] italic text-violet-300/60">
              {m.text}
            </div>
          );
        })}

        {busy && (
          <div className="flex items-center gap-2 pl-6 text-[11px] font-semibold text-fuchsia-300/80">
            <Eye className="h-3.5 w-3.5 animate-pulse" />
            <span>{stepInfo || 'агент думає та діє…'}</span>
          </div>
        )}
      </div>

      {/* Input */}
      <form
        onSubmit={(e) => { e.preventDefault(); submit(); }}
        className="flex shrink-0 items-center gap-2 border-t border-white/10 bg-black/90 px-3.5 py-2.5"
      >
        <span className="shrink-0 text-fuchsia-400" title="AI-агент">
          <TerminalSquare className="h-4 w-4" />
        </span>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={busy}
          spellCheck={false}
          autoComplete="off"
          aria-label="Задача для AI-агента"
          placeholder={busy ? 'Аген працює — «Стоп», щоб перервати…' : 'Наприклад: відкрий Telegram і напиши Печеньці «привіт»…'}
          className="min-w-0 flex-1 border-none bg-transparent text-[12px] text-white placeholder:text-zinc-600 focus:outline-none disabled:opacity-60"
        />
        <button
          type="submit"
          disabled={busy || !input.trim()}
          aria-label="Надіслати задачу"
          title="Надіслати (Enter)"
          className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white shadow transition-all hover:brightness-110 disabled:opacity-40"
        >
          <SendHorizonal className="h-3.5 w-3.5" />
        </button>
      </form>

      {/* Fullscreen screenshot viewer */}
      {viewImage && (
        <div
          className="fixed inset-0 z-[80] flex items-center justify-center bg-black/92 p-4 backdrop-blur-sm"
          onClick={() => setViewImage(null)}
          role="dialog"
          aria-label="Перегляд скриншота"
        >
          <img
            src={`data:image/jpeg;base64,${viewImage}`}
            alt="Скриншот екрана ПК"
            className="max-h-full max-w-full rounded-xl border border-white/15 object-contain shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          />
          <button
            type="button"
            onClick={() => setViewImage(null)}
            aria-label="Закрити"
            className="absolute right-4 top-4 grid h-9 w-9 place-items-center rounded-xl border border-white/15 bg-white/10 text-white transition-colors hover:bg-white/20"
          >
            <ChevronDown className="h-5 w-5" />
          </button>
        </div>
      )}
    </div>
  );
};
