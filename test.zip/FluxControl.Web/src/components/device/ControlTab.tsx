import React, { useEffect, useRef, useState } from 'react';
import {
  Ban,
  ChevronRight,
  Clock,
  CloudMoon,
  Globe,
  Keyboard,
  Lock,
  Maximize2,
  Minus,
  Monitor,
  Moon,
  Mouse,
  MousePointer,
  MousePointerClick,
  Move,
  Pause,
  Play,
  Plus,
  Power,
  RotateCcw,
  ScreenShare,
  SkipBack,
  SkipForward,
  Square,
  Timer,
  Touchpad,
  Type,
  Volume2,
  VolumeX,
  X
} from 'lucide-react';
import { Device } from '../../types';
import { deviceClient } from '../../services/deviceClient';
import { RemoteCaptureTools } from './RemoteCaptureTools';
import { VirtualKeyboardLauncher } from './VirtualKeyboard';
import { WinLockCard } from './WinLockCard';
import { toast } from '../../utils/toast';
import { clampPercent, formatSeconds, loadStoredNumber, pick, storeValue } from './fcEvents';

interface ControlTabProps {
  device: Device;
}

/* ============================================================ */
/* Touchpad gestures: shared accumulate + flush logic            */
/* ============================================================ */

/** Спільна логіка тачпада: накопичує дельти і шле рух мишки ПК не частіше
 *  ніж раз на 16 мс (події тачпада значно частіші за потребу релея). */
function useTouchpadMove(scale: number) {
  const lastRef = useRef<{ x: number; y: number } | null>(null);
  const accRef = useRef({ x: 0, y: 0, lastSent: 0 });

  const begin = (x: number, y: number) => {
    lastRef.current = { x, y };
    accRef.current = { x: 0, y: 0, lastSent: performance.now() };
  };

  const move = (x: number, y: number, s = scale) => {
    if (!lastRef.current) return;
    const dx = (x - lastRef.current.x) * s;
    const dy = (y - lastRef.current.y) * s;
    lastRef.current = { x, y };
    const acc = accRef.current;
    acc.x += dx;
    acc.y += dy;
    const now = performance.now();
    if (now - acc.lastSent >= 16) {
      const rx = Math.round(acc.x);
      const ry = Math.round(acc.y);
      if (rx !== 0 || ry !== 0) {
        deviceClient.sendMouseMove(rx, ry);
        acc.x -= rx;
        acc.y -= ry;
      }
      acc.lastSent = now;
    }
  };

  const end = () => { lastRef.current = null; };

  return {
    onTouchStart: (e: React.TouchEvent) => {
      if (e.touches.length === 1) begin(e.touches[0].clientX, e.touches[0].clientY);
    },
    onTouchMove: (e: React.TouchEvent) => {
      if (e.touches.length === 1) move(e.touches[0].clientX, e.touches[0].clientY);
    },
    onTouchEnd: end,
    onMouseDown: (e: React.MouseEvent) => begin(e.clientX, e.clientY),
    onMouseMove: (e: React.MouseEvent) => {
      if (e.buttons === 1) move(e.clientX, e.clientY, scale - 0.2);
    },
    onMouseUp: end
  };
}

/* ============================================================ */
/* Fullscreen touchpad — для телефонів: не скролить сайт         */
/* ============================================================ */

const TouchpadFullscreen: React.FC<{ deviceName: string; onClose: () => void }> = React.memo(({ deviceName, onClose }) => {
  const moveHandlers = useTouchpadMove(2.1);
  // Жест по поверхні: тап = клік, два пальці = скрол, тап двома = ПКМ.
  const gest = useRef({ fingers: 0, moved: false, startT: 0, twoFinger: false, scrollLastY: 0 });
  // Затиснута кнопка в нижній панелі (drag пальцем + затиснута ЛКМ).
  const heldBtn = useRef<'left' | null>(null);

  useEffect(() => {
    const prior = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = prior;
      window.removeEventListener('keydown', onKey);
    };
  }, [onClose]);

  const markMoved = () => { gest.current.moved = true; };

  const surfaceTouchStart = (e: React.TouchEvent) => {
    const t = e.touches;
    gest.current.fingers = t.length;
    gest.current.moved = false;
    gest.current.startT = performance.now();
    if (t.length === 1) {
      gest.current.twoFinger = false;
      moveHandlers.onTouchStart(e);
    } else if (t.length >= 2) {
      gest.current.twoFinger = true;
      gest.current.scrollLastY = (t[0].clientY + t[1].clientY) / 2;
    }
  };

  const surfaceTouchMove = (e: React.TouchEvent) => {
    const t = e.touches;
    if (t.length >= 2 && gest.current.twoFinger) {
      const y = (t[0].clientY + t[1].clientY) / 2;
      const dy = y - gest.current.scrollLastY;
      gest.current.scrollLastY = y;
      if (Math.abs(dy) >= 2) {
        deviceClient.sendMouseScroll(0, Math.round(-dy * 2.6));
        markMoved();
      }
    } else if (t.length === 1) {
      moveHandlers.onTouchMove(e);
    }
  };

  const surfaceTouchEnd = (e: React.TouchEvent) => {
    const remaining = e.touches.length;
    if (remaining === 0) {
      const g = gest.current;
      const dur = performance.now() - g.startT;
      if (!g.moved && dur < 280) {
        // Тап без руху: один палець — ЛКМ, два пальці — ПКМ.
        deviceClient.sendMouseClick(g.twoFinger ? 'right' : 'left');
      }
      moveHandlers.onTouchEnd();
      gest.current.fingers = 0;
    } else if (remaining === 1) {
      // Другий палець підняли — перезапускаємо трекінг руху чисто.
      gest.current.twoFinger = false;
      moveHandlers.onTouchEnd();
      moveHandlers.onTouchStart({ touches: e.touches } as React.TouchEvent);
    }
  };

  const holdLeftDown = () => {
    heldBtn.current = 'left';
    deviceClient.sendMouseDown('left');
  };
  const holdLeftUp = () => {
    if (heldBtn.current === 'left') {
      heldBtn.current = null;
      deviceClient.sendMouseUp('left');
    }
  };

  return (
    <div className="tp-fs" role="dialog" aria-modal="true" aria-label="Тачпад на весь екран">
      <div className="tp-fs-bar" style={{ paddingTop: '.8rem', paddingBottom: 0 }}>
        <div className="flex min-w-0 items-center gap-2.5">
          <span className="grid h-9 w-9 flex-none place-items-center rounded-xl border border-indigo-400/30 bg-indigo-500/20 text-indigo-300">
            <Touchpad className="h-4.5 w-4.5" />
          </span>
          <div className="min-w-0">
            <p className="truncate text-xs font-extrabold text-white">Тачпад — {deviceName}</p>
            <p className="text-[10px] text-zinc-400">сайт не скролиться, поки тачпад відкритий</p>
          </div>
        </div>
        <button onClick={onClose} className="tp-fs-btn tp-fs-close ml-auto" aria-label="Закрити тачпад">
          <X className="h-5 w-5" />
        </button>
      </div>

      <div
        className="tp-fs-surface"
        {...moveHandlers}
        onTouchStart={surfaceTouchStart}
        onTouchMove={surfaceTouchMove}
        onTouchEnd={surfaceTouchEnd}
      >
        <div className="tp-fs-dots" />
        <div className="tp-fs-hint">
          <Move className="h-8 w-8" />
          <b>Водіть пальцем — мишка на ПК рухається</b>
          <small>
            тап — лівий клік &nbsp;·&nbsp; тап двома пальцями — правий клік<br />
            рух двома пальцями — прокрутка &nbsp;·&nbsp; затиснута «ЛКМ» знизу — перетягування
          </small>
        </div>
      </div>

      <div className="tp-fs-bar">
        <button
          className={`tp-fs-btn ${heldBtn.current === 'left' ? 'held' : ''}`}
          onPointerDown={holdLeftDown}
          onPointerUp={holdLeftUp}
          onPointerLeave={holdLeftUp}
          onPointerCancel={holdLeftUp}
        >
          <MousePointerClick className="h-4 w-4" />
          <span>ЛКМ (тримати = drag)</span>
        </button>
        <button className="tp-fs-btn" onClick={() => deviceClient.sendMouseClick('left', true)}>
          <span>2×</span>
        </button>
        <button className="tp-fs-btn" onClick={() => deviceClient.sendMouseClick('right')}>
          <MousePointer className="h-4 w-4" />
          <span>ПКМ</span>
        </button>
      </div>
    </div>
  );
});
TouchpadFullscreen.displayName = 'TouchpadFullscreen';

/* ============================================================ */
/* Мишка-пристрій: натискабельна форма з ЛКМ / ПКМ / коліщатком  */
/* ============================================================ */

const CLICK_DELAY_MS = 240;

const MouseCard: React.FC<{ deviceName: string }> = React.memo(({ deviceName }) => {
  const inlinePad = useTouchpadMove(1.8);
  const [fsOpen, setFsOpen] = useState(false);
  const [held, setHeld] = useState<string | null>(null);
  // Ліва кнопка: перший тап чекає CLICK_DELAY — якщо прийде другий,
  // надсилаємо подвійний клік замість двох одиночних.
  const singleClickTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const dragMoved = useRef(false);

  const clearSingleTimer = () => {
    if (singleClickTimer.current) {
      clearTimeout(singleClickTimer.current);
      singleClickTimer.current = null;
    }
  };

  useEffect(() => clearSingleTimer, []);

  /** Спільна обробка зони: затиснення = press-hold (drag), короткий тап = клік. */
  const zoneHandlers = (id: string, button: 'left' | 'right' | 'middle') => ({
    onPointerDown: () => {
      dragMoved.current = false;
      setHeld(id);
      if (button !== 'middle') deviceClient.sendMouseDown(button);
    },
    onPointerMove: () => {
      dragMoved.current = true;
    },
    onPointerUp: () => {
      setHeld(null);
      if (button === 'middle') return; // коліщатко: тільки клік нижче
      deviceClient.sendMouseUp(button);
      if (!dragMoved.current) {
        if (button === 'left') {
          if (singleClickTimer.current) {
            clearTimeout(singleClickTimer.current);
            singleClickTimer.current = null;
            deviceClient.sendMouseClick('left', true);
          } else {
            singleClickTimer.current = setTimeout(() => {
              singleClickTimer.current = null;
              deviceClient.sendMouseClick('left');
            }, CLICK_DELAY_MS);
          }
        } else {
          deviceClient.sendMouseClick('right');
        }
      }
    },
    onPointerLeave: () => {
      if (held !== id) return;
      setHeld(null);
      if (button !== 'middle') deviceClient.sendMouseUp(button);
      clearSingleTimer();
    }
  });

  // Коліщатко: тап = середній клік; затиснути + рух вертикально = скрол.
  const wheelRef = useRef<{ y: number; active: boolean }>({ y: 0, active: false });
  const wheelHandlers = {
    onPointerDown: (e: React.PointerEvent) => {
      wheelRef.current = { y: e.clientY, active: true };
      setHeld('wheel');
    },
    onPointerMove: (e: React.PointerEvent) => {
      if (!wheelRef.current.active) return;
      const dy = e.clientY - wheelRef.current.y;
      if (Math.abs(dy) >= 6) {
        wheelRef.current.y = e.clientY;
        deviceClient.sendMouseScroll(0, Math.round(-dy * 2.2));
      }
    },
    onPointerUp: () => {
      const wasActive = wheelRef.current.active;
      wheelRef.current.active = false;
      setHeld(null);
      // Коротке натискання без прокрутки = середній клік.
      if (wasActive) deviceClient.sendMouseClick('middle');
    },
    onPointerLeave: () => {
      wheelRef.current.active = false;
      setHeld(null);
    }
  };

  return (
    <section className="fc-card p-5">
      <div className="fc-section-head mb-4">
        <div className="fc-section-icon"><Mouse className="h-5 w-5" /></div>
        <div>
          <h3>Віртуальна мишка</h3>
          <p>Натискабельна форма мишки + тачпад на весь екран</p>
        </div>
      </div>

      <div className="grid items-center gap-5 sm:grid-cols-[auto,1fr]">
        {/* Форма мишки: реальні зони натискань */}
        <div className="mouse-device">
          <button
            className={`mouse-zone mouse-l ${held === 'l' ? 'held' : ''}`}
            {...zoneHandlers('l', 'left')}
            aria-label="Ліва кнопка мишки"
          />
          <button
            className={`mouse-zone mouse-r ${held === 'r' ? 'held' : ''}`}
            {...zoneHandlers('r', 'right')}
            aria-label="Права кнопка мишки"
          />
          <button
            className={`mouse-wheel ${held === 'wheel' ? 'held' : ''}`}
            {...wheelHandlers}
            aria-label="Коліщатко (середня кнопка / скрол)"
          />
          <span className="mouse-sep" />
          <span className="mouse-hline" />
          <span className="mouse-zone-tag" style={{ left: '.9rem', top: '1.1rem' }}>ЛКМ</span>
          <span className="mouse-zone-tag" style={{ right: '.9rem', top: '1.1rem' }}>ПКМ</span>
          <div className="mouse-zone mouse-palm">
            <div className="mouse-palm-inner">
              <MousePointer />
              <b>Затисніть ЛКМ або ПКМ</b>
              <small>і ведіть — це перетягування на ПК. Тап — клік, два тапи підряд — подвійний.</small>
            </div>
          </div>
        </div>

        {/* Компактний тачпад + кнопка на весь екран */}
        <div className="flex flex-col gap-3">
          <div
            {...inlinePad}
            className="group relative flex h-36 w-full select-none flex-col items-center justify-center overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-black/70 via-indigo-950/20 to-black/70 shadow-inner touch-none cursor-crosshair hover:border-indigo-500/30"
          >
            <div className="absolute inset-0 bg-[radial-gradient(#6366f1_1px,transparent_1px)] [background-size:16px_16px] opacity-10" />
            <p className="text-xs font-medium text-indigo-300/60">Швидкий тачпад</p>
            <p className="mt-0.5 text-[10px] text-zinc-500">водіть пальцем — мишка рухається</p>
          </div>
          <button onClick={() => setFsOpen(true)} className="fc-btn fc-btn-primary fc-shine w-full">
            <Maximize2 className="h-4 w-4" />
            <span>Тачпад на весь екран</span>
          </button>
          <p className="text-center text-[10px] leading-relaxed text-zinc-500 sm:text-left">
            На телефоні відкривається на весь екран: сайт не скролиться,
            тап — клік, два пальці — скрол і ПКМ.
          </p>
        </div>
      </div>

      {/* Virtual keyboard launcher */}
      <div className="fc-card-static mt-4 flex items-center justify-between gap-3 px-4 py-3">
        <div className="flex items-center gap-2.5">
          <div className="grid h-9 w-9 flex-none place-items-center rounded-xl border border-indigo-400/25 bg-indigo-500/15 text-indigo-300">
            <Keyboard className="h-4 w-4" />
          </div>
          <div>
            <p className="text-xs font-bold text-white">Керування введенням</p>
            <p className="mt-0.5 text-[10px] text-zinc-400">Повна віртуальна клавіатура з комбінаціями</p>
          </div>
        </div>
        <VirtualKeyboardLauncher />
      </div>

      {fsOpen && <TouchpadFullscreen deviceName={deviceName} onClose={() => setFsOpen(false)} />}
    </section>
  );
});
MouseCard.displayName = 'MouseCard';

/* ============================================================ */
/* Text & link printing                                          */
/* ============================================================ */

const TextLinkCard: React.FC = React.memo(() => {
  const [textInput, setTextInput] = useState('');
  const [urlInput, setUrlInput] = useState('');

  const handleSendText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!textInput.trim()) return;
    deviceClient.sendText(textInput.trim());
    toast.success('Текст надруковано у активному вікні ПК');
    setTextInput('');
  };

  const handleOpenUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!urlInput.trim()) return;
    let url = urlInput.trim();
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url;
    }
    deviceClient.openUrl(url);
    toast.info(`Відкриття посилання на ПК: ${url}`);
    setUrlInput('');
  };

  return (
    <section className="fc-card p-5">
      <div className="fc-section-head mb-4">
        <div className="fc-section-icon"><Type className="h-5 w-5" /></div>
        <div>
          <h3>Друк тексту та посилання</h3>
          <p>Надішліть текст або URL прямо на екран ПК</p>
        </div>
      </div>

      <div className="space-y-4">
        <form onSubmit={handleSendText} className="flex flex-col items-stretch gap-2 sm:flex-row sm:items-center">
          <input
            type="text"
            value={textInput}
            onChange={(e) => setTextInput(e.target.value)}
            placeholder="Текст, який треба надрукувати на ПК…"
            className="fc-input flex-1"
          />
          <button type="submit" className="fc-btn fc-btn-primary">
            <Keyboard className="h-3.5 w-3.5" />
            <span>Надрукувати</span>
          </button>
        </form>

        <form onSubmit={handleOpenUrl} className="flex flex-col items-stretch gap-2 sm:flex-row sm:items-center">
          <input
            type="text"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            placeholder="Посилання — youtube.com або будь-який сайт…"
            className="fc-input flex-1"
          />
          <button type="submit" className="fc-btn fc-btn-primary">
            <Globe className="h-3.5 w-3.5" />
            <span>Відкрити на ПК</span>
          </button>
        </form>
      </div>
    </section>
  );
});
TextLinkCard.displayName = 'TextLinkCard';

/* ============================================================ */
/* Media player + volume                                         */
/* ============================================================ */

const RoundMediaButton: React.FC<{
  label: string;
  onClick: () => void;
  children: React.ReactNode;
}> = React.memo(({ label, onClick, children }) => (
  <button
    onClick={onClick}
    title={label}
    aria-label={label}
    className="grid h-11 w-11 flex-none place-items-center rounded-full border border-white/10 bg-white/[.06] text-zinc-200 transition hover:border-indigo-400/50 hover:bg-white/[.12] hover:text-white active:scale-95"
  >
    {children}
  </button>
));
RoundMediaButton.displayName = 'RoundMediaButton';

const MediaPlayerCard: React.FC = React.memo(() => {
  const [volume, setVolume] = useState(50);
  const [muted, setMuted] = useState(false);
  const [playing, setPlaying] = useState(false);
  const VOLUME_STEP = 2; // фикс: ±2% всегда
  const volumeSendRef = useRef({ lastSent: 0, trailing: null as ReturnType<typeof setTimeout> | null });
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    const offState = deviceClient.on('volume_state', (raw: any) => {
      if (!mountedRef.current) return;
      const s = pick<any>(raw);
      if (s && typeof s.value === 'number') {
        setVolume(clampPercent(Math.round(s.value)));
        setMuted(!!s.muted);
      }
    });
    const offError = deviceClient.on('media_error', (raw: any) => {
      if (!mountedRef.current) return;
      const s = pick<any>(raw);
      toast.error(s?.message || 'Помилка медіа-керування');
    });
    // Sync with the real volume of the remote PC.
    deviceClient.requestVolumeState();
    return () => {
      mountedRef.current = false;
      offState();
      offError();
      if (volumeSendRef.current.trailing) clearTimeout(volumeSendRef.current.trailing);
    };
  }, []);

  // Throttled exact-set while dragging the slider: at most one message per
  // 150 ms with a trailing flush of the final position.
  const pushSet = (value: number) => {
    const st = volumeSendRef.current;
    const now = Date.now();
    if (st.trailing) clearTimeout(st.trailing);
    if (now - st.lastSent >= 150) {
      st.lastSent = now;
      deviceClient.sendVolumeEx('set', value);
    } else {
      st.trailing = setTimeout(() => {
        st.lastSent = Date.now();
        st.trailing = null;
        deviceClient.sendVolumeEx('set', value);
      }, 150);
    }
  };

  const onSliderChange = (value: number) => {
    setVolume(value);
    if (muted) setMuted(false);
    pushSet(value);
  };

  const stepDown = () => {
    const v = clampPercent(volume - VOLUME_STEP);
    setVolume(v);
    setMuted(false);
    deviceClient.sendVolumeEx('down', undefined, VOLUME_STEP);
  };

  const stepUp = () => {
    const v = clampPercent(volume + VOLUME_STEP);
    setVolume(v);
    setMuted(false);
    deviceClient.sendVolumeEx('up', undefined, VOLUME_STEP);
  };

  const toggleMute = () => {
    setMuted(m => !m);
    deviceClient.sendMediaControl('mute');
  };

  const media = (command: string, optimistic?: () => void) => {
    optimistic?.();
    deviceClient.sendMediaControl(command);
  };

  return (
    <section className="fc-card p-5">
      <div className="fc-section-head mb-4">
        <div className="fc-section-icon"><Volume2 className="h-5 w-5" /></div>
        <div>
          <h3>Медіа та звук</h3>
          <p>Плеєр і гучність віддаленого ПК</p>
        </div>
        <span className={`vol-big ml-auto flex-none ${muted ? 'text-rose-300' : 'text-indigo-200'}`}>
          {muted ? 'MUTE' : `${volume}%`}
        </span>
      </div>

      {/* Гучність: mute · мінус · слайдер · плюс — крок фіксований ±2% */}
      <div className="flex items-center gap-2.5">
        <button
          onClick={toggleMute}
          title={muted ? 'Увімкнути звук' : 'Вимкнути звук (mute)'}
          aria-label={muted ? 'Увімкнути звук' : 'Вимкнути звук'}
          className={`grid h-11 w-11 flex-none place-items-center rounded-xl border transition active:scale-95 ${muted
            ? 'border-rose-400/50 bg-gradient-to-br from-rose-600/55 to-rose-950/70 text-rose-200 shadow-[0_10px_26px_-10px_rgba(225,29,72,.85)]'
            : 'border-white/10 bg-white/[.06] text-zinc-200 hover:border-indigo-400/50 hover:bg-white/[.12] hover:text-white'}`}
        >
          {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
        </button>
        <button onClick={stepDown} title="Тихіше (−2%)" aria-label="Тихіше" className="vol-round">
          <Minus />
        </button>
        <input
          type="range"
          min={0}
          max={100}
          value={muted ? 0 : volume}
          onChange={(e) => onSliderChange(parseInt(e.target.value, 10))}
          aria-label="Гучність на ПК"
          className="fc-range"
          style={{
            background: muted
              ? 'linear-gradient(90deg, #3f3f46 0%, #52525b 100%)'
              : `linear-gradient(90deg, #6366f1 0%, #a78bfa ${volume}%, rgba(0,0,0,.55) ${volume}%)`
          }}
        />
        <button onClick={stepUp} title="Гучніше (+2%)" aria-label="Гучніше" className="vol-round">
          <Plus />
        </button>
      </div>

      {/* Transport controls */}
      <div className="mt-4 flex items-center justify-center gap-3 rounded-2xl border border-white/10 bg-gradient-to-br from-white/[.055] to-transparent p-4">
        <RoundMediaButton label="Попередній трек" onClick={() => media('prev', () => setPlaying(true))}>
          <SkipBack className="h-4 w-4" />
        </RoundMediaButton>

        <button
          onClick={() => media('play_pause', () => setPlaying(p => !p))}
          title="Відтворення / Пауза"
          aria-label="Відтворення або пауза"
          className="grid h-16 w-16 flex-none place-items-center rounded-full bg-gradient-to-br from-violet-500 via-violet-600 to-indigo-700 text-white shadow-[0_14px_34px_-10px_rgba(124,58,237,.9),inset_0_1px_rgba(255,255,255,.35)] transition hover:brightness-110 active:scale-95"
        >
          {playing ? <Pause className="h-6 w-6" /> : <Play className="ml-0.5 h-6 w-6" />}
        </button>

        <RoundMediaButton label="Наступний трек" onClick={() => media('next', () => setPlaying(true))}>
          <SkipForward className="h-4 w-4" />
        </RoundMediaButton>

        <RoundMediaButton label="Стоп" onClick={() => media('stop', () => setPlaying(false))}>
          <Square className="h-4 w-4" />
        </RoundMediaButton>
      </div>
    </section>
  );
});
MediaPlayerCard.displayName = 'MediaPlayerCard';

/* ============================================================ */
/* Power actions + shutdown/restart timer                        */
/* ============================================================ */

type DangerAction = 'shutdown' | 'restart' | 'sleep' | 'hibernate';

const POWER_META: Record<DangerAction, { title: string; toast: string; icon: typeof Power; iconCls: string }> = {
  shutdown: { title: 'Вимкнути комп\'ютер?', toast: 'Вимкнення ПК запущено', icon: Power, iconCls: 'border-rose-400/40 bg-rose-500/15 text-rose-300 shadow-[0_0_44px_-8px_rgba(225,29,72,.75)]' },
  restart: { title: 'Перезавантажити комп\'ютер?', toast: 'Перезавантаження ПК запущено', icon: RotateCcw, iconCls: 'border-amber-400/40 bg-amber-500/15 text-amber-300 shadow-[0_0_44px_-8px_rgba(245,158,11,.65)]' },
  sleep: { title: 'Перевести комп\'ютер у режим сну?', toast: 'ПК перейде в режим сну', icon: Moon, iconCls: 'border-indigo-400/40 bg-indigo-500/15 text-indigo-300 shadow-[0_0_44px_-8px_rgba(99,102,241,.65)]' },
  hibernate: { title: 'Перевести комп\'ютер у гібернацію?', toast: 'Гібернацію запущено', icon: CloudMoon, iconCls: 'border-violet-400/40 bg-violet-500/15 text-violet-300 shadow-[0_0_44px_-8px_rgba(124,58,237,.65)]' }
};

type TimerAction = 'shutdown' | 'restart' | 'sleep' | 'hibernate' | 'lock';

const TIMER_ACTION_META: Record<TimerAction, { label: string; icon: typeof Power }> = {
  shutdown: { label: 'Вимкнення', icon: Power },
  restart: { label: 'Перезавантаження', icon: RotateCcw },
  sleep: { label: 'Сон', icon: Moon },
  hibernate: { label: 'Гібернація', icon: CloudMoon },
  lock: { label: 'Блокування', icon: Lock }
};

const TIMER_MINUTE_CHIPS = [5, 10, 15, 30, 60];

type ActiveTimer = { action: TimerAction; endsAt: number; totalSeconds: number };

const PowerCard: React.FC<{ deviceName: string }> = React.memo(({ deviceName }) => {
  const [pending, setPending] = useState<DangerAction | null>(null);
  // Authoritative timer state comes from the AGENT (timer_state, unix-ms endsAt),
  // so a page refresh or a reconnect restores the real countdown instantly.
  const [timer, setTimer] = useState<ActiveTimer | null>(null);
  const [nowTick, setNowTick] = useState(Date.now());
  // Timer creation modal
  const [timerOpen, setTimerOpen] = useState(false);
  const [timerAction, setTimerAction] = useState<TimerAction>('shutdown');
  const [timerMinutes, setTimerMinutes] = useState<number | null>(10);
  const [customMinutes, setCustomMinutes] = useState('');

  // Ask the agent for the current pending timer on mount (it also pushes
  // timer_state right after every relay reconnect).
  useEffect(() => {
    deviceClient.send('timer_get', {});
  }, []);

  // Live countdown: 1 tick per second and ONLY while a timer is shown.
  useEffect(() => {
    if (!timer) return;
    const t = window.setInterval(() => setNowTick(Date.now()), 1000);
    return () => window.clearInterval(t);
  }, [timer]);

  // Agent-side timer state is the single source of truth.
  useEffect(() => {
    const off = deviceClient.on('timer_state', (raw: any) => {
      const s = pick<any>(raw);
      if (!s || typeof s !== 'object') return;
      if (s.active === true && s.endsAt) {
        setTimer({
          action: (s.action as TimerAction) || 'shutdown',
          endsAt: Number(s.endsAt),
          totalSeconds: Number(s.totalSeconds) || Math.max(1, Math.round((Number(s.endsAt) - Date.now()) / 1000))
        });
        setNowTick(Date.now());
      } else {
        setTimer(null);
      }
    });
    const offAck = deviceClient.on('timer_ack', (raw: any) => {
      const s = pick<any>(raw);
      if (s && s.ok === false) {
        setTimer(null);
        toast.error(s.error || 'Не вдалося запустити таймер');
      }
    });
    return () => {
      off();
      offAck();
    };
  }, []);

  const runPower = (action: DangerAction) => {
    deviceClient.sendPowerAction(action);
    toast.info(POWER_META[action].toast);
    setPending(null);
  };

  const lockScreen = () => {
    deviceClient.sendPowerAction('lock');
    toast.info('Команду блокування екрана надіслано');
  };

  const secondsLeft = timer ? Math.max(0, Math.ceil((timer.endsAt - nowTick) / 1000)) : 0;
  const scheduledAt = timer ? new Date(timer.endsAt).toLocaleTimeString('uk-UA', { hour: '2-digit', minute: '2-digit' }) : '';
  const timerMeta = timer ? TIMER_ACTION_META[timer.action] ?? TIMER_ACTION_META.shutdown : null;

  const confirmStartTimer = () => {
    const minutes = customMinutes.trim() !== '' ? Number(customMinutes.replace(',', '.')) : timerMinutes;
    if (!minutes || !Number.isFinite(minutes) || minutes <= 0 || minutes > 1440) {
      toast.warn('Вкажіть кількість хвилин від 1 до 1440');
      return;
    }
    const seconds = Math.max(5, Math.round(minutes * 60));
    // Optimistic start — the agent's timer_state immediately confirms/corrects.
    setTimer({ action: timerAction, endsAt: Date.now() + seconds * 1000, totalSeconds: seconds });
    setNowTick(Date.now());
    deviceClient.startPowerTimer(timerAction, seconds);
    toast.info(`${TIMER_ACTION_META[timerAction].label} заплановано через ${minutes} хв`);
    setTimerOpen(false);
    setCustomMinutes('');
  };

  const cancelTimer = () => {
    deviceClient.cancelPowerTimer();
    setTimer(null);
    toast.info('Таймер скасовано');
  };

  return (
    <section className="fc-card p-5">
      <div className="fc-section-head mb-4">
        <div className="fc-section-icon fc-icon-rose"><Power className="h-5 w-5" /></div>
        <div>
          <h3>Живлення</h3>
          <p>Вимкнення, перезавантаження, сон і блокування</p>
        </div>
      </div>

      {/* ВЕЛИКІ градієнтні кнопки живлення — найважливіша дія першою. Усі дії
          з підтвердженням, щоб не вимкнути ПК випадковим дотиком. */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <button
          onClick={() => setPending('shutdown')}
          className="pwr-tile pwr-shutdown fc-shine"
        >
          <span className="pwr-ico"><Power /></span>
          <span className="min-w-0">
            <b>Вимкнути ПК</b>
            <small>Повне вимкнення комп&apos;ютера</small>
          </span>
        </button>

        <button
          onClick={() => setPending('restart')}
          className="pwr-tile pwr-restart fc-shine"
        >
          <span className="pwr-ico"><RotateCcw /></span>
          <span className="min-w-0">
            <b>Перезавантажити</b>
            <small>Restart із повним циклом</small>
          </span>
        </button>
      </div>

      <div className="mt-3 grid grid-cols-1 gap-2.5 sm:grid-cols-3">
        <button onClick={() => setPending('sleep')} className="pwr-mini pwr-sleep">
          <Moon className="h-4 w-4" />
          <span>Режим сну</span>
        </button>
        <button onClick={() => setPending('hibernate')} className="pwr-mini pwr-hiber">
          <CloudMoon className="h-4 w-4" />
          <span>Гібернація</span>
        </button>
        <button onClick={lockScreen} className="pwr-mini pwr-lock">
          <Lock className="h-4 w-4" />
          <span>Заблокувати екран</span>
        </button>
      </div>

      {/* Unified power timer: one entry point, the agent executes the action */}
      <div className="mt-4 border-t border-white/10 pt-4">
        {timer === null ? (
          <button onClick={() => setTimerOpen(true)} className="pwr-timer-btn">
            <span className="grid h-10 w-10 flex-none place-items-center rounded-xl border border-amber-400/40 bg-gradient-to-br from-amber-500/35 to-amber-900/50 text-amber-300 shadow-[inset_0_1px_rgba(255,255,255,.2),0_8px_20px_-8px_rgba(245,158,11,.6)]">
              <Timer className="h-[18px] w-[18px]" />
            </span>
            <span className="min-w-0">
              <b className="block text-xs font-extrabold text-white">Таймер живлення</b>
              <small className="block text-[10px] font-semibold text-amber-200/70">вимкнення · перезавантаження · сон · блокування</small>
            </span>
            <span className="pwr-timer-chev"><ChevronRight className="h-4 w-4" /></span>
          </button>
        ) : (
          <div className="pwr-timer-active">
            <div className="flex items-center justify-between gap-3">
              <div className="min-w-0">
                <b className="flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-wide text-amber-200/90">
                  {timerMeta && <timerMeta.icon className="h-3.5 w-3.5 flex-none" />}
                  {timerMeta?.label ?? 'Дія'} — ПК «{deviceName}»
                </b>
                <span className="pwr-countdown mt-1 block">{formatSeconds(secondsLeft)}</span>
                <span className="mt-0.5 block text-[10px] text-amber-300/80">Заплановано на {scheduledAt}</span>
              </div>
              <button onClick={cancelTimer} className="fc-btn fc-btn-warn fc-btn-sm flex-none">
                <Ban className="h-3 w-3" />
                <span>Скасувати</span>
              </button>
            </div>
            {timer.totalSeconds > 0 && (
              <div className="fc-progress mt-3">
                <i
                  className="block h-full rounded-[inherit]"
                  style={{
                    width: `${clampPercent((secondsLeft / timer.totalSeconds) * 100)}%`,
                    background: 'linear-gradient(90deg,#f59e0b,#fbbf24)',
                    boxShadow: '0 0 12px rgba(245,158,11,.6)'
                  }}
                />
              </div>
            )}
          </div>
        )}
      </div>

      {/* Unified timer modal */}
      {timerOpen && (
        <div className="fc-modal-backdrop" role="dialog" aria-modal="true" onClick={() => setTimerOpen(false)}>
          <div className="fc-modal" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-3">
              <div className="fc-section-icon fc-icon-amber"><Timer className="h-5 w-5" /></div>
              <div>
                <h3>Таймер дії</h3>
                <p className="text-[11px] text-zinc-400">Дію виконає ПК, навіть якщо сайт закрити</p>
              </div>
            </div>

            <p className="mb-2 mt-4 text-[10px] font-extrabold uppercase tracking-wide text-zinc-500">Тип дії</p>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {(Object.keys(TIMER_ACTION_META) as TimerAction[]).map(action => {
                const meta = TIMER_ACTION_META[action];
                const active = timerAction === action;
                return (
                  <button
                    key={action}
                    onClick={() => setTimerAction(action)}
                    aria-pressed={active}
                    className={`fc-radio-card ${active ? 'active' : ''}`}
                  >
                    <span className="flex items-center gap-2.5">
                      <meta.icon className={`h-4 w-4 flex-none ${active ? 'text-indigo-300' : 'text-zinc-500'}`} />
                      <span className="flex-1 truncate text-xs font-extrabold text-white">{meta.label}</span>
                      <span className={`fc-radio-dot ${active ? 'on' : ''}`} />
                    </span>
                  </button>
                );
              })}
            </div>

            <p className="mb-2 mt-4 text-[10px] font-extrabold uppercase tracking-wide text-zinc-500">Через скільки хвилин</p>
            <div className="flex flex-wrap gap-1.5">
              {TIMER_MINUTE_CHIPS.map(m => (
                <button
                  key={m}
                  onClick={() => { setTimerMinutes(m); setCustomMinutes(''); }}
                  aria-pressed={timerMinutes === m && customMinutes.trim() === ''}
                  className={`fc-btn fc-btn-sm flex-1 ${
                    timerMinutes === m && customMinutes.trim() === '' ? 'fc-btn-primary' : 'fc-btn-ghost'
                  }`}
                >
                  {m < 60 ? `${m} хв` : '1 год'}
                </button>
              ))}
            </div>
            <div className="mt-2 flex items-center gap-2">
              <input
                type="number"
                min={1}
                max={1440}
                inputMode="decimal"
                value={customMinutes}
                onChange={(e) => setCustomMinutes(e.target.value)}
                placeholder="Свій час, хв (напр. 45)"
                className="fc-input flex-1"
                aria-label="Свій час у хвилинах"
              />
              <span className="text-[10px] text-zinc-500">хв</span>
            </div>

            <div className="mt-5 flex items-center gap-3">
              <button onClick={() => setTimerOpen(false)} className="fc-btn fc-btn-ghost flex-1">Скасувати</button>
              <button onClick={confirmStartTimer} className="fc-btn fc-btn-primary fc-shine flex-1">
                <Clock className="h-3.5 w-3.5" />
                <span>Запустити</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation modal for dangerous actions */}
      {pending && (() => {
        const meta = POWER_META[pending];
        const PendingIcon = meta.icon;
        return (
          <div className="fc-modal-backdrop" role="dialog" aria-modal="true" onClick={() => setPending(null)}>
            <div className="fc-modal text-center" onClick={(e) => e.stopPropagation()}>
              <div className={`mx-auto grid h-16 w-16 place-items-center rounded-[1.25rem] border ${meta.iconCls}`}>
                <PendingIcon className="h-7 w-7" />
              </div>
              <h3 className="mt-3.5 text-base">{meta.title}</h3>
              <p className="mt-1.5 text-xs leading-relaxed text-zinc-400">
                Дію буде виконано негайно на віддаленому комп&apos;ютері{' '}
                <span className="inline-flex items-center gap-1 rounded-lg border border-indigo-400/30 bg-indigo-500/15 px-2 py-0.5 font-bold text-indigo-300">
                  <Monitor className="h-3 w-3" />
                  {deviceName}
                </span>
              </p>
              <div className="mt-5 flex items-center gap-2.5">
                <button onClick={() => setPending(null)} className="fc-btn fc-btn-ghost flex-1">Скасувати</button>
                <button onClick={() => runPower(pending)} className="fc-btn fc-btn-danger fc-shine flex-1">
                  <PendingIcon className="h-3.5 w-3.5" />
                  <span>Так, виконати</span>
                </button>
              </div>
            </div>
          </div>
        );
      })()}
    </section>
  );
});
PowerCard.displayName = 'PowerCard';

/* ============================================================ */
/* Control tab root: screen stream + layout                      */
/* ============================================================ */

export const ControlTab: React.FC<ControlTabProps> = React.memo(({ device }) => {
  const [screenOpen, setScreenOpen] = useState(false);
  const [streamFps, setStreamFps] = useState(0);
  const [streamStatus, setStreamStatus] = useState<'idle' | 'starting' | 'live' | 'error'>('idle');

  const streamImageRef = useRef<HTMLImageElement>(null);
  const frameStatsRef = useRef({ count: 0, since: performance.now() });
  const startTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const unFrame = deviceClient.on('screen_frame', (frame: any) => {
      const data = frame?.data ?? frame;
      if (!data?.imageBase64 || !streamImageRef.current) return;
      if (startTimeoutRef.current) clearTimeout(startTimeoutRef.current);
      setStreamStatus('live');
      streamImageRef.current.src = `data:image/jpeg;base64,${data.imageBase64}`;
      const stats = frameStatsRef.current;
      stats.count += 1;
      const elapsed = performance.now() - stats.since;
      if (elapsed >= 500) {
        const fps = Math.round((stats.count * 1000) / elapsed);
        setStreamFps(fps);
        deviceClient.sendScreenStreamFeedback(fps);
        stats.count = 0;
        stats.since = performance.now();
      }
    });
    const unError = deviceClient.on('screen_stream_error', (error: any) => {
      toast.error(error?.message || 'Трансляцію екрана перервано');
      setScreenOpen(false);
      setStreamStatus('idle');
    });
    const unStarted = deviceClient.on('screen_stream_started', () => {
      setStreamStatus('live');
      if (startTimeoutRef.current) clearTimeout(startTimeoutRef.current);
    });
    return () => {
      if (startTimeoutRef.current) clearTimeout(startTimeoutRef.current);
      unFrame();
      unError();
      unStarted();
      deviceClient.stopScreenStream();
    };
  }, []);

  const startScreenStream = () => {
    frameStatsRef.current = { count: 0, since: performance.now() };
    setStreamFps(0);
    setStreamStatus('starting');
    setScreenOpen(true);
    // Balanced relay profile. The agent lowers bitrate automatically when the
    // phone reports fewer received frames, preventing a high-latency backlog.
    deviceClient.startScreenStream(30, 72, 1280);
    startTimeoutRef.current = setTimeout(() => {
      setStreamStatus(current => {
        if (current === 'starting') {
          toast.warn('Агент не підтвердив запуск трансляції. Оновіть і перезапустіть FluxControl на віддаленому ПК.');
          return 'error';
        }
        return current;
      });
    }, 8000);
  };

  const stopScreenStream = () => {
    deviceClient.stopScreenStream();
    setScreenOpen(false);
    setStreamFps(0);
    setStreamStatus('idle');
    if (startTimeoutRef.current) clearTimeout(startTimeoutRef.current);
  };

  return (
    <div className="space-y-6">

      {/* 1. ЖИВЛЕННЯ — найперша секція: великі кнопки з підтвердженням */}
      <PowerCard deviceName={device.name} />

      {/* 2. ЗАХОПЛЕННЯ ЕКРАНА ТА ВІДЕО — одна рамка з 4 плитками */}
      <RemoteCaptureTools deviceName={device.name} />

      {/* 3. Трансляція екрана */}
      <section className="fc-card flex flex-col items-start justify-between gap-4 p-5 sm:flex-row sm:items-center">
        <div className="fc-section-head">
          <div className="fc-section-icon"><ScreenShare className="h-5 w-5" /></div>
          <div>
            <h3>Трансляція екрана</h3>
            <p>Адаптивна якість і FPS: потік підлаштовується під канал без черги кадрів.</p>
          </div>
        </div>
        <button onClick={startScreenStream} className="fc-btn fc-btn-primary fc-shine w-full flex-none sm:w-auto">
          <ScreenShare className="h-4 w-4" />
          <span>Відкрити трансляцію</span>
        </button>
      </section>

      {/* 4. Медіа, мишка, друк, WinLock */}
      <div className="grid grid-cols-1 items-start gap-6 lg:grid-cols-2">
        <div className="space-y-6">
          <MediaPlayerCard />
          <MouseCard deviceName={device.name} />
        </div>
        <div className="space-y-6">
          <TextLinkCard />
          <WinLockCard />
        </div>
      </div>

      {/* Fullscreen screen-stream overlay */}
      {screenOpen && (
        <div className="fixed inset-0 z-[70] flex flex-col bg-[#050508] animate-in fade-in duration-200">
          <div className="flex h-16 shrink-0 items-center justify-between border-b border-white/10 bg-black/70 px-4 backdrop-blur-xl sm:px-6">
            <div className="flex min-w-0 items-center gap-3">
              <div className="grid place-items-center rounded-xl border border-indigo-400/25 bg-indigo-500/15 p-2 text-indigo-300"><ScreenShare className="h-5 w-5" /></div>
              <div className="min-w-0">
                <h3 className="truncate text-sm font-bold text-white">Екран: {device.name}</h3>
                <p className="text-[10px] text-zinc-400">Потік активний · {streamFps || '…'} FPS</p>
              </div>
            </div>
            <button onClick={stopScreenStream} className="fc-btn fc-btn-danger flex-none">Зупинити</button>
          </div>
          <div className="relative grid flex-1 place-items-center overflow-hidden bg-black">
            <img ref={streamImageRef} alt="Трансляція екрана" className="h-auto max-h-full max-w-full w-auto object-contain" />
            {streamStatus === 'starting' && (
              <div className="pointer-events-none absolute inset-0 grid place-items-center text-center">
                <div className="rounded-2xl border border-white/10 bg-black/60 px-5 py-4 text-sm text-indigo-200">Запуск трансляції…</div>
              </div>
            )}
            {streamStatus === 'error' && (
              <div className="absolute inset-0 grid place-items-center text-center">
                <div className="max-w-sm rounded-2xl border border-rose-500/30 bg-black/75 px-5 py-4 text-sm text-rose-200">Агент не підтримує трансляцію. Оновіть і перезапустіть FluxControl на віддаленому ПК.</div>
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
});

ControlTab.displayName = 'ControlTab';
