import React, { useState, useEffect, useRef } from 'react';
import {
  Terminal,
  Monitor,
  WifiOff,
  AlertCircle,
  RefreshCw,
  Loader2,
  ArrowLeft
} from 'lucide-react';
import { Device, SessionTab, DeviceMetrics } from '../../types';
import { deviceClient } from '../../services/deviceClient';
import { useDevices } from '../../context/DeviceContext';
import { InfoTab } from './InfoTab';
import { ControlTab } from './ControlTab';
import { FilesTab } from './FilesTab';
import { ProcessesTab } from './ProcessesTab';
import { TerminalTab } from './TerminalTab';
import { AITab } from './AITab';

/** Consecutive socket failures before the calm "reconnecting" state escalates. */
const MAX_SOFT_FAILURES = 4;

interface DeviceSessionViewProps {
  device: Device;
  activeTab: SessionTab;
  onTabChange: (tab: SessionTab) => void;
  onDisconnect: () => void;
  onConnectStateChange?: (state: 'connecting' | 'connected' | 'error') => void;
}

export const DeviceSessionView: React.FC<DeviceSessionViewProps> = React.memo(({
  device,
  activeTab,
  onTabChange,
  onDisconnect,
  onConnectStateChange
}) => {
  const { updateDeviceStatus } = useDevices();
  // Telemetry arrives every second. Storing it in component state re-rendered
  // the whole session tree (touchpad, capture tools, modals) at 1 Hz — the
  // main cause of the “управление жёстко лагает” report. It now lives in a
  // ref, and only a one-shot “first telemetry arrived” flag touches state.
  const metricsRef = useRef<DeviceMetrics | null>(null);
  const [hasTelemetry, setHasTelemetry] = useState(false);
  const getMetrics = React.useCallback(() => metricsRef.current, []);
  const [connectState, setConnectState] = useState<'connecting' | 'connected' | 'error'>('connecting');
  const [connectStep, setConnectStep] = useState<number>(1);
  const [connectError, setConnectError] = useState<string | null>(null);
  // Live end-to-end status of the current session. It becomes true only after
  // the agent has actually answered (not merely when the relay socket opens),
  // and it flips back to false whenever the agent or the relay goes away.
  const [sessionLive, setSessionLive] = useState<boolean>(false);
  const sessionLiveRef = useRef(false);
  // Mid-session drop UX: the socket auto-reconnects every ~3.5 s, so a single
  // "disconnected" event shows a calm amber "reconnecting" state instead of a
  // dead-end error. Only after MAX_SOFT_FAILURES consecutive failures (~15 s)
  // does the UI escalate to a stronger error with a manual retry button.
  const [connectionLost, setConnectionLost] = useState(false);
  const [failCount, setFailCount] = useState(0);
  const failCountRef = useRef(0);
  // Mirror of `connectionLost`: socket handlers captured on mount must read
  // the CURRENT value, not the stale first-render closure.
  const connectionLostRef = useRef(false);
  const setLost = (lost: boolean) => {
    connectionLostRef.current = lost;
    setConnectionLost(lost);
  };
  const retryTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const deviceKey = device.code || device.id;

  const updateState = (state: 'connecting' | 'connected' | 'error') => {
    setConnectState(state);
    onConnectStateChange?.(state);
  };

  // Mid-session liveness transitions. Guards prevent hammering the shared
  // device context with an update on every single telemetry frame.
  const markSessionAlive = () => {
    if (!sessionLiveRef.current) {
      sessionLiveRef.current = true;
      setSessionLive(true);
      updateDeviceStatus(deviceKey, 'connected');
    }
    // The agent answered again: any "lost connection" overlay goes away and
    // the failure counter resets — full automatic recovery, no user action.
    if (connectionLostRef.current) setLost(false);
    if (failCountRef.current !== 0) {
      failCountRef.current = 0;
      setFailCount(0);
    }
  };

  const markSessionDead = () => {
    if (!sessionLiveRef.current) return;
    sessionLiveRef.current = false;
    setSessionLive(false);
    // 'connecting' keeps the navbar badge Online during its short grace window
    // and turns it to Offline if the agent really stays unreachable.
    updateDeviceStatus(deviceKey, 'connecting');
  };

  useEffect(() => {
    updateState('connecting');
    setConnectStep(1);
    setConnectError(null);
    setSessionLive(false);
    sessionLiveRef.current = false;
    setLost(false);
    failCountRef.current = 0;
    setFailCount(0);

    const isDoneRef = { current: false };

    // Step 1: Connecting to Relay
    const step1Timer = setTimeout(() => {
      if (!isDoneRef.current) setConnectStep(2);
    }, 300);

    const step2Timer = setTimeout(() => {
      if (!isDoneRef.current) setConnectStep(3);
    }, 700);

    // Timeout fallback (12s) — connection counts ONLY after a real reply from the agent
    const timeoutTimer = setTimeout(() => {
      if (!isDoneRef.current) {
        updateState('error');
        setConnectError('Час очікування відповіді від ПК вичерпано. Переконайтеся, що програма запущена на комп\'ютері.');
      }
    }, 12000);

    // Initiate connection
    deviceClient.connect(device.code || device.id);

    const markConnected = () => {
      if (isDoneRef.current) return;
      isDoneRef.current = true;
      setConnectStep(4);
      markSessionAlive();
      setTimeout(() => {
        updateState('connected');
      }, 450);
    };

    // Relay socket opened. During the initial connect it advances the progress
    // UI; mid-session it means the socket recovered but the agent has not
    // proven liveness yet, so the session stays "dead" until the first reply.
    const unsubConnected = deviceClient.on('connected', () => {
      failCountRef.current = 0;
      setFailCount(0);
      if (isDoneRef.current) {
        markSessionDead();
        return;
      }
      setConnectStep(3);
      deviceClient.send('ping', {});
      deviceClient.send('telemetry', {});
    });

    const unsubAgentStatus = deviceClient.on('agent_status', (data) => {
      if (data?.status === 'online') {
        setConnectStep(3);
        deviceClient.send('ping', {});
        deviceClient.send('telemetry', {});
        // Mid-session recovery: the agent is reachable again.
        if (isDoneRef.current) {
          markSessionAlive();
          return;
        }
        setTimeout(() => {
          if (!isDoneRef.current && deviceClient.isOpen()) {
            markConnected();
          }
        }, 1500);
      } else if (data?.status === 'offline') {
        if (!isDoneRef.current) {
          updateState('error');
          setConnectError('ПК зараз офлайн. Запустіть програму FluxControl на комп\'ютері та спробуйте ще раз.');
        } else {
          // The relay confirmed the agent stopped responding while the session
          // is open — the UI must honestly switch to Offline.
          markSessionDead();
        }
      }
    });

    const unsubMetrics = deviceClient.on('metrics', (m) => {
      metricsRef.current = m;
      setHasTelemetry(true);
      markConnected();
      markSessionAlive();
    });

    const unsubTelemetry = deviceClient.on('telemetry', (t) => {
      metricsRef.current = t?.data ?? t;
      setHasTelemetry(true);
      markConnected();
      markSessionAlive();
    });

    const unsubPong = deviceClient.on('pong', () => {
      markConnected();
      markSessionAlive();
    });

    const unsubError = deviceClient.on('error', (err) => {
      console.warn('[DeviceSessionView] Relay error:', err);
    });

    // Socket dropped. The client reconnects automatically every ~3.5 s; the UI
    // counts consecutive failures and only escalates after ~15 s of them.
    const unsubSocketClose = deviceClient.on('disconnected', () => {
      failCountRef.current += 1;
      setFailCount(failCountRef.current);
      if (!isDoneRef.current) {
        // Still in the initial handshake: keep the radar up, escalate later.
        if (failCountRef.current >= MAX_SOFT_FAILURES) {
          updateState('error');
          setConnectError('Не вдається підключитися до ПК. Перевірте інтернет та чи запущена програма FluxControl на комп\'ютері.');
        }
        return;
      }
      markSessionDead();
      setLost(true);
    });

    return () => {
      isDoneRef.current = true;
      clearTimeout(step1Timer);
      clearTimeout(step2Timer);
      clearTimeout(timeoutTimer);
      if (retryTimeoutRef.current) clearTimeout(retryTimeoutRef.current);
      unsubConnected();
      unsubAgentStatus();
      unsubMetrics();
      unsubTelemetry();
      unsubPong();
      unsubError();
      unsubSocketClose();
      deviceClient.disconnect();
    };
  }, [device.id, device.code, deviceKey, updateDeviceStatus]);

  const handleRetry = () => {
    updateState('connecting');
    setConnectStep(1);
    setConnectError(null);
    sessionLiveRef.current = false;
    setSessionLive(false);
    // disconnect() emits 'disconnected' synchronously — reset the failure
    // counter AFTER it so a manual retry never counts as a failed attempt.
    deviceClient.disconnect();
    failCountRef.current = 0;
    setFailCount(0);
    setLost(false);
    deviceClient.connect(device.code || device.id);
    // The initial 12s timeout is gone once it fired — arm a fresh one for the
    // retry attempt so a hanging retry can never leave an eternal spinner.
    if (retryTimeoutRef.current) clearTimeout(retryTimeoutRef.current);
    retryTimeoutRef.current = setTimeout(() => {
      setConnectState(current => {
        if (current === 'connecting') {
          setConnectError('Час очікування відповіді від ПК вичерпано. Переконайтеся, що програма запущена на комп\'ютері.');
          return 'error';
        }
        return current;
      });
    }, 12000);
  };

  const showLostOverlay = connectState === 'connected' && connectionLost && failCount < MAX_SOFT_FAILURES;
  const showEscalatedOverlay = connectState === 'connected' && connectionLost && failCount >= MAX_SOFT_FAILURES;

  return (
    <div className="relative min-h-[calc(100vh-80px)] w-full">

      {/* Fullscreen Animated Radar Connection Loading Screen (stops at the sidebar on desktop) */}
      {connectState === 'connecting' && (
        <div className="fixed inset-0 z-40 flex flex-col items-center justify-center bg-[#050508]/95 p-6 text-center backdrop-blur-2xl animate-in fade-in duration-300">

          {/* Pulsing Radar Ring Container */}
          <div className="relative mb-8 flex h-44 w-44 items-center justify-center">
            <div className="absolute inset-0 animate-ping rounded-full bg-indigo-600/10 duration-1000" />
            <div className="absolute -inset-4 animate-pulse rounded-full border border-indigo-500/20 duration-700" />
            <div className="absolute -inset-8 rounded-full border border-violet-500/10" />

            <div className="relative z-10 flex h-24 w-24 items-center justify-center rounded-3xl bg-gradient-to-br from-indigo-600 to-violet-600 p-0.5 shadow-2xl shadow-indigo-600/40">
              <div className="flex h-full w-full items-center justify-center rounded-[22px] bg-[#090b14] text-indigo-400">
                <Monitor className="h-10 w-10 animate-pulse text-indigo-300" />
              </div>
            </div>
          </div>

          {/* Карточка целевого ПК: имя + код подключения */}
          <div className="mb-6 flex items-center gap-3 rounded-2xl border border-indigo-500/25 bg-black/60 px-4 py-3 backdrop-blur-md">
            <Monitor className="h-5 w-5 flex-none text-indigo-300" />
            <div className="text-left">
              <p className="max-w-[220px] truncate text-sm font-extrabold text-white">{device.name}</p>
              <p className="font-mono text-[10px] text-indigo-300/70">{device.code || device.id}</p>
            </div>
          </div>
          <h2 className="mb-2 text-xl font-black tracking-tight text-white sm:text-2xl">
            Підключення до ПК
          </h2>

          {/* Progress status indicators */}
          <div className="mb-8 max-w-sm space-y-2 text-xs font-medium text-gray-400">
            <div className="flex items-center justify-center gap-2">
              <span className={`h-2 w-2 rounded-full ${connectStep >= 1 ? 'animate-pulse bg-indigo-400' : 'bg-gray-600'}`} />
              <span className={connectStep === 1 ? 'font-bold text-white' : ''}>1. Підключення до релей-сервера</span>
            </div>
            <div className="flex items-center justify-center gap-2">
              <span className={`h-2 w-2 rounded-full ${connectStep >= 2 ? 'animate-pulse bg-indigo-400' : 'bg-gray-600'}`} />
              <span className={connectStep === 2 ? 'font-bold text-white' : ''}>2. Авторизація десктопного агента</span>
            </div>
            <div className="flex items-center justify-center gap-2">
              <span className={`h-2 w-2 rounded-full ${connectStep >= 3 ? 'animate-pulse bg-indigo-400' : 'bg-gray-600'}`} />
              <span className={connectStep === 3 ? 'font-bold text-white' : ''}>3. Отримання метрик та заліза</span>
            </div>
            {connectStep >= 4 && (
              <div className="flex animate-in items-center justify-center gap-2 font-semibold text-emerald-400 fade-in duration-300">
                <span className="h-2 w-2 animate-ping rounded-full bg-emerald-400" />
                <span>4. З'єднання успішно встановлено!</span>
              </div>
            )}
          </div>

          <div className="mb-6 h-1.5 w-64 overflow-hidden rounded-full bg-white/10">
            <div
              className="h-full rounded-full bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-400 transition-all duration-500 ease-out"
              style={{ width: `${connectStep === 1 ? 25 : connectStep === 2 ? 60 : connectStep === 3 ? 90 : 100}%` }}
            />
          </div>

          <button
            onClick={onDisconnect}
            className="cursor-pointer rounded-2xl border border-white/10 bg-white/5 px-5 py-2.5 text-xs font-semibold text-gray-400 transition-colors hover:bg-white/10 hover:text-white"
          >
            Скасувати підключення
          </button>
        </div>
      )}

      {/* Connection Error Screen (initial connect failed) */}
      {connectState === 'error' && (
        <div className="fixed inset-0 z-40 flex flex-col items-center justify-center bg-[#050508]/95 p-6 text-center backdrop-blur-2xl animate-in fade-in duration-300">
          <div className="glass-card w-full max-w-md rounded-3xl border border-red-500/30 bg-[#090b14]/90 p-8 shadow-2xl">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-3xl border border-red-500/30 bg-red-500/20 text-red-400">
              <AlertCircle className="h-8 w-8" />
            </div>
            <h3 className="mb-2 text-lg font-bold text-white">Не вдалося підключитися</h3>
            <p className="mb-6 text-xs leading-relaxed text-gray-400">
              {connectError || 'Перевірте, чи запущена програма FluxControl на ПК та чи є інтернет-з\'єднання.'}
            </p>
            <div className="flex items-center gap-3">
              <button
                onClick={onDisconnect}
                className="flex-1 cursor-pointer rounded-2xl bg-white/5 py-3 text-xs font-bold text-gray-300 transition-colors hover:bg-white/10"
              >
                До списку ПК
              </button>
              <button
                onClick={handleRetry}
                className="flex flex-1 cursor-pointer items-center justify-center gap-1.5 rounded-2xl bg-indigo-600 py-3 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 transition-all hover:bg-indigo-500"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                <span>Повторити</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Calm amber reconnecting overlay (socket dropped, auto-retry in progress) */}
      {showLostOverlay && (
        <div className="fixed inset-0 z-40 flex flex-col items-center justify-center bg-[#050508]/90 p-6 text-center backdrop-blur-xl animate-in fade-in duration-300">
          <div className="relative mb-6 flex h-28 w-28 items-center justify-center">
            <div className="absolute inset-0 animate-ping rounded-full bg-amber-500/10 duration-1000" />
            <div className="absolute -inset-3 animate-pulse rounded-full border border-amber-400/25 duration-700" />
            <div className="relative z-10 grid h-16 w-16 place-items-center rounded-3xl border border-amber-400/30 bg-amber-500/10 text-amber-300">
              <WifiOff className="h-7 w-7" />
            </div>
          </div>

          <h2 className="text-lg font-black text-amber-100 sm:text-xl">З&apos;єднання втрачено</h2>
          <p className="mt-2 flex items-center gap-2 text-xs font-semibold text-amber-200/80">
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
            <span>Перепідключення… спроба {failCount + 1}</span>
          </p>
          <p className="mt-1 max-w-xs text-[11px] leading-relaxed text-zinc-500">
            З&apos;єднання відновиться автоматично, щойно ПК знову відповість.
          </p>

          <button
            onClick={onDisconnect}
            className="mt-6 flex cursor-pointer items-center gap-1.5 rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-[11px] font-semibold text-zinc-400 transition-colors hover:bg-white/10 hover:text-white"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            <span>До списку ПК</span>
          </button>
        </div>
      )}

      {/* Escalated state after several failed attempts (~15 s) */}
      {showEscalatedOverlay && (
        <div className="fixed inset-0 z-40 flex flex-col items-center justify-center bg-[#050508]/95 p-6 text-center backdrop-blur-2xl animate-in fade-in duration-300">
          <div className="glass-card w-full max-w-md rounded-3xl border border-red-500/30 bg-[#090b14]/90 p-8 shadow-2xl">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-3xl border border-red-500/30 bg-red-500/20 text-red-400">
              <AlertCircle className="h-8 w-8" />
            </div>
            <h3 className="mb-2 text-lg font-bold text-white">Не вдається підключитися до ПК</h3>
            <p className="mb-6 text-xs leading-relaxed text-gray-400">
              ПК не відповідає після {failCount} невдалих спроб. Перевірте, чи працює програма FluxControl
              на комп&apos;ютері та чи є інтернет, або спробуйте ще раз.
            </p>
            <div className="flex items-center gap-3">
              <button
                onClick={onDisconnect}
                className="flex-1 cursor-pointer rounded-2xl bg-white/5 py-3 text-xs font-bold text-gray-300 transition-colors hover:bg-white/10"
              >
                До списку ПК
              </button>
              <button
                onClick={handleRetry}
                className="flex flex-1 cursor-pointer items-center justify-center gap-1.5 rounded-2xl bg-indigo-600 py-3 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 transition-all hover:bg-indigo-500"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                <span>Повторити зараз</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Active Connected Session View — pt-28 on ALL breakpoints:
          the fixed navbar pill (~88px incl. offset) must never cover the
          first card when scrolled to the very top. */}
      <div className={`mx-auto w-full max-w-6xl px-4 pb-28 pt-28 transition-opacity duration-300 ${connectState === 'connected' ? 'opacity-100' : 'opacity-0'}`}>

        {/* Direct Tab Content */}
        <div className="w-full animate-in fade-in duration-200">
          {activeTab === 'info' && <InfoTab device={device} getMetrics={getMetrics} hasTelemetry={hasTelemetry} sessionLive={sessionLive} />}
          {activeTab === 'control' && <ControlTab device={device} />}
          {activeTab === 'files' && <FilesTab device={device} />}
          {activeTab === 'processes' && <ProcessesTab device={device} />}
          {activeTab === 'terminal' && <TerminalTab device={device} />}
          {activeTab === 'ai' && <AITab device={device} />}
        </div>

      </div>

    </div>
  );
});
