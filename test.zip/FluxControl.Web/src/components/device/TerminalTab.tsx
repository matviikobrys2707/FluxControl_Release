import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Check, Copy, Eraser, FolderOpen, Loader2, SendHorizonal } from 'lucide-react';
import { Device } from '../../types';
import { deviceClient } from '../../services/deviceClient';
import { displayCwd } from './fcHelpers';
import { toast } from '../../utils/toast';

interface TerminalTabProps {
  device: Device;
}

type ShellKind = 'powershell' | 'cmd';

interface TLine {
  id: number;
  kind: 'cmd' | 'out' | 'sys';
  text: string;
  /** cwd captured at the moment the command was submitted (for echo lines). */
  cwd?: string;
  /** sys-рядок «шлях змінився» — малюємо пілюлею з іконкою папки. */
  cwdChange?: boolean;
}

const MAX_LINES = 2000;
const HISTORY_LIMIT = 100;
/** Маркер шляху шукаємо В ЛЮБОМУ місці рядка: оболонки іноді клеять його
 *  разом з виводом/відлунням — старий full-line regex такі рядки губив. */
const MARKER_RE = /FLUX_CWD::(.+?)(?:::END|>)/;
const MARKER_STRIP_RE = /FLUX_CWD::.*?(::END|>)/g;
const ERROR_LINE_RE = /(error|exception|помилка)/i;

export const TerminalTab: React.FC<TerminalTabProps> = ({ device }) => {
  const [shell, setShell] = useState<ShellKind>('powershell');
  const [lines, setLines] = useState<TLine[]>([]);
  const [cwd, setCwd] = useState('');
  const [command, setCommand] = useState('');
  const [copied, setCopied] = useState(false);
  const [starting, setStarting] = useState(true);

  const idRef = useRef(1);
  const shellRef = useRef<ShellKind>('powershell');
  const cwdRef = useRef('');
  const lastSentRef = useRef('');
  const historyRef = useRef<string[]>([]);
  const histIdxRef = useRef(-1);
  const sawOutputRef = useRef(false);
  const resentRef = useRef(false);
  const resendTimerRef = useRef<number | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const atBottomRef = useRef(true);
  const inputRef = useRef<HTMLInputElement>(null);

  const pushLines = useCallback((incoming: Array<Omit<TLine, 'id'>>) => {
    if (!incoming.length) return;
    // IDs are minted outside the state updater (updaters must stay pure —
    // StrictMode double-invokes them in dev).
    const withIds = incoming.map((l) => ({ ...l, id: (idRef.current += 1) }));
    setLines((prev) => {
      const next = prev.concat(withIds);
      return next.length > MAX_LINES ? next.slice(next.length - MAX_LINES) : next;
    });
  }, []);

  // If the agent stays silent after terminal_start, re-send it once.
  const armStartGuard = useCallback(() => {
    if (resendTimerRef.current) window.clearTimeout(resendTimerRef.current);
    resendTimerRef.current = window.setTimeout(() => {
      if (!sawOutputRef.current && !resentRef.current) {
        resentRef.current = true;
        deviceClient.send('terminal_start', { shell: shellRef.current });
      }
    }, 2500);
  }, []);

  const beginSession = useCallback(
    (next: ShellKind, message?: string) => {
      shellRef.current = next;
      setShell(next);
      sawOutputRef.current = false;
      resentRef.current = false;
      cwdRef.current = '';
      setCwd('');
      lastSentRef.current = '';
      setStarting(true);
      atBottomRef.current = true;
      // (Re)starting the shell clears the screen, keeping only system lines.
      const sys: Array<Omit<TLine, 'id'>> = [];
      if (message) sys.push({ kind: 'sys', text: message });
      sys.push({ kind: 'sys', text: `Запуск ${next === 'powershell' ? 'PowerShell' : 'CMD'} на «${device.name}»…` });
      setLines(sys.map((l) => ({ ...l, id: (idRef.current += 1) })));
      deviceClient.send('terminal_start', { shell: next });
      armStartGuard();
    },
    [armStartGuard, device.name]
  );

  // Mount: start the persistent shell exactly once. Unmount: kill it.
  useEffect(() => {
    beginSession('powershell');
    // If the tab mounted before the relay socket opened, terminal_start was
    // dropped — re-send as soon as the connection is up.
    const offConnected = deviceClient.on('connected', () => {
      if (!sawOutputRef.current && !resentRef.current) {
        resentRef.current = true;
        deviceClient.send('terminal_start', { shell: shellRef.current });
      }
    });
    return () => {
      offConnected();
      if (resendTimerRef.current) window.clearTimeout(resendTimerRef.current);
      deviceClient.killTerminal();
    };
  }, [beginSession]);

  // ================= Output stream =================

  useEffect(() => {
    const off = deviceClient.on('terminal_output', (payload: any) => {
      const text =
        typeof payload === 'string'
          ? payload
          : String(payload?.data ?? payload?.output ?? payload?.text ?? '');
      if (!text) return;
      if (!sawOutputRef.current) {
        sawOutputRef.current = true;
        setStarting(false);
      }

      const rawLines = text.replace(/\r/g, '').split('\n');
      // Drop only the trailing fragment created by the final '\n'.
      if (rawLines.length && rawLines[rawLines.length - 1] === '') rawLines.pop();

      const outs: Array<Omit<TLine, 'id'>> = [];
      let markerCwd: string | null = null;

      for (const raw of rawLines) {
        const m = raw.match(MARKER_RE);
        if (m) {
          // NEVER render marker lines — just track the cwd (last one wins).
          markerCwd = m[1].trim();
        }
        // Strip any inline marker remnants just in case.
        const cleaned = raw.replace(MARKER_STRIP_RE, '').trimEnd();
        const t = cleaned.trim();
        if (!t) {
          // Порожній рядок показуємо тільки якщо це справді вивід, а не
          // залишок від standalone-маркера шляху.
          if (!m && outs.length) outs.push({ kind: 'out', text: '' });
          continue;
        }
        // Defensive de-dup: hide the agent-side bare prompt / prompt+echo so
        // the UI renders exactly ONE echo line per submitted command.
        const lc = t.toLowerCase();
        const cwdLc = cwdRef.current.toLowerCase();
        const sentLc = lastSentRef.current.toLowerCase();
        if (cwdLc && (lc === `${cwdLc}>` || lc === `ps ${cwdLc}>`)) continue;
        if (sentLc && cwdLc && (lc === `${cwdLc}> ${sentLc}` || lc === `ps ${cwdLc}> ${sentLc}`)) continue;
        outs.push({ kind: 'out', text: cleaned });
      }

      if (markerCwd !== null && markerCwd.toLowerCase() !== cwdRef.current.toLowerCase()) {
        // The cwd changed → surface it immediately so `cd appdata` is visible.
        cwdRef.current = markerCwd;
        setCwd(markerCwd);
        if (outs.length && outs[outs.length - 1].text === '') outs.pop();
        outs.push({ kind: 'sys', text: displayCwd(markerCwd) || markerCwd, cwdChange: true });
      }

      pushLines(outs);
    });
    return off;
  }, [pushLines]);

  // Stick-to-bottom: follow the stream only when the user is already there.
  useEffect(() => {
    const el = scrollRef.current;
    if (el && atBottomRef.current) el.scrollTop = el.scrollHeight;
  }, [lines]);

  const handleScroll = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    atBottomRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 48;
  }, []);

  // ================= Input =================

  const submit = useCallback(
    (raw?: string) => {
      const text = (raw !== undefined ? raw : command).trim();
      setCommand('');
      histIdxRef.current = -1;
      if (!text) return;
      pushLines([{ kind: 'cmd', text, cwd: cwdRef.current }]);
      historyRef.current.push(text);
      if (historyRef.current.length > HISTORY_LIMIT) historyRef.current.shift();
      lastSentRef.current = text;
      deviceClient.sendTerminalInput(text);
      atBottomRef.current = true;
      inputRef.current?.focus();
    },
    [command, pushLines]
  );

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLInputElement>) => {
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        const h = historyRef.current;
        if (!h.length) return;
        const idx = histIdxRef.current === -1 ? h.length - 1 : Math.max(0, histIdxRef.current - 1);
        histIdxRef.current = idx;
        setCommand(h[idx]);
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        if (histIdxRef.current === -1) return;
        const idx = histIdxRef.current + 1;
        if (idx >= historyRef.current.length) {
          histIdxRef.current = -1;
          setCommand('');
        } else {
          histIdxRef.current = idx;
          setCommand(historyRef.current[idx]);
        }
      }
    },
    []
  );

  const switchShell = useCallback(
    (next: ShellKind) => {
      inputRef.current?.focus();
      if (next === shellRef.current) return;
      beginSession(
        next,
        `Оболонку змінено на ${next === 'powershell' ? 'PowerShell' : 'CMD'}. Консоль очищено.`
      );
    },
    [beginSession]
  );

  const clearScreen = useCallback(() => {
    setLines([]);
    // Clearing the browser console never touches the remote shell or its cwd.
    pushLines([{ kind: 'sys', text: 'Консоль очищено (лише локально). Робоча папка незмінна.' }]);
    atBottomRef.current = true;
    inputRef.current?.focus();
  }, [pushLines]);

  const copyAll = useCallback(async () => {
    const text = lines
      .map((l) => (l.kind === 'cmd' ? `${displayCwd(l.cwd || cwd)}> ${l.text}` : l.text))
      .join('\n');
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      toast.warn('Не вдалося скопіювати вивід');
    }
  }, [cwd, lines]);

  // ================= Render =================

  const promptCwd = displayCwd(cwd);

  return (
    <div className="fc-card-static flex h-[calc(100vh-15rem)] min-h-[30rem] flex-col overflow-hidden">
      {/* Header: shell chips + tools */}
      <div className="flex shrink-0 items-center justify-between gap-3 border-b border-white/10 bg-black/50 px-3.5 py-2.5">
        <div className="flex min-w-0 items-center gap-2.5">
          <span className="hidden shrink-0 gap-1 sm:flex" aria-hidden="true">
            <span className="h-2.5 w-2.5 rounded-full bg-rose-500/70" />
            <span className="h-2.5 w-2.5 rounded-full bg-amber-500/70" />
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-500/70" />
          </span>
          <div
            className="flex shrink-0 items-center rounded-xl border border-white/10 bg-black/60 p-0.5 text-[11px] font-bold"
            role="group"
            aria-label="Вибір оболонки"
          >
            <button
              type="button"
              onClick={() => switchShell('powershell')}
              className={`rounded-lg px-2.5 py-1 transition-all ${
                shell === 'powershell'
                  ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              PowerShell
            </button>
            <button
              type="button"
              onClick={() => switchShell('cmd')}
              className={`rounded-lg px-2.5 py-1 transition-all ${
                shell === 'cmd'
                  ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              CMD
            </button>
          </div>
          {starting && (
            <span className="flex items-center gap-1.5 text-[10px] font-semibold text-violet-300">
              <Loader2 className="h-3 w-3 animate-spin" />
              очікування оболонки…
            </span>
          )}
          {!starting && promptCwd && (
            <span className="term-cwd-pill ml-1 hidden min-w-0 flex-1 md:inline-flex" title={promptCwd}>
              <FolderOpen />
              <span>{promptCwd}</span>
            </span>
          )}
        </div>
        <div className="flex shrink-0 items-center gap-1.5">
          <button
            type="button"
            onClick={copyAll}
            title="Скопіювати вивід"
            aria-label="Скопіювати вивід"
            className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 bg-white/5 text-zinc-400 transition-colors hover:bg-white/10 hover:text-white"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
          </button>
          <button
            type="button"
            onClick={clearScreen}
            title="Очистити консоль"
            aria-label="Очистити консоль"
            className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 bg-white/5 text-zinc-400 transition-colors hover:bg-white/10 hover:text-white"
          >
            <Eraser className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Output */}
      <div
        ref={scrollRef}
        onScroll={handleScroll}
        onClick={() => inputRef.current?.focus()}
        className="flex-1 cursor-text space-y-0.5 overflow-y-auto bg-black px-3.5 py-3 font-mono text-[12px] leading-[1.55]"
        aria-live="polite"
      >
        {lines.length === 0 && !starting && (
          <div className="text-zinc-600">Готово до введення команд.</div>
        )}
        {lines.map((l) => {
          if (l.kind === 'cmd') {
            return (
              <div key={l.id} className="break-all whitespace-pre-wrap">
                <span className="font-bold text-violet-400">{displayCwd(l.cwd || cwd) || '…'}&gt;&nbsp;</span>
                <span className="text-white">{l.text}</span>
              </div>
            );
          }
          if (l.kind === 'sys') {
            if (l.cwdChange) {
              return (
                <div key={l.id} className="mt-1">
                  <span className="line-cwd-change">
                    <FolderOpen />
                    {l.text}
                  </span>
                </div>
              );
            }
            return (
              <div key={l.id} className="whitespace-pre-wrap break-words italic text-violet-300/60">
                {l.text}
              </div>
            );
          }
          return (
            <div
              key={l.id}
              className={`whitespace-pre-wrap break-words ${ERROR_LINE_RE.test(l.text) ? 'text-rose-400/90' : 'text-zinc-300'}`}
            >
              {l.text || '\u00A0'}
            </div>
          );
        })}
      </div>

      {/* Input row */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
        className="flex shrink-0 items-center gap-2 border-t border-white/10 bg-black/90 px-3.5 py-2.5"
      >
        <span className="shrink-0 font-mono text-[12px] font-bold text-violet-400" title={promptCwd}>
          {promptCwd ? `${promptCwd}>` : '…>'}
        </span>
        <input
          ref={inputRef}
          value={command}
          onChange={(e) => setCommand(e.target.value)}
          onKeyDown={handleKeyDown}
          autoFocus
          spellCheck={false}
          autoComplete="off"
          aria-label="Команда терміналу"
          placeholder="Введіть команду…"
          className="min-w-0 flex-1 border-none bg-transparent font-mono text-[12px] text-white placeholder:text-zinc-600 focus:outline-none"
        />
        <button
          type="submit"
          aria-label="Виконати команду"
          title="Виконати (Enter)"
          className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow transition-all hover:brightness-110"
        >
          <SendHorizonal className="h-3.5 w-3.5" />
        </button>
      </form>
    </div>
  );
};
