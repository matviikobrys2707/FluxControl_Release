import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Archive,
  ArrowUp,
  ChevronRight,
  Download,
  ExternalLink,
  File,
  FileCode2,
  FilePlus,
  FileQuestion,
  Folder,
  FolderOpen,
  FolderPlus,
  HardDrive,
  Image as ImageIcon,
  Loader2,
  MoreVertical,
  Music2,
  Network,
  Pencil,
  RefreshCw,
  Search,
  Trash2,
  Usb,
  Video,
} from 'lucide-react';
import { Device } from '../../types';
import { deviceClient } from '../../services/deviceClient';
import { toast } from '../../utils/toast';
import {
  ARCHIVE_EXTS,
  AUDIO_EXTS,
  DriveCardInfo,
  FsItem,
  IMAGE_EXTS,
  TEXT_EXTS,
  TEXT_PREVIEW_LIMIT,
  VIDEO_EXTS,
  base64ToBlob,
  extOf,
  formatBytes,
  formatDateUk,
  formatGb,
  joinWinPath,
  mediaKindOf,
  mimeFor,
  parentOf,
  pathCrumbs,
  samePath,
  saveBlobAs,
  winNormalize,
  type MediaKind,
} from './fcHelpers';
import { FcConfirmModal, FcModal, FcPromptModal } from './fcModals';

interface FilesTabProps {
  device: Device;
}

type EditorState = {
  item: FsItem;
  path: string;
  content: string;
  original: string;
  loading: boolean;
  loadError: string | null;
  saving: boolean;
  closeArmed: boolean;
};

type PreviewState = {
  item: FsItem;
  path: string;
  kind: MediaKind;
  url: string | null;
  blob: Blob | null;
  loading: boolean;
  error: string | null;
};

type UnsupportedState = { item: FsItem; reason: 'type' | 'big' } | null;
type MenuState = { item: FsItem; x: number; y: number } | null;

const INITIAL_ROWS = 500;
const ROWS_STEP = 500;

// ================= Icon per file type =================

function iconFor(item: FsItem): React.ReactNode {
  const cls = 'h-[1.15rem] w-[1.15rem]';
  if (item.isDirectory) return <Folder className={`${cls} fill-amber-400/70 text-amber-300`} />;
  const e = extOf(item.name);
  if (IMAGE_EXTS.has(e)) return <ImageIcon className={`${cls} text-sky-400`} />;
  if (VIDEO_EXTS.has(e)) return <Video className={`${cls} text-violet-400`} />;
  if (AUDIO_EXTS.has(e)) return <Music2 className={`${cls} text-pink-400`} />;
  if (ARCHIVE_EXTS.has(e)) return <Archive className={`${cls} text-amber-300`} />;
  if (TEXT_EXTS.has(e)) return <FileCode2 className={`${cls} text-emerald-400`} />;
  return <File className={`${cls} text-zinc-400`} />;
}

// ================= Memoized file row =================

interface FileRowProps {
  item: FsItem;
  modified: string;
  sizeLabel: string;
  onOpen: (item: FsItem) => void;
  onDownload: (item: FsItem) => void;
  onMenu: (item: FsItem, x: number, y: number) => void;
  onTouchStart: (item: FsItem, e: React.TouchEvent) => void;
  onTouchCancel: () => void;
}

const FileRow = React.memo<FileRowProps>(({
  item,
  modified,
  sizeLabel,
  onOpen,
  onDownload,
  onMenu,
  onTouchStart,
  onTouchCancel,
}) => (
  <div
    tabIndex={0}
    onClick={() => onOpen(item)}
    onKeyDown={(e) => {
      if (e.key === 'Enter') onOpen(item);
    }}
    onContextMenu={(e) => {
      e.preventDefault();
      onMenu(item, e.clientX, e.clientY);
    }}
    onTouchStart={(e) => onTouchStart(item, e)}
    onTouchEnd={onTouchCancel}
    onTouchMove={onTouchCancel}
    className={`group flex cursor-pointer select-none items-center gap-3 px-3 py-2.5 transition-colors hover:bg-violet-500/[0.07] focus:bg-violet-500/[0.07] focus:outline-none ${
      item.isHidden ? 'opacity-55' : ''
    }`}
  >
    <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-white/5 bg-black/40">
      {iconFor(item)}
    </span>
    <span className="min-w-0 flex-1">
      <span className="block truncate text-xs font-semibold text-zinc-100 group-hover:text-white">{item.name}</span>
      <span className="block truncate text-[10px] text-zinc-500 md:hidden">
        {modified} • {sizeLabel}
      </span>
    </span>
    <span className="hidden w-40 shrink-0 truncate text-[11px] text-zinc-500 md:block">{modified}</span>
    <span className="hidden w-20 shrink-0 text-right font-mono text-[11px] text-zinc-400 sm:block">{sizeLabel}</span>
    <span className="flex shrink-0 items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100 group-focus:opacity-100 max-md:opacity-100">
      <button
        type="button"
        title="Завантажити"
        aria-label={`Завантажити ${item.name}`}
        onClick={(e) => {
          e.stopPropagation();
          onDownload(item);
        }}
        className="grid h-8 w-8 place-items-center rounded-lg text-zinc-400 transition-colors hover:bg-violet-500/15 hover:text-violet-300"
      >
        <Download className="h-4 w-4" />
      </button>
      <button
        type="button"
        title="Дії"
        aria-label={`Дії для ${item.name}`}
        onClick={(e) => {
          e.stopPropagation();
          onMenu(item, e.clientX, e.clientY);
        }}
        className="grid h-8 w-8 place-items-center rounded-lg text-zinc-400 transition-colors hover:bg-white/10 hover:text-white"
      >
        <MoreVertical className="h-4 w-4" />
      </button>
    </span>
  </div>
));
FileRow.displayName = 'FileRow';

// ================= Memoized drive card =================

const DriveCard = React.memo<{ drive: DriveCardInfo; active: boolean; onClick: () => void }>(({
  drive,
  active,
  onClick,
}) => {
  const Icon = drive.driveType === 'removable' ? Usb : drive.driveType === 'network' ? Network : HardDrive;
  const letter = (drive.name || '').replace(/[\\:]/g, '');
  const used = drive.usedGb ?? Math.max(0, drive.totalGb - drive.freeGb);
  const pct = Math.min(100, Math.max(0, Math.round(drive.percentUsed || (drive.totalGb ? (used / drive.totalGb) * 100 : 0))));
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={`Відкрити диск ${letter}`}
      className={`fc-card p-3.5 text-left transition-all hover:-translate-y-0.5 ${
        active
          ? 'border-violet-500/70 bg-violet-500/[0.07] shadow-[0_0_0_1px_rgba(139,92,246,.35),0_12px_32px_-14px_rgba(139,92,246,.45)]'
          : ''
      }`}
    >
      <div className="flex items-center gap-3">
        <span
          className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl border ${
            active
              ? 'border-violet-400/40 bg-violet-500/15 text-violet-300'
              : 'border-white/10 bg-black/40 text-zinc-400'
          }`}
        >
          <Icon className="h-[1.1rem] w-[1.1rem]" />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-sm font-extrabold text-white">
            {letter}
            {drive.label ? <span className="text-xs font-semibold text-zinc-400"> — {drive.label}</span> : null}
          </span>
          <span className="mt-0.5 block truncate text-[11px] text-zinc-500">
            {formatGb(drive.totalGb)} • використано {formatGb(used)} ({pct}%)
          </span>
        </span>
      </div>
      <div className="fc-progress mt-3">
        <i style={{ width: `${pct}%` }} />
      </div>
    </button>
  );
});
DriveCard.displayName = 'DriveCard';

// ================= FilesTab =================

export const FilesTab: React.FC<FilesTabProps> = ({ device }) => {
  const [drives, setDrives] = useState<DriveCardInfo[]>([]);
  const [currentPath, setCurrentPath] = useState('');
  const [parentPath, setParentPath] = useState<string | null>(null);
  const [items, setItems] = useState<FsItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [visibleCount, setVisibleCount] = useState(INITIAL_ROWS);

  const [menu, setMenu] = useState<MenuState>(null);
  const [renameTarget, setRenameTarget] = useState<FsItem | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<FsItem | null>(null);
  const [createKind, setCreateKind] = useState<'file' | 'folder' | null>(null);
  const [editor, setEditor] = useState<EditorState | null>(null);
  const [preview, setPreview] = useState<PreviewState | null>(null);
  const [unsupported, setUnsupported] = useState<UnsupportedState>(null);

  // Refs mirrored from state so socket handlers never read stale values.
  const currentPathRef = useRef('');
  const lastRequestedRef = useRef<string | null>(null);
  const loadingRef = useRef(false);
  const drivesReceivedRef = useRef(false);
  const listedRef = useRef(false);
  const pendingMediaRef = useRef<{ path: string; name: string } | null>(null);
  const holdTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const suppressClickRef = useRef(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const previewUrlRef = useRef<string | null>(null);

  const readPathParam = useCallback((): string | null => {
    try {
      return new URLSearchParams(window.location.search).get('path');
    } catch {
      return null;
    }
  }, []);

  const syncUrl = useCallback(
    (dir: string) => {
      try {
        const code = device.code || device.id;
        window.history.replaceState(
          window.history.state,
          '',
          `/device/${encodeURIComponent(code)}/files?path=${encodeURIComponent(dir)}`
        );
      } catch {
        /* URL sync is best-effort */
      }
    },
    [device]
  );

  const loadDirectory = useCallback((rawPath: string, opts?: { force?: boolean }) => {
    const path = winNormalize(String(rawPath || '').trim());
    if (!path) return;
    // One fs_list per navigation: skip when this directory is already the
    // in-flight/loaded one (the refresh button passes force).
    if (!opts?.force && lastRequestedRef.current && samePath(path, lastRequestedRef.current)) return;
    lastRequestedRef.current = path;
    loadingRef.current = true;
    setLoading(true);
    deviceClient.requestDirectory(path);
  }, []);

  const navigateTo = useCallback(
    (rawPath: string) => {
      const path = winNormalize(String(rawPath || '').trim());
      if (!path) return;
      if (!samePath(path, currentPathRef.current)) setFilter('');
      loadDirectory(path);
    },
    [loadDirectory]
  );

  const refresh = useCallback(() => {
    if (!currentPathRef.current) return;
    loadDirectory(currentPathRef.current, { force: true });
  }, [loadDirectory]);

  // ================= Open / preview routing =================

  const openPreview = useCallback((item: FsItem) => {
    const kind = mediaKindOf(item.name);
    const path = item.path || joinWinPath(currentPathRef.current, item.name);
    if (kind) {
      // Media: download from the agent and render from the base64 blob.
      pendingMediaRef.current = { path, name: item.name };
      setPreview({ item, path, kind, url: null, blob: null, loading: true, error: null });
      deviceClient.downloadFile(path);
      return;
    }
    if (TEXT_EXTS.has(extOf(item.name))) {
      if (typeof item.size === 'number' && item.size > TEXT_PREVIEW_LIMIT) {
        setUnsupported({ item, reason: 'big' });
        return;
      }
      setEditor({ item, path, content: '', original: '', loading: true, loadError: null, saving: false, closeArmed: false });
      deviceClient.readFile(path);
      return;
    }
    setUnsupported({ item, reason: 'type' });
  }, []);

  const handleOpen = useCallback(
    (item: FsItem) => {
      // Swallow the synthetic click that iOS fires right after a long-press.
      if (suppressClickRef.current) {
        suppressClickRef.current = false;
        return;
      }
      if (item.isDirectory) navigateTo(item.path || joinWinPath(currentPathRef.current, item.name));
      else openPreview(item);
    },
    [navigateTo, openPreview]
  );

  const requestDownload = useCallback((item: FsItem) => {
    const path = item.path || joinWinPath(currentPathRef.current, item.name);
    if (item.isDirectory) {
      toast.info('Архівація папки…', { title: 'Завантаження' });
      deviceClient.downloadFolderZip(path);
    } else {
      deviceClient.downloadFile(path);
    }
  }, []);

  const openOnPc = useCallback((item: FsItem) => {
    deviceClient.openFileOnPC(item.path || joinWinPath(currentPathRef.current, item.name));
  }, []);

  const showMenu = useCallback((item: FsItem, x: number, y: number) => {
    setMenu({
      item,
      x: Math.max(8, Math.min(x, window.innerWidth - 232)),
      y: Math.max(8, Math.min(y, window.innerHeight - 290)),
    });
  }, []);

  const cancelHold = useCallback(() => {
    if (holdTimerRef.current) {
      clearTimeout(holdTimerRef.current);
      holdTimerRef.current = null;
    }
  }, []);

  const handleTouchStart = useCallback(
    (item: FsItem, e: React.TouchEvent) => {
      const touch = e.touches[0];
      if (!touch) return;
      cancelHold();
      holdTimerRef.current = setTimeout(() => {
        // The tap that follows a long-press must not leak into rows below.
        suppressClickRef.current = true;
        showMenu(item, touch.clientX, touch.clientY);
      }, 550);
    },
    [cancelHold, showMenu]
  );

  // ================= Socket subscriptions =================

  useEffect(() => {
    const subs = [
      deviceClient.on('fs_drives', (payload: any) => {
        const arr = Array.isArray(payload)
          ? payload
          : Array.isArray(payload?.data)
            ? payload.data
            : Array.isArray(payload?.drives)
              ? payload.drives
              : [];
        const cards: DriveCardInfo[] = arr
          .map((d: any) => ({
            name: String(d?.name || d?.letter || '').trim(),
            label: d?.label || d?.volumeLabel || '',
            totalGb: Number(d?.totalGb ?? (d?.totalBytes ? d.totalBytes / 1024 ** 3 : 0)) || 0,
            freeGb: Number(d?.freeGb ?? (d?.freeBytes ? d.freeBytes / 1024 ** 3 : 0)) || 0,
            usedGb: d?.usedGb != null ? Number(d.usedGb) : undefined,
            percentUsed: Number(d?.percentUsed ?? 0) || 0,
            driveType: d?.driveType || (d?.isRemovable ? 'removable' : 'fixed'),
          }))
          .filter((d: DriveCardInfo) => d.name);
        setDrives(cards);
        drivesReceivedRef.current = true;
        // Without a ?path= deep link, open the first drive once.
        if (!listedRef.current && !lastRequestedRef.current && cards.length) {
          navigateTo(cards[0].name);
        }
      }),

      deviceClient.on('fs_list', (payload: any) => {
        let d: any = null;
        if (Array.isArray(payload)) {
          d = { currentPath: lastRequestedRef.current || '', parentPath: null, items: payload };
        } else if (payload && Array.isArray(payload.items)) {
          d = payload;
        } else if (payload?.data && Array.isArray(payload.data.items)) {
          d = payload.data;
        }
        if (!d) return;
        const confirmed = winNormalize(String(d.currentPath || ''));
        // A late answer for an abandoned navigation must not overwrite the UI.
        if (lastRequestedRef.current && confirmed && !samePath(confirmed, lastRequestedRef.current)) return;
        loadingRef.current = false;
        setLoading(false);
        listedRef.current = true;
        const resolved = confirmed || lastRequestedRef.current || '';
        lastRequestedRef.current = resolved;
        const list: FsItem[] = (d.items || []).map((it: any) => {
          const name = String(it?.name ?? '');
          return {
            name,
            path: String(it?.path || joinWinPath(resolved, name)),
            isDirectory: !!it?.isDirectory,
            size: typeof it?.size === 'number' ? it.size : undefined,
            lastModified: it?.lastModified || it?.modified || it?.modifiedAt || undefined,
            extension: it?.extension || it?.ext || undefined,
            isHidden: !!it?.isHidden,
          };
        });
        setItems(list);
        setCurrentPath(resolved);
        currentPathRef.current = resolved;
        setParentPath(typeof d.parentPath === 'string' && d.parentPath ? d.parentPath : parentOf(resolved));
        setVisibleCount(INITIAL_ROWS);
        setMenu(null);
        if (resolved) syncUrl(resolved);
      }),

      deviceClient.on('fs_error', (payload: any) => {
        loadingRef.current = false;
        setLoading(false);
        lastRequestedRef.current = null; // allow retrying the failed directory
        if (pendingMediaRef.current) {
          const p = pendingMediaRef.current;
          pendingMediaRef.current = null;
          setPreview((prev) => (prev && samePath(prev.path, p.path) ? { ...prev, loading: false, error: payload?.message || 'Не вдалося завантажити файл' } : prev));
        }
        toast.error(payload?.message || 'Не вдалося відкрити папку');
      }),

      deviceClient.on('fs_read_file_result', (payload: any) => {
        if (!payload || typeof payload !== 'object') return;
        if (!payload.success) {
          setEditor((prev) => (prev ? { ...prev, loading: false, loadError: payload.error || 'Не вдалося завантажити файл' } : prev));
          toast.error(payload.error || 'Не вдалося завантажити файл');
          return;
        }
        setEditor((prev) =>
          prev && (!payload.path || samePath(prev.path, payload.path))
            ? { ...prev, content: String(payload.content ?? ''), original: String(payload.content ?? ''), loading: false, loadError: null }
            : prev
        );
      }),

      deviceClient.on('fs_save_file_result', (payload: any) => {
        if (payload?.success) {
          toast.success('Файл збережено');
          setEditor(null);
          loadDirectory(currentPathRef.current, { force: true });
        } else {
          setEditor((prev) => (prev ? { ...prev, saving: false } : prev));
          toast.error(payload?.error || 'Не вдалося зберегти файл');
        }
      }),

      deviceClient.on('fs_create_file_result', (payload: any) => {
        if (payload?.success) {
          toast.success('Файл створено');
          loadDirectory(currentPathRef.current, { force: true });
        } else toast.error(payload?.error || 'Не вдалося створити файл');
      }),

      deviceClient.on('fs_create_folder_result', (payload: any) => {
        if (payload?.success) {
          toast.success('Папку створено');
          loadDirectory(currentPathRef.current, { force: true });
        } else toast.error(payload?.error || 'Не вдалося створити папку');
      }),

      deviceClient.on('fs_rename_result', (payload: any) => {
        if (payload?.success) {
          toast.success('Назву змінено');
          loadDirectory(currentPathRef.current, { force: true });
        } else toast.error(payload?.error || 'Не вдалося перейменувати');
      }),

      deviceClient.on('fs_delete_result', (payload: any) => {
        if (payload?.success) {
          toast.success('Видалено');
          loadDirectory(currentPathRef.current, { force: true });
        } else toast.error(payload?.error || 'Не вдалося видалити');
      }),

      deviceClient.on('fs_open_on_pc_result', (payload: any) => {
        if (payload?.success) toast.success('Відкрито на ПК');
        else toast.error(payload?.error || 'Не вдалося відкрити на ПК');
      }),

      deviceClient.on('fs_download_file_result', (payload: any) => {
        const d = payload || {};
        if (!d.success || !d.base64) {
          if (pendingMediaRef.current) {
            const p = pendingMediaRef.current;
            pendingMediaRef.current = null;
            setPreview((prev) => (prev && samePath(prev.path, p.path) ? { ...prev, loading: false, error: d.error || 'Не вдалося завантажити файл' } : prev));
          }
          toast.error(d.error || 'Не вдалося завантажити');
          return;
        }
        const pending = pendingMediaRef.current;
        if (pending && (!d.path || samePath(d.path, pending.path))) {
          // The result belongs to an open media preview — render it inline.
          pendingMediaRef.current = null;
          const blob = base64ToBlob(d.base64, mimeFor(pending.name));
          const url = URL.createObjectURL(blob);
          setPreview((prev) => (prev && samePath(prev.path, pending.path) ? { ...prev, url, blob, loading: false } : prev));
          return;
        }
        const name = String(d.name || 'download');
        const isZip = d.isZip === true || name.toLowerCase().endsWith('.zip');
        const blob = base64ToBlob(d.base64, isZip ? 'application/zip' : mimeFor(name));
        saveBlobAs(name, blob);
        if (isZip) toast.success('Папку завантажено');
        else toast.success(`«${name}» завантажено`);
      }),
    ];

    // Deep link: /device/<code>/files?path=... opens that directory directly
    // (drives are still requested for the switcher). Otherwise wait for the
    // drive list and auto-open the first disk.
    const p0 = readPathParam();
    if (p0) loadDirectory(p0);
    else deviceClient.requestDrives();

    // The tab mounts while the session is still connecting — the very first
    // requests can be dropped by the closed socket. When the relay socket
    // (re)opens and NO listing has arrived yet, re-issue the initial load.
    const offConnected = deviceClient.on('connected', () => {
      if (listedRef.current) return;
      const p = readPathParam();
      if (p) {
        loadDirectory(p, { force: true });
        return;
      }
      if (!drivesReceivedRef.current) deviceClient.requestDrives();
    });

    // Back/Forward navigation re-reads the ?path param.
    const onPopState = () => {
      const p = readPathParam();
      if (p && !samePath(p, currentPathRef.current)) {
        setFilter('');
        loadDirectory(p);
      }
    };
    window.addEventListener('popstate', onPopState);

    return () => {
      subs.forEach((unsub) => unsub());
      offConnected();
      window.removeEventListener('popstate', onPopState);
    };
  }, [loadDirectory, navigateTo, readPathParam, syncUrl]);

  // Context menu: close on outside interaction / Escape / scroll.
  useEffect(() => {
    if (!menu) return undefined;
    const onOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenu(null);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMenu(null);
    };
    const onScroll = () => setMenu(null);
    window.addEventListener('mousedown', onOutside);
    window.addEventListener('keydown', onKey);
    window.addEventListener('wheel', onScroll, { passive: true });
    return () => {
      window.removeEventListener('mousedown', onOutside);
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('wheel', onScroll);
    };
  }, [menu]);

  // Keep the latest preview URL reachable for the unmount cleanup.
  useEffect(() => {
    previewUrlRef.current = preview?.url ?? null;
  }, [preview]);

  // Unmount: clear long-press timer, revoke any open preview object URL.
  useEffect(
    () => () => {
      if (holdTimerRef.current) clearTimeout(holdTimerRef.current);
      if (previewUrlRef.current) URL.revokeObjectURL(previewUrlRef.current);
    },
    []
  );

  // ================= Derived =================

  const crumbs = useMemo(() => pathCrumbs(currentPath), [currentPath]);
  const atRoot = useMemo(() => {
    if (parentPath) return samePath(parentPath, currentPath);
    return crumbs.length <= 1;
  }, [parentPath, currentPath, crumbs.length]);

  const filtered = useMemo(() => {
    const q = filter.trim().toLowerCase();
    if (!q) return items;
    return items.filter((i) => i.name.toLowerCase().includes(q));
  }, [items, filter]);

  const visible = useMemo(() => filtered.slice(0, visibleCount), [filtered, visibleCount]);
  const remaining = filtered.length - visible.length;

  const upPath = atRoot ? null : parentPath || parentOf(currentPath);

  // ================= Handlers =================

  const closePreview = useCallback(() => {
    if (preview?.url) URL.revokeObjectURL(preview.url);
    setPreview(null);
    pendingMediaRef.current = null;
  }, [preview]);

  // Two-step close keeps unsaved edits from being lost by a single click.
  const requestEditorClose = useCallback(() => {
    if (!editor) return;
    if (editor.content !== editor.original && !editor.closeArmed) {
      setEditor({ ...editor, closeArmed: true });
      return;
    }
    setEditor(null);
  }, [editor]);

  const saveEditor = useCallback(() => {
    if (!editor || editor.loading || editor.saving || editor.loadError) return;
    setEditor({ ...editor, saving: true });
    deviceClient.saveFile(editor.path, editor.content);
  }, [editor]);

  const submitRename = useCallback(
    (value: string) => {
      const target = renameTarget;
      setRenameTarget(null);
      if (!target) return;
      if (value === target.name) return;
      deviceClient.renameItem(target.path || joinWinPath(currentPathRef.current, target.name), value);
    },
    [renameTarget]
  );

  const submitCreate = useCallback((value: string) => {
    const kind = createKind;
    setCreateKind(null);
    if (!kind) return;
    if (kind === 'folder') deviceClient.createFolder(currentPathRef.current, value);
    else deviceClient.createFile(currentPathRef.current, value);
  }, [createKind]);

  const confirmDelete = useCallback(() => {
    const target = deleteTarget;
    setDeleteTarget(null);
    if (!target) return;
    deviceClient.deleteFile(target.path || joinWinPath(currentPathRef.current, target.name));
  }, [deleteTarget]);

  const menuAction = (action: 'open' | 'rename' | 'download' | 'delete' | 'openPc') => {
    if (!menu) return;
    const item = menu.item;
    setMenu(null);
    if (action === 'open') handleOpen(item);
    else if (action === 'rename') setRenameTarget(item);
    else if (action === 'download') requestDownload(item);
    else if (action === 'delete') setDeleteTarget(item);
    else if (action === 'openPc') openOnPc(item);
  };

  // ================= Render =================

  return (
    <div className="space-y-4">
      {/* Toolbar card */}
      <section className="fc-card-static space-y-3.5 p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="fc-section-head">
            <span className="fc-section-icon">
              <HardDrive className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <h3>Файли</h3>
              <p className="truncate">
                {device.name}
                {items.length > 0 ? ` • ${items.length} об'єктів` : ''}
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button type="button" className="fc-btn fc-btn-primary fc-btn-sm" onClick={() => setCreateKind('folder')}>
              <FolderPlus className="h-3.5 w-3.5" />
              Нова папка
            </button>
            <button type="button" className="fc-btn fc-btn-ghost fc-btn-sm" onClick={() => setCreateKind('file')}>
              <FilePlus className="h-3.5 w-3.5" />
              Новий файл
            </button>
            <button
              type="button"
              className="fc-btn fc-btn-ghost fc-btn-sm"
              onClick={refresh}
              title="Оновити"
              aria-label="Оновити"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">Оновити</span>
            </button>
          </div>
        </div>

        {/* Breadcrumbs + up */}
        <div className="flex items-center gap-1 overflow-x-auto rounded-xl border border-white/10 bg-black/40 px-1.5 py-1.5 text-xs">
          <button
            type="button"
            onClick={() => upPath && navigateTo(upPath)}
            disabled={!upPath || loading}
            aria-label="На рівень вище"
            title="На рівень вище"
            className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-violet-300 transition-colors hover:bg-violet-500/15 disabled:opacity-30"
          >
            <ArrowUp className="h-3.5 w-3.5" />
          </button>
          {crumbs.length === 0 ? (
            <span className="px-2 font-mono text-[11px] text-zinc-500">…</span>
          ) : (
            crumbs.map((c, i) => (
              <React.Fragment key={c.path}>
                {i > 0 && <ChevronRight className="h-3 w-3 shrink-0 text-zinc-600" />}
                <button
                  type="button"
                  onClick={() => navigateTo(c.path)}
                  className={`whitespace-nowrap rounded-lg px-2 py-1 font-mono text-[11px] transition-colors ${
                    i === crumbs.length - 1
                      ? 'bg-violet-500/15 font-bold text-violet-200'
                      : 'text-zinc-400 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  {c.name}
                </button>
              </React.Fragment>
            ))
          )}
          {loading && <Loader2 className="ml-auto h-3.5 w-3.5 shrink-0 animate-spin text-violet-300" />}
        </div>

        {/* Search inside the current folder */}
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
          <input
            className="fc-input pl-9"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            placeholder="Пошук у цій папці…"
            aria-label="Пошук у цій папці"
          />
        </div>
      </section>

      {/* Drive switcher */}
      {drives.length > 0 && (
        <section className="space-y-2">
          <h4 className="px-1 text-[10px] font-bold uppercase tracking-wider text-zinc-500">Диски</h4>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {drives.map((d) => (
              <DriveCard
                key={d.name}
                drive={d}
                active={currentPath.toLowerCase().startsWith(d.name.replace(/\\+$/, '').toLowerCase())}
                onClick={() => navigateTo(d.name)}
              />
            ))}
          </div>
        </section>
      )}

      {/* File list */}
      <section className="fc-card-static overflow-hidden">
        {/* Header row (desktop) */}
        <div className="hidden items-center gap-3 border-b border-white/5 bg-black/30 px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-zinc-500 md:flex">
          <span className="h-9 w-9 shrink-0" />
          <span className="flex-1">Назва</span>
          <span className="w-40 shrink-0">Змінено</span>
          <span className="w-20 shrink-0 text-right">Розмір</span>
          <span className="w-[4.25rem] shrink-0" />
        </div>

        {loading && items.length === 0 ? (
          <div className="divide-y divide-white/[0.04]">
            {Array.from({ length: 9 }).map((_, i) => (
              <div key={i} className="flex animate-pulse items-center gap-3 px-3 py-3">
                <div className="h-9 w-9 rounded-xl bg-white/5" />
                <div className="h-3 max-w-[40%] flex-1 rounded bg-white/5" />
                <div className="hidden h-3 w-24 rounded bg-white/5 md:block" />
                <div className="h-3 w-14 rounded bg-white/5" />
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center gap-3 px-6 py-14 text-center">
            <span className="grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-black/40 text-zinc-500">
              {items.length === 0 ? <FolderOpen className="h-6 w-6" /> : <Search className="h-6 w-6" />}
            </span>
            <p className="text-xs font-semibold text-zinc-400">
              {items.length === 0 ? 'Ця папка порожня' : `Нічого не знайдено за запитом «${filter.trim()}»`}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-white/[0.04]">
            {visible.map((item) => (
              <FileRow
                key={`${item.path}|${item.name}`}
                item={item}
                modified={formatDateUk(item.lastModified)}
                sizeLabel={item.isDirectory ? 'Папка' : formatBytes(item.size)}
                onOpen={handleOpen}
                onDownload={requestDownload}
                onMenu={showMenu}
                onTouchStart={handleTouchStart}
                onTouchCancel={cancelHold}
              />
            ))}
          </div>
        )}

        {remaining > 0 && (
          <div className="border-t border-white/5 p-3">
            <button
              type="button"
              className="fc-btn fc-btn-ghost w-full"
              onClick={() => setVisibleCount((c) => c + ROWS_STEP)}
            >
              Показати ще — залишилось {remaining}
            </button>
          </div>
        )}
      </section>

      {/* Context menu */}
      {menu && (
        <div
          ref={menuRef}
          style={{ position: 'fixed', left: menu.x, top: menu.y }}
          className="z-[9500] w-56 rounded-2xl border border-white/10 bg-[#12101f]/95 p-1.5 shadow-[0_24px_60px_rgba(0,0,0,.7)] backdrop-blur-xl"
          role="menu"
        >
          {menu.item.isDirectory ? (
            <button type="button" className="menu-item" onClick={() => menuAction('open')}>
              <FolderOpen className="h-4 w-4 text-violet-300" />
              Відкрити
            </button>
          ) : (
            <button type="button" className="menu-item" onClick={() => menuAction('open')}>
              <Search className="h-4 w-4 text-violet-300" />
              Попередній перегляд
            </button>
          )}
          <button type="button" className="menu-item" onClick={() => menuAction('openPc')}>
            <ExternalLink className="h-4 w-4 text-zinc-400" />
            Відкрити на ПК
          </button>
          <button type="button" className="menu-item" onClick={() => menuAction('rename')}>
            <Pencil className="h-4 w-4 text-zinc-400" />
            Перейменувати
          </button>
          <button type="button" className="menu-item" onClick={() => menuAction('download')}>
            <Download className="h-4 w-4 text-zinc-400" />
            Завантажити
          </button>
          <button type="button" className="menu-item text-rose-300 hover:text-rose-200" onClick={() => menuAction('delete')}>
            <Trash2 className="h-4 w-4" />
            Видалити
          </button>
        </div>
      )}

      {/* Delete confirmation */}
      <FcConfirmModal
        open={!!deleteTarget}
        title={deleteTarget?.isDirectory ? 'Видалити папку?' : 'Видалити?'}
        message={deleteTarget ? `Видалити «${deleteTarget.name}»? Дію не можна скасувати.` : ''}
        confirmLabel="Видалити"
        onConfirm={confirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />

      {/* Rename */}
      <FcPromptModal
        open={!!renameTarget}
        title="Перейменувати"
        label="Нова назва"
        initialValue={renameTarget?.name || ''}
        placeholder="Введіть нову назву"
        confirmLabel="ОК"
        onSubmit={submitRename}
        onCancel={() => setRenameTarget(null)}
      />

      {/* Create file / folder */}
      <FcPromptModal
        open={!!createKind}
        title={createKind === 'file' ? 'Створити файл' : 'Нова папка'}
        label={createKind === 'file' ? 'Назва файлу (з розширенням)' : 'Назва папки'}
        initialValue=""
        placeholder={createKind === 'file' ? 'наприклад notes.txt' : 'наприклад Звіти'}
        confirmLabel="Створити"
        onSubmit={submitCreate}
        onCancel={() => setCreateKind(null)}
      />

      {/* Unsupported / too-big file */}
      {unsupported && (
        <FcModal title="Попередній перегляд недоступний" onClose={() => setUnsupported(null)} width={26}>
          <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl border border-white/10 bg-black/40 text-zinc-400">
            <FileQuestion className="h-7 w-7" />
          </div>
          <p className="break-words text-center text-xs leading-relaxed text-zinc-300">
            {unsupported.reason === 'big'
              ? `«${unsupported.item.name}» завеликий для перегляду (${formatBytes(unsupported.item.size)}).`
              : `Цей тип файлу не можна переглянути${extOf(unsupported.item.name) ? ` (.${extOf(unsupported.item.name)})` : ''}.`}
          </p>
          <p className="mt-2 text-center text-[11px] text-zinc-500">
            Завантажте файл або відкрийте його безпосередньо на ПК.
          </p>
          <div className="mt-6 flex flex-wrap justify-end gap-2">
            <button type="button" className="fc-btn fc-btn-ghost" onClick={() => setUnsupported(null)}>
              Скасувати
            </button>
            <button
              type="button"
              className="fc-btn fc-btn-ghost"
              onClick={() => {
                openOnPc(unsupported.item);
                setUnsupported(null);
              }}
            >
              <ExternalLink className="h-3.5 w-3.5" />
              Відкрити на ПК
            </button>
            <button
              type="button"
              className="fc-btn fc-btn-primary"
              onClick={() => {
                requestDownload(unsupported.item);
                setUnsupported(null);
              }}
            >
              <Download className="h-3.5 w-3.5" />
              Завантажити
            </button>
          </div>
        </FcModal>
      )}

      {/* Media preview */}
      {preview && (
        <FcModal
          title={preview.item.name}
          subtitle={`${preview.kind === 'image' ? 'Зображення' : preview.kind === 'video' ? 'Відео' : 'Аудіо'} • ${formatBytes(preview.item.size)}`}
          width={40}
          onClose={closePreview}
        >
          {preview.loading && (
            <div className="flex h-52 flex-col items-center justify-center gap-3 text-violet-300">
              <Loader2 className="h-7 w-7 animate-spin" />
              <span className="text-xs font-semibold">Завантаження з ПК…</span>
            </div>
          )}
          {!preview.loading && preview.error && (
            <div className="flex h-32 flex-col items-center justify-center gap-2 text-center">
              <FileQuestion className="h-8 w-8 text-rose-400" />
              <p className="text-xs text-rose-300">{preview.error}</p>
            </div>
          )}
          {!preview.loading && !preview.error && preview.url && preview.kind === 'image' && (
            <img src={preview.url} alt={preview.item.name} className="mx-auto max-h-[56vh] rounded-xl border border-white/10 bg-black/60 object-contain" />
          )}
          {!preview.loading && !preview.error && preview.url && preview.kind === 'video' && (
            <video src={preview.url} controls autoPlay playsInline className="mx-auto max-h-[56vh] w-full rounded-xl border border-white/10 bg-black" />
          )}
          {!preview.loading && !preview.error && preview.url && preview.kind === 'audio' && (
            <div className="flex flex-col items-center gap-4 py-8">
              <span className="grid h-16 w-16 place-items-center rounded-2xl border border-pink-400/30 bg-pink-500/10 text-pink-300">
                <Music2 className="h-8 w-8" />
              </span>
              <audio src={preview.url} controls autoPlay className="w-full" />
            </div>
          )}
          <div className="mt-5 flex justify-end gap-2">
            <button type="button" className="fc-btn fc-btn-ghost" onClick={closePreview}>
              Закрити
            </button>
            {preview.blob && (
              <button
                type="button"
                className="fc-btn fc-btn-primary"
                onClick={() => preview.blob && saveBlobAs(preview.item.name, preview.blob)}
              >
                <Download className="h-3.5 w-3.5" />
                Завантажити
              </button>
            )}
          </div>
        </FcModal>
      )}

      {/* Text editor */}
      {editor && (
        <FcModal title={editor.item.name} subtitle={editor.path} width={46} onClose={requestEditorClose}>
          {editor.loading ? (
            <div className="flex h-52 flex-col items-center justify-center gap-3 text-violet-300">
              <Loader2 className="h-7 w-7 animate-spin" />
              <span className="text-xs font-semibold">Читання файлу…</span>
            </div>
          ) : editor.loadError ? (
            <div className="flex h-32 flex-col items-center justify-center gap-2 text-center">
              <FileQuestion className="h-8 w-8 text-rose-400" />
              <p className="text-xs text-rose-300">{editor.loadError}</p>
            </div>
          ) : (
            <>
              <div className="mb-2 flex items-center justify-between gap-2">
                <span className="text-[10px] text-zinc-500">
                  {formatBytes(editor.item.size)} • редагування тексту
                </span>
                {editor.content !== editor.original && (
                  <span className="fc-badge fc-badge-warn">Є незбережені зміни</span>
                )}
              </div>
              <textarea
                value={editor.content}
                onChange={(e) =>
                  setEditor((prev) =>
                    prev ? { ...prev, content: e.target.value, closeArmed: false } : prev
                  )
                }
                spellCheck={false}
                className="fc-input min-h-[46vh] resize-y font-mono text-xs leading-5"
                aria-label={`Редагування ${editor.item.name}`}
              />
              {editor.closeArmed && (
                <p className="mt-2 text-[11px] font-semibold text-amber-300">
                  Зміни не збережено. Натисніть ще раз, щоб закрити без збереження.
                </p>
              )}
            </>
          )}
          <div className="mt-4 flex flex-wrap justify-end gap-2">
            <button type="button" className={`fc-btn ${editor.content !== editor.original && !editor.closeArmed && !editor.loading ? 'fc-btn-warn' : 'fc-btn-ghost'}`} onClick={requestEditorClose}>
              {editor.closeArmed ? 'Закрити без збереження' : 'Закрити'}
            </button>
            <button
              type="button"
              className="fc-btn fc-btn-primary"
              disabled={editor.loading || editor.saving || editor.loadError != null}
              onClick={saveEditor}
            >
              {editor.saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}
              Зберегти
            </button>
          </div>
        </FcModal>
      )}
    </div>
  );
};
