import React, { useEffect, useState } from 'react';
import { Square, Video } from 'lucide-react';
import { recordingStore, ActiveRecording } from '../../utils/recordingStore';
import { deviceClient } from '../../services/deviceClient';

/**
 * Глобальний індикатор активного запису екрана/камери.
 * Маленька «липка» плашка зліва внизу, яку видно НА БУДЬ-ЯКІЙ сторінці сайту,
 * доки на ПК триває запис: пульсуюча точка, зворотний відлік і кнопка стоп.
 * Зникає сама, коли приходить recording_result / recording_cancelled.
 */
export const RecordingBadge: React.FC = React.memo(() => {
  const [rec, setRec] = useState<ActiveRecording>(recordingStore.get());
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => recordingStore.subscribe(setRec), []);

  useEffect(() => {
    if (!rec) { setElapsed(0); return; }
    const timer = window.setInterval(
      () => setElapsed(Math.max(0, Math.floor((Date.now() - rec.startedAt) / 1000))),
      500
    );
    return () => window.clearInterval(timer);
  }, [rec]);

  if (!rec) return null;

  const left = Math.max(0, rec.total - elapsed);
  const canCancel = deviceClient.isOpen();
  const progress = Math.min(100, Math.max(0, (elapsed / Math.max(1, rec.total)) * 100));

  return (
    <div className="fixed bottom-4 left-4 z-[10060] animate-in fade-in slide-in-from-bottom-4 duration-300">
      <div className="rec-badge relative flex items-center gap-3 px-4 pb-4 pt-3">
        <span className="relative flex h-2.5 w-2.5 flex-none">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-rose-400 opacity-75" />
          <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-rose-500 shadow-[0_0_10px_rgba(244,63,94,.9)]" />
        </span>
        <div className="min-w-0">
          <p className="flex items-center gap-1.5 text-[11px] font-extrabold text-white">
            <Video className="h-3 w-3 text-rose-300" />
            Запис {rec.source === 'screen' ? 'екрана' : 'камери'} — {rec.deviceName}
          </p>
          <p className="font-mono text-[10px] text-rose-200/80">
            {Math.floor(elapsed / 60)}:{String(elapsed % 60).padStart(2, '0')} / {Math.floor(rec.total / 60)}:{String(rec.total % 60).padStart(2, '0')}
            {left > 0 ? ` · залишилось ${left} с` : ' · завершення…'}
          </p>
        </div>
        {canCancel && (
          <button
            onClick={() => deviceClient.send('record_cancel', {})}
            className="ml-1 flex flex-none cursor-pointer items-center gap-1 rounded-xl border border-white/25 bg-gradient-to-br from-rose-500 to-rose-700 px-2.5 py-1.5 text-[10px] font-bold text-white shadow-[0_8px_20px_-8px_rgba(225,29,72,.9),inset_0_1px_rgba(255,255,255,.25)] transition hover:brightness-110 active:scale-95"
            title="Скасувати запис"
          >
            <Square className="h-3 w-3" />
            Стоп
          </button>
        )}
        <div className="rec-badge-bar">
          <i style={{ width: `${progress}%` }} />
        </div>
      </div>
    </div>
  );
});

RecordingBadge.displayName = 'RecordingBadge';
