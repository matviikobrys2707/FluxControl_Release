import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Camera,
  CameraOff,
  Clock,
  Download,
  Image as ImageIcon,
  Loader2,
  Monitor,
  Square,
  Video,
  X
} from 'lucide-react';
import { deviceClient } from '../../services/deviceClient';
import { toast } from '../../utils/toast';
import { recordingStore } from '../../utils/recordingStore';
import { cameraWord, clampPercent, loadStoredNumber, pick, storeValue } from './fcEvents';

type Viewer = { kind: 'image' | 'video'; data: string; name: string } | null;
type Recording = { source: 'screen' | 'webcam'; total: number; startedAt: number } | null;

/** Camera delay presets in seconds (persisted selection). */
const CAM_DELAYS = [0, 5, 10, 15, 30, 60, 180, 300] as const;
const CAM_DELAY_KEY = 'flux_cam_delay';
/** Recording duration presets in seconds. */
const RECORD_DURATIONS = [5, 10, 15, 30, 60, 180, 300] as const;

const delayLabel = (s: number): string => (s === 0 ? 'Негайно' : s < 60 ? `${s} с` : `${s / 60} хв`);
const recordLabel = (s: number): string => (s < 60 ? `${s} с` : `${s / 60} хв`);

const saveBase64 = (value: string, name: string, type: string) => {
  const bytes = Uint8Array.from(atob(value), char => char.charCodeAt(0));
  const url = URL.createObjectURL(new Blob([bytes], { type }));
  const link = document.createElement('a');
  link.href = url;
  link.download = name;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
};

/** One big capture tile (screenshot / record screen / record camera). */
const CaptureTile: React.FC<{
  icon: React.ReactNode;
  tone: string;
  title: string;
  subtitle: string;
  onClick: () => void;
}> = React.memo(({ icon, tone, title, subtitle, onClick }) => (
  <button
    onClick={onClick}
    className="group flex min-h-[6.4rem] flex-col items-start justify-center gap-1.5 rounded-2xl border border-white/10 bg-white/[.03] p-3.5 text-left transition hover:-translate-y-0.5 hover:border-indigo-400/40 hover:bg-white/[.06] active:scale-[.98]"
  >
    <span className={`grid h-9 w-9 flex-none place-items-center rounded-xl border ${tone}`}>{icon}</span>
    <b className="text-[13px] font-extrabold text-white">{title}</b>
    <small className="text-[11px] leading-tight text-zinc-400">{subtitle}</small>
  </button>
));
CaptureTile.displayName = 'CaptureTile';

export const RemoteCaptureTools: React.FC<{ deviceName?: string }> = React.memo(({ deviceName: dn }) => {
  const [viewer, setViewer] = useState<Viewer>(null);
  const [recordDialog, setRecordDialog] = useState<'screen' | 'webcam' | null>(null);
  const [recordSeconds, setRecordSeconds] = useState(30);
  const [recording, setRecording] = useState<Recording>(null);
  const [elapsed, setElapsed] = useState(0);

  // ----- Camera photo state -----
  const [cameras, setCameras] = useState<string[]>([]);
  const [camerasKnown, setCamerasKnown] = useState(false); // camera_list answer received
  const [selectedCamera, setSelectedCamera] = useState('');
  const [camDelay, setCamDelay] = useState<number>(() => loadStoredNumber(CAM_DELAY_KEY, [...CAM_DELAYS], 0));
  const [camDeadline, setCamDeadline] = useState<number | null>(null); // when the shot fires
  const [camLeft, setCamLeft] = useState<number | null>(null); // displayed countdown
  const camBusy = camLeft !== null;

  const mediaUrl = useMemo(() => (viewer?.kind === 'video' ? `data:video/mp4;base64,${viewer.data}` : ''), [viewer]);

  // ----- Event subscriptions -----
  useEffect(() => {
    const off = [
      deviceClient.on('screenshot_response', (raw: any) => {
        const d = pick<any>(raw);
        const image = d?.imageBase64 || d?.data;
        if (image) {
          setViewer({ kind: 'image', data: image, name: `Screenshot_${Date.now()}.jpg` });
          toast.success('Скріншот готово');
        } else {
          toast.error(d?.error || 'Скріншот не отримано');
        }
      }),
      deviceClient.on('screenshot', (raw: any) => {
        const d = pick<any>(raw);
        const image = typeof d === 'string' ? d : d?.imageBase64;
        if (image) {
          setViewer({ kind: 'image', data: image, name: `Screenshot_${Date.now()}.jpg` });
          toast.success('Скріншот готово');
        }
      }),
      deviceClient.on('camera_list', (raw: any) => {
        const d = pick<any>(raw);
        const list = Array.isArray(d) ? d : d?.cameras;
        if (!Array.isArray(list)) return;
        const names = list
          .map((c: any) => (typeof c === 'string' ? c : c?.name))
          .filter((n: any): n is string => typeof n === 'string' && n.length > 0);
        setCameras(names);
        setCamerasKnown(true);
        setSelectedCamera(prev => (names.length > 0 && !names.includes(prev) ? names[0] : prev));
      }),
      deviceClient.on('webcam_status', (raw: any) => {
        const d = pick<any>(raw);
        if (d && typeof d.secondsLeft === 'number' && d.secondsLeft >= 0) {
          setCamDeadline(Date.now() + d.secondsLeft * 1000);
          setCamLeft(Math.ceil(d.secondsLeft));
        }
      }),
      deviceClient.on('webcam_response', (raw: any) => {
        const d = pick<any>(raw);
        setCamDeadline(null);
        setCamLeft(null);
        if (d?.imageBase64) {
          setViewer({ kind: 'image', data: d.imageBase64, name: `Camera_${Date.now()}.jpg` });
          toast.success('Фото з камери готове');
        } else {
          toast.error(`${d?.error || 'Камеру не знайдено'}. Перевірте, чи дозволено застосунку доступ до камери на ПК.`);
        }
      }),
      deviceClient.on('recording_result', (raw: any) => {
        const d = pick<any>(raw);
        setRecording(null);
        recordingStore.set(null);
        if (d?.success && d?.videoBase64) {
          setViewer({ kind: 'video', data: d.videoBase64, name: d.name || `Recording_${Date.now()}.mp4` });
          toast.success('Запис готово');
        } else {
          toast.error(d?.error || 'Запис не створено');
        }
      }),
      deviceClient.on('recording_cancelled', () => {
        setRecording(null);
        recordingStore.set(null);
        toast.info('Запис скасовано');
      })
    ];
    return () => off.forEach(unsubscribe => unsubscribe());
  }, []);

  // Ask the agent for the camera list on mount.
  useEffect(() => {
    deviceClient.listCameras();
  }, []);

  // Persist the selected camera delay.
  useEffect(() => {
    storeValue(CAM_DELAY_KEY, String(camDelay));
  }, [camDelay]);

  // Displayed countdown for the delayed camera shot (ticks only while shown).
  useEffect(() => {
    if (camDeadline === null) return;
    let timer: number | null = window.setInterval(() => {
      const left = Math.max(0, Math.ceil((camDeadline - Date.now()) / 1000));
      setCamLeft(left);
      if (left <= 0 && timer !== null) {
        window.clearInterval(timer);
        timer = null;
      }
    }, 250);
    // Immediate first paint of the countdown (no waiting 250 ms).
    setCamLeft(Math.max(0, Math.ceil((camDeadline - Date.now()) / 1000)));
    return () => { if (timer !== null) window.clearInterval(timer); };
  }, [camDeadline]);

  // Safety: if the agent never answers after the countdown, free the button.
  useEffect(() => {
    if (camLeft !== 0) return;
    const t = window.setTimeout(() => {
      setCamDeadline(null);
      setCamLeft(null);
      toast.warn('Камера не відповіла вчасно');
    }, 15000);
    return () => window.clearTimeout(t);
  }, [camLeft]);

  // Recording progress ticker (only while a recording is active).
  useEffect(() => {
    if (!recording) { setElapsed(0); return; }
    const timer = window.setInterval(
      () => setElapsed(Math.min(recording.total, Math.floor((Date.now() - recording.startedAt) / 1000))),
      250
    );
    return () => window.clearInterval(timer);
  }, [recording]);

  // Lock page scroll while a fullscreen viewer/dialog is open.
  useEffect(() => {
    if (!viewer && !recordDialog) return;
    const old = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = old; };
  }, [viewer, recordDialog]);

  // ----- Actions -----
  const [photoDialog, setPhotoDialog] = useState(false);
  const [deviceName, setDeviceName] = useState(dn || '');
  useEffect(() => { if (dn) setDeviceName(dn); }, [dn]);

  /** Кнопка-плитка «Фото з камери»: кілька камер → діалог вибору, одна → знімок одразу. */
  const openPhotoDialog = () => {
    if (camBusy) return;
    if (cameras.length > 1) {
      setPhotoDialog(true);
      return;
    }
    takePhoto();
  };

  const takePhoto = () => {
    if (camBusy) return;
    setPhotoDialog(false);
    if (camDelay > 0) {
      setCamDeadline(Date.now() + camDelay * 1000);
      setCamLeft(camDelay);
    } else {
      // No local countdown: still block the button until the answer arrives.
      setCamDeadline(Date.now());
      setCamLeft(0);
    }
    deviceClient.captureWebcam(selectedCamera || undefined, camDelay > 0 ? camDelay : undefined);
  };

  const startRecording = () => {
    if (!recordDialog) return;
    const rec = { source: recordDialog, total: recordSeconds, startedAt: Date.now(), deviceName: deviceName || 'ПК' };
    setRecording(rec);
    recordingStore.set(rec); // глобальний індикатор на будь-якій сторінці
    deviceClient.send('record_capture', { source: recordDialog, seconds: recordSeconds });
    setRecordDialog(null);
    toast.info('Запис розпочато');
  };

  const remaining = recording ? Math.max(0, recording.total - elapsed) : 0;

  return (
    <>
      {/* ============ ЕДИНАЯ РАМКА «Захоплення екрана та відео»: 4 плитки ============ */}
      <section className="fc-card p-5">
        <div className="fc-section-head mb-4">
          <div className="fc-section-icon"><Monitor className="h-5 w-5" /></div>
          <div>
            <h3>Захоплення екрана та відео</h3>
            <p>Скриншот, записи та камера віддаленого ПК</p>
          </div>
          {recording && (
            <span className="fc-badge fc-badge-err ml-auto flex-none">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-rose-400" /> запис йде…
            </span>
          )}
        </div>

        <div className="capture-actions">
          <button className="capture-action capture-screenshot" onClick={() => deviceClient.captureScreenshot()}>
            <span className="cap-ico"><ImageIcon /></span>
            <b>Скриншот</b>
            <small>Знімок усього екрана</small>
          </button>
          <button className="capture-action capture-record-screen" onClick={() => setRecordDialog('screen')}>
            <span className="cap-ico"><Monitor /></span>
            <b>Запис екрана</b>
            <small>Відео дисплея з таймером</small>
          </button>
          <button className="capture-action capture-camera-photo" onClick={openPhotoDialog} disabled={camBusy}>
            <span className="cap-ico"><Camera /></span>
            <b>Фото з камери</b>
            <small>{cameras.length > 1 ? `доступно ${cameras.length} ${cameraWord(cameras.length)}` : 'один кадр'}</small>
          </button>
          <button className="capture-action capture-camera-video" onClick={() => setRecordDialog('webcam')}>
            <span className="cap-ico"><Video /></span>
            <b>Запис камери</b>
            <small>Відео з веб-камери</small>
          </button>
        </div>

        {camerasKnown && cameras.length === 0 && (
          <div className="capture-notice mt-4 flex items-center gap-2 !text-[11px]">
            <CameraOff className="h-4 w-4 flex-none" />
            <span>Камер не знайдено — «Фото з камери» спробує стандартну камеру.</span>
          </div>
        )}
      </section>

      {/* ============ Идет запись: локальная панель (в этой вкладке) ============ */}
      {recording && (
        <section className="fc-card p-5 !border-rose-500/30">
          <div className="capture-recording-status">
            <div>
              <b className="flex items-center gap-2">
                <span className="rec-dot" />
                Йде запис: {recording.source === 'screen' ? 'екрана' : 'камери'} — {recording.deviceName}
              </b>
              <span>{elapsed} с із {recording.total} с · залишилось {remaining} с · не закривайте ПК до кінця запису</span>
            </div>
            <button onClick={() => deviceClient.send('record_cancel', {})}>
              <Square className="h-3 w-3" />
              Скасувати
            </button>
            <div className="capture-progress">
              <i style={{ width: `${clampPercent((elapsed / Math.max(1, recording.total)) * 100)}%` }} />
            </div>
          </div>
        </section>
      )}

      {/* ============ Photo dialog: выбор камеры + задержка ============ */}
      {photoDialog && (
        <div className="fc-modal-backdrop" role="dialog" aria-modal="true" onClick={() => setPhotoDialog(false)}>
          <div className="fc-modal" onClick={(e) => e.stopPropagation()}>
            <div className="fc-section-head">
              <div className="fc-section-icon fc-icon-cyan"><Camera className="h-5 w-5" /></div>
              <div>
                <h3>Фото з камери</h3>
                <p>Виберіть камеру та затримку знімка</p>
              </div>
              <button onClick={() => setPhotoDialog(false)} className="keyboard-close ml-auto" aria-label="Закрити">
                <X className="h-5 w-5" />
              </button>
            </div>

            {cameras.length > 1 ? (
              <div className="mt-4">
                <p className="mb-1.5 text-[10px] font-extrabold uppercase tracking-wide text-zinc-500">Камера</p>
                <div className="flex flex-wrap gap-2">
                  {cameras.map(name => (
                    <button
                      key={name}
                      onClick={() => setSelectedCamera(name)}
                      title={name}
                      className={`fc-btn fc-btn-sm max-w-[15rem] ${selectedCamera === name ? 'fc-btn-primary' : 'fc-btn-ghost'}`}
                    >
                      <Camera className="h-3 w-3 flex-none" />
                      <span className="truncate">{name}</span>
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="mt-4 flex items-center gap-2 rounded-xl border border-white/10 bg-white/[.04] px-3 py-2.5 text-[11px] text-zinc-300">
                <Camera className="h-3.5 w-3.5 flex-none text-cyan-300" />
                <span className="truncate">{cameras[0] || 'Стандартна камера ПК'}</span>
              </div>
            )}

            <div className="mt-4">
              <p className="mb-1.5 flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-wide text-zinc-500">
                <Clock className="h-3 w-3" /> Затримка
              </p>
              <div className="flex flex-wrap gap-2">
                {CAM_DELAYS.map(seconds => (
                  <button
                    key={seconds}
                    onClick={() => setCamDelay(seconds)}
                    className={`fc-btn fc-btn-sm ${camDelay === seconds ? 'fc-btn-primary' : 'fc-btn-ghost'}`}
                  >
                    {delayLabel(seconds)}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-5 flex items-center gap-3">
              <button onClick={() => setPhotoDialog(false)} className="fc-btn fc-btn-ghost flex-1">Скасувати</button>
              <button onClick={takePhoto} className="fc-btn fc-btn-primary flex-1">
                <Camera className="h-4 w-4" />
                <span>Зробити фото</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============ Recording duration dialog ============ */}
      {recordDialog && (
        <div className="fc-fullscreen-modal fc-modal-center" role="dialog" aria-modal="true">
          <div className="record-dialog">
            <div className="record-dialog-heading">
              <div className="flex items-center gap-3">
                <span className="rec-dlg-ico">
                  {recordDialog === 'screen' ? <Monitor className="h-5 w-5" /> : <Video className="h-5 w-5" />}
                </span>
                <div>
                  <p>ТРИВАЛІСТЬ ЗАПИСУ</p>
                  <h3>{recordDialog === 'screen' ? 'Запис екрана' : 'Запис камери'}</h3>
                </div>
              </div>
              <button onClick={() => setRecordDialog(null)} className="keyboard-close" aria-label="Закрити">
                <X className="h-5 w-5" />
              </button>
            </div>
            <p className="record-dialog-sub">
              Виберіть тривалість — запис виконає сам ПК. Це вікно можна закрити: на будь-якій сторінці сайту залишиться індикатор запису.
            </p>
            <div className="record-duration-grid">
              {RECORD_DURATIONS.map(seconds => (
                <button
                  key={seconds}
                  onClick={() => setRecordSeconds(seconds)}
                  className={recordSeconds === seconds ? 'active' : ''}
                >
                  {recordLabel(seconds)}
                </button>
              ))}
            </div>
            <button onClick={startRecording} className="record-start-button">
              <span className="rec-dot" />
              <Video className="h-4 w-4" />
              Почати запис
            </button>
          </div>
        </div>
      )}

      {/* ============ Media viewer ============ */}
      {viewer && (
        <div className="fc-fullscreen-modal media-viewer" role="dialog" aria-modal="true">
          <header>
            <span>{viewer.name}</span>
            <div>
              <button
                onClick={() => saveBase64(viewer.data, viewer.name, viewer.kind === 'image' ? 'image/jpeg' : 'video/mp4')}
                className="fc-btn fc-btn-primary fc-shine"
              >
                <Download className="h-4 w-4" /> Завантажити
              </button>
              <button onClick={() => setViewer(null)} className="keyboard-close" aria-label="Закрити перегляд">
                <X className="h-5 w-5" />
              </button>
            </div>
          </header>
          <main>
            {viewer.kind === 'image'
              ? <img src={`data:image/jpeg;base64,${viewer.data}`} alt="Знімок з віддаленого ПК" />
              : <video src={mediaUrl} controls autoPlay />}
          </main>
        </div>
      )}
    </>
  );
});

RemoteCaptureTools.displayName = 'RemoteCaptureTools';
