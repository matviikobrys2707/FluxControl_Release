/**
 * Shared helpers for the device tabs (Files / Processes / Terminal).
 * Referenced ONLY by FilesTab.tsx, ProcessesTab.tsx and TerminalTab.tsx.
 *
 * Pure functions + payload types — no React, no side effects.
 */

// ================= Payload shapes (agent message contracts) =================

export interface FsItem {
  name: string;
  path: string;
  isDirectory: boolean;
  size?: number;
  /** C# DateTime JSON string from the agent. */
  lastModified?: string;
  extension?: string;
  isHidden?: boolean;
}

export interface DriveCardInfo {
  name: string;
  label?: string;
  totalGb: number;
  freeGb: number;
  usedGb?: number;
  percentUsed: number;
  driveType?: 'fixed' | 'removable' | 'network' | 'unknown';
}

export interface ProcInfo {
  pid: number;
  name: string;
  exePath?: string;
  memoryMb: number;
  /** Реальний CPU% (дельта між оновленнями списку, як у Task Manager). */
  cpuPercent?: number;
  /** \"app\" (має вікно) | \"background\" | \"system\" (сесія 0). */
  category?: 'app' | 'background' | 'system' | string;
}

// ================= Paths =================

export function winNormalize(p: string | null | undefined): string {
  return String(p || '').replace(/\//g, '\\').replace(/\\+/g, '\\');
}

/** Case-insensitive, separator-insensitive Windows path comparison. */
export function samePath(a: string | null | undefined, b: string | null | undefined): boolean {
  if (!a || !b) return false;
  const norm = (s: string) => winNormalize(s).replace(/\\+$/, '').toLowerCase();
  return norm(a) === norm(b);
}

export function joinWinPath(parent: string, name: string): string {
  return `${winNormalize(parent).replace(/\\+$/, '')}\\${name}`;
}

export function parentOf(path: string): string {
  const p = winNormalize(path).replace(/\\+$/, '');
  if (/^[A-Za-z]:$/.test(p)) return `${p}\\`;
  const idx = p.lastIndexOf('\\');
  if (idx <= 2) {
    const drive = p.slice(0, 2);
    return /^[A-Za-z]:$/.test(drive) ? `${drive}\\` : p;
  }
  return p.slice(0, idx);
}

export interface PathCrumb {
  name: string;
  path: string;
}

/** "C:\Users\BlazeX" → [{C:\}, {Users}, {BlazeX}] with cumulative paths. */
export function pathCrumbs(path: string): PathCrumb[] {
  const parts = winNormalize(path).split('\\').filter(Boolean);
  if (!parts.length) return [];
  return parts.map((part, i) => ({
    name: part,
    path: i === 0 ? `${parts[0]}\\` : parts.slice(0, i + 1).join('\\'),
  }));
}

/** Prompt-safe cwd display: root stays "C:\", others keep as-is. */
export function displayCwd(cwd: string): string {
  const c = winNormalize(cwd);
  if (!c) return '';
  return /^[A-Za-z]:$/.test(c) ? `${c}\\` : c;
}

// ================= File kinds =================

export function extOf(name: string): string {
  const n = String(name || '');
  const idx = n.lastIndexOf('.');
  if (idx < 0) return '';
  // Dotfiles like ".env" / ".gitignore" → "env" / "gitignore"
  return n.slice(idx + 1).toLowerCase();
}

export const TEXT_EXTS = new Set([
  'txt', 'md', 'py', 'js', 'mjs', 'ts', 'tsx', 'json', 'cs', 'c', 'cpp', 'h', 'html', 'css', 'scss',
  'xml', 'yml', 'yaml', 'log', 'ini', 'cfg', 'conf', 'bat', 'cmd', 'ps1', 'sh', 'csv', 'env',
  'gitignore', 'sql', 'java', 'rb', 'go', 'php',
]);
export const IMAGE_EXTS = new Set(['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp']);
export const VIDEO_EXTS = new Set(['mp4', 'webm']);
export const AUDIO_EXTS = new Set(['mp3', 'wav', 'ogg']);
export const ARCHIVE_EXTS = new Set(['zip', 'rar', '7z', 'tar', 'gz']);

/** Max size of a text file that can still be opened in the in-browser editor. */
export const TEXT_PREVIEW_LIMIT = 512 * 1024;

export type MediaKind = 'image' | 'video' | 'audio';

export function mediaKindOf(name: string): MediaKind | null {
  const e = extOf(name);
  if (IMAGE_EXTS.has(e)) return 'image';
  if (VIDEO_EXTS.has(e)) return 'video';
  if (AUDIO_EXTS.has(e)) return 'audio';
  return null;
}

export function isTextFile(name: string): boolean {
  return TEXT_EXTS.has(extOf(name));
}

export function mimeFor(name: string): string {
  switch (extOf(name)) {
    case 'png': return 'image/png';
    case 'jpg': case 'jpeg': return 'image/jpeg';
    case 'gif': return 'image/gif';
    case 'webp': return 'image/webp';
    case 'bmp': return 'image/bmp';
    case 'mp4': return 'video/mp4';
    case 'webm': return 'video/webm';
    case 'mp3': return 'audio/mpeg';
    case 'wav': return 'audio/wav';
    case 'ogg': return 'audio/ogg';
    case 'zip': return 'application/zip';
    default: return 'application/octet-stream';
  }
}

// ================= Formatting =================

export function formatBytes(bytes?: number | null): string {
  const v = Number(bytes);
  if (!v || v <= 0) return '—';
  const units = ['Б', 'КБ', 'МБ', 'ГБ', 'ТБ'];
  let i = 0;
  let val = v;
  while (val >= 1024 && i < units.length - 1) {
    val /= 1024;
    i += 1;
  }
  const rounded = i === 0 || val >= 100 ? Math.round(val) : Math.round(val * 10) / 10;
  return `${rounded} ${units[i]}`;
}

export function formatGb(valueGb?: number | null): string {
  const v = Number(valueGb) || 0;
  return `${v >= 100 ? Math.round(v) : Math.round(v * 10) / 10} ГБ`;
}

export function formatMemoryMb(mb: number): string {
  const v = Number(mb) || 0;
  if (v >= 1024) return `${(Math.round((v / 1024) * 10) / 10).toFixed(1)} ГБ`;
  return `${Math.round(v)} МБ`;
}

export function formatDateUk(value?: string | null): string {
  if (!value) return '—';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  const date = d.toLocaleDateString('uk-UA', { day: '2-digit', month: '2-digit', year: 'numeric' });
  const time = d.toLocaleTimeString('uk-UA', { hour: '2-digit', minute: '2-digit' });
  return `${date}, ${time}`;
}

// ================= Binary / download =================

export function base64ToBlob(b64: string, mime: string = 'application/octet-stream'): Blob {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i += 1) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}

/** Trigger a browser download for an in-memory blob (DownloadModal pattern). */
export function saveBlobAs(name: string, blob: Blob): void {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = name || 'download';
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  // Revoke late: some browsers abort the download if the URL dies too early.
  window.setTimeout(() => URL.revokeObjectURL(url), 10000);
}

// ================= Windows naming rules =================

/** Returns an error message for an invalid Windows file/folder name, or null. */
export function invalidNameError(name: string): string | null {
  if (!name || !name.trim()) return 'Введіть назву';
  if (/[\\/:*?"<>|]/.test(name)) return 'Назва не може містити символи \\ / : * ? " < > |';
  if (/[. ]$/.test(name)) return 'Назва не може закінчуватися крапкою або пробілом';
  return null;
}
