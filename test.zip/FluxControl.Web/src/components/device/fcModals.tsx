/**
 * Shared modal shells for the device tabs, built on the unified design
 * tokens from index.css (.fc-modal-backdrop / .fc-modal / .fc-btn / .fc-input).
 * Referenced ONLY by FilesTab.tsx and ProcessesTab.tsx.
 */

import React, { useEffect, useRef, useState } from 'react';
import { AlertTriangle, X } from 'lucide-react';
import { invalidNameError } from './fcHelpers';

// ================= Base modal =================

interface FcModalProps {
  title: string;
  subtitle?: string;
  onClose: () => void;
  children: React.ReactNode;
  /** Max width in rem (default 27 — matches the .fc-modal token). */
  width?: number;
}

export const FcModal: React.FC<FcModalProps> = ({ title, subtitle, onClose, children, width = 27 }) => {
  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener('keydown', onKey);
    };
  }, [onClose]);

  return (
    <div
      className="fc-modal-backdrop"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className="fc-modal"
        style={{ width: `min(100%, ${width}rem)` }}
        role="dialog"
        aria-modal="true"
        aria-label={title}
      >
        <div className="mb-4 flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h3 className="break-words">{title}</h3>
            {subtitle && <p className="mt-1 truncate font-mono text-[11px] text-zinc-500">{subtitle}</p>}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Закрити"
            className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-white/10 bg-white/5 text-zinc-400 transition-colors hover:bg-white/10 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
};

// ================= Confirm modal =================

interface FcConfirmModalProps {
  open: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  danger?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export const FcConfirmModal: React.FC<FcConfirmModalProps> = ({
  open,
  title,
  message,
  confirmLabel = 'Підтвердити',
  danger = true,
  onConfirm,
  onCancel,
}) => {
  if (!open) return null;
  return (
    <FcModal title={title} onClose={onCancel} width={24}>
      <div
        className={`mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl border ${
          danger
            ? 'border-rose-500/30 bg-rose-500/10 text-rose-400'
            : 'border-violet-500/30 bg-violet-500/10 text-violet-300'
        }`}
      >
        <AlertTriangle className="h-7 w-7" />
      </div>
      <p className="break-words text-center text-xs leading-relaxed text-zinc-300">{message}</p>
      <div className="mt-6 flex gap-2">
        <button type="button" className="fc-btn fc-btn-ghost flex-1" onClick={onCancel}>
          Скасувати
        </button>
        <button type="button" autoFocus className={`fc-btn flex-1 ${danger ? 'fc-btn-danger' : 'fc-btn-primary'}`} onClick={onConfirm}>
          {confirmLabel}
        </button>
      </div>
    </FcModal>
  );
};

// ================= Prompt (single input) modal =================

interface FcPromptModalProps {
  open: boolean;
  title: string;
  label: string;
  initialValue?: string;
  placeholder?: string;
  confirmLabel?: string;
  /** Receives the trimmed value; only called when it passes validation. */
  onSubmit: (value: string) => void;
  onCancel: () => void;
}

export const FcPromptModal: React.FC<FcPromptModalProps> = ({
  open,
  title,
  label,
  initialValue = '',
  placeholder,
  confirmLabel = 'Зберегти',
  onSubmit,
  onCancel,
}) => {
  const [value, setValue] = useState(initialValue);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!open) return undefined;
    setValue(initialValue);
    setError(null);
    // Windows-style: preselect the base name without the extension.
    const timer = window.setTimeout(() => {
      const el = inputRef.current;
      if (!el) return;
      el.focus();
      const dot = initialValue.lastIndexOf('.');
      if (dot > 0) el.setSelectionRange(0, dot);
      else el.select();
    }, 40);
    return () => window.clearTimeout(timer);
  }, [open, initialValue]);

  if (!open) return null;

  const submit = () => {
    const v = value.trim();
    const err = invalidNameError(v);
    if (err) {
      setError(err);
      return;
    }
    onSubmit(v);
  };

  return (
    <FcModal title={title} onClose={onCancel} width={24}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
      >
        <label className="mb-1.5 block text-[11px] font-semibold text-zinc-400">{label}</label>
        <input
          ref={inputRef}
          className="fc-input"
          value={value}
          placeholder={placeholder}
          onChange={(e) => {
            setValue(e.target.value);
            setError(null);
          }}
          spellCheck={false}
          autoComplete="off"
        />
        {error && <p className="mt-2 text-[11px] font-semibold text-rose-400">{error}</p>}
        <div className="mt-5 flex gap-2">
          <button type="button" className="fc-btn fc-btn-ghost flex-1" onClick={onCancel}>
            Скасувати
          </button>
          <button type="submit" className="fc-btn fc-btn-primary flex-1">
            {confirmLabel}
          </button>
        </div>
      </form>
    </FcModal>
  );
};
