import React, { useState, useRef, useEffect } from 'react';
import {
  Home,
  Monitor,
  BookOpen,
  User as UserIcon,
  LogOut,
  ChevronDown,
  Sliders,
  FolderTree,
  Activity,
  Terminal,
  Bot,
  Gauge,
  Crown,
  Zap,
  ShieldAlert
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Device, AppRoute, SessionTab } from '../types';

interface NavbarProps {
  currentRoute: AppRoute;
  onNavigate: (route: AppRoute) => void;
  activeDevice: Device | null;
  activeSessionTab: SessionTab;
  onSessionTabChange: (tab: SessionTab) => void;
  onDisconnectSession: () => void;
  onDownloadClient: () => void;
  /** Режим заблокованого акаунта: показуємо тільки профіль і вихід. */
  gated?: boolean;
}

/** Пункт нижньої мобільної панелі. */
const BottomTab: React.FC<{
  icon: React.ReactNode;
  label: string;
  active: boolean;
  danger?: boolean;
  accent?: boolean;
  onClick: () => void;
}> = ({ icon, label, active, danger, accent, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    className={`relative flex min-w-[48px] flex-1 cursor-pointer flex-col items-center justify-center gap-0.5 px-0.5 py-2 transition-colors ${
      danger
        ? 'text-red-400'
        : accent
          ? active
            ? 'text-amber-300'
            : 'text-amber-300/60'
          : active
            ? 'text-indigo-300'
            : 'text-gray-500'
    }`}
  >
    {active && (
      <span
        className={`absolute top-0 h-[3px] w-7 rounded-full ${
          danger ? 'bg-red-400' : accent ? 'bg-amber-400' : 'bg-indigo-400'
        }`}
      />
    )}
    <span className="transition-transform active:scale-90">{icon}</span>
    <span className="max-w-full truncate text-[9px] font-bold leading-none">{label}</span>
  </button>
);

export const Navbar: React.FC<NavbarProps> = ({
  currentRoute,
  onNavigate,
  activeDevice,
  activeSessionTab,
  onSessionTabChange,
  onDisconnectSession,
  onDownloadClient,
  gated,
}) => {
  const { user, loginWithGoogle, logout, isAdmin, isSubscribed } = useAuth();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  // Do not expose short relay/polling drops as an offline state in the header.
  const [displayedOnline, setDisplayedOnline] = useState(Boolean(activeDevice?.isOnline));
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!activeDevice) return;
    if (activeDevice.isOnline) {
      setDisplayedOnline(true);
      return;
    }
    const graceTimer = window.setTimeout(() => setDisplayedOnline(false), 4000);
    return () => window.clearTimeout(graceTimer);
  }, [activeDevice?.id, activeDevice?.isOnline]);

  // Close dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // ================= Мобильная нижняя панель =================
  const renderBottomBar = () => {
    if (gated) {
      return (
        <nav className="fixed inset-x-0 bottom-0 z-50 flex items-stretch justify-around border-t border-white/10 bg-[#0a0a12]/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-2xl md:hidden">
          <BottomTab icon={<UserIcon className="h-5 w-5" />} label="Профіль" active={currentRoute === '/profile'} onClick={() => onNavigate('/profile')} />
          <BottomTab icon={<LogOut className="h-5 w-5" />} label="Вийти" active={false} danger onClick={logout} />
        </nav>
      );
    }
    if (activeDevice) {
      return (
        <nav
          className="fixed inset-x-0 bottom-0 z-50 flex items-stretch gap-0.5 overflow-x-auto border-t border-white/10 bg-[#0a0a12]/95 px-1 pb-[env(safe-area-inset-bottom)] backdrop-blur-2xl md:hidden"
          aria-label="Вкладки сесії"
        >
          <BottomTab icon={<Gauge className="h-5 w-5" />} label="Інфо" active={activeSessionTab === 'info'} onClick={() => onSessionTabChange('info')} />
          <BottomTab icon={<Sliders className="h-5 w-5" />} label="Керувати" active={activeSessionTab === 'control'} onClick={() => onSessionTabChange('control')} />
          <BottomTab icon={<FolderTree className="h-5 w-5" />} label="Файли" active={activeSessionTab === 'files'} onClick={() => onSessionTabChange('files')} />
          <BottomTab icon={<Activity className="h-5 w-5" />} label="Процеси" active={activeSessionTab === 'processes'} onClick={() => onSessionTabChange('processes')} />
          <BottomTab icon={<Terminal className="h-5 w-5" />} label="Термінал" active={activeSessionTab === 'terminal'} onClick={() => onSessionTabChange('terminal')} />
          <BottomTab icon={<Bot className="h-5 w-5" />} label="AI" active={activeSessionTab === 'ai'} onClick={() => onSessionTabChange('ai')} />
          <BottomTab icon={<LogOut className="h-5 w-5" />} label="Вийти" active={false} danger onClick={onDisconnectSession} />
        </nav>
      );
    }
    return (
      <nav
        className="fixed inset-x-0 bottom-0 z-50 flex items-stretch justify-around border-t border-white/10 bg-[#0a0a12]/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-2xl md:hidden"
        aria-label="Головна навігація"
      >
        <BottomTab icon={<Home className="h-5 w-5" />} label="Головна" active={currentRoute === '/'} onClick={() => onNavigate('/')} />
        <BottomTab icon={<Monitor className="h-5 w-5" />} label="Пристрої" active={currentRoute === '/devices'} onClick={() => onNavigate('/devices')} />
        <BottomTab icon={<BookOpen className="h-5 w-5" />} label="Інструкція" active={currentRoute === '/guide'} onClick={() => onNavigate('/guide')} />
        {isAdmin && (
          <BottomTab icon={<Crown className="h-5 w-5" />} label="Адмін" active={currentRoute === '/admin'} accent onClick={() => onNavigate('/admin')} />
        )}
        <BottomTab icon={<UserIcon className="h-5 w-5" />} label="Профіль" active={currentRoute === '/profile'} onClick={() => onNavigate('/profile')} />
      </nav>
    );
  };

  return (
    <>
      <header className="fixed top-3 left-1/2 z-50 w-[96%] -translate-x-1/2 sm:top-4 md:max-w-6xl">
        <div className="glass-panel flex items-center justify-between rounded-2xl border border-white/10 px-3 py-2.5 shadow-2xl backdrop-blur-2xl transition-all sm:px-6 sm:rounded-full">

          {/* Left Side: Brand Logo (when disconnected) OR Device Status Frame (when connected) */}
          {activeDevice ? (
            <div
              id="navbar-active-device-frame"
              className="flex shrink-0 cursor-pointer select-none items-center gap-2.5 rounded-2xl border border-indigo-500/30 bg-black/80 px-3 py-1.5 transition-all hover:border-indigo-400/50 shadow-md"
              onClick={() => onSessionTabChange('info')}
              title={`Підключено до: ${activeDevice.name}`}
            >
              <div className="rounded-xl border border-indigo-500/30 bg-indigo-950/60 p-1.5 text-indigo-300">
                <Monitor className="w-4 h-4" />
              </div>

              <div className="text-left">
                <p className="text-xs font-black leading-tight text-white truncate max-w-[110px] sm:max-w-[170px]">
                  {activeDevice.name}
                </p>
                <div className="mt-0.5 flex items-center gap-1.5">
                  <span className={`w-1.5 h-1.5 rounded-full ${
                    displayedOnline ? 'bg-emerald-400 animate-pulse' : 'bg-red-400'
                  }`} />
                  <span className="font-mono text-[10px] font-semibold text-gray-300">
                    {displayedOnline ? 'Онлайн' : 'Офлайн'}
                  </span>
                  <span className="hidden font-mono text-[10px] text-indigo-300/70 sm:inline">
                    • {activeDevice.code || activeDevice.id}
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <div
              id="navbar-brand-btn"
              className="flex shrink-0 cursor-pointer select-none items-center gap-2.5 group"
              onClick={() => onNavigate('/')}
            >
              <div className="glow-indigo rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 p-2 text-white shadow-md shadow-indigo-600/30 transition-transform group-hover:scale-105">
                <Zap className="w-4 h-4 fill-white text-white" />
              </div>
              <span className="hidden bg-gradient-to-r from-white via-indigo-100 to-indigo-400 bg-clip-text text-base font-extrabold tracking-tight text-transparent sm:inline sm:text-lg">
                FluxControl
              </span>
            </div>
          )}

          {/* Center Navigation Mode: Active Device Session Tabs vs Global Navigation
              (desktop only — на телефонах вкладки живуть у нижній панелі) */}
          {!gated && activeDevice && (
            <nav className="hidden items-center gap-1 overflow-x-auto rounded-full border border-white/10 bg-black/50 p-1.5 text-xs md:flex">
              <button
                id="tab-btn-info"
                onClick={() => onSessionTabChange('info')}
                className={`flex cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-full px-3 py-1.5 font-semibold transition-all ${
                  activeSessionTab === 'info'
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Gauge className="w-3.5 h-3.5" />
                <span>Інфо</span>
              </button>

              <button
                id="tab-btn-control"
                onClick={() => onSessionTabChange('control')}
                className={`flex cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-full px-3 py-1.5 font-semibold transition-all ${
                  activeSessionTab === 'control'
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>Управління</span>
              </button>

              <button
                id="tab-btn-files"
                onClick={() => onSessionTabChange('files')}
                className={`flex cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-full px-3 py-1.5 font-semibold transition-all ${
                  activeSessionTab === 'files'
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <FolderTree className="w-3.5 h-3.5" />
                <span>Файли</span>
              </button>

              <button
                id="tab-btn-processes"
                onClick={() => onSessionTabChange('processes')}
                className={`flex cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-full px-3 py-1.5 font-semibold transition-all ${
                  activeSessionTab === 'processes'
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Activity className="w-3.5 h-3.5" />
                <span>Процеси</span>
              </button>

              <button
                id="tab-btn-terminal"
                onClick={() => onSessionTabChange('terminal')}
                className={`flex cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-full px-3 py-1.5 font-semibold transition-all ${
                  activeSessionTab === 'terminal'
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Terminal className="w-3.5 h-3.5" />
                <span>Термінал</span>
              </button>

              <button
                id="tab-btn-ai"
                onClick={() => onSessionTabChange('ai')}
                className={`flex cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-full px-3 py-1.5 font-semibold transition-all ${
                  activeSessionTab === 'ai'
                    ? 'bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white shadow-lg shadow-fuchsia-600/30'
                    : 'text-fuchsia-300/80 hover:text-fuchsia-200 hover:bg-fuchsia-500/10'
                }`}
              >
                <Bot className="w-3.5 h-3.5" />
                <span>AI</span>
              </button>

              <button
                id="btn-disconnect-session"
                onClick={onDisconnectSession}
                className="ml-1 flex cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-full border border-red-500/25 px-3 py-1.5 text-xs font-semibold text-red-400 transition-all hover:border-red-500/40 hover:bg-red-500/15 hover:text-red-300 active:scale-95"
                title="Відключитись від ПК"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Вийти</span>
              </button>
            </nav>
          )}

          {!gated && !activeDevice && (
            <nav className="hidden items-center gap-1 overflow-x-auto rounded-full border border-white/10 bg-black/50 p-1.5 text-xs md:flex">
              <button
                id="nav-btn-home"
                onClick={() => onNavigate('/')}
                className={`flex cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-full px-4 py-1.5 font-semibold transition-all ${
                  currentRoute === '/'
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Home className="w-3.5 h-3.5" />
                <span>Головна</span>
              </button>

              <button
                id="nav-btn-devices"
                onClick={() => onNavigate('/devices')}
                className={`flex cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-full px-4 py-1.5 font-semibold transition-all ${
                  currentRoute === '/devices'
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Monitor className="w-3.5 h-3.5" />
                <span>Пристрої</span>
              </button>

              <button
                id="nav-btn-guide"
                onClick={() => onNavigate('/guide')}
                className={`flex cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-full px-4 py-1.5 font-semibold transition-all ${
                  currentRoute === '/guide'
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Інструкція</span>
              </button>

              {/* Admin Panel Button if user is Admin */}
              {isAdmin && (
                <button
                  id="nav-btn-admin"
                  onClick={() => onNavigate('/admin')}
                  className={`flex cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-full px-4 py-1.5 font-bold transition-all ${
                    currentRoute === '/admin'
                      ? 'bg-gradient-to-r from-amber-500 to-purple-600 text-white shadow-lg shadow-amber-500/30'
                      : 'text-amber-300/80 hover:text-amber-200 hover:bg-amber-500/10'
                  }`}
                >
                  <Crown className="w-3.5 h-3.5 text-amber-400" />
                  <span>Адміністратор</span>
                </button>
              )}
            </nav>
          )}

          {gated && (
            <div className="hidden items-center gap-1.5 rounded-full border border-amber-500/25 bg-amber-500/10 px-3.5 py-1.5 text-[11px] font-bold text-amber-300 md:flex">
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>Доступ обмежено — тільки профіль</span>
            </div>
          )}

          {/* User Profile Frame & Interactive Dropdown Menu */}
          <div className="relative shrink-0" ref={dropdownRef}>
            {user ? (
              <div>
                <button
                  id="user-profile-frame-btn"
                  onClick={() => setDropdownOpen(prev => !prev)}
                  className="group flex cursor-pointer items-center gap-2.5 rounded-full border border-indigo-500/25 bg-black/70 px-2 py-1.5 transition-all hover:border-indigo-400/50 hover:bg-indigo-950/40 sm:px-3"
                  title="Відкрити меню профілю"
                >
                  <div className="relative">
                    {user.photoURL || user.picture ? (
                      <img
                        src={user.photoURL || user.picture}
                        alt={user.name}
                        className="w-7 h-7 rounded-full border border-indigo-400/60 object-cover"
                      />
                    ) : (
                      <div className="flex h-7 w-7 items-center justify-center rounded-full border border-indigo-400/50 bg-indigo-600/40 text-xs font-bold text-indigo-200">
                        {user.name.charAt(0).toUpperCase()}
                      </div>
                    )}
                    <span className="absolute bottom-0 right-0 w-2 h-2 rounded-full bg-emerald-400 ring-2 ring-[#050508]" />
                  </div>

                  <div className="hidden text-left max-w-[120px] sm:block">
                    <p className="text-xs font-bold leading-tight text-white truncate group-hover:text-indigo-200">
                      {user.name}
                    </p>
                    <p className="font-mono text-[10px] leading-tight text-gray-400 truncate">
                      {isAdmin ? 'Admin' : isSubscribed ? 'PRO' : 'Без підписки'}
                    </p>
                  </div>

                  <ChevronDown className={`w-3.5 h-3.5 text-indigo-300 transition-transform ${dropdownOpen ? 'rotate-180' : ''}`} />
                </button>

                {/* Interactive Dropdown Menu — minimal & compact */}
                {dropdownOpen && (
                  <div
                    id="user-profile-dropdown-menu"
                    className="absolute right-0 mt-2 w-44 animate-in rounded-2xl border border-white/10 bg-black/95 p-1.5 text-left shadow-2xl shadow-black/60 backdrop-blur-xl z-50 fade-in zoom-in-95 duration-150"
                  >
                    <button
                      id="dropdown-menu-profile"
                      onClick={() => {
                        setDropdownOpen(false);
                        onNavigate('/profile');
                      }}
                      className="flex w-full cursor-pointer items-center gap-2.5 rounded-xl px-3 py-2 text-left text-xs font-semibold text-gray-300 transition-all hover:bg-white/10 hover:text-white"
                    >
                      <UserIcon className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Мій профіль</span>
                    </button>

                    <button
                      id="dropdown-menu-logout"
                      onClick={() => {
                        setDropdownOpen(false);
                        logout();
                      }}
                      className="flex w-full cursor-pointer items-center gap-2.5 rounded-xl px-3 py-2 text-left text-xs font-semibold text-red-400 transition-all hover:bg-red-500/10 hover:text-red-300"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Вийти з акаунта</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                id="btn-login-google"
                onClick={loginWithGoogle}
                className="flex cursor-pointer items-center gap-2 rounded-full bg-indigo-600 px-3.5 py-2 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 transition-all hover:bg-indigo-500 active:scale-95 sm:px-4"
              >
                <UserIcon className="w-3.5 h-3.5" />
                <span>
                  Увійти
                  <span className="hidden sm:inline"> через Google</span>
                </span>
              </button>
            )}
          </div>

        </div>
      </header>

      {/* Мобильная нижняя панель вкладок */}
      {renderBottomBar()}
    </>
  );
};
