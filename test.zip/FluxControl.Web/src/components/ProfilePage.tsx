import React, { useState } from 'react';
import {
  User as UserIcon,
  Mail,
  Key,
  Monitor,
  ShieldCheck,
  LogOut,
  Check,
  Copy,
  Sparkles,
  Crown,
  AlertCircle,
  KeyRound,
  Wifi,
  WifiOff
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useDevices } from '../context/DeviceContext';
import { AppRoute } from '../types';

interface ProfilePageProps {
  onNavigate: (route: AppRoute) => void;
  onDownloadClient: () => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({ onNavigate }) => {
  const { user, updateProfile, logout, isAdmin, isSubscribed, subscriptionExpiresAt, activateKey } = useAuth();
  const { devices } = useDevices();

  const [isEditingName, setIsEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(user?.name || '');
  const [copiedId, setCopiedId] = useState(false);

  // License Key activation state
  const [keyCodeInput, setKeyCodeInput] = useState('');
  const [isActivating, setIsActivating] = useState(false);
  const [activationResult, setActivationResult] = useState<{ success: boolean; message: string } | null>(null);

  if (!user) {
    return (
      <div className="max-w-md mx-auto px-4 pt-36 pb-20 text-center">
        <div className="glass-card rounded-3xl p-8 border border-white/10 bg-[#090b14]">
          <div className="w-16 h-16 bg-indigo-600/20 border border-indigo-500/30 rounded-full flex items-center justify-center text-indigo-400 mx-auto mb-4">
            <UserIcon className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-white mb-2">Авторизація необхідна</h2>
          <p className="text-xs text-gray-400 mb-6">
            Будь ласка, увійдіть у свій акаунт, щоб переглядати профіль, керувати ліцензіями та пристроями.
          </p>
          <button
            onClick={() => window.location.reload()}
            className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white rounded-2xl font-bold text-xs shadow-lg shadow-indigo-600/30 cursor-pointer"
          >
            Оновити сторінку
          </button>
        </div>
      </div>
    );
  }

  const handleSaveName = () => {
    if (nameInput.trim()) {
      updateProfile(nameInput.trim());
    }
    setIsEditingName(false);
  };

  const handleCopyId = () => {
    navigator.clipboard.writeText(user.id).catch(() => {});
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const handleActivateKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!keyCodeInput.trim()) return;

    setIsActivating(true);
    setActivationResult(null);

    const res = await activateKey(keyCodeInput.trim());
    setIsActivating(false);
    setActivationResult(res);

    if (res.success) {
      setKeyCodeInput('');
    }
  };

  const formatRemainingTime = () => {
    if (isAdmin) return 'Безлімітний доступ';
    if (subscriptionExpiresAt === -1) return 'Безстрокова підписка';
    if (!subscriptionExpiresAt) return 'Немає активної підписки';

    const diff = subscriptionExpiresAt - Date.now();
    if (diff <= 0) return 'Термін дії закінчився';

    const days = Math.floor(diff / (24 * 3600 * 1000));
    const hours = Math.floor((diff % (24 * 3600 * 1000)) / (3600 * 1000));
    const minutes = Math.floor((diff % (3600 * 1000)) / (60 * 1000));

    if (days > 0) return `${days} дн. ${hours} год. ${minutes} хв.`;
    if (hours > 0) return `${hours} год. ${minutes} хв.`;
    return `${minutes} хв.`;
  };

  const expiresLabel = (() => {
    if (isAdmin || subscriptionExpiresAt === -1) return 'Без обмежень';
    if (!subscriptionExpiresAt) return '—';
    return new Date(subscriptionExpiresAt).toLocaleDateString('uk-UA', { day: 'numeric', month: 'long', year: 'numeric' });
  })();

  const onlineCount = devices.filter(d => d.isOnline).length;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 pt-28 pb-24 w-full animate-in fade-in duration-300">

      {/* ================= Hero profile card ================= */}
      <div className="fc-card relative overflow-hidden bg-[#090b14]/90 p-6 sm:p-8">
        <div className="absolute -top-24 right-0 w-80 h-80 bg-indigo-600/10 blur-3xl rounded-full pointer-events-none" />
        <div className="absolute -bottom-32 -left-10 w-72 h-72 bg-violet-600/10 blur-3xl rounded-full pointer-events-none" />

        <div className="relative flex flex-col items-center gap-6 sm:flex-row sm:items-center sm:gap-8">
          {/* Avatar */}
          <div className="relative flex-shrink-0">
            <div className="w-24 h-24 rounded-3xl p-[2px] bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 shadow-xl shadow-indigo-600/25 sm:w-28 sm:h-28">
              {user.photoURL || user.picture ? (
                <img
                  src={user.photoURL || user.picture}
                  alt={user.name}
                  className="h-full w-full rounded-[22px] object-cover"
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center rounded-[22px] bg-[#11162b] text-4xl font-black text-indigo-200">
                  {user.name?.charAt(0).toUpperCase() || 'U'}
                </div>
              )}
            </div>
          </div>

          {/* Name + email + status */}
          <div className="min-w-0 flex-1 text-center sm:text-left">
            {isEditingName ? (
              <div className="mx-auto flex max-w-sm items-center gap-2 sm:mx-0">
                <input
                  type="text"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') handleSaveName(); }}
                  autoFocus
                  className="fc-input flex-1 !text-base !font-bold"
                  aria-label="Ім'я користувача"
                />
                <button onClick={handleSaveName} className="fc-btn fc-btn-primary flex-none !px-3" title="Зберегти">
                  <Check className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => { setNameInput(user.name); setIsEditingName(true); }}
                className="group inline-flex cursor-pointer items-center gap-2.5 rounded-2xl px-2 py-1 transition-colors hover:bg-white/5 sm:px-1.5"
                title="Змінити ім'я"
              >
                <h1 className="text-2xl font-black text-white sm:text-3xl">{user.name}</h1>
                <KeyRound className="h-4 w-4 flex-none text-indigo-400 opacity-60 transition-opacity group-hover:opacity-100" />
              </button>
            )}

            <div className="mt-2 flex flex-wrap items-center justify-center gap-2 text-xs text-zinc-400 sm:justify-start">
              <span className="inline-flex items-center gap-1.5">
                <Mail className="h-3.5 w-3.5 text-indigo-400" />
                {user.email || 'Не вказано'}
              </span>
              <span className="inline-flex items-center gap-1.5 font-mono">
                ID: {user.id.slice(0, 10)}…
                <button onClick={handleCopyId} className="cursor-pointer transition-colors hover:text-white" title="Скопіювати повний ID">
                  {copiedId ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                </button>
              </span>
            </div>
          </div>

          {/* Status badge */}
          <div className="flex flex-shrink-0 flex-col items-center gap-2 sm:items-end">
            {isAdmin ? (
              <span className="inline-flex items-center gap-1.5 rounded-2xl border border-amber-500/40 bg-gradient-to-r from-amber-500/20 to-purple-500/20 px-4 py-2 text-xs font-black text-amber-300">
                <Crown className="h-4 w-4 text-amber-400" />
                <span>Адміністратор</span>
              </span>
            ) : isSubscribed ? (
              <span className="inline-flex items-center gap-1.5 rounded-2xl border border-emerald-500/30 bg-emerald-500/15 px-4 py-2 text-xs font-black text-emerald-300">
                <ShieldCheck className="h-4 w-4 text-emerald-400" />
                <span>PRO Підписка</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-xs font-bold text-zinc-300">
                <span>Без підписки</span>
              </span>
            )}

            {/* Вихід — текстова дія, не «велика кнопка» */}
            <button
              onClick={logout}
              className="inline-flex cursor-pointer items-center gap-1.5 px-2 py-1 text-[11px] font-semibold text-red-400/70 transition-colors hover:text-red-300"
            >
              <LogOut className="h-3 w-3" />
              <span>Вийти з акаунта</span>
            </button>
          </div>
        </div>
      </div>

      {/* ================= Stats row ================= */}
      <div className="mt-5 grid grid-cols-2 gap-4 lg:grid-cols-3">
        <div className="fc-card-static flex items-center gap-3.5 p-4 sm:p-5">
          <div className="grid h-11 w-11 flex-none place-items-center rounded-2xl border border-indigo-400/25 bg-indigo-500/15 text-indigo-300">
            <Monitor className="h-5 w-5" />
          </div>
          <div className="min-w-0">
            <p className="text-xl font-black text-white">{devices.length}</p>
            <p className="text-[11px] font-semibold text-zinc-400">Пристроїв прив'язано</p>
          </div>
        </div>
        <div className="fc-card-static flex items-center gap-3.5 p-4 sm:p-5">
          <div className="grid h-11 w-11 flex-none place-items-center rounded-2xl border border-emerald-400/25 bg-emerald-500/15 text-emerald-300">
            <Wifi className="h-5 w-5" />
          </div>
          <div className="min-w-0">
            <p className="text-xl font-black text-white">{onlineCount}</p>
            <p className="text-[11px] font-semibold text-zinc-400">Зараз в мережі</p>
          </div>
        </div>
        <div className="fc-card-static col-span-2 flex items-center gap-3.5 p-4 sm:p-5 lg:col-span-1">
          <div className={`grid h-11 w-11 flex-none place-items-center rounded-2xl border ${isSubscribed || isAdmin ? 'border-violet-400/25 bg-violet-500/15 text-violet-300' : 'border-amber-400/25 bg-amber-500/15 text-amber-300'}`}>
            <Key className="h-5 w-5" />
          </div>
          <div className="min-w-0">
            <p className="truncate text-sm font-black text-white">{formatRemainingTime()}</p>
            <p className="text-[11px] font-semibold text-zinc-400">Діє до: {expiresLabel}</p>
          </div>
        </div>
      </div>

      {/* ================= Activation + devices (two columns) ================= */}
      <div className="mt-5 grid grid-cols-1 items-start gap-5 lg:grid-cols-5">

        {/* Activation card */}
        <div className="fc-card bg-[#090b14]/90 p-6 lg:col-span-3">
          <div className="fc-section-head mb-5">
            <div className="fc-section-icon"><Key className="h-5 w-5" /></div>
            <div>
              <h3>Активація ключа</h3>
              <p>Ліцензійний ключ відкриває доступ до сервісу</p>
            </div>
          </div>

          <form onSubmit={handleActivateKey} className="space-y-4">
            <div className="flex flex-col items-stretch gap-3 sm:flex-row">
              <input
                type="text"
                required
                value={keyCodeInput}
                onChange={(e) => setKeyCodeInput(e.target.value)}
                placeholder="FC-A1B2-C3D4-E5F6-G7H8"
                className="fc-input flex-1 font-mono uppercase tracking-widest placeholder:text-zinc-600"
                aria-label="Ліцензійний ключ"
              />
              <button
                type="submit"
                disabled={isActivating || !keyCodeInput.trim()}
                className="fc-btn fc-btn-primary flex-none disabled:cursor-not-allowed disabled:opacity-50"
              >
                <Sparkles className="h-4 w-4" />
                <span>{isActivating ? 'Активація…' : 'Активувати'}</span>
              </button>
            </div>

            {activationResult && (
              <div className={`flex animate-in items-center gap-2.5 rounded-2xl p-3.5 text-xs fade-in ${
                activationResult.success
                  ? 'border border-emerald-500/30 bg-emerald-500/15 text-emerald-300'
                  : 'border border-red-500/30 bg-red-500/15 text-red-300'
              }`}>
                {activationResult.success ? <Check className="h-4 w-4 flex-shrink-0 text-emerald-400" /> : <AlertCircle className="h-4 w-4 flex-shrink-0 text-red-400" />}
                <span>{activationResult.message}</span>
              </div>
            )}
          </form>

          <p className="mt-4 text-[11px] leading-relaxed text-zinc-500">
            Ключ активується один раз і прив'язується до вашого акаунта. Якщо ключ не приймається — зверніться до адміністратора.
          </p>
        </div>

        {/* Devices mini-list */}
        <div className="fc-card bg-[#090b14]/90 p-6 lg:col-span-2">
          <div className="fc-section-head mb-4">
            <div className="fc-section-icon"><Monitor className="h-5 w-5" /></div>
            <div>
              <h3>Мої ПК</h3>
              <p>{devices.length > 0 ? `${onlineCount} онлайн з ${devices.length}` : 'поки що немає'}</p>
            </div>
            <button
              onClick={() => onNavigate('/devices')}
              className="ml-auto flex-none text-[11px] font-bold text-indigo-300 transition-colors hover:text-white cursor-pointer"
            >
              Керувати
            </button>
          </div>

          {devices.length > 0 ? (
            <div className="space-y-2">
              {devices.slice(0, 5).map(d => (
                <button
                  key={d.id}
                  onClick={() => onNavigate('/devices')}
                  className="fc-card-static flex w-full cursor-pointer items-center gap-2.5 px-3 py-2.5 text-left transition hover:border-indigo-400/40"
                >
                  {d.isOnline
                    ? <Wifi className="h-3.5 w-3.5 flex-none text-emerald-400" />
                    : <WifiOff className="h-3.5 w-3.5 flex-none text-zinc-500" />}
                  <span className="min-w-0 flex-1 truncate text-xs font-bold text-white">{d.name}</span>
                  <span className="flex-none font-mono text-[10px] text-zinc-500">{d.code || d.id}</span>
                </button>
              ))}
            </div>
          ) : (
            <p className="py-2 text-xs leading-relaxed text-zinc-400">
              Прив'яжіть перший комп'ютер у вкладці «Пристрої» — він з'явиться тут.
            </p>
          )}
        </div>
      </div>

    </div>
  );
};
