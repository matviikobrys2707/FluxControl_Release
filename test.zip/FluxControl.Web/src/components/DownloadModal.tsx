import React, { useState } from 'react';
import { 
  Download, 
  X, 
  Check, 
  ShieldCheck, 
  Laptop, 
  HardDrive, 
  FileCode, 
  ExternalLink,
  Sparkles,
  AlertCircle
} from 'lucide-react';

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadModal: React.FC<DownloadModalProps> = ({ isOpen, onClose }) => {
  const [downloading, setDownloading] = useState(false);
  const [downloaded, setDownloaded] = useState(false);

  if (!isOpen) return null;

  const handleStartDownload = () => {
    setDownloading(true);
    // Trigger download of client executable stub
    const element = document.createElement('a');
    const content = `[FluxControl Desktop Client Stub]\nVersion=1.4.2\nPlatform=win64\nServerRelay=wss://fluxcontrol-backend.onrender.com/ws\nNotice=Run this executable on your PC to generate your unique connection code.`;
    const file = new Blob([content], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = 'Flux control.exe';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);

    setTimeout(() => {
      setDownloading(false);
      setDownloaded(true);
      setTimeout(() => setDownloaded(false), 5000);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="glass-panel w-full max-w-lg rounded-3xl p-6 sm:p-8 border border-white/15 bg-[#090b14] shadow-2xl relative space-y-6">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-indigo-600/20 border border-indigo-500/30 rounded-2xl text-indigo-300">
              <Laptop className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg sm:text-xl font-black text-white">
                Завантажити Flux control.exe
              </h3>
              <p className="text-xs text-indigo-300/80 font-mono">
                Офіційний агент для Windows 10 / 11 (64-bit)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-white rounded-xl hover:bg-white/5 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Download file details card */}
        <div className="p-5 rounded-2xl bg-black/50 border border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <FileCode className="w-5 h-5 text-indigo-400" />
              <div>
                <span className="font-bold text-white text-sm">Flux control.exe</span>
                <span className="text-[11px] text-gray-400 block font-mono">Портативна версія v1.4.2</span>
              </div>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-400">18.4 МБ</span>
          </div>

          <div className="pt-2 border-t border-white/10 flex flex-wrap items-center gap-4 text-xs text-gray-400">
            <span className="flex items-center gap-1.5 text-emerald-400">
              <ShieldCheck className="w-4 h-4" />
              <span>Перевірено на віруси</span>
            </span>
            <span>•</span>
            <span>Без встановлення (Standalone)</span>
          </div>
        </div>

        {/* Setup steps overview */}
        <div className="space-y-2 text-xs text-gray-300">
          <p className="font-bold text-white mb-1 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>Як запустити:</span>
          </p>
          <div className="space-y-1.5 pl-2 border-l-2 border-indigo-500/30">
            <p>1. Збережіть файл <span className="text-indigo-300 font-semibold font-mono">Flux control.exe</span> на комп'ютер.</p>
            <p>2. Запустіть програму — у вікні згенерується ваш унікальний код.</p>
            <p>3. Введіть цей код на вкладці <span className="text-white font-semibold">«Пристрої»</span> для миттєвого доступу.</p>
          </div>
        </div>

        {downloaded && (
          <div className="p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-emerald-300 text-xs flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>Файл завантажено! Запустіть його на вашому комп'ютері.</span>
          </div>
        )}

        {/* Action button */}
        <div className="flex items-center gap-3 pt-2">
          <button
            onClick={onClose}
            className="px-5 py-3 text-xs font-semibold text-gray-400 hover:text-white transition-colors cursor-pointer"
          >
            Закрити
          </button>

          <button
            id="modal-confirm-download-btn"
            onClick={handleStartDownload}
            disabled={downloading}
            className="flex-1 flex items-center justify-center gap-2 py-3 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white rounded-2xl font-black text-xs transition-all shadow-xl shadow-indigo-600/30 cursor-pointer disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>{downloading ? 'Підготовка файлу...' : 'Завантажити Flux control.exe'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
