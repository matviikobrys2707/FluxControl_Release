import React, { useState, useEffect, useCallback } from 'react';
import {
  Shield,
  Key,
  Plus,
  Trash2,
  Copy,
  Check,
  Users,
  Sparkles,
  Search,
  AlertCircle,
  RefreshCw,
  Crown,
  Monitor,
  Settings2,
  Wifi,
  WifiOff,
  CalendarClock,
  ShieldOff,
  ShieldCheck,
  Loader2
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { LicenseKey, AppRoute } from '../types';
import { ConfirmDialog } from './ConfirmDialog';
import { toast } from '../utils/toast';

interface AdminPageProps {
  onNavigate: (route: AppRoute) => void;
}

const API_BASE = 'https://fluxcontrol-backend.onrender.com';

/** fetch із заголовком адміна: спочатку Render, потім локальний фолбек. */
async function adminFetch(path: string, init?: RequestInit): Promise<any> {
  const user = JSON.parse(localStorage.getItem('fluxcontrol_user') || 'null');
  const headers: Record<string, string> = { 'Content-Type': 'application/json', ...(init?.headers as any || {}) };
  if (user?.id) headers['x-fc-user-id'] = user.id;

  let res = await fetch(`${API_BASE}${path}`, { ...init, headers }).catch(() => null);
  if (!res || !res.ok) {
    res = await fetch(path, { ...init, headers }).catch(() => null);
  }
  if (!res) throw new Error('Сервер недоступний');
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new Error(data?.error || data?.message || `HTTP ${res.status}`);
  return data;
}

const SUB_PRESETS = [
  { label: '7 днів', addDays: 7 },
  { label: '1 місяць', addDays: 30 },
  { label: '3 місяці', addDays: 90 },
  { label: '1 рік', addDays: 365 },
];

function fmtSub(v: any): string {
  if (v === -1) return 'Lifetime PRO';
  if (!v) return '—';
  const d = new Date(Number(v));
  if (isNaN(d.getTime())) return '—';
  return d.toLocaleString('uk-UA', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function toLocalInput(v: any): string {
  const n = Number(v);
  if (!n || n < 0 || isNaN(n)) return '';
  const d = new Date(n);
  const pad = (x: number) => String(x).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

export const AdminPage: React.FC<AdminPageProps> = ({ onNavigate }) => {
  const { user, isAdmin } = useAuth();

  const [keys, setKeys] = useState<LicenseKey[]>([]);
  const [usersList, setUsersList] = useState<any[]>([]);
  const [computers, setComputers] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'keys' | 'users' | 'pcs'>('keys');
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Generator form state
  const [durationType, setDurationType] = useState<string>('30d');
  const [keyCount, setKeyCount] = useState<number>(1);
  const [customLabel, setCustomLabel] = useState('');
  const [generatedKeys, setGeneratedKeys] = useState<LicenseKey[]>([]);
  const [keyToDelete, setKeyToDelete] = useState<LicenseKey | null>(null);

  // User edit modal state
  const [editUser, setEditUser] = useState<any | null>(null);
  const [editRole, setEditRole] = useState<'user' | 'admin'>('user');
  const [editAccess, setEditAccess] = useState<boolean>(true);
  const [editSubMode, setEditSubMode] = useState<'keep' | 'preset' | 'exact' | 'clear' | 'lifetime'>('keep');
  const [editPreset, setEditPreset] = useState<number>(30);
  const [editExact, setEditExact] = useState<string>('');
  const [editBusy, setEditBusy] = useState(false);
  const [userToDelete, setUserToDelete] = useState<any | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const [k, u, c] = await Promise.allSettled([
        adminFetch('/api/admin/keys'),
        adminFetch('/api/admin/users'),
        adminFetch('/api/admin/computers')
      ]);
      if (k.status === 'fulfilled' && Array.isArray(k.value?.keys)) setKeys(k.value.keys);
      if (u.status === 'fulfilled' && Array.isArray(u.value?.users)) setUsersList(u.value.users);
      if (c.status === 'fulfilled' && Array.isArray(c.value?.computers)) setComputers(c.value.computers);
    } catch (e) {
      console.error('[Admin] Fetch error:', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (isAdmin) refresh();
  }, [isAdmin, refresh]);

  const handleGenerateKey = async (e: React.FormEvent) => {
    e.preventDefault();
    setGenerating(true);
    try {
      const data = await adminFetch('/api/admin/keys/generate', {
        method: 'POST',
        body: JSON.stringify({
          durationType,
          count: Math.min(Math.max(Number(keyCount) || 1, 1), 50),
          customLabel: customLabel.trim(),
          createdBy: user?.email || 'admin'
        })
      });
      if (data?.success && Array.isArray(data.keys)) {
        setGeneratedKeys(data.keys);
        setKeys(prev => [...data.keys, ...prev]);
        setCustomLabel('');
        toast.success(`${data.keys.length} шт. · ${data.keys[0]?.keyCode || ''}`, { title: 'Ключі згенеровано' });
      }
    } catch (e: any) {
      toast.error(e?.message || '', { title: 'Генерація не вдалася' });
    } finally {
      setGenerating(false);
    }
  };

  const handleDeleteKey = async (id: string) => {
    setKeys(prev => prev.filter(k => k.id !== id));
    try {
      await adminFetch(`/api/admin/keys/${id}`, { method: 'DELETE' });
    } catch {}
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).catch(() => {});
    setCopiedKey(text);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  // ================= User edit =================
  const openEdit = (u: any) => {
    setEditUser(u);
    setEditRole(u.role === 'admin' ? 'admin' : 'user');
    setEditAccess(u.accessEnabled !== false);
    setEditSubMode('keep');
    setEditPreset(30);
    setEditExact(toLocalInput(u.subscriptionExpiresAt));
  };

  const saveEdit = async () => {
    if (!editUser) return;
    setEditBusy(true);
    try {
      const payload: any = { userId: editUser.id, role: editRole, accessEnabled: editAccess };
      if (editSubMode === 'preset') payload.addDays = Number(editPreset) || 0;
      if (editSubMode === 'exact') {
        const t = new Date(editExact).getTime();
        if (isNaN(t)) {
          toast.error('Виберіть коректну дату і час завершення', { title: 'Невірна дата' });
          setEditBusy(false);
          return;
        }
        payload.subscriptionExpiresAt = t;
      }
      if (editSubMode === 'clear') payload.subscriptionExpiresAt = null;
      if (editSubMode === 'lifetime') payload.subscriptionExpiresAt = -1;

      const data = await adminFetch('/api/admin/users/update', { method: 'POST', body: JSON.stringify(payload) });
      if (data?.success && data.user) {
        setUsersList(prev => prev.map(u => u.id === data.user.id ? { ...u, ...data.user } : u));
        toast.success(String(data.user.email || data.user.name || ''), { title: 'Користувача оновлено' });
        setEditUser(null);
      }
    } catch (e: any) {
      toast.error(e?.message || '', { title: 'Не вдалося зберегти' });
    } finally {
      setEditBusy(false);
    }
  };

  const handleDeleteUser = async (u: any) => {
    try {
      await adminFetch(`/api/admin/users/${u.id}`, { method: 'DELETE' });
      setUsersList(prev => prev.filter(x => x.id !== u.id));
      toast.success('Готово', { title: 'Користувача видалено' });
    } catch (e: any) {
      toast.error(e?.message || '', { title: 'Видалення не вдалося' });
    }
  };

  const quickToggleAccess = async (u: any) => {
    const next = u.accessEnabled === false;
    setUsersList(prev => prev.map(x => x.id === u.id ? { ...x, accessEnabled: next } : x));
    try {
      await adminFetch('/api/admin/users/update', { method: 'POST', body: JSON.stringify({ userId: u.id, accessEnabled: next }) });
      toast.success(u.email || u.name, { title: next ? 'Доступ відкрито' : 'Доступ закрито' });
    } catch (e: any) {
      setUsersList(prev => prev.map(x => x.id === u.id ? { ...x, accessEnabled: !next } : x));
      toast.error(e?.message || '', { title: 'Помилка' });
    }
  };

  if (!isAdmin) {
    return (
      <div className="max-w-md mx-auto px-4 pt-36 pb-20 text-center">
        <div className="glass-card rounded-3xl p-8 border border-red-500/20 bg-[#090b14]/90">
          <div className="w-16 h-16 bg-red-500/20 border border-red-500/30 rounded-3xl flex items-center justify-center text-red-400 mx-auto mb-4">
            <AlertCircle className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-white mb-2">Доступ обмежено</h2>
          <p className="text-xs text-gray-400 mb-6">
            Ця сторінка доступна лише для користувачів із правами адміністратора.
          </p>
          <button
            onClick={() => onNavigate('/')}
            className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-bold text-xs cursor-pointer"
          >
            Повернутися на головну
          </button>
        </div>
      </div>
    );
  }

  const formatDurationName = (type: string) => {
    switch (type) {
      case '1m': return '1 хвилина (Тест)';
      case '5m': return '5 хвилин';
      case '1h': return '1 година';
      case '1d': return '1 день';
      case '7d': return '7 днів (1 тиждень)';
      case '30d': return '30 днів (1 місяць)';
      case '90d': return '90 днів (3 місяці)';
      case '1y': return '1 рік (365 днів)';
      case 'lifetime': return 'Назавжди (Безстроково)';
      default: return type;
    }
  };

  const filteredKeys = keys.filter(k =>
    k.keyCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (k.customLabel && k.customLabel.toLowerCase().includes(searchQuery.toLowerCase())) ||
    (k.usedByEmail && k.usedByEmail.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const filteredUsers = usersList.filter(u =>
    (u.name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (u.email || '').toLowerCase().includes(searchQuery.toLowerCase())
  );

  const now = Date.now();
  const stats = {
    users: usersList.length,
    admins: usersList.filter(u => u.role === 'admin').length,
    activeSubs: usersList.filter(u => u.role === 'admin' || u.subscriptionExpiresAt === -1 || (Number(u.subscriptionExpiresAt) > now)).length,
    blocked: usersList.filter(u => u.accessEnabled === false).length,
    pcs: computers.length,
    pcsOnline: computers.filter(c => c.isOnline).length,
    keysFree: keys.filter(k => !k.isUsed).length
  };

  return (
    <div className="max-w-6xl mx-auto px-4 pt-32 pb-24 w-full animate-in fade-in duration-300">

      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/20 to-purple-500/20 border border-amber-500/30 text-amber-300 text-xs font-bold mb-2">
            <Crown className="w-3.5 h-3.5 text-amber-400" />
            <span>Панель Адміністратора FluxControl</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            Повне керування сервісом
          </h1>
          <p className="text-xs sm:text-sm text-gray-400 mt-1">
            Користувачі, підписки до секунди, доступи, ключі та всі комп&apos;ютери — в одному місці.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 p-1.5 bg-black/60 border border-white/10 rounded-2xl">
          {([
            { id: 'keys', icon: <Key className="w-4 h-4" />, label: `Ключі (${keys.length})` },
            { id: 'users', icon: <Users className="w-4 h-4" />, label: `Користувачі (${usersList.length})` },
            { id: 'pcs', icon: <Monitor className="w-4 h-4" />, label: `ПК (${computers.length})` },
          ] as const).map(t => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id)}
              className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === t.id
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              {t.icon}
              <span>{t.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Stats strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5 mb-8">
        {[
          { label: 'Користувачів', value: stats.users, icon: <Users className="w-3.5 h-3.5" /> },
          { label: 'Адмінів', value: stats.admins, icon: <Crown className="w-3.5 h-3.5" /> },
          { label: 'Активних підписок', value: stats.activeSubs, icon: <ShieldCheck className="w-3.5 h-3.5" /> },
          { label: 'Без доступу', value: stats.blocked, icon: <ShieldOff className="w-3.5 h-3.5" /> },
          { label: 'Комп’ютерів', value: stats.pcs, icon: <Monitor className="w-3.5 h-3.5" /> },
          { label: 'Онлайн зараз', value: stats.pcsOnline, icon: <Wifi className="w-3.5 h-3.5" /> },
          { label: 'Вільних ключів', value: stats.keysFree, icon: <Key className="w-3.5 h-3.5" /> },
        ].map(s => (
          <div key={s.label} className="glass-card rounded-2xl border border-white/10 bg-[#090b14]/80 px-3 py-3 min-w-0">
            <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide text-gray-400 truncate">{s.icon}{s.label}</p>
            <p className="text-lg font-black text-white mt-0.5">{s.value}</p>
          </div>
        ))}
      </div>

      {/* ======================= KEYS TAB ======================= */}
      {activeTab === 'keys' && (
        <div className="space-y-8">

          {/* Key Generator Card */}
          <div className="glass-card rounded-3xl p-6 sm:p-8 border border-white/15 bg-gradient-to-br from-[#0d0d1a] to-[#07070f] relative overflow-hidden shadow-2xl">
            <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

            <div className="flex items-center gap-3 mb-6">
              <div className="p-2.5 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 text-indigo-400">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-bold text-white">Генератор ліцензійних ключів</h3>
                <p className="text-xs text-gray-400">Ключ відкриває підписку та доступ до функціоналу після активації</p>
              </div>
            </div>

            <form onSubmit={handleGenerateKey} className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">Термін дії підписки</label>
                <select
                  value={durationType}
                  onChange={(e) => setDurationType(e.target.value)}
                  className="w-full bg-black/70 border border-white/10 focus:border-indigo-500 rounded-2xl px-4 py-3 text-xs sm:text-sm text-white focus:outline-none transition-colors"
                >
                  <option value="1m">1 хвилина (Для швидкого тесту)</option>
                  <option value="5m">5 хвилин</option>
                  <option value="1h">1 година</option>
                  <option value="1d">1 день</option>
                  <option value="7d">7 днів (1 тиждень)</option>
                  <option value="30d">30 днів (1 місяць)</option>
                  <option value="90d">90 днів (3 місяці)</option>
                  <option value="1y">1 рік (365 днів)</option>
                  <option value="lifetime">Назавжди (Lifetime PRO)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">Кількість ключів</label>
                <input
                  type="number"
                  min={1}
                  max={50}
                  value={keyCount}
                  onChange={(e) => setKeyCount(Number(e.target.value))}
                  className="w-full bg-black/70 border border-white/10 focus:border-indigo-500 rounded-2xl px-4 py-3 text-xs sm:text-sm text-white focus:outline-none transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1.5">
                  Мітка / Коментар (необов'язково)
                </label>
                <input
                  type="text"
                  value={customLabel}
                  onChange={(e) => setCustomLabel(e.target.value)}
                  placeholder="Наприклад: Для друга, Promo-2026..."
                  className="w-full bg-black/70 border border-white/10 focus:border-indigo-500 rounded-2xl px-4 py-3 text-xs sm:text-sm text-white placeholder:text-gray-600 focus:outline-none transition-colors"
                />
              </div>

              <div className="flex items-end">
                <button
                  type="submit"
                  disabled={generating}
                  className="w-full py-3 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 active:scale-[0.98] text-white rounded-2xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 transition-all cursor-pointer disabled:opacity-50"
                >
                  {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                  <span>{generating ? 'Генерація...' : 'Згенерувати'}</span>
                </button>
              </div>
            </form>

            {/* Newly Generated Keys banner */}
            {generatedKeys.length > 0 && (
              <div className="mt-6 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 animate-in slide-in-from-top-2">
                <div className="flex items-center gap-2 mb-2.5">
                  <Check className="w-4 h-4 text-emerald-400" />
                  <p className="text-xs text-emerald-300 font-semibold">Згенеровано {generatedKeys.length} ключ(ів):</p>
                </div>
                <div className="space-y-1.5 max-h-40 overflow-y-auto">
                  {generatedKeys.map(k => (
                    <div key={k.id} className="flex items-center justify-between gap-3 rounded-xl bg-black/40 px-3 py-2">
                      <span className="font-mono text-sm font-black text-white tracking-widest">{k.keyCode}</span>
                      <div className="flex items-center gap-2">
                        <span className="hidden sm:inline text-[10px] text-gray-400">{formatDurationName(k.durationType)}</span>
                        <button
                          onClick={() => copyToClipboard(k.keyCode)}
                          className="p-1 text-gray-400 hover:text-white rounded hover:bg-white/10 transition-colors cursor-pointer"
                          title="Скопіювати"
                        >
                          {copiedKey === k.keyCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Keys Table & Filter */}
          <div className="glass-card rounded-3xl p-6 sm:p-8 border border-white/10 bg-[#090b14]/80">

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
              <div className="flex items-center gap-2">
                <Key className="w-5 h-5 text-indigo-400" />
                <h3 className="text-base font-bold text-white">Список згенерованих ключів</h3>
              </div>

              <div className="flex items-center gap-3">
                <div className="relative w-full sm:w-64">
                  <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Пошук ключа або пошти..."
                    className="w-full bg-black/60 border border-white/10 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder:text-gray-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <button
                  onClick={refresh}
                  className="p-2 bg-white/5 hover:bg-white/10 rounded-xl border border-white/10 text-gray-300 hover:text-white transition-colors cursor-pointer"
                  title="Оновити список"
                >
                  <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                </button>
              </div>
            </div>

            {filteredKeys.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-white/10 text-[11px] font-semibold text-gray-400 uppercase tracking-wider">
                      <th className="py-3 px-4">Ключ ліцензії</th>
                      <th className="py-3 px-4">Термін дії</th>
                      <th className="py-3 px-4">Мітка</th>
                      <th className="py-3 px-4">Статус</th>
                      <th className="py-3 px-4">Ким використано</th>
                      <th className="py-3 px-4 text-right">Дії</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-xs">
                    {filteredKeys.map((k) => (
                      <tr key={k.id} className="hover:bg-white/[0.02] transition-colors">
                        <td className="py-3.5 px-4 font-mono font-bold text-white tracking-wider">
                          <span className="flex items-center gap-2">
                            <span>{k.keyCode}</span>
                            <button
                              onClick={() => copyToClipboard(k.keyCode)}
                              className="p-1 text-gray-400 hover:text-white rounded hover:bg-white/10 transition-colors"
                              title="Скопіювати"
                            >
                              {copiedKey === k.keyCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                            </button>
                          </span>
                        </td>

                        <td className="py-3.5 px-4 text-gray-300">
                          {formatDurationName(k.durationType)}
                        </td>

                        <td className="py-3.5 px-4 text-gray-400">
                          {k.customLabel || '—'}
                        </td>

                        <td className="py-3.5 px-4">
                          {k.isUsed ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-[11px] font-semibold">
                              Використано
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[11px] font-semibold">
                              Активний
                            </span>
                          )}
                        </td>

                        <td className="py-3.5 px-4 text-gray-300 font-mono text-[11px]">
                          {k.usedByEmail || k.usedBy || '—'}
                        </td>

                        <td className="py-3.5 px-4 text-right">
                          <button
                            onClick={() => setKeyToDelete(k)}
                            className="p-1.5 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-colors cursor-pointer"
                            title="Видалити ключ"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="py-12 text-center text-gray-400 text-xs">
                {searchQuery ? 'Ключів за вашим запитом не знайдено' : 'Ще не згенеровано жодного ключа. Створіть перший ключ вище!'}
              </div>
            )}

          </div>

        </div>
      )}

      {/* ======================= USERS TAB ======================= */}
      {activeTab === 'users' && (
        <div className="glass-card rounded-3xl p-6 sm:p-8 border border-white/10 bg-[#090b14]/80">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-indigo-400" />
              <h3 className="text-base font-bold text-white">Усі зареєстровані користувачі</h3>
            </div>
            <div className="flex items-center gap-3">
              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Пошук за ім'ям або поштою..."
                  className="w-full bg-black/60 border border-white/10 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder:text-gray-500 focus:outline-none focus:border-indigo-500"
                />
              </div>
              <button
                onClick={refresh}
                className="p-2 bg-white/5 hover:bg-white/10 rounded-xl border border-white/10 text-gray-300 hover:text-white transition-colors cursor-pointer"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-white/10 text-[11px] font-semibold text-gray-400 uppercase tracking-wider">
                  <th className="py-3 px-4">Користувач</th>
                  <th className="py-3 px-4">Роль</th>
                  <th className="py-3 px-4">Доступ</th>
                  <th className="py-3 px-4">Підписка (до секунди)</th>
                  <th className="py-3 px-4 text-right">Керування</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-xs">
                {filteredUsers.map((u) => {
                  const isUserAdmin = u.role === 'admin';
                  const isSubActive = isUserAdmin || u.subscriptionExpiresAt === -1 || (Number(u.subscriptionExpiresAt) > now);
                  const accessOn = u.accessEnabled !== false;

                  return (
                    <tr key={u.id} className="hover:bg-white/[0.02] transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full bg-indigo-600/30 overflow-hidden flex items-center justify-center text-xs text-indigo-300 flex-shrink-0">
                            {u.picture ? (
                              <img src={u.picture} alt="" className="w-full h-full object-cover" />
                            ) : (
                              u.name?.charAt(0) || 'U'
                            )}
                          </div>
                          <div className="min-w-0">
                            <p className="font-bold text-white truncate">{u.name}</p>
                            <p className="font-mono text-[10px] text-gray-500 truncate">{u.email || '—'}</p>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        {isUserAdmin ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[11px] font-bold">
                            <Crown className="w-3 h-3" />
                            <span>Адмін</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white/10 text-gray-300 text-[11px] font-semibold">
                            Користувач
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4">
                        <button
                          onClick={() => quickToggleAccess(u)}
                          className={`inline-flex cursor-pointer items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold border transition-all ${
                            accessOn
                              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20'
                              : 'bg-red-500/10 border-red-500/30 text-red-400 hover:bg-red-500/20'
                          }`}
                          title={accessOn ? 'Забрати доступ' : 'Відкрити доступ'}
                        >
                          {accessOn ? <ShieldCheck className="w-3 h-3" /> : <ShieldOff className="w-3 h-3" />}
                          <span>{accessOn ? 'Відкрито' : 'Заблокований'}</span>
                        </button>
                      </td>

                      <td className="py-3.5 px-4">
                        {isSubActive ? (
                          <span className="flex items-center gap-1.5 text-emerald-400 font-semibold text-[11px]">
                            <Check className="w-3.5 h-3.5 shrink-0" />
                            <span>{fmtSub(u.subscriptionExpiresAt)}</span>
                          </span>
                        ) : (
                          <span className="text-gray-500 text-[11px]">
                            Немає активної підписки
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => openEdit(u)}
                          className="inline-flex cursor-pointer items-center gap-1.5 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/40 border border-indigo-500/30 text-indigo-200 hover:text-white px-3 py-1.5 text-[11px] font-bold transition-colors"
                        >
                          <Settings2 className="w-3.5 h-3.5" />
                          <span>Керувати</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ======================= PCs TAB ======================= */}
      {activeTab === 'pcs' && (
        <div className="glass-card rounded-3xl p-6 sm:p-8 border border-white/10 bg-[#090b14]/80">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Monitor className="w-5 h-5 text-indigo-400" />
              <h3 className="text-base font-bold text-white">Усі комп&apos;ютери в базі</h3>
            </div>
            <button
              onClick={refresh}
              className="p-2 bg-white/5 hover:bg-white/10 rounded-xl border border-white/10 text-gray-300 hover:text-white transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>

          {computers.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {computers.map((c) => (
                <div key={c.id} className="rounded-2xl border border-white/10 bg-black/40 p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className={`p-2 rounded-xl border ${c.isOnline ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-white/5 border-white/10 text-gray-500'}`}>
                        <Monitor className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-[13px] font-bold text-white truncate">{c.name || 'Без назви'}</p>
                        <p className="font-mono text-[10px] text-gray-500 truncate">{c.code || c.hwid}</p>
                      </div>
                    </div>
                    <span className={`flex items-center gap-1 text-[10px] font-bold px-2 py-1 rounded-lg border flex-shrink-0 ${
                      c.isOnline
                        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                        : 'bg-gray-500/10 border-gray-500/30 text-gray-400'
                    }`}>
                      {c.isOnline ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
                      {c.isOnline ? 'Онлайн' : 'Офлайн'}
                    </span>
                  </div>
                  <div className="mt-3 space-y-1 text-[10.5px] text-gray-400 font-mono">
                    <p className="truncate">OS: {c.os || '—'}</p>
                    <p className="truncate">CPU: {c.cpu || '—'}</p>
                    <p className="truncate">GPU: {c.gpu || '—'}</p>
                    <p className="truncate">RAM: {c.ram || '—'}</p>
                    <p className="truncate">Власників: {c.ownerIds?.length || 0}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-12 text-center text-gray-400 text-xs">Комп&apos;ютерів поки немає</div>
          )}
        </div>
      )}

      {/* ======================= USER EDIT MODAL ======================= */}
      {editUser && (
        <div className="fixed inset-0 z-[10060] flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm p-3 sm:p-6" onClick={() => !editBusy && setEditUser(null)}>
          <div
            className="w-full max-w-lg max-h-[90vh] overflow-y-auto fcx-scroll rounded-3xl border border-indigo-500/25 bg-[#0b0d18] p-6 shadow-2xl animate-in fade-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3 mb-5">
              <div className="w-11 h-11 rounded-2xl bg-indigo-600/25 border border-indigo-500/30 overflow-hidden flex items-center justify-center text-indigo-200 font-black">
                {editUser.picture ? <img src={editUser.picture} alt="" className="w-full h-full object-cover" /> : (editUser.name?.charAt(0) || 'U')}
              </div>
              <div className="min-w-0">
                <p className="text-sm font-black text-white truncate">{editUser.name}</p>
                <p className="text-[11px] font-mono text-gray-500 truncate">{editUser.email}</p>
              </div>
            </div>

            {/* Роль */}
            <p className="text-[10.5px] font-black uppercase tracking-wide text-gray-400 mb-2">Роль</p>
            <div className="grid grid-cols-2 gap-2 mb-5">
              <button
                onClick={() => setEditRole('user')}
                className={`cursor-pointer rounded-2xl border px-3 py-2.5 text-xs font-bold transition-all ${
                  editRole === 'user' ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-white/5 border-white/10 text-gray-400 hover:text-white'
                }`}
              >
                <Users className="mx-auto mb-1 h-4 w-4" />
                Користувач
              </button>
              <button
                onClick={() => setEditRole('admin')}
                className={`cursor-pointer rounded-2xl border px-3 py-2.5 text-xs font-bold transition-all ${
                  editRole === 'admin' ? 'bg-gradient-to-r from-amber-500 to-purple-600 border-amber-400 text-white' : 'bg-white/5 border-white/10 text-gray-400 hover:text-white'
                }`}
              >
                <Crown className="mx-auto mb-1 h-4 w-4 text-amber-300" />
                Адміністратор
              </button>
            </div>

            {/* Доступ */}
            <p className="text-[10.5px] font-black uppercase tracking-wide text-gray-400 mb-2">Доступ до функціоналу</p>
            <div className="grid grid-cols-2 gap-2 mb-5">
              <button
                onClick={() => setEditAccess(true)}
                className={`flex cursor-pointer items-center justify-center gap-2 rounded-2xl border px-3 py-2.5 text-xs font-bold transition-all ${
                  editAccess ? 'bg-emerald-600/25 border-emerald-500/40 text-emerald-300' : 'bg-white/5 border-white/10 text-gray-400 hover:text-white'
                }`}
              >
                <ShieldCheck className="h-4 w-4" /> Відкрито
              </button>
              <button
                onClick={() => setEditAccess(false)}
                className={`flex cursor-pointer items-center justify-center gap-2 rounded-2xl border px-3 py-2.5 text-xs font-bold transition-all ${
                  !editAccess ? 'bg-red-600/25 border-red-500/40 text-red-300' : 'bg-white/5 border-white/10 text-gray-400 hover:text-white'
                }`}
              >
                <ShieldOff className="h-4 w-4" /> Заблокований
              </button>
            </div>

            {/* Підписка */}
            <p className="text-[10.5px] font-black uppercase tracking-wide text-gray-400 mb-2">Підписка</p>
            <div className="rounded-2xl border border-white/10 bg-black/40 p-3.5 space-y-3">
              <div className="flex flex-wrap gap-1.5">
                {([
                  { id: 'keep', label: 'Не змінювати' },
                  { id: 'preset', label: '+ період' },
                  { id: 'exact', label: 'До секунди' },
                  { id: 'lifetime', label: 'Lifetime' },
                  { id: 'clear', label: 'Забрати' },
                ] as const).map(m => (
                  <button
                    key={m.id}
                    onClick={() => setEditSubMode(m.id)}
                    className={`cursor-pointer rounded-xl px-3 py-1.5 text-[11px] font-bold border transition-all ${
                      editSubMode === m.id ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-white/5 border-white/10 text-gray-400 hover:text-white'
                    }`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>

              {editSubMode === 'keep' && (
                <p className="text-[11px] text-gray-500">Зараз: <span className="font-bold text-gray-300">{fmtSub(editUser.subscriptionExpiresAt)}</span></p>
              )}

              {editSubMode === 'preset' && (
                <div className="grid grid-cols-4 gap-1.5">
                  {SUB_PRESETS.map(p => (
                    <button
                      key={p.addDays}
                      onClick={() => setEditPreset(p.addDays)}
                      className={`cursor-pointer rounded-xl border px-2 py-2 text-[10.5px] font-bold transition-all ${
                        editPreset === p.addDays ? 'bg-violet-600 border-violet-500 text-white' : 'bg-white/5 border-white/10 text-gray-300 hover:text-white'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              )}

              {editSubMode === 'exact' && (
                <div>
                  <label className="mb-1 flex items-center gap-1.5 text-[10.5px] font-semibold text-gray-400">
                    <CalendarClock className="h-3.5 w-3.5" />
                    Точна дата і час завершення (до секунди)
                  </label>
                  <input
                    type="datetime-local"
                    step="1"
                    value={editExact}
                    onChange={(e) => setEditExact(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-black/70 px-3.5 py-2.5 text-xs text-white focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              )}

              {editSubMode === 'lifetime' && (
                <p className="text-[11px] text-gray-500">Безстрокова PRO-підписка (ніколи не завершується).</p>
              )}

              {editSubMode === 'clear' && (
                <p className="text-[11px] text-gray-500">Підписку буде прибрано повністю.</p>
              )}
            </div>

            <div className="mt-6 flex items-center gap-2.5">
              <button
                onClick={() => setUserToDelete(editUser)}
                disabled={editBusy}
                className="flex cursor-pointer items-center justify-center gap-1.5 rounded-2xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-xs font-bold text-red-300 transition-colors hover:bg-red-500/20 disabled:opacity-40"
              >
                <Trash2 className="h-3.5 w-3.5" />
                Видалити акаунт
              </button>
              <span className="flex-1" />
              <button
                onClick={() => setEditUser(null)}
                disabled={editBusy}
                className="cursor-pointer rounded-2xl bg-white/5 px-4 py-3 text-xs font-bold text-gray-300 transition-colors hover:bg-white/10 disabled:opacity-40"
              >
                Скасувати
              </button>
              <button
                onClick={saveEdit}
                disabled={editBusy}
                className="flex cursor-pointer items-center gap-1.5 rounded-2xl bg-gradient-to-r from-indigo-600 to-violet-600 px-5 py-3 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 transition-all hover:brightness-110 disabled:opacity-50"
              >
                {editBusy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
                Зберегти
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Key Confirmation */}
      <ConfirmDialog
        isOpen={Boolean(keyToDelete)}
        title="Видалити ключ?"
        message={keyToDelete ? `Ключ ${keyToDelete.keyCode} буде видалено/анулюовано. Цю дію неможливо скасувати.` : ''}
        confirmLabel="Видалити"
        onCancel={() => setKeyToDelete(null)}
        onConfirm={() => {
          if (keyToDelete) handleDeleteKey(keyToDelete.id);
          setKeyToDelete(null);
        }}
      />

      {/* Delete User Confirmation */}
      <ConfirmDialog
        isOpen={Boolean(userToDelete)}
        title="Видалити користувача?"
        message={userToDelete ? `Акаунт ${userToDelete.email || userToDelete.name} та всі прив'язки пристроїв буде видалено назавжди.` : ''}
        confirmLabel="Видалити назавжди"
        onCancel={() => setUserToDelete(null)}
        onConfirm={() => {
          if (userToDelete) handleDeleteUser(userToDelete);
          setUserToDelete(null);
          setEditUser(null);
        }}
      />

    </div>
  );
};
