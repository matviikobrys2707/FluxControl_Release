import React, { useEffect, useRef, useState } from 'react';
import {
  Zap,
  Copy,
  RefreshCw,
  QrCode,
  ExternalLink,
  Crown,
  Lock,
  Minus,
  X,
  LogOut,
  Sliders,
  LogIn,
  Download,
  AlertTriangle,
  Package,
  Loader2,
  ShieldCheck,
  Link2,
  Home,
  MonitorSmartphone,
  UserRound,
  KeyRound,
  BadgeCheck,
  MousePointerClick
} from 'lucide-react';
// The desktop window uses its OWN toast style — deliberately different from
// the website's toasts (bottom-right, gradient accent, branded).
import { agentToast as toast } from '../utils/agentToast';

type AgentTab = 'home' | 'settings' | 'account';

/** Сторонній контекст: WebView2-вікно FluxControl або звичайний браузер. */
const IS_HOSTED = Boolean((window as any).chrome?.webview);

type FfmpegState = {
  status: string; // checking | ready | missing | installing | error
  stage?: string;
  percent?: number;
  error?: string | null;
};

type HostUser = {
  id?: string;
  name?: string;
  email?: string;
  picture?: string;
  role?: string;
  subscriptionExpiresAt?: number;
};

type PairingRequestState = {
  requestId: string;
  deviceName: string;
  ip?: string;
} | null;

/** Hash routing gives every agent screen its own address, e.g. #/auth, #/settings. */
const readHashTab = (): AgentTab => {
  const hash = window.location.hash;
  if (hash === '#/settings') return 'settings';
  if (hash === '#/account') return 'account';
  return 'home';
};

/**
 * Agent v2 design system — fully self-contained (fcx-* prefix), mirrors the
 * website look (violet/black, rounded, glassy) but tuned for a 1000x640
 * desktop window: sidebar, hero code card, stat strip, calm animations.
 */
const AgentScopedStyle: React.FC = () => {
  React.useEffect(() => {
    if (IS_HOSTED) document.documentElement.classList.add('fcx-hosted');
    return () => document.documentElement.classList.remove('fcx-hosted');
  }, []);
  return (
  <style>{`
    .fcx-root { background:#050508; color:#f4f4f8; font-family:'Segoe UI Variable','Segoe UI',system-ui,-apple-system,sans-serif; }
    .fcx-glow { position:fixed; border-radius:9999px; filter:blur(120px); pointer-events:none; z-index:0; }
    .fcx-glow-a { top:-140px; left:12%; width:460px; height:300px; background:rgba(124,58,237,.13); }
    .fcx-glow-b { bottom:-160px; right:10%; width:420px; height:300px; background:rgba(79,70,229,.11); }

    /* ---------- HOSTED WINDOW (FluxControl.exe only) ----------
       The WPF window is OPAQUE (#05050A) and the OS rounds its corners
       (DWMWCP_ROUND on Win11, GDI region on Win10). The page therefore
       fills the window edge-to-edge — no padding, no shadows, no CSS
       chrome. Fixed overlays (QR, modals, toasts) are clipped by the
       window itself. */
    html.fcx-hosted, html.fcx-hosted body { background: #05050A !important; }
    html.fcx-hosted .fcx-root { background: #05050A !important; }

    @keyframes fcx-in { from { opacity:0; transform:translateY(10px); } to { opacity:1; transform:translateY(0); } }
    .fcx-in { animation:fcx-in .45s cubic-bezier(.16,1,.3,1) both; }

    /* Narrow window / mobile: the sidebar hides (Tailwind hidden md:flex) and a
       compact tab bar under the title bar takes over. The inline .fcx-side
       display:flex would beat .hidden in the cascade — force it off here. */
    @media (max-width: 767.9px) {
      .fcx-side { display: none !important; }
    }
    .fcx-in-1 { animation-delay:.05s; } .fcx-in-2 { animation-delay:.12s; }
    .fcx-in-3 { animation-delay:.19s; } .fcx-in-4 { animation-delay:.26s; }

    @keyframes fcx-ring { 0% { transform:scale(.9); opacity:.6; } 100% { transform:scale(1.75); opacity:0; } }
    .fcx-ring { position:absolute; inset:-6px; border-radius:30px; border:2px solid rgba(139,92,246,.45); animation:fcx-ring 2.1s ease-out infinite; pointer-events:none; }
    .fcx-ring-late { animation-delay:1.05s; }

    @keyframes fcx-spin { to { transform:rotate(360deg); } }
    .fcx-spin { animation:fcx-spin 1s linear infinite; }

    @keyframes fcx-dot { 0%,100% { opacity:.55; transform:scale(.85); } 50% { opacity:1; transform:scale(1.12); } }
    .fcx-dot-live { animation:fcx-dot 2s ease-in-out infinite; }

    @keyframes fcx-shimmer { 0% { transform:translateX(-100%); } 100% { transform:translateX(220%); } }
    .fcx-shimmer-wrap { position:relative; overflow:hidden; }
    .fcx-shimmer-wrap::after { content:''; position:absolute; top:0; bottom:0; width:34%;
      background:linear-gradient(90deg,transparent,rgba(255,255,255,.35),transparent); animation:fcx-shimmer 1.6s ease-in-out infinite; }

    /* ---------- title bar ---------- */
    .fcx-titlebar { height:46px; flex-shrink:0; display:flex; align-items:center; justify-content:space-between;
      padding-left:14px; padding-right:6px; border-bottom:1px solid rgba(255,255,255,.06);
      background:rgba(9,9,16,.6); position:relative; z-index:50; user-select:none; }
    .fcx-tb-btn { height:34px; width:42px; display:flex; align-items:center; justify-content:center; border:none;
      border-radius:10px; background:transparent; color:#8b8fa3; cursor:pointer; transition:.15s; }
    .fcx-tb-btn:hover { background:rgba(255,255,255,.08); color:#fff; }
    .fcx-tb-btn.close:hover { background:rgba(244,63,94,.16); color:#fda4af; }

    /* ---------- buttons ---------- */
    .fcx-btn { display:inline-flex; align-items:center; justify-content:center; gap:8px; height:38px; padding:0 16px;
      border-radius:12px; font-size:12.5px; font-weight:700; cursor:pointer; border:1px solid transparent;
      transition:filter .15s, background .15s, border-color .15s, transform .1s; user-select:none; white-space:nowrap; }
    .fcx-btn:active { transform:scale(.98); }
    .fcx-btn-primary { background:linear-gradient(135deg,#8b5cf6,#6366f1); color:#fff; box-shadow:0 8px 22px rgba(99,102,241,.28); }
    .fcx-btn-primary:hover { filter:brightness(1.14); }
    .fcx-btn-ghost { background:rgba(255,255,255,.045); border-color:rgba(255,255,255,.09); color:#d6d8e4; }
    .fcx-btn-ghost:hover { background:rgba(255,255,255,.09); color:#fff; border-color:rgba(255,255,255,.16); }
    .fcx-btn-danger { background:rgba(244,63,94,.10); border-color:rgba(244,63,94,.30); color:#fda4af; }
    .fcx-btn-danger:hover { background:rgba(244,63,94,.18); }
    .fcx-btn-sm { height:32px; padding:0 12px; font-size:11.5px; border-radius:10px; }
    .fcx-icon-btn { width:34px; height:34px; padding:0; display:inline-flex; align-items:center; justify-content:center;
      border-radius:10px; border:1px solid rgba(255,255,255,.09); background:rgba(255,255,255,.045);
      color:#c8cad8; cursor:pointer; transition:.15s; }
    .fcx-icon-btn:hover { background:rgba(255,255,255,.10); color:#fff; }

    /* ---------- surfaces ---------- */
    .fcx-card { background:rgba(255,255,255,.030); border:1px solid rgba(255,255,255,.08); border-radius:20px; }
    .fcx-card-hover { transition:border-color .2s, background .2s; }
    .fcx-card-hover:hover { border-color:rgba(139,92,246,.35); background:rgba(255,255,255,.045); }

    .fcx-eyebrow { font-size:10.5px; font-weight:800; letter-spacing:.12em; text-transform:uppercase; color:#8b8fa3; }

    .fcx-code { font-family:'Cascadia Code','JetBrains Mono',Consolas,monospace; font-weight:800;
      letter-spacing:.16em; background:linear-gradient(90deg,#c4b5fd,#a5b4fc);
      -webkit-background-clip:text; background-clip:text; color:transparent;
      text-shadow:0 0 34px rgba(139,92,246,.25); user-select:all; }

    .fcx-stat { display:flex; flex-direction:column; gap:5px; padding:13px 15px; border-radius:16px;
      background:rgba(255,255,255,.028); border:1px solid rgba(255,255,255,.075); min-width:0; }
    .fcx-stat-label { font-size:10.5px; font-weight:800; letter-spacing:.1em; text-transform:uppercase; color:#8b8fa3; }
    .fcx-stat-value { font-size:13px; font-weight:800; color:#f4f4f8; display:flex; align-items:center; gap:7px; min-width:0; }
    .fcx-stat-value .truncate { min-width:0; }

    .fcx-dot { width:8px; height:8px; border-radius:9999px; flex-shrink:0; }
    .fcx-dot-ok { background:#34d399; box-shadow:0 0 10px rgba(52,211,153,.7); }
    .fcx-dot-warn { background:#fbbf24; box-shadow:0 0 10px rgba(251,191,36,.55); }
    .fcx-dot-err { background:#fb7185; box-shadow:0 0 10px rgba(251,113,133,.55); }

    /* ---------- sidebar ---------- */
    .fcx-side { width:212px; flex-shrink:0; display:flex; flex-direction:column; justify-content:space-between;
      padding:14px 12px; border-right:1px solid rgba(255,255,255,.06); background:rgba(8,8,15,.45);
      position:relative; z-index:10; }
    .fcx-nav-btn { display:flex; align-items:center; gap:10px; width:100%; padding:10px 13px; border:none;
      border-radius:12px; background:transparent; color:#9aa0b4; font-size:12.5px; font-weight:700;
      cursor:pointer; transition:.15s; text-align:left; }
    .fcx-nav-btn:hover { background:rgba(255,255,255,.05); color:#fff; }
    .fcx-nav-btn.active { background:linear-gradient(135deg,rgba(139,92,246,.9),rgba(99,102,241,.9)); color:#fff;
      box-shadow:0 6px 18px rgba(99,102,241,.30); }

    .fcx-avatar { width:34px; height:34px; border-radius:11px; background:rgba(139,92,246,.25);
      border:1px solid rgba(139,92,246,.45); display:flex; align-items:center; justify-content:center;
      font-size:12.5px; font-weight:800; color:#fff; overflow:hidden; flex-shrink:0; }
    .fcx-avatar img { width:100%; height:100%; object-fit:cover; }

    .fcx-badge { display:inline-flex; align-items:center; gap:4px; padding:2.5px 8px; border-radius:9999px;
      font-size:10px; font-weight:800; border:1px solid; white-space:nowrap; }

    /* ---------- progress ---------- */
    .fcx-progress { height:8px; border-radius:9999px; background:rgba(255,255,255,.07); overflow:hidden; }
    .fcx-progress i { display:block; height:100%; border-radius:inherit;
      background:linear-gradient(90deg,#8b5cf6,#6366f1); transition:width .3s ease; }

    .fcx-scroll { scrollbar-width:thin; scrollbar-color:rgba(255,255,255,.14) transparent; }
    .fcx-scroll::-webkit-scrollbar { width:8px; }
    .fcx-scroll::-webkit-scrollbar-thumb { background:rgba(255,255,255,.14); border-radius:8px; }
    .fcx-scroll::-webkit-scrollbar-track { background:transparent; }
  `}</style>
  );
};

/** Бренд-знак FluxControl: той самий SVG, що на favicon та в трею
    (темна плитка + градієнтне кільце живлення + блискавка). */
const BrandMark: React.FC<{ size?: number }> = ({ size = 24 }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" aria-hidden="true">
    <defs>
      <linearGradient id="fcbm-ring" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor="#A78BFA" />
        <stop offset="0.55" stopColor="#7C3AED" />
        <stop offset="1" stopColor="#4F46E5" />
      </linearGradient>
      <linearGradient id="fcbm-bolt" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#FFFFFF" />
        <stop offset="1" stopColor="#E0E7FF" />
      </linearGradient>
    </defs>
    <rect x="24" y="24" width="464" height="464" rx="112" fill="#0B0A14" />
    <path d="M 326.4 123.6 A 150 150 0 1 1 185.6 123.6" fill="none" stroke="url(#fcbm-ring)" strokeWidth="42" strokeLinecap="round" />
    <g transform="translate(94,94) scale(13.5)">
      <path d="M13 2 L3 14 h9 l-1 8 L21 10 h-9 l1 -8 Z" fill="url(#fcbm-bolt)" />
    </g>
  </svg>
);

/** Оболонка вікна: тепер просто заповнює весь WebView edge-to-edge.
    Скруглення й тінь малює операційна система (DWM/регіон) — сторінка
    не малює жодного віконного хрому, тож артефактів бути не може. */
const WinShell: React.FC<{ maximized: boolean; children: React.ReactNode }> = ({ children }) => (
  <div style={{ height: '100vh', width: '100vw', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', background: '#05050A' }}>
    {children}
  </div>
);

// ================================================================
// TITLE BAR — the ONLY drag zone. Exactly two window buttons
// (Згорнути / Закрити), always enabled, always clickable, on every
// screen (splash, auth, installer, main). No maximize anywhere.
// ================================================================
type AgentTitleBarProps = {
  onDragStart: (e: React.MouseEvent) => void;
  onMinimize: () => void;
  onClose: () => void;
  trailing?: React.ReactNode;
};

const AgentTitleBar: React.FC<AgentTitleBarProps> = ({ onDragStart, onMinimize, onClose, trailing }) => (
  <div className="fcx-titlebar" onMouseDown={onDragStart}>
    <div className="flex items-center gap-2.5 min-w-0 pointer-events-none">
      <div className="flex-shrink-0 drop-shadow-lg shadow-indigo-600/30">
        <BrandMark size={26} />
      </div>
      <span className="text-[12.5px] font-extrabold tracking-tight text-gray-100 truncate">FluxControl</span>
    </div>

    <div className="flex items-center gap-1.5 flex-shrink-0" onMouseDown={(e) => e.stopPropagation()}>
      {trailing}
      <button type="button" onClick={onMinimize} title="Згорнути" aria-label="Згорнути" className="fcx-tb-btn">
        <Minus className="w-4 h-4" />
      </button>
      <button type="button" onClick={onClose} title="Закрити" aria-label="Закрити" className="fcx-tb-btn close">
        <X className="w-4 h-4" />
      </button>
    </div>
  </div>
);

// ================================================================
// SETTINGS TOGGLE — shared switch control
// ================================================================
const AgentToggle: React.FC<{ title: string; desc: string; enabled: boolean; onToggle: () => void }> = ({
  title,
  desc,
  enabled,
  onToggle,
}) => (
  <div className="flex items-center justify-between gap-4 py-3.5">
    <div className="min-w-0">
      <p className="text-[13px] font-bold text-white">{title}</p>
      <p className="text-[11.5px] text-gray-400 mt-0.5">{desc}</p>
    </div>
    <button
      type="button"
      role="switch"
      aria-checked={enabled}
      aria-label={title}
      onClick={onToggle}
      className={`w-[46px] h-[26px] rounded-full transition-colors relative flex-shrink-0 cursor-pointer border ${
        enabled ? 'bg-[#7c3aed] border-[#8b5cf6]' : 'bg-white/10 border-white/15'
      }`}
    >
      <span
        className={`absolute top-[3px] w-[18px] h-[18px] rounded-full bg-white shadow transition-all duration-200 ${
          enabled ? 'left-[24px]' : 'left-[3px]'
        }`}
      />
    </button>
  </div>
);

export const AgentHostedUiPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AgentTab>(readHashTab);
  const [loadingSplash, setLoadingSplash] = useState<boolean>(true);
  const [authChecked, setAuthChecked] = useState<boolean>(false);
  const [code, setCode] = useState<string>('');
  const [qrBase64, setQrBase64] = useState<string>('');
  const [relayStatus, setRelayStatus] = useState<string>('connecting');
  const [relayError, setRelayError] = useState<string | null>(null);
  const [connectedClients, setConnectedClients] = useState<number>(0);
  const [autoRun, setAutoRun] = useState<boolean>(true);
  const [minimizeToTray, setMinimizeToTray] = useState<boolean>(true);
  const [showQr, setShowQr] = useState<boolean>(true);
  const [showQrFull, setShowQrFull] = useState<boolean>(false);
  const [confirmRegen, setConfirmRegen] = useState<boolean>(false);

  // Account tab: license key activation
  const [keyCode, setKeyCode] = useState<string>('');
  const [keyBusy, setKeyBusy] = useState<boolean>(false);

  // FFmpeg dependency state pushed by the desktop host.
  const [ffmpeg, setFfmpeg] = useState<FfmpegState | null>(null);

  // Incoming pairing request (client wants to connect to this PC).
  const [pairing, setPairing] = useState<PairingRequestState>(null);

  // User & subscription info from the desktop session
  const [user, setUser] = useState<HostUser | null>(null);
  const [computerName, setComputerName] = useState<string>('');
  // версія застосунку, зашита в exe (приходить у стані від агента)
  const [appVersion, setAppVersion] = useState<string>('');

  // Round-window mode: the host tells us whether the window is maximized.
  const [winMax, setWinMax] = useState<boolean>(false);
  // Останній результат авто-speedtest (пінг/швидкість) з десктоп-хоста.
  const [speedTest, setSpeedTest] = useState<any>(null);
  // Попередній знімок юзера — для тоста «статус підписки оновлено».
  const prevUserRef = useRef<HostUser | null>(null);

  // ETA estimation for the FFmpeg download: (time, percent) samples.
  const installSamplesRef = useRef<{ t: number; p: number }[]>([]);
  const [etaText, setEtaText] = useState<string | null>(null);

  // ---------- Hash routing: each tab owns its own URL ----------
  useEffect(() => {
    const syncFromHash = () => {
      const hash = window.location.hash;
      if (hash === '#/settings') setActiveTab('settings');
      else if (hash === '#/account') setActiveTab('account');
      else if (hash === '#/home' || hash === '' || hash === '#') setActiveTab('home');
    };
    window.addEventListener('hashchange', syncFromHash);
    return () => window.removeEventListener('hashchange', syncFromHash);
  }, []);

  const switchTab = (tab: AgentTab) => {
    setActiveTab(tab);
    try {
      const hash = tab === 'settings' ? '#/settings' : tab === 'account' ? '#/account' : '#/home';
      window.history.replaceState(null, '', hash);
    } catch {
      /* noop */
    }
  };

  useEffect(() => {
    let gotFirstMessage = false;
    const splashTimer = setTimeout(() => {
      // The splash must never trap the user: it closes by itself after a few
      // seconds even if the host never answers.
      setLoadingSplash(false);
      setAuthChecked(true);
    }, 4500);

    const handleWebMessage = (event: any) => {
      try {
        const msg = event.data || (typeof event === 'string' ? JSON.parse(event) : event);
        if (!msg) return;

        if (!gotFirstMessage) {
          gotFirstMessage = true;
          setLoadingSplash(false);
          setAuthChecked(true);
          if (!window.location.hash) {
            try {
              window.history.replaceState(null, '', '#/home');
            } catch {
              /* noop */
            }
          }
        }

        // A client is asking for permission to connect to this PC.
        if (msg.type === 'pairing_request' && msg.requestId) {
          setPairing({
            requestId: String(msg.requestId),
            deviceName: String(msg.deviceName || 'Невідомий пристрій'),
            ip: msg.ip ? String(msg.ip) : undefined,
          });
          return;
        }

        if (msg.code || msg.deviceCode) setCode(msg.formattedCode || msg.code || msg.deviceCode);
        if (msg.qrBase64 || msg.qrCode) setQrBase64(msg.qrBase64 || msg.qrCode);
        if (msg.relayStatus) setRelayStatus(String(msg.relayStatus));
        if (msg.relayError !== undefined) setRelayError(msg.relayError ? String(msg.relayError) : null);
        if (msg.computerName) setComputerName(String(msg.computerName));
        if (msg.appVersion) setAppVersion(String(msg.appVersion));
        if (msg.activeClients !== undefined) setConnectedClients(Number(msg.activeClients) || 0);
        if (msg.autoRun !== undefined || msg.isAutoRun !== undefined) setAutoRun(Boolean(msg.autoRun ?? msg.isAutoRun));
        if (msg.minimizeToTray !== undefined) setMinimizeToTray(Boolean(msg.minimizeToTray));
        if (msg.user !== undefined) {
          const nextUser = (msg.user || null) as HostUser | null;
          // Автоматичне оновлення статусу підписки: хост опитує сервер кожні 20с.
          // Коли дані реально змінилися — показуємо тост (якщо вікно видно; коли
          // сховано — Windows-повідомлення показує сам хост, тут дубля не буде).
          const prev = prevUserRef.current;
          if (prev && nextUser && prev.id && nextUser.id && prev.id === nextUser.id) {
            const expChanged = prev.subscriptionExpiresAt !== nextUser.subscriptionExpiresAt;
            const roleChanged = prev.role !== nextUser.role;
            if (expChanged || roleChanged) {
              toast.success('Статус підписки оновлено', { title: 'Акаунт синхронізовано' });
            }
          }
          prevUserRef.current = nextUser;
          setUser(nextUser);
        }
        if (msg.speedTest) setSpeedTest(msg.speedTest);
        if (msg.type === 'chrome' && msg.maximized !== undefined) setWinMax(Boolean(msg.maximized));
        const ffmpegState = msg.ffmpeg ?? msg.dependencies?.ffmpeg;
        if (ffmpegState) setFfmpeg(ffmpegState);
      } catch (e) {
        console.error('[HostedUI] Message parse error:', e);
      }
    };

    if ((window as any).chrome?.webview) {
      (window as any).chrome.webview.addEventListener('message', handleWebMessage);
      sendToHost('ready');
    }

    return () => {
      clearTimeout(splashTimer);
      if ((window as any).chrome?.webview) {
        (window as any).chrome.webview.removeEventListener('message', handleWebMessage);
      }
    };
  }, []);

  const sendToHost = (type: string, data: any = {}) => {
    if ((window as any).chrome?.webview) {
      (window as any).chrome.webview.postMessage({ type, ...data });
    }
  };

  const handleStartDrag = (e: React.MouseEvent) => {
    // Dragging belongs to the title bar only, like any normal desktop app.
    if (e.button === 0) sendToHost('window_drag');
  };

  // NOTE: no double-click maximize — double-click on the title bar does
  // nothing on purpose (the maximize button was removed by design).

  // ---------- Clipboard with WebView2-safe fallback ----------
  const copyText = async (text: string): Promise<boolean> => {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      try {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        const ok = document.execCommand('copy');
        ta.remove();
        return ok;
      } catch {
        return false;
      }
    }
  };

  const handleCopyCode = async () => {
    const plain = code.replace(/-/g, '');
    const ok = await copyText(plain);
    if (ok) toast.success('Код скопійовано в буфер обміну');
    else toast.error('Не вдалося скопіювати код');
  };

  const handleCopyWebLink = async () => {
    const plain = code.replace(/-/g, '');
    const url = `https://fluxcontrol.pages.dev/device/${plain}`;
    const ok = await copyText(url);
    if (ok) toast.success('Посилання скопійовано');
    else toast.error('Не вдалося скопіювати посилання');
  };

  const handleRegenerate = () => {
    setConfirmRegen(true);
  };

  const handleConfirmRegenerate = () => {
    setConfirmRegen(false);
    sendToHost('regenerate_code');
    toast.info('Генеруємо новий код підключення…');
  };

  const handleLoginViaBrowser = () => sendToHost('login_via_browser');
  const handleLogout = () => {
    setUser(null);
    sendToHost('logout');
  };
  const handleCheckSubscription = () => {
    sendToHost('check_subscription');
    toast.info('Оновлюємо статус підписки…');
  };

  // ---------- License key activation (same API the website profile uses) ----------
  const handleActivateKey = async () => {
    const clean = keyCode.trim().toUpperCase();
    if (!clean) {
      toast.warn('Введіть ліцензійний ключ');
      return;
    }
    if (!user?.id) {
      toast.error('Акаунт не розпізнано — увійдіть знову');
      return;
    }
    setKeyBusy(true);
    const payload = { userId: user.id, keyCode: clean };
    try {
      let data: any = null;
      try {
        const res = await fetch('/api/license/activate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
          signal: AbortSignal.timeout(8000)
        });
        data = await res.json().catch(() => null);
      } catch {}
      if (!data) {
        const res = await fetch('https://fluxcontrol-backend.onrender.com/api/license/activate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
          signal: AbortSignal.timeout(8000)
        });
        data = await res.json().catch(() => null);
      }
      if (data?.success) {
        setUser((u) => ({
          ...(u || {}),
          ...(data.user || {}),
          subscriptionExpiresAt: data.expiresAt ?? data.user?.subscriptionExpiresAt ?? u?.subscriptionExpiresAt,
        }));
        setKeyCode('');
        toast.success(data.message || 'Підписку активовано!', { title: 'Ключ прийнято' });
      } else {
        toast.error(data?.message || 'Ключ не знайдено або він недійсний');
      }
    } catch {
      toast.error("Помилка з'єднання із сервером активації");
    } finally {
      setKeyBusy(false);
    }
  };

  const handleToggleAutoRun = () => {
    const next = !autoRun;
    setAutoRun(next);
    sendToHost('set_autorun', { enable: next });
    toast.success(next ? 'Автозапуск увімкнено' : 'Автозапуск вимкнено');
  };

  const handleToggleMinimizeToTray = () => {
    const next = !minimizeToTray;
    setMinimizeToTray(next);
    sendToHost('set_tray', { enable: next });
    toast.success(next ? 'Згортання в трей увімкнено' : 'Згортання в трей вимкнено');
  };

  const handleInstallFfmpeg = () => sendToHost('install_ffmpeg');
  const handleRetryDependency = () => sendToHost('retry_dependency_check');
  const handleRetryConnection = () => {
    sendToHost('retry_connection');
    toast.info('Повторне підключення до хмарної служби…');
  };
  const handleManualFfmpeg = () => {
    window.open('https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip', '_blank', 'noopener');
  };

  // ---------- Pairing request response ----------
  useEffect(() => {
    if (!pairing) return;
    // The host auto-cancels the request after 30s — mirror that in the UI.
    const t = setTimeout(() => setPairing(null), 30500);
    return () => clearTimeout(t);
  }, [pairing]);

  const respondPairing = (allow: boolean) => {
    if (!pairing) return;
    sendToHost('respond_pairing', { requestId: pairing.requestId, allow });
    if (allow) toast.success(`Доступ дозволено: ${pairing.deviceName}`);
    else toast.info('Запит на підключення відхилено');
    setPairing(null);
  };

  // ---------- ETA estimation while FFmpeg downloads ----------
  useEffect(() => {
    if (!ffmpeg || ffmpeg.status !== 'installing') {
      installSamplesRef.current = [];
      setEtaText(null);
      return;
    }
    const p = typeof ffmpeg.percent === 'number' ? ffmpeg.percent : 0;
    const now = Date.now();
    const arr = installSamplesRef.current;
    const last = arr[arr.length - 1];
    // Install restarted → drop old samples.
    if (last && p < last.p - 1) arr.length = 0;
    // Sample at most ~1.4/sec so noisy 1s state pushes stay smooth.
    if (!last || now - last.t >= 700) {
      arr.push({ t: now, p });
      if (arr.length > 40) arr.shift();
    }
    if (p < 3) {
      setEtaText(null);
      return;
    }
    const first = arr[0];
    if (arr.length >= 2 && first) {
      const dP = p - first.p;
      const dT = now - first.t;
      if (dP >= 0.5 && dT >= 2000) {
        const remainingSec = Math.round((100 - p) / (dP / dT) / 1000);
        if (remainingSec > 600) setEtaText('кілька хвилин…');
        else if (remainingSec >= 60) setEtaText(`≈ залишилось ${Math.ceil(remainingSec / 60)} хв`);
        else setEtaText(`≈ залишилось ${Math.max(1, remainingSec)} сек`);
        return;
      }
    }
    setEtaText(null);
  }, [ffmpeg]);

  const getSubBadge = () => {
    if (!user) return null;
    if (user.role === 'admin') {
      return (
        <span className="fcx-badge bg-violet-500/15 text-violet-300 border-violet-500/30">
          <Crown className="w-3 h-3 text-violet-400" />
          <span>Admin</span>
        </span>
      );
    }
    if (user.subscriptionExpiresAt === -1) {
      return (
        <span className="fcx-badge bg-emerald-500/15 text-emerald-300 border-emerald-500/30">
          <Zap className="w-3 h-3 text-emerald-400" />
          <span>PRO Безліміт</span>
        </span>
      );
    }
    if (user.subscriptionExpiresAt && user.subscriptionExpiresAt > Date.now()) {
      const days = Math.ceil((user.subscriptionExpiresAt - Date.now()) / (1000 * 60 * 60 * 24));
      return (
        <span className="fcx-badge bg-emerald-500/15 text-emerald-300 border-emerald-500/30">
          <Zap className="w-3 h-3 text-emerald-400" />
          <span>PRO ({days} дн.)</span>
        </span>
      );
    }
    return (
      <span className="fcx-badge bg-amber-500/15 text-amber-300 border-amber-500/30">
        <Lock className="w-3 h-3 text-amber-400" />
        <span>Без підписки</span>
      </span>
    );
  };

  const relayConnected = relayStatus === 'connected';
  const relayErrored = relayStatus === 'error';
  const isSubscribedActive = Boolean(
    user?.role === 'admin' ||
    user?.subscriptionExpiresAt === -1 ||
    (user?.subscriptionExpiresAt && user.subscriptionExpiresAt > Date.now())
  );
  const relayLabel = relayConnected
    ? 'Підключено'
    : relayErrored
      ? 'Помилка з’єднання'
      : 'Підключення…';
  const dependencyChecking = ffmpeg?.status === 'checking';
  const ffmpegReady = ffmpeg?.status === 'ready';
  const ffmpegLabel = !ffmpeg || dependencyChecking
    ? 'Перевірка…'
    : ffmpegReady
      ? 'Готовий'
      : ffmpeg?.status === 'installing'
        ? 'Встановлення…'
        : 'Не знайдено';

  const formatExpiry = (ts?: number | null): string => {
    if (ts === -1) return 'Безстрокова (PRO Forever)';
    if (!ts || ts <= Date.now()) return 'Не активна';
    const d = new Date(ts);
    const months = ['січ', 'лют', 'бер', 'кві', 'тра', 'чер', 'лип', 'сер', 'вер', 'жов', 'лис', 'гру'];
    return `активна до ${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
  };

  // Esc closes the fullscreen QR overlay.
  useEffect(() => {
    if (!showQrFull) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setShowQrFull(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [showQrFull]);

  // ---------- Fullscreen QR overlay: scan-friendly size, click/Esc closes ----------
  const qrFullscreen = showQrFull ? (
    <div
      className="fixed inset-0 top-[46px] z-40 flex flex-col items-center justify-center gap-5 bg-black/85 backdrop-blur-md cursor-pointer fcx-in"
      onClick={() => setShowQrFull(false)}
      role="dialog"
      aria-modal="true"
      aria-label="QR-код на весь екран"
    >
      <div className="flex items-center gap-2 text-[12.5px] font-bold text-gray-300">
        <QrCode className="w-4 h-4 text-violet-300" />
        <span>Відскануйте камерою телефона</span>
      </div>
      <div className="p-4 bg-white rounded-[24px] shadow-2xl shadow-violet-900/40" style={{ width: 'min(62vh, 74vw, 420px)', height: 'min(62vh, 74vw, 420px)' }}>
        {qrBase64 ? (
          <img src={qrBase64} alt="QR-код" className="w-full h-full object-contain" />
        ) : (
          <div className="w-full h-full grid place-items-center text-gray-400 text-sm">QR недоступний</div>
        )}
      </div>
      <div className="fcx-code text-[20px] tracking-[.2em]">{code || '••••-••••-••••-••••'}</div>
      <p className="flex items-center gap-1.5 text-[11px] text-gray-500">
        <MousePointerClick className="w-3.5 h-3.5" />
        Натисніть будь-де або Esc, щоб закрити
      </p>
    </div>
  ) : null;

  // ---------- "Оновити код" confirmation: resetting the code cuts off old links ----------
  const regenerateModal = confirmRegen ? (
    <div
      className="fixed inset-x-0 top-[46px] bottom-0 z-40 flex items-center justify-center p-4 bg-black/75 backdrop-blur-[6px]"
      role="dialog"
      aria-modal="true"
      aria-label="Підтвердження оновлення коду"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) setConfirmRegen(false);
      }}
    >
      <div className="w-full max-w-[400px] p-5 rounded-[22px] bg-[#0c0c16]/97 border border-amber-500/25 shadow-2xl space-y-4 fcx-in">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-[14px] bg-amber-500/12 border border-amber-500/35 flex items-center justify-center flex-shrink-0">
            <AlertTriangle className="w-5 h-5 text-amber-300" />
          </div>
          <h3 className="text-[13.5px] font-extrabold text-white">Оновити код підключення?</h3>
        </div>
        <p className="text-[12px] text-gray-300 leading-relaxed">
          Поточний код і QR-код перестануть діяти одразу. Це вплине на інших:
        </p>
        <ul className="space-y-2 text-[11.5px] text-gray-400 leading-relaxed">
          <li className="flex items-start gap-2">
            <X className="w-3.5 h-3.5 text-rose-400 flex-shrink-0 mt-0.5" />
            <span>користувачі, які додали цей ПК за старим кодом, втратять доступ — пристрій стане недоступним у їхньому списку;</span>
          </li>
          <li className="flex items-start gap-2">
            <X className="w-3.5 h-3.5 text-rose-400 flex-shrink-0 mt-0.5" />
            <span>старе пряме посилання покаже помилку «код невірний»;</span>
          </li>
          <li className="flex items-start gap-2">
            <KeyRound className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
            <span>щоб підключитися знову, треба ввести новий код або відсканувати новий QR.</span>
          </li>
        </ul>
        <div className="grid grid-cols-2 gap-2.5 pt-1">
          <button type="button" onClick={() => setConfirmRegen(false)} className="fcx-btn fcx-btn-ghost">
            Скасувати
          </button>
          <button type="button" onClick={handleConfirmRegenerate} className="fcx-btn fcx-btn-danger !bg-amber-500/15 !border-amber-500/40 !text-amber-200 hover:!bg-amber-500/25">
            Так, оновити
          </button>
        </div>
      </div>
    </div>
  ) : null;

  // ---------- Shared window controls ----------
  const windowControls = {
    onDragStart: handleStartDrag,
    onMinimize: () => sendToHost('window_minimize'),
    onClose: () => sendToHost('window_close'),
  };

  // ---------- Pairing request modal (rendered on every interactive screen;
  // the title bar stays above it, so Згорнути/Закрити always work) ----------
  const pairingModal = pairing ? (
    <div
      className="fixed inset-x-0 top-[46px] bottom-0 z-40 flex items-center justify-center p-4 bg-black/70 backdrop-blur-[6px]"
      role="dialog"
      aria-modal="true"
      aria-label="Запит на підключення"
    >
      <div className="w-full max-w-[380px] p-5 rounded-[22px] bg-[#0c0c16]/95 border border-white/10 shadow-2xl space-y-4 fcx-in">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-[14px] bg-violet-600/15 border border-violet-500/35 flex items-center justify-center flex-shrink-0">
            <MonitorSmartphone className="w-5 h-5 text-violet-300" />
          </div>
          <div className="min-w-0">
            <h3 className="text-[13.5px] font-extrabold text-white">Запит на підключення</h3>
            <p className="text-[11px] text-gray-400 truncate">
              {pairing.deviceName}
              {pairing.ip ? ` · ${pairing.ip}` : ''}
            </p>
          </div>
        </div>
        <p className="text-[12px] text-gray-300 leading-relaxed">
          Пристрій <strong className="text-white">{pairing.deviceName}</strong> хоче підключитися до цього
          комп&apos;ютера та керувати ним. Дозволити доступ?
        </p>
        <div className="grid grid-cols-2 gap-2.5">
          <button type="button" onClick={() => respondPairing(false)} className="fcx-btn fcx-btn-ghost">
            Відхилити
          </button>
          <button type="button" onClick={() => respondPairing(true)} className="fcx-btn fcx-btn-primary">
            Дозволити
          </button>
        </div>
        <p className="text-[10px] text-gray-500 text-center">Запит автоматично скасується за 30 секунд</p>
      </div>
    </div>
  ) : null;

  // ================================================================
  // STARTUP SPLASH — everything loads behind it (libraries, account
  // check, relay handshake). The main screen appears only after the
  // host reports readiness.
  // ================================================================
  if (loadingSplash) {
    return (
      <WinShell maximized={winMax}>
      <div className="fcx-root h-full w-full select-none overflow-hidden relative flex flex-col" id="agent-splash">
        <AgentScopedStyle />
        <AgentTitleBar {...windowControls} />
        <div className="relative flex-1 flex flex-col items-center justify-center text-center overflow-hidden">
          <div className="fcx-glow fcx-glow-a" />
          <div className="relative mb-7 fcx-in">
            <div className="drop-shadow-2xl shadow-indigo-600/40">
              <BrandMark size={84} />
            </div>
            <span className="fcx-ring" />
            <span className="fcx-ring fcx-ring-late" />
          </div>
          <h2 className="text-[26px] font-black tracking-tight mb-1.5 fcx-in fcx-in-1">
            <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">Flux</span>
            <span className="bg-gradient-to-r from-violet-300 to-indigo-300 bg-clip-text text-transparent">Control</span>
          </h2>
          <p className="text-[11.5px] text-gray-400 max-w-[300px] mb-6 fcx-in fcx-in-2">
            Запуск програми: підвантаження бібліотек та перевірка даних…
          </p>
          <div className="fcx-in fcx-in-3 space-y-3.5">
            <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/[0.04] border border-white/[0.09] text-[11.5px] text-gray-300 w-fit mx-auto">
              <Loader2 className="w-3.5 h-3.5 fcx-spin text-violet-400" />
              <span>Ініціалізація захищеного зв&apos;язку</span>
            </div>
            <div className="fcx-progress fcx-shimmer-wrap w-[210px] mx-auto">
              <i style={{ width: '36%' }} />
            </div>
          </div>
          <div className="absolute bottom-5 left-0 right-0 text-center text-[11px] text-gray-500 flex items-center justify-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5" />
            Захищений віддалений доступ
          </div>
        </div>
      </div>
      </WinShell>
    );
  }

  // ================================================================
  // AUTH GATE — until the account is verified nothing of the program
  // is rendered. Separate window design, browser-based login.
  // ================================================================
  if (authChecked && !user) {
    return (
      <WinShell maximized={winMax}>
      <div className="fcx-root h-full w-full select-none overflow-hidden relative flex flex-col" id="agent-auth">
        <AgentScopedStyle />
        <AgentTitleBar {...windowControls} />

        <div className="relative flex-1 overflow-y-auto fcx-scroll flex items-center justify-center p-6">
          <div className="fcx-glow fcx-glow-a" />
          <div className="fcx-glow fcx-glow-b" />

          <div className="relative w-full max-w-[400px] text-center space-y-5 py-4">
            <div className="relative mx-auto w-fit fcx-in">
              <div className="drop-shadow-2xl shadow-indigo-600/40">
                <BrandMark size={92} />
              </div>
              <span className="fcx-ring" />
              <span className="fcx-ring fcx-ring-late" />
            </div>

            <div className="fcx-in fcx-in-1">
              <h1 className="text-[23px] font-black tracking-tight text-white">Вхід у FluxControl</h1>
              <p className="text-[12px] text-gray-400 mt-2.5 leading-relaxed">
                Програма не має доступу, поки ви не авторизуєтесь. Увійдіть у свій акаунт через браузер —
                після підтвердження головне вікно відкриється автоматично.
              </p>
            </div>

            {/* What the account unlocks — branded feature rows */}
            <div className="flex flex-col gap-2 text-left fcx-in fcx-in-2">
              {[
                { icon: MonitorSmartphone, title: 'Керування ПК з будь-якої точки', desc: 'екран, файли, процеси, термінал' },
                { icon: ShieldCheck, title: 'Захищене з\u2019єднання', desc: 'коду доступу + шифрування трафіку' },
                { icon: Crown, title: 'PRO-можливості', desc: 'запис екрана, камера, WinLock та інше' },
              ].map((f) => (
                <div key={f.title} className="flex items-center gap-3 px-3.5 py-2.5 rounded-[14px] bg-white/[0.03] border border-white/[0.07]">
                  <div className="w-8 h-8 rounded-[10px] bg-violet-600/15 border border-violet-500/30 grid place-items-center flex-shrink-0">
                    <f.icon className="w-4 h-4 text-violet-300" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-[11.5px] font-bold text-white leading-tight">{f.title}</p>
                    <p className="text-[10px] text-gray-500 leading-tight mt-0.5">{f.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <button type="button" onClick={handleLoginViaBrowser} className="fcx-btn fcx-btn-primary w-full !h-[46px] !text-[13.5px] fcx-in fcx-in-3">
              <LogIn className="w-4 h-4" />
              <span>Увійти через браузер</span>
            </button>

            <div className="flex items-center justify-center gap-2 text-[11px] text-gray-500 fcx-in fcx-in-3">
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Відкриється сторінка входу fluxcontrol.pages.dev</span>
            </div>

            <div className="flex flex-col items-center gap-2.5 pt-1 fcx-in fcx-in-3">
              <div className="flex items-center justify-center gap-2">
                <span className={`fcx-dot ${relayConnected ? 'fcx-dot-ok fcx-dot-live' : relayErrored ? 'fcx-dot-err' : 'fcx-dot-warn'}`} />
                <span className="text-[11px] text-gray-400">
                  {relayConnected ? 'Хмарна служба підключена' : relayErrored ? 'Хмарна служба: помилка з&apos;єднання' : 'Підключення до хмарної служби…'}
                </span>
              </div>
              {relayErrored && (
                <button type="button" onClick={handleRetryConnection} className="fcx-btn fcx-btn-ghost fcx-btn-sm">
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Спробувати ще раз</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {pairingModal}
      </div>
      </WinShell>
    );
  }

  // ================================================================
  // FFmpeg DEPENDENCY INSTALLER — shown while the required library is
  // downloaded or failed. The title bar (Згорнути / Закрити) stays on
  // top of everything and is always clickable — installation continues
  // in the background when minimized.
  // ================================================================
  if (ffmpeg && (ffmpeg.status === 'installing' || ffmpeg.status === 'error' || ffmpeg.status === 'missing')) {
    const installing = ffmpeg.status === 'installing';
    const failed = ffmpeg.status === 'error';
    const percent = typeof ffmpeg.percent === 'number' ? ffmpeg.percent : 0;

    return (
      <WinShell maximized={winMax}>
      <div className="fcx-root h-full w-full select-none overflow-hidden relative flex flex-col" id="agent-installer">
        <AgentScopedStyle />
        <AgentTitleBar {...windowControls} />

        <div className="flex-1 min-h-0 overflow-y-auto fcx-scroll flex items-center justify-center p-4 sm:p-6">
          <div className="fcx-glow fcx-glow-a" />

          <div className="relative w-full max-w-[460px] fcx-in">
            <div className="p-7 rounded-[24px] bg-white/[0.032] border border-white/[0.09] shadow-2xl space-y-5">
              {/* Animated icon card */}
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="relative">
                  <div
                    className={`w-[84px] h-[84px] rounded-[26px] flex items-center justify-center border ${
                      installing
                        ? 'bg-violet-600/15 border-violet-500/40 text-violet-300'
                        : failed
                          ? 'bg-amber-600/15 border-amber-500/40 text-amber-300'
                          : 'bg-white/[0.04] border-white/[0.12] text-gray-300'
                    }`}
                  >
                    {installing ? (
                      <Package className="w-10 h-10" />
                    ) : failed ? (
                      <AlertTriangle className="w-10 h-10" />
                    ) : (
                      <Download className="w-10 h-10" />
                    )}
                  </div>
                  {installing && (
                    <>
                      <span className="fcx-ring" />
                      <span className="fcx-ring fcx-ring-late" />
                    </>
                  )}
                </div>

                <div>
                  <h2 className="text-[19px] font-black text-white">
                    {installing ? 'Встановлення компонентів' : 'Потрібен компонент'}
                  </h2>
                  <p className="text-[11.5px] text-gray-400 mt-2 leading-relaxed max-w-[380px] mx-auto">
                    FFmpeg потрібен для запису екрана та камери. Він завантажується автоматично — це
                    одноразове встановлення, далі все працюватиме без інтернету.
                  </p>
                </div>
              </div>

              {installing && (
                <div className="space-y-3.5">
                  {/* Big downloaded percent */}
                  <div className="text-center">
                    <div className="text-[44px] font-black tabular-nums leading-none fcx-code">
                      {Math.round(percent)}
                      <span className="text-[22px]">%</span>
                    </div>
                    {etaText && <p className="text-[11px] text-violet-300/90 mt-1.5">{etaText}</p>}
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-[11px] text-gray-400 gap-3">
                      <span className="truncate">{ffmpeg.stage || 'завантаження…'}</span>
                      <span className="font-mono flex-shrink-0">{Math.round(percent)}%</span>
                    </div>
                    <div className="fcx-progress fcx-shimmer-wrap">
                      <i style={{ width: `${Math.max(2, Math.min(100, percent))}%` }} />
                    </div>
                  </div>

                  <p className="text-[11px] text-gray-400 flex items-center justify-center gap-1.5 pt-1">
                    <Minus className="w-3.5 h-3.5 text-violet-400" />
                    Можна згорнути вікно — встановлення триватиме у фоні
                  </p>
                </div>
              )}

              {!installing && (
                <div className="space-y-3">
                  {failed && ffmpeg.error && (
                    <div className="p-3 rounded-[14px] bg-amber-500/[0.08] border border-amber-500/25">
                      <p className="text-[11px] text-amber-200 leading-relaxed break-words">
                        <strong className="font-bold">Помилка: </strong>
                        {ffmpeg.error}
                      </p>
                    </div>
                  )}

                  <div className="grid grid-cols-1 gap-2.5">
                    {failed ? (
                      <button type="button" onClick={handleRetryDependency} className="fcx-btn fcx-btn-primary w-full">
                        <RefreshCw className="w-4 h-4" />
                        <span>Спробувати ще раз</span>
                      </button>
                    ) : (
                      <button type="button" onClick={handleInstallFfmpeg} className="fcx-btn fcx-btn-primary w-full">
                        <Download className="w-4 h-4" />
                        <span>Встановити автоматично</span>
                      </button>
                    )}
                    <button type="button" onClick={failed ? handleInstallFfmpeg : handleManualFfmpeg} className="fcx-btn fcx-btn-ghost w-full">
                      {failed ? <Download className="w-4 h-4" /> : <ExternalLink className="w-4 h-4" />}
                      <span>{failed ? 'Встановити автоматично' : 'Завантажити вручну з офіційного сайту'}</span>
                    </button>
                    {!failed && (
                      <button type="button" onClick={handleRetryDependency} className="fcx-btn fcx-btn-ghost w-full">
                        <RefreshCw className="w-4 h-4" />
                        <span>Перевірити ще раз</span>
                      </button>
                    )}
                    {failed && (
                      <button type="button" onClick={handleManualFfmpeg} className="fcx-btn fcx-btn-ghost w-full">
                        <ExternalLink className="w-4 h-4" />
                        <span>Завантажити вручну з офіційного сайту</span>
                      </button>
                    )}
                  </div>

                  <p className="text-[10px] text-gray-500 leading-relaxed">
                    Якщо завантажили вручну — розпакуйте <span className="font-mono text-gray-400">ffmpeg.exe</span> у папку
                    <span className="font-mono text-gray-400"> %AppData%\FluxControl\ffmpeg</span> або поруч із FluxControl.exe
                    та натисніть «Перевірити ще раз». Постійна папка надійніша — вона не зникає після пересборки програми.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {pairingModal}
      </div>
      </WinShell>
    );
  }

  // ================================================================
  // MAIN APPLICATION (authorized + dependencies ready)
  // Window is ~1000x640: title bar → sidebar (nav + account) →
  // main content with hero code card, stat strip and QR card.
  // ================================================================
  return (
    <WinShell maximized={winMax}>
    <div className="fcx-root h-full w-full select-none flex flex-col overflow-hidden relative" id="agent-main">
      <AgentScopedStyle />

      {/* Fixed top bar: the ONLY drag zone. Згорнути/Закрити always on top. */}
      <AgentTitleBar
        {...windowControls}
        trailing={
          <>
            <div className="hidden md:flex items-center gap-2 mr-1 pointer-events-none">
              <span className={`fcx-dot ${relayConnected ? 'fcx-dot-ok fcx-dot-live' : relayErrored ? 'fcx-dot-err' : 'fcx-dot-warn'}`} />
              <span className="text-[11px] font-semibold text-gray-400 whitespace-nowrap">Хмарна служба: {relayLabel}</span>
              {connectedClients > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-violet-500/15 text-violet-300 border border-violet-500/30 text-[10px] font-bold whitespace-nowrap">
                  Сесій: {connectedClients}
                </span>
              )}
            </div>
          </>
        }
      />

      {/* Body: sidebar + content */}
      <div className="flex flex-1 min-h-0 relative z-10">
        {/* ---------- Mobile tab bar: replaces the sidebar below md ---------- */}
        <nav className="md:hidden absolute top-0 left-0 right-0 z-20 flex items-center gap-1 px-3 py-2 bg-[rgba(8,8,15,0.88)] backdrop-blur-xl border-b border-white/[0.06]">
          {([
            { id: 'home', label: 'Головна', Icon: Home },
            { id: 'account', label: 'Акаунт', Icon: UserRound },
            { id: 'settings', label: 'Налаштування', Icon: Sliders },
          ] as const).map(({ id, label, Icon }) => (
            <button
              key={id}
              type="button"
              onClick={() => switchTab(id)}
              className={`flex-1 flex items-center justify-center gap-1.5 h-9 rounded-xl text-[11.5px] font-bold transition-all ${
                activeTab === id
                  ? 'bg-gradient-to-r from-[rgba(139,92,246,0.9)] to-[rgba(99,102,241,0.9)] text-white shadow-lg shadow-indigo-600/25'
                  : 'text-[#9aa0b4] hover:text-white hover:bg-white/5'
              }`}
            >
              <Icon className="w-3.5 h-3.5 flex-shrink-0" />
              <span>{label}</span>
            </button>
          ))}
        </nav>

        {/* ---------- Sidebar: nav on top, user card pinned BOTTOM-LEFT ---------- */}
        <aside className="fcx-side hidden md:flex">
          <div className="w-full min-w-0">
            <nav className="flex flex-col gap-1.5">
              <button type="button" onClick={() => switchTab('home')} className={`fcx-nav-btn ${activeTab === 'home' ? 'active' : ''}`}>
                <Home className="w-4 h-4 flex-shrink-0" />
                <span>Головна</span>
              </button>
              <button type="button" onClick={() => switchTab('account')} className={`fcx-nav-btn ${activeTab === 'account' ? 'active' : ''}`}>
                <UserRound className="w-4 h-4 flex-shrink-0" />
                <span>Акаунт</span>
              </button>
              <button type="button" onClick={() => switchTab('settings')} className={`fcx-nav-btn ${activeTab === 'settings' ? 'active' : ''}`}>
                <Sliders className="w-4 h-4 flex-shrink-0" />
                <span>Налаштування</span>
              </button>
            </nav>
          </div>

          {/* User info lives in ONE place — bottom-left, as requested.
              Рівно два рядки: (іконка + ім'я) / email. Статус підписки
              тут більше не малюємо — він у вкладці «Акаунт». */}
          <div className="w-full min-w-0 pt-3 border-t border-white/[0.07]">
            <div className="flex items-center gap-2.5 px-1 min-w-0">
              <div className="fcx-avatar !w-9 !h-9 !rounded-xl">
                {user?.picture ? <img src={user.picture} alt="" /> : (user?.name?.charAt(0) || <UserRound className="w-4 h-4 text-violet-200" />)}
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-[13px] font-extrabold text-gray-50 truncate leading-tight">{user?.name || 'Акаунт'}</p>
                <p className="text-[10.5px] text-gray-400 truncate leading-tight mt-[3px]">{user?.email || 'не авторизовано'}</p>
              </div>
            </div>
          </div>
        </aside>

        {/* ---------- Main content ---------- */}
        <main className="flex-1 min-h-0 overflow-y-auto fcx-scroll relative">
          <div className="fcx-glow fcx-glow-a" />
          <div className="fcx-glow fcx-glow-b" />

          <div className="relative max-w-[720px] mx-auto px-5 pt-16 pb-5 md:pt-5 md:pb-5 space-y-4">
            {/* Non-intrusive dependency check indicator (screen stays usable) */}
            {dependencyChecking && (
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/[0.04] border border-white/[0.09] text-[11px] text-gray-400">
                <Loader2 className="w-3.5 h-3.5 fcx-spin text-violet-400" />
                <span>Перевірка компонентів…</span>
              </div>
            )}

            {/* ============ TAB 1: Головна ============ */}
            {activeTab === 'home' && (
              <div className="space-y-4">
                {/* Hero: connection code */}
                <section className="fcx-card fcx-in p-5 relative overflow-hidden" aria-label="Код підключення">
                  <div className="absolute -top-16 -right-10 w-[220px] h-[160px] bg-violet-600/10 rounded-full blur-[70px] pointer-events-none" />

                  <div className="relative flex items-center justify-between gap-3 mb-4 flex-wrap">
                    <span className="fcx-eyebrow">Підключення з сайту</span>
                    {computerName && (
                      <span className="px-2.5 py-1 rounded-full bg-white/[0.045] border border-white/[0.09] text-[10.5px] text-gray-300 font-bold">
                        ПК: {computerName}
                      </span>
                    )}
                  </div>

                  <div className="relative bg-black/45 border border-violet-500/[0.18] p-4 rounded-[16px] flex items-center justify-between gap-3 flex-wrap">
                    <span className="fcx-code text-[26px] sm:text-[32px] leading-none">
                      {code || '••••-••••-••••-••••'}
                    </span>
                    <button
                      type="button"
                      onClick={handleCopyCode}
                      className="fcx-icon-btn flex-shrink-0"
                      title="Копіювати код"
                      aria-label="Копіювати код"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="relative flex items-center gap-2 flex-wrap pt-4">
                    <button type="button" onClick={handleCopyWebLink} className="fcx-btn fcx-btn-primary">
                      <Link2 className="w-4 h-4" />
                      <span>Пряме посилання</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowQr((v) => !v)}
                      aria-pressed={showQr}
                      className="fcx-btn fcx-btn-ghost"
                      style={showQr ? { color: '#c4b5fd', borderColor: 'rgba(139,92,246,.45)', background: 'rgba(139,92,246,.08)' } : undefined}
                    >
                      <QrCode className="w-4 h-4" />
                      <span>{showQr ? 'Приховати QR' : 'Показати QR'}</span>
                    </button>
                  </div>

                  <p className="relative text-[11px] text-gray-400 pt-3.5">
                    Введіть цей код на сайті <strong className="text-white font-mono">fluxcontrol.pages.dev</strong>{' '}
                    <span className="text-gray-500">— або відскануйте QR-код камерою телефона.</span>
                  </p>
                </section>

                {/* Жива статистика з'єднання замість кроків-карток: пінг і швидкість
                    з автоматичного speedtest хоста (з'являється, коли виміряно). */}
                {(speedTest?.pingMs || speedTest?.downloadMbps) && (
                  <section className="flex items-center justify-center gap-4 flex-wrap fcx-in fcx-in-1 text-[11px] text-gray-400">
                    {speedTest?.pingMs && (
                      <span className="inline-flex items-center gap-1.5" title="Затримка до хмарної служби">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                        Пінг: <strong className="text-white font-bold">{Math.round(speedTest.pingMs)} мс</strong>
                      </span>
                    )}
                    {speedTest?.downloadMbps && (
                      <span className="inline-flex items-center gap-1.5" title="Швидкість завантаження">
                        ↓ <strong className="text-white font-bold">{Number(speedTest.downloadMbps).toFixed(1)} Мбіт/с</strong>
                      </span>
                    )}
                    {speedTest?.uploadMbps && (
                      <span className="inline-flex items-center gap-1.5" title="Швидкість віддачі">
                        ↑ <strong className="text-white font-bold">{Number(speedTest.uploadMbps).toFixed(1)} Мбіт/с</strong>
                      </span>
                    )}
                  </section>
                )}

                {/* Relay problem strip + retry_connection */}
                {!relayConnected && (
                  <section className="p-3.5 rounded-[16px] bg-amber-500/[0.07] border border-amber-500/25 flex items-center justify-between gap-3 flex-wrap fcx-in fcx-in-2">
                    <div className="min-w-0">
                      <p className="text-[11.5px] font-bold text-amber-200">
                        {relayErrored ? 'Хмарна служба недоступна' : 'Підключення до хмарної служби…'}
                      </p>
                      {relayErrored && relayError && (
                        <p className="text-[10.5px] text-amber-200/70 mt-0.5 truncate">{relayError}</p>
                      )}
                      {relayErrored && (
                        <p className="text-[10.5px] text-amber-200/70 mt-0.5">
                          Поки служба не підключена, код не працюватиме на сайті.
                        </p>
                      )}
                    </div>
                    {relayErrored && (
                      <button type="button" onClick={handleRetryConnection} className="fcx-btn fcx-btn-ghost fcx-btn-sm flex-shrink-0">
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>Спробувати ще раз</span>
                      </button>
                    )}
                  </section>
                )}

                {/* QR code & mobile connection — click the code to open it FULLSCREEN */}
                {showQr && (
                  <section className="fcx-card fcx-card-hover p-4 flex flex-col sm:flex-row items-center gap-4 fcx-in fcx-in-2">
                    <button
                      type="button"
                      onClick={() => setShowQrFull(true)}
                      className="w-[104px] h-[104px] bg-white p-2 rounded-[16px] flex items-center justify-center flex-shrink-0 shadow-lg cursor-zoom-in group relative overflow-hidden"
                      title="Відкрити на весь екран"
                      aria-label="Відкрити QR-код на весь екран"
                    >
                      {qrBase64 ? (
                        <img src={qrBase64} alt="QR-код для підключення зі смартфона" className="w-full h-full object-contain" />
                      ) : (
                        <QrCode className="w-11 h-11 text-gray-700" />
                      )}
                      <span className="absolute inset-0 bg-violet-600/0 group-hover:bg-violet-600/10 transition-colors" />
                      <span className="absolute bottom-1.5 right-1.5 p-1 rounded-lg bg-black/70 text-white opacity-0 group-hover:opacity-100 transition-opacity">
                        <QrCode className="w-3 h-3" />
                      </span>
                    </button>
                    <div className="min-w-0 text-center sm:text-left">
                      <h4 className="text-[13px] font-bold text-white">Швидке підключення зі смартфона</h4>
                      <p className="text-[11.5px] text-gray-400 leading-relaxed mt-1.5">
                        Відскануйте QR-код камерою телефона, щоб миттєво відкрити панель керування цим
                        комп&apos;ютером у мобільному браузері.
                      </p>
                      <button type="button" onClick={() => setShowQrFull(true)} className="mt-2 fcx-btn fcx-btn-ghost fcx-btn-sm">
                        <QrCode className="w-3.5 h-3.5" />
                        <span>Збільшити на весь екран</span>
                      </button>
                    </div>
                  </section>
                )}

                {/* Reassurance footer */}
                <p className="text-[11px] text-gray-500 flex items-center justify-center gap-1.5 pt-1 pb-2 fcx-in fcx-in-3">
                  <ShieldCheck className="w-3.5 h-3.5 text-violet-400/70" />
                  Захищене з&apos;єднання · Код оновлюється під час кожного запуску програми
                </p>
              </div>
            )}

            {/* ============ TAB 2: Налаштування ============ */}
            {activeTab === 'settings' && (
              <div className="space-y-4">
                {/* Connection code card — the small regenerate button with a warning dialog */}
                <section className="fcx-card p-4 fcx-in">
                  <p className="fcx-eyebrow mb-3">Код підключення</p>
                  <div className="flex items-center justify-between gap-3 flex-wrap">
                    <div className="min-w-0 flex-1">
                      <p className="text-[12px] font-bold text-white">Оновити код доступу</p>
                      <p className="text-[11px] text-gray-400 mt-0.5 leading-relaxed">
                        Створить новий код замість поточного. Попередній код, QR та пряме посилання перестануть діяти.
                      </p>
                    </div>
                    <button type="button" onClick={handleRegenerate} className="fcx-btn fcx-btn-ghost fcx-btn-sm flex-shrink-0">
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Оновити код</span>
                    </button>
                  </div>
                </section>

                {/* General card */}
                <section className="fcx-card px-4 fcx-in fcx-in-1">
                  <p className="fcx-eyebrow pt-4">Загальні</p>
                  <div className="divide-y divide-white/[0.06]">
                    <AgentToggle
                      title="Автозапуск при старті Windows"
                      desc="Запускати програму у фоні при вході в систему"
                      enabled={autoRun}
                      onToggle={handleToggleAutoRun}
                    />
                    <AgentToggle
                      title="Згортати в системний трей"
                      desc="При закритті ховати вікно поруч з годинником"
                      enabled={minimizeToTray}
                      onToggle={handleToggleMinimizeToTray}
                    />
                  </div>
                </section>

                {/* About card */}
                <section className="fcx-card p-4 fcx-in fcx-in-2 space-y-2.5">
                  <p className="fcx-eyebrow">Про програму</p>
                  <div className="flex items-center justify-between text-[12px]">
                    <span className="text-gray-400">FluxControl</span>
                    <span className="font-bold text-white">{appVersion ? `v${appVersion}` : '—'}</span>
                  </div>
                  <div className="flex items-center justify-between text-[12px]">
                    <span className="text-gray-400">Компонент FFmpeg</span>
                    <span className="font-bold text-white">{ffmpegLabel}</span>
                  </div>
                  <div className="flex items-center justify-between text-[12px]">
                    <span className="text-gray-400">Ім&apos;я комп&apos;ютера</span>
                    <span className="font-bold text-white truncate max-w-[200px]">{computerName || '—'}</span>
                  </div>
                </section>
              </div>
            )}

            {/* ============ TAB 3: Акаунт ============ */}
            {activeTab === 'account' && (
              <div className="space-y-4">
                {user ? (
                  <>
                    {/* Profile header card */}
                    <section className="fcx-card p-5 fcx-in relative overflow-hidden">
                      <div className="absolute -top-14 -right-8 w-[200px] h-[150px] bg-violet-600/10 rounded-full blur-[70px] pointer-events-none" />
                      <div className="relative flex items-center gap-4 flex-wrap">
                        <div className="fcx-avatar !w-[64px] !h-[64px] !rounded-[20px] !text-[22px]">
                          {user.picture ? <img src={user.picture} alt="" /> : (user.name?.charAt(0) || 'U')}
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-[16px] font-black text-white truncate leading-tight">{user.name}</p>
                          <p className="text-[11.5px] text-gray-400 truncate mt-0.5">{user.email}</p>
                          <div className="mt-2">{getSubBadge()}</div>
                        </div>
                      </div>
                    </section>

                    {/* Subscription card */}
                    <section className="fcx-card p-4 fcx-in fcx-in-1">
                      <div className="flex items-center justify-between gap-3 mb-3">
                        <p className="fcx-eyebrow">Підписка</p>
                        <button type="button" onClick={handleCheckSubscription} className="fcx-btn fcx-btn-ghost fcx-btn-sm">
                          <RefreshCw className="w-3.5 h-3.5" />
                          <span>Оновити</span>
                        </button>
                      </div>
                      <div className="flex items-center gap-3 p-3 rounded-[14px] bg-white/[0.03] border border-white/[0.07]">
                        <div className={`w-9 h-9 rounded-xl grid place-items-center flex-shrink-0 border ${
                          user.role === 'admin'
                            ? 'bg-violet-500/15 border-violet-500/35 text-violet-300'
                            : isSubscribedActive
                              ? 'bg-emerald-500/15 border-emerald-500/35 text-emerald-300'
                              : 'bg-amber-500/12 border-amber-500/30 text-amber-300'
                        }`}>
                          {user.role === 'admin' ? <Crown className="w-4.5 h-4.5" /> : isSubscribedActive ? <BadgeCheck className="w-[18px] h-[18px]" /> : <Lock className="w-4 h-4" />}
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-[12.5px] font-bold text-white leading-tight">
                            {user.role === 'admin' ? 'Адміністратор — повний доступ' : isSubscribedActive ? 'PRO-підписка' : 'Без підписки'}
                          </p>
                          <p className="text-[11px] text-gray-400 mt-0.5">{formatExpiry(user.subscriptionExpiresAt)}</p>
                        </div>
                      </div>
                      <p className="text-[10.5px] text-gray-500 mt-2.5 leading-relaxed">
                        Підписка відкриває керування ПК, передачу файлів, термінал та всі інструменти на сайті.
                      </p>
                    </section>

                    {/* License key activation */}
                    <section className="fcx-card p-4 fcx-in fcx-in-2">
                      <p className="fcx-eyebrow mb-1.5">Активація ключа</p>
                      <p className="text-[11px] text-gray-400 leading-relaxed mb-3">
                        Введіть ліцензійний ключ, щоб продовжити або активувати підписку.
                      </p>
                      <div className="flex items-center gap-2 flex-wrap">
                        <input
                          value={keyCode}
                          onChange={(e) => setKeyCode(e.target.value.toUpperCase())}
                          onKeyDown={(e) => { if (e.key === 'Enter') handleActivateKey(); }}
                          placeholder="XXXX-XXXX-XXXX-XXXX"
                          maxLength={24}
                          spellCheck={false}
                          className="flex-1 min-w-[180px] h-[38px] rounded-xl bg-black/45 border border-white/10 focus:border-violet-400/60 outline-none px-3.5 text-[12.5px] font-bold text-white font-mono tracking-wider placeholder:text-gray-600 placeholder:font-normal transition-colors"
                        />
                        <button type="button" onClick={handleActivateKey} disabled={keyBusy} className="fcx-btn fcx-btn-primary !h-[38px] disabled:opacity-60">
                          {keyBusy ? <Loader2 className="w-4 h-4 fcx-spin" /> : <KeyRound className="w-4 h-4" />}
                          <span>{keyBusy ? 'Активуємо…' : 'Активувати'}</span>
                        </button>
                      </div>
                    </section>

                    {/* Session info + logout */}
                    <section className="fcx-card p-4 fcx-in fcx-in-3">
                      <div className="flex items-center justify-between gap-3 flex-wrap">
                        <div className="min-w-0">
                          <p className="text-[12px] font-bold text-white">Цей комп&apos;ютер</p>
                          <p className="text-[11px] text-gray-400 mt-0.5 truncate">{computerName || '—'} · підключений до вашого акаунта</p>
                        </div>
                        <button type="button" onClick={handleLogout} className="fcx-btn fcx-btn-danger flex-shrink-0">
                          <LogOut className="w-4 h-4" />
                          <span>Вийти з акаунта</span>
                        </button>
                      </div>
                    </section>
                  </>
                ) : (
                  <section className="fcx-card p-6 fcx-in text-center">
                    <div className="w-14 h-14 mx-auto rounded-[18px] bg-violet-600/15 border border-violet-500/35 grid place-items-center mb-3.5">
                      <UserRound className="w-6 h-6 text-violet-300" />
                    </div>
                    <p className="text-[13px] font-bold text-white">Акаунт не підключено</p>
                    <p className="text-[11.5px] text-gray-400 mt-1.5 leading-relaxed max-w-[300px] mx-auto">
                      Увійдіть через браузер, щоб бачити статус підписки, активувати ключі та керувати цим ПК.
                    </p>
                    <button type="button" onClick={handleLoginViaBrowser} className="fcx-btn fcx-btn-primary mx-auto mt-4">
                      <LogIn className="w-4 h-4" />
                      <span>Увійти через браузер</span>
                    </button>
                  </section>
                )}
              </div>
            )}
          </div>
        </main>
      </div>

      {qrFullscreen}
      {regenerateModal}
      {pairingModal}
    </div>
    </WinShell>
  );
};


