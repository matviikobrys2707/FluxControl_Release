import React, { useEffect } from 'react';
import { AlertTriangle } from 'lucide-react';

interface ConfirmDialogProps {
  isOpen: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  danger?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

/**
 * Styled replacement for the native window.confirm() dialog.
 * Matches the FluxControl dark + violet design system, blocks page scroll
 * while open and closes on Escape.
 */
export const ConfirmDialog: React.FC<ConfirmDialogProps> = ({
  isOpen,
  title,
  message,
  confirmLabel = 'Підтвердити',
  cancelLabel = 'Скасувати',
  danger = true,
  onConfirm,
  onCancel
}) => {
  useEffect(() => {
    if (!isOpen) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const handleKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onCancel(); };
    window.addEventListener('keydown', handleKey);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener('keydown', handleKey);
    };
  }, [isOpen, onCancel]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="glass-panel w-full max-w-sm rounded-3xl p-6 border border-white/15 shadow-2xl relative bg-[#090b14] text-center">
        <div className={`w-14 h-14 rounded-2xl border flex items-center justify-center mx-auto mb-4 ${
          danger
            ? 'bg-red-600/20 border-red-500/30 text-red-400'
            : 'bg-indigo-600/20 border-indigo-500/30 text-indigo-400'
        }`}>
          <AlertTriangle className="w-7 h-7" />
        </div>

        <h3 className="text-base font-bold text-white mb-2">{title}</h3>
        <p className="text-xs text-gray-400 leading-relaxed mb-6 break-words">{message}</p>

        <div className="flex items-center gap-3">
          <button
            onClick={onCancel}
            className="flex-1 py-2.5 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white rounded-xl text-xs font-semibold transition-colors cursor-pointer"
          >
            {cancelLabel}
          </button>
          <button
            onClick={onConfirm}
            autoFocus
            className={`flex-1 py-2.5 rounded-xl text-xs font-bold text-white transition-all shadow-lg cursor-pointer ${
              danger
                ? 'bg-red-600 hover:bg-red-500 shadow-red-600/30'
                : 'bg-indigo-600 hover:bg-indigo-500 shadow-indigo-600/30'
            }`}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
};
