/**
 * Types definition for FluxControl Remote PC Manager
 */

export interface User {
  id: string;
  email: string;
  name: string;
  photoURL?: string;
  picture?: string;
  role?: 'admin' | 'user';
  subscriptionExpiresAt?: number | null; // ms timestamp or null, -1 = lifetime
  /** false = новий/заблокований акаунт: функціонал відкриває адмін або ключ доступу. */
  accessEnabled?: boolean;
  createdAt?: string | number;
  isDemo?: boolean;
}

export interface LicenseKey {
  id: string;
  keyCode: string;
  durationType: '1m' | '5m' | '1h' | '1d' | '7d' | '30d' | '90d' | '1y' | 'lifetime' | string;
  durationMs: number;
  customLabel?: string;
  isUsed: boolean;
  usedBy?: string | null;
  usedByEmail?: string | null;
  usedAt?: number | null;
  createdAt: number;
  createdBy?: string;
}

export interface DiskInfo {
  name: string;
  label?: string;
  totalGb: number;
  freeGb: number;
  percentUsed: number;
  /** Raw byte values — used for smart unit formatting (MB for small drives). */
  totalBytes?: number;
  freeBytes?: number;
  driveType?: 'fixed' | 'removable' | 'network' | 'unknown';
  /** Модель фізичного диска (напр. «Samsung SSD 870 EVO 1TB»). */
  model?: string;
  /** Тип носія: "SSD", "HDD", "NVMe", "USB". */
  mediaType?: string;
}

export interface SpeedTestResult {
  downloadMbps?: number;
  uploadMbps?: number;
  pingMs?: number;
  timestamp?: number;
  running?: boolean;
  stage?: string;
  error?: string;
  /** "manual" — користувач натиснув кнопку, "auto" — тест при підключенні. */
  mode?: 'manual' | 'auto' | string;
  /** Тривалість завершеного тесту, мс. */
  durationMs?: number;
}

export interface DeviceMetrics {
  cpuUsage: number;
  cpuPercent?: number;
  cpuModel?: string;
  cpuName?: string;
  cpuTemp?: number;
  cpuTempC?: number;
  cpuFreqGhz?: number;
  cpuCores?: number;
  cpuThreads?: number;
  cpuCoresThreads?: string;
  
  gpuUsage?: number;
  gpuModel?: string;
  gpuName?: string;
  gpuTemp?: number;
  gpuVramUsedGb?: number;
  gpuVramTotalGb?: number;
  gpuVram?: string;
  gpuSharedUsedGb?: number;
  gpuSharedTotalGb?: number;
  gpuClockCoreMhz?: number;
  gpuClockMemMhz?: number;
  
  ramUsage: number;
  ramPercent?: number;
  ramTotalGb: number;
  ramUsedGb: number;
  ramFreqMhz?: number;
  ramType?: string;
  ramSpeed?: string;
  
  lanIp?: string;
  wanIp?: string;
  
  uptime?: string;
  machineName?: string;
  userName?: string;
  osVersion?: string;
  disks?: DiskInfo[];
  networkIn?: number;
  networkOut?: number;
  pingMs?: number;
  speedTest?: SpeedTestResult | null;
}

export interface Device {
  id: string;
  code?: string;
  name: string;
  /** Оригінальне hostname машини (custom name може відрізнятися). */
  machineName?: string;
  osInfo?: string;
  cpuInfo?: string;
  gpuInfo?: string;
  ramInfo?: string;
  lanIp?: string;
  wanIp?: string;
  isOnline: boolean;
  /** Relay-derived status. `isOnline` remains for existing UI callers. */
  connectionState?: 'checking' | 'online' | 'connecting' | 'connected' | 'degraded' | 'offline';
  statusUpdatedAt?: number;
  lastSeen?: number | string;
  ip?: string;
  url?: string;
  localUrl?: string;
}

export interface ProcessItem {
  pid: number;
  name: string;
  cpu: number;
  memoryMb: number;
  user?: string;
  status?: string;
  /** Executable path reported by the agent (used to match cached icons). */
  exePath?: string;
  /** Inline data-URL icon extracted from the exe on the remote PC. */
  icon?: string;
}

export interface CameraInfo {
  /** FFmpeg DirectShow device name, passed back on capture. */
  name: string;
}

export interface VolumeState {
  value: number;
  muted?: boolean;
}

export type WinLockMode = 'code' | 'site';

export interface WinLockState {
  locked: boolean;
  mode?: WinLockMode;
  unlockViaSite?: boolean;
  unlockViaCode?: boolean;
  lockedAt?: number;
}

export interface FileItem {
  name: string;
  isDirectory: boolean;
  size?: number;
  modified?: string;
  modifiedAt?: string;
  path: string;
  ext?: string;
  extension?: string;
}

export interface FileDirectoryListing {
  currentPath: string;
  parentPath: string | null;
  items: FileItem[];
}

export interface TerminalLine {
  id: string;
  type: 'input' | 'output' | 'error' | 'system';
  content: string;
  timestamp: Date;
}

export type SessionTab = 'info' | 'control' | 'files' | 'processes' | 'terminal' | 'ai';

export type AppRoute = 
  | '/' 
  | '/devices' 
  | '/guide' 
  | '/profile' 
  | '/admin'
  | '/auth/device'
  | '/agent-ui'
  | string;
