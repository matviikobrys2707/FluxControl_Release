import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { installToastKeyframes } from './utils/toast';

installToastKeyframes();

// DEV-ONLY host mock: lets the agent UI be previewed in a plain browser with
// ?mockhost — never included in production builds (import.meta.env.DEV).
if (import.meta.env.DEV && new URLSearchParams(location.search).has('mockhost')) {
  const handlers: Array<(e: { data: unknown }) => void> = [];
  (window as any).chrome = {
    webview: {
      addEventListener: (_t: string, h: (e: { data: unknown }) => void) => handlers.push(h),
      removeEventListener: (_t: string, h: (e: { data: unknown }) => void) => {
        const i = handlers.indexOf(h);
        if (i >= 0) handlers.splice(i, 1);
      },
      postMessage: (m: unknown) => console.log('[mockhost] →', m),
    },
  };
  const state = {
    computerName: 'BLAZIX-PC',
    code: '4821-7753-9012-6604',
    formattedCode: '4821-7753-9012-6604',
    relayStatus: 'connected',
    activeClients: 2,
    autoRun: true,
    minimizeToTray: true,
    user: { name: 'Blazix', email: 'blazix@gmail.com', role: 'admin', subscriptionExpiresAt: -1 },
    ffmpeg: { status: 'ready' },
  };
  // Second paint after React mounts and subscribes.
  setTimeout(() => handlers.forEach((h) => h({ data: state })), 250);
  setTimeout(() => handlers.forEach((h) => h({ data: state })), 900);
}

// DEV-ONLY session mock: with ?mocksession the relay WebSocket is replaced by
// a fake agent so the live device-session tabs (info/control/files/processes/
// terminal) can be previewed without a real PC. Dev builds only.
if (import.meta.env.DEV && new URLSearchParams(location.search).has('mocksession')) {
  const mkMetrics = () => ({
    cpuUsage: 23, cpuPercent: 23,
    cpuModel: 'Intel Core i7-12700K', cpuName: 'Intel Core i7-12700K',
    cpuTemp: 52, cpuTempC: 52, cpuFreqGhz: 4.7,
    cpuCores: 12, cpuThreads: 20, cpuCoresThreads: '12 ядер / 20 потоків',
    gpuUsage: 41, gpuModel: 'NVIDIA GeForce RTX 3070', gpuName: 'NVIDIA GeForce RTX 3070',
    gpuTemp: 61, gpuVramUsedGb: 4.2, gpuVramTotalGb: 8, gpuVram: '4.2 / 8 GB',
    gpuClockCoreMhz: 1725, gpuClockMemMhz: 14000,
    ramUsage: 58, ramPercent: 58, ramTotalGb: 32, ramUsedGb: 18.6,
    ramType: 'DDR4', ramSpeed: '3200 MHz', ramFreqMhz: 3200,
    lanIp: '192.168.1.10', wanIp: '93.175.29.114',
    uptime: '2 дн 4 год 17 хв', machineName: 'BLAZIX-PC', userName: 'blazix',
    osVersion: 'Windows 11 Pro 23H2',
    disks: [
      { name: 'C:', label: 'Система', totalGb: 931, freeGb: 412, percentUsed: 56, driveType: 'fixed', model: 'Samsung SSD 870 EVO 1TB', mediaType: 'SSD' },
      { name: 'D:', label: 'Дані', totalGb: 1863, freeGb: 1502, percentUsed: 19, driveType: 'fixed', model: 'WDC WD20EZAZ-00GGJA0 2TB', mediaType: 'HDD' },
    ],
    networkIn: 1.24, networkOut: 0.43, pingMs: 18,
    speedTest: { downloadMbps: 94.2, uploadMbps: 48.6, pingMs: 18, mode: 'auto', timestamp: Date.now() },
  });
  const processes = [
    { pid: 4124, name: 'chrome.exe', cpuPercent: 12.4, memoryMb: 842, user: 'blazix', status: 'Running', category: 'app', exePath: 'C:\\Program Files\\Google\\Chrome\\chrome.exe' },
    { pid: 9112, name: 'FluxControl.Agent.exe', cpuPercent: 3.1, memoryMb: 156, user: 'blazix', status: 'Running', category: 'background', exePath: 'C:\\Program Files\\FluxControl\\Agent.exe' },
    { pid: 2210, name: 'explorer.exe', cpuPercent: 1.7, memoryMb: 210, user: 'blazix', status: 'Running', category: 'system', exePath: 'C:\\Windows\\explorer.exe' },
    { pid: 7741, name: 'steam.exe', cpuPercent: 0.9, memoryMb: 96, user: 'blazix', status: 'Running', category: 'app', exePath: 'C:\\Program Files (x86)\\Steam\\steam.exe' },
    { pid: 8302, name: 'Code.exe', cpuPercent: 2.6, memoryMb: 512, user: 'blazix', status: 'Running', category: 'app', exePath: 'C:\\Users\\blazix\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe' },
    { pid: 1064, name: 'svchost.exe', cpuPercent: 0.2, memoryMb: 64, user: 'SYSTEM', status: 'Running', category: 'system', exePath: 'C:\\Windows\\System32\\svchost.exe' },
    { pid: 5518, name: 'Discord.exe', cpuPercent: 1.2, memoryMb: 384, user: 'blazix', status: 'Running', category: 'app', exePath: 'C:\\Users\\blazix\\AppData\\Local\\Discord\\Discord.exe' },
    { pid: 6602, name: 'Notion.exe', cpuPercent: 0.5, memoryMb: 298, user: 'blazix', status: 'Running', category: 'background', exePath: 'C:\\Users\\blazix\\AppData\\Local\\Programs\\Notion\\Notion.exe' },
    { pid: 3391, name: 'SearchIndexer.exe', cpuPercent: 0.1, memoryMb: 48, user: 'SYSTEM', status: 'Running', category: 'background', exePath: 'C:\\Windows\\System32\\SearchIndexer.exe' },
    { pid: 5102, name: 'dwm.exe', cpuPercent: 1.9, memoryMb: 122, user: 'blazix', status: 'Running', category: 'system', exePath: 'C:\\Windows\\System32\\dwm.exe' },
  ];
  const fsItems = [
    { name: 'Documents', isDirectory: true, modified: '2026-09-20 14:32', path: 'C:\\Users\\blazix\\Documents' },
    { name: 'Downloads', isDirectory: true, modified: '2026-09-23 09:15', path: 'C:\\Users\\blazix\\Downloads' },
    { name: 'Desktop', isDirectory: true, modified: '2026-09-22 18:44', path: 'C:\\Users\\blazix\\Desktop' },
    { name: 'Pictures', isDirectory: true, modified: '2026-09-01 11:02', path: 'C:\\Users\\blazix\\Pictures' },
    { name: 'report-q3.xlsx', isDirectory: false, size: 48213, modified: '2026-09-21 16:20', path: 'C:\\Users\\blazix\\report-q3.xlsx', ext: '.xlsx' },
    { name: 'setup-fluxcontrol.exe', isDirectory: false, size: 6412800, modified: '2026-09-19 10:05', path: 'C:\\Users\\blazix\\setup-fluxcontrol.exe', ext: '.exe' },
    { name: 'notes.txt', isDirectory: false, size: 1204, modified: '2026-09-18 22:41', path: 'C:\\Users\\blazix\\notes.txt', ext: '.txt' },
  ];
  class FakeAgentSocket {
    static OPEN = 1;
    static CONNECTING = 0;
    static CLOSING = 2;
    static CLOSED = 3;
    readyState = 0;
    onopen: any = null; onmessage: any = null; onclose: any = null; onerror: any = null;
    private timer: any = null;
    constructor(public url: string) {
      // &slowconnect — тримаємо оверлей «Підключення…» відкритим для скріншот-QA.
      const delay = new URLSearchParams(location.search).has('slowconnect') ? 15000 : 80;
      setTimeout(() => {
        this.readyState = 1;
        this.onopen?.();
        this.reply({ type: 'agent_status', data: { status: 'online', machineName: 'BLAZIX-PC' } });
      }, delay);
      this.timer = setInterval(() => {
        this.reply({ type: 'telemetry', data: mkMetrics() });
      }, 3000);
    }
    private reply(obj: any) {
      if (this.readyState !== 1) return;
      try { this.onmessage?.({ data: JSON.stringify(obj) }); } catch {}
    }
    send(text: string) {
      let msg: any = {};
      try { msg = JSON.parse(text); } catch { return; }
      const t = String(msg.type || '');
      if (t === 'ping') this.reply({ type: 'pong', data: {} });
      else if (t === 'telemetry') this.reply({ type: 'telemetry', data: mkMetrics() });
      else if (t === 'process_list') {
        // Мок: перші 2 іконки одразу, решта — фоном (process_icons), як реальний агент 5.8+.
        const iconSvg = (c: string) => 'data:image/svg+xml;utf8,' + encodeURIComponent(
          `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect x="2" y="2" width="28" height="28" rx="8" fill="${c}"/><circle cx="16" cy="16" r="7" fill="#fff" opacity=".9"/></svg>`);
        const palette = ['#7C3AED', '#4F46E5', '#0EA5E9', '#10B981', '#F59E0B', '#E11D48', '#8B5CF6', '#D946EF', '#14B8A6', '#F43F5E'];
        const allIcons: Record<string, string> = {};
        processes.forEach((pr, i) => { if (pr.exePath) allIcons[pr.exePath.toLowerCase()] = iconSvg(palette[i % palette.length]); });
        const firstEntries = Object.entries(allIcons).slice(0, 2);
        this.reply({ type: 'process_list', data: { processes, icons: Object.fromEntries(firstEntries) } });
        Object.entries(allIcons).slice(2).forEach(([k, v], i) => {
          setTimeout(() => this.reply({ type: 'process_icons', data: { [k]: v } }), 320 * (i + 1));
        });
      }
      else if (t === 'fs_drives') this.reply({ type: 'fs_drives', data: { drives: [
        { name: 'C:', label: 'Windows', totalGb: 931, freeGb: 412, percentUsed: 56, driveType: 'fixed', model: 'Samsung SSD 870 EVO 1TB', mediaType: 'SSD' },
        { name: 'D:', label: 'Дані', totalGb: 1863, freeGb: 1502, percentUsed: 19, driveType: 'fixed', model: 'WDC WD20EZAZ-00GGJA0 2TB', mediaType: 'HDD' },
      ] } });
      else if (t === 'fs_list') this.reply({ type: 'fs_list', data: {
        currentPath: msg.path || 'C:',
        parentPath: (msg.path || 'C:').length > 2 ? 'C:\\' : null,
        items: fsItems,
      } });
      else if (t === 'get_network_info') this.reply({ type: 'network_info', data: {
        lanIp: '192.168.1.10', wanIp: '93.175.29.114', gateway: '192.168.1.1',
        dns: '1.1.1.1, 8.8.8.8', adapter: 'Ethernet (Realtek PCIe 2.5GbE)', mac: 'A4:BB:6D:11:22:33',
      } });
      else if (t === 'volume_get' || t === 'volume') this.reply({ type: 'volume_state', data: { value: 42, muted: false } });
      else if (t.startsWith('winlock')) this.reply({ type: 'winlock_state', data: { locked: false } });
      else if (t.startsWith('timer')) this.reply({ type: 'timer_state', data: { running: false, remainingSec: 0 } });
      else if (t === 'terminal_start') this.reply({ type: 'terminal_output', data: `FLUX_CWD::${(this as any).cwd || 'C:\\Users\\blazix'}>\r\n` });
      else if (t === 'ai_memory_get') this.reply({ type: 'ai_memory_data', data: (window as any).__fcAiMem ?? null });
      else if (t === 'ai_memory_set') {
        (window as any).__fcAiMem = String(msg.data || '');
        this.reply({ type: 'ai_memory_saved', success: true, bytes: (window as any).__fcAiMem.length });
      }
      else if (t === 'terminal_input') {
        // Мок-оболонка з реальною зміною CWD: cd dir / cd.. / cd \\ / d:
        const self = this as any;
        self.cwd = self.cwd || 'C:\\Users\\blazix';
        const input = String(msg.data || '').trim();
        let out = '';
        const cd = input.match(/^(?:cd|chdir)\s+(.+)$/i) || (/^[a-zA-Z]:\s*$/.test(input) ? [input, input] : null);
        if (cd) {
          const arg = cd[1].trim();
          const base = self.cwd.replace(/\\+$/, '');
          if (/^[a-zA-Z]:\\?$/.test(arg)) self.cwd = arg.slice(0, 2).toUpperCase() + '\\';
          else if (arg === '..') self.cwd = base.split('\\').slice(0, -1).join('\\') || 'C:\\';
          else if (/^\.\./.test(arg)) {
            const ups = (arg.match(/\.\./g) || []).length;
            const rest = arg.replace(/^(\.\.\\?)+/, '');
            const parts = base.split('\\');
            for (let i = 0; i < ups && parts.length > 1; i++) parts.pop();
            self.cwd = (rest ? parts.join('\\') + '\\' + rest : parts.join('\\')) || 'C:\\';
          } else if (/^[a-zA-Z]:/.test(arg)) self.cwd = arg.replace(/\//g, '\\');
          else self.cwd = base + '\\' + arg.replace(/\//g, '\\');
        } else if (/^dir$/i.test(input)) {
          out = ` Directory of ${self.cwd}\r\n\r\n2026-09-20  10:00    <DIR>          .\r\n2026-09-20  10:00             1 204 notes.txt\r\n`;
        } else if (/^echo /i.test(input)) {
          out = input.slice(5) + '\r\n';
        } else if (input.includes('CLIP_OK')) {
          out = 'CLIP_OK\r\n';
        }
        this.reply({ type: 'terminal_output', data: `\r\n${out}\r\nFLUX_CWD::${self.cwd}> ` });
      }
      else if (t === 'terminal_kill') { /* mock shell stopped */ }
      else if (t === 'mouse_move_abs' || t === 'mouse_click' || t === 'key_text' || t === 'key_press' || t === 'shortcut' || t === 'open_url') {
        // AI-керування: імітуємо реакцію екрана, віддаючи свіжий «скриншот».
        const canvas2 = document.createElement('canvas'); canvas2.width = 640; canvas2.height = 360;
        const c2 = canvas2.getContext('2d')!;
        const grad2 = c2.createLinearGradient(0, 0, 640, 360);
        grad2.addColorStop(0, '#312e81'); grad2.addColorStop(1, '#155e75');
        c2.fillStyle = grad2; c2.fillRect(0, 0, 640, 360);
        c2.fillStyle = 'rgba(255,255,255,.92)'; c2.font = 'bold 26px sans-serif';
        c2.fillText('BLAZIX-PC — після дії ' + t, 36, 186);
        const url2 = canvas2.toDataURL('image/jpeg', 0.7);
        this.reply({ type: 'screenshot_response', data: { imageBase64: url2.split(',')[1] } });
      }
      else if (t === 'capture_screenshot') {
        const canvas = document.createElement('canvas'); canvas.width = 640; canvas.height = 360;
        const ctx = canvas.getContext('2d')!;
        const grad = ctx.createLinearGradient(0, 0, 640, 360);
        grad.addColorStop(0, '#1e1b4b'); grad.addColorStop(1, '#0c4a6e');
        ctx.fillStyle = grad; ctx.fillRect(0, 0, 640, 360);
        ctx.strokeStyle = 'rgba(255,255,255,.14)';
        for (let i = 0; i < 640; i += 64) { ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, 360); ctx.stroke(); }
        ctx.fillStyle = 'rgba(255,255,255,.92)'; ctx.font = 'bold 26px sans-serif';
        ctx.fillText('BLAZIX-PC — робочий стіл (мок)', 36, 186);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
        this.reply({ type: 'screenshot_response', data: { imageBase64: dataUrl.split(',')[1] } });
      }
      else if (t === 'fs_download_file') {
        const dlPath = String(msg.path || '');
        const dlName = dlPath.split('\\').pop() || 'file';
        // Маленький валідний mp4 (1 кадр) для картки-відео в чаті; інакше — текст.
        const mp4 = btoa('FCMOCKVIDEO'.repeat(230)); // валідний base64 (заповнення лише в кінці)
        this.reply({ type: 'fs_download_file_result', data: { success: true, path: dlPath, name: dlName, base64: /\.(mp4|webm)$/i.test(dlName) ? mp4 : btoa('Mock file: ' + dlPath) } });
      }
      else if (t === 'camera_list') this.reply({ type: 'camera_list', data: { cameras: ['Integrated Webcam HD', 'USB Live Camera'] } });
      else if (t === 'record_capture') {
        const src = String(msg.source || 'screen');
        const secs = Number(msg.seconds || 30);
        setTimeout(() => {
          this.reply({ type: 'recording_result', data: { success: true, name: `Mock_${src}_${Date.now()}.mp4`, videoBase64: 'AAAAIGZ0eXBpc29tAAACAGlzb21pc28yYXZjMW1wNDE=' } });
        }, Math.min(secs, 4) * 1000);
      }
      else if (t.startsWith('webcam')) {
        const canvas3 = document.createElement('canvas'); canvas3.width = 640; canvas3.height = 360;
        const c3 = canvas3.getContext('2d')!;
        c3.fillStyle = '#111827'; c3.fillRect(0, 0, 640, 360);
        c3.fillStyle = 'rgba(103,232,249,.9)'; c3.font = 'bold 24px sans-serif';
        c3.fillText('Мок-камера: кадр знято', 170, 186);
        const d3 = canvas3.toDataURL('image/jpeg', 0.7);
        setTimeout(() => this.reply({ type: 'webcam_response', data: { imageBase64: d3.split(',')[1] } }), 800);
      }
    }
    close() {
      this.readyState = 3;
      if (this.timer) clearInterval(this.timer);
      this.onclose?.();
    }
    addEventListener() {}
    removeEventListener() {}
    dispatchEvent() { return false; }
  }
  (window as any).WebSocket = FakeAgentSocket as any;
  console.log('[mocksession] Fake agent WebSocket installed');
  // DEV-only: зі стабом AI локально не летимо на живий Render — усі запити
  // /api/ai/chat (обидва ендпоінти) урізаємо на локальний проксі.
  if (new URLSearchParams(location.search).has('stubai')) {
    const origFetch = window.fetch.bind(window);
    (window as any).fetch = (input: any, init?: any) => {
      const u = typeof input === 'string' ? input : String(input?.url ?? '');
      if (u.includes('/api/ai/chat') || u.includes('/api/ai/status')) return origFetch(u.replace(/^https?:\/\/[^/]+/, ''), init);
      return origFetch(input, init);
    };
    console.log('[mocksession] AI fetch redirected to local stub');
  }
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
