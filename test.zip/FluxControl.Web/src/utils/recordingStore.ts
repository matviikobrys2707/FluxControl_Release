/**
 * Глобальний стан запису (екрана/камери) — живе поза React-деревом, тому
 * індикатор запису видно НА БУДЬ-ЯКІЙ сторінці сайту, доки триває запис,
 * навіть якщо користувач пішов з вкладки «Керувати» або підключення.
 */

export type ActiveRecording = {
  source: 'screen' | 'webcam';
  total: number;       // тривалість, с
  startedAt: number;   // Date.now()
  deviceName: string;
} | null;

type Listener = (rec: ActiveRecording) => void;

let current: ActiveRecording = null;
const listeners = new Set<Listener>();

export const recordingStore = {
  get(): ActiveRecording {
    return current;
  },
  set(rec: ActiveRecording) {
    current = rec;
    listeners.forEach(fn => {
      try { fn(rec); } catch {}
    });
  },
  subscribe(fn: Listener): () => void {
    listeners.add(fn);
    return () => { listeners.delete(fn); };
  }
};
