/**
 * FluxControl toast notifications — site-wide, DOM-based so any tab,
 * context or service can call it without React plumbing.
 *
 * Replaces the old single green banner with a right-top stack of
 * animated, typed toasts (success / error / warn / info) with close
 * buttons and an optional lifetime progress bar.
 */
export type ToastType = 'success' | 'error' | 'warn' | 'info';

export interface ToastOptions {
  /** Bold first line. Defaults to a per-type title. */
  title?: string;
  /** Auto-dismiss timeout in ms. 0 = sticky until closed. */
  durationMs?: number;
  /** Show the animated lifetime progress bar (default: true when durationMs > 0). */
  progress?: boolean;
}

const ICONS: Record<ToastType, string> = {
  success: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>',
  error: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M15 9l-6 6M9 9l6 6"/></svg>',
  warn: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 9v4M12 17h.01"/><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/></svg>',
  info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>',
};

const TITLES: Record<ToastType, string> = {
  success: 'Готово',
  error: 'Помилка',
  warn: 'Увага',
  info: 'FluxControl',
};

const CLOSE_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg>';

function ensureStack(): HTMLElement {
  let stack = document.getElementById('fc-toast-stack');
  if (!stack) {
    stack = document.createElement('div');
    stack.id = 'fc-toast-stack';
    stack.className = 'fc-toast-stack';
    stack.setAttribute('aria-live', 'polite');
    document.body.appendChild(stack);
  }
  return stack;
}

/** Show a typed toast. Returns the toast element (for manual dismissal). */
export function showToast(message: string, type: ToastType = 'info', options: ToastOptions = {}): HTMLElement | null {
  if (typeof document === 'undefined') return null;

  const stack = ensureStack();

  // Keep the stack readable — drop the oldest toast beyond 5.
  while (stack.children.length >= 5) {
    const first = stack.firstElementChild;
    if (first) first.remove();
  }

  const duration = options.durationMs ?? 4200;
  const showProgress = options.progress ?? duration > 0;

  const toast = document.createElement('div');
  toast.className = `fc-toast fc-toast-${type}`;
  toast.setAttribute('role', 'status');

  const icon = document.createElement('span');
  icon.className = 'fc-toast-icon';
  icon.innerHTML = ICONS[type] ?? ICONS.info;

  const body = document.createElement('div');
  body.className = 'fc-toast-body';
  const titleText = options.title ?? TITLES[type];
  const titleEl = document.createElement('span');
  titleEl.className = 'fc-toast-title';
  titleEl.textContent = titleText;
  const msgEl = document.createElement('span');
  msgEl.className = 'fc-toast-msg';
  msgEl.textContent = message;
  body.appendChild(titleEl);
  if (message && message !== titleText) body.appendChild(msgEl);

  const close = document.createElement('button');
  close.className = 'fc-toast-close';
  close.setAttribute('aria-label', 'Закрити');
  close.innerHTML = CLOSE_SVG;
  close.addEventListener('click', () => dismiss());

  toast.appendChild(icon);
  toast.appendChild(body);
  toast.appendChild(close);
  if (showProgress && duration > 0) {
    const bar = document.createElement('span');
    bar.className = 'fc-toast-progress';
    bar.style.animation = `fcToastShrink ${duration}ms linear forwards`;
    toast.appendChild(bar);
  }

  stack.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add('show'));

  let gone = false;
  function dismiss() {
    if (gone) return;
    gone = true;
    toast.classList.remove('show');
    window.setTimeout(() => toast.remove(), 260);
  }
  (toast as HTMLElement & { dismiss?: () => void }).dismiss = dismiss;

  if (duration > 0) window.setTimeout(dismiss, duration);

  return toast;
}

export const toast = {
  success: (msg: string, o?: ToastOptions) => showToast(msg, 'success', o),
  error: (msg: string, o?: ToastOptions) => showToast(msg, 'error', o),
  warn: (msg: string, o?: ToastOptions) => showToast(msg, 'warn', o),
  info: (msg: string, o?: ToastOptions) => showToast(msg, 'info', o),
};

/**
 * Backwards-compatible entry point used by contexts/services.
 * Previously a single purple banner; now a proper info toast.
 */
export function showGlobalToast(message: string, durationMs = 4000): void {
  showToast(message, 'info', { durationMs });
}

/** Injected once by main.tsx: keyframes for the toast lifetime bar. */
export function installToastKeyframes(): void {
  if (typeof document === 'undefined') return;
  if (document.getElementById('fc-toast-keyframes')) return;
  const style = document.createElement('style');
  style.id = 'fc-toast-keyframes';
  style.textContent = '@keyframes fcToastShrink { from { transform: scaleX(1); } to { transform: scaleX(0); } }';
  document.head.appendChild(style);
}
