/**
 * FluxControl AGENT toast notifications — used ONLY inside the desktop
 * window (WebView2 hosted UI). Deliberately styled differently from the
 * website toasts (site: top-right tile with square icon; agent: bottom-right
 * dark-glass pill with a violet gradient accent bar and slide-up motion) so
 * the desktop app reads as its own branded surface.
 *
 * Self-contained: injects its own stylesheet, no dependency on index.css.
 */

export type AgentToastType = 'success' | 'error' | 'warn' | 'info';

const STYLE_ID = 'fcax-toast-style';
const STACK_ID = 'fcax-toast-stack';

const ICONS: Record<AgentToastType, string> = {
  success: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>',
  error: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M15 9l-6 6M9 9l6 6"/></svg>',
  warn: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 9v4M12 17h.01"/><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/></svg>',
  info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>',
};

const TITLES: Record<AgentToastType, string> = {
  success: 'Готово',
  error: 'Помилка',
  warn: 'Увага',
  info: 'FluxControl',
};

const CLOSE_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg>';

const BRAND_SVG = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M13 2 3 14h7v8l10-12h-7l0-8z"/></svg>';

function ensureStyle(): void {
  if (document.getElementById(STYLE_ID)) return;
  const style = document.createElement('style');
  style.id = STYLE_ID;
  style.textContent = `
#fcax-toast-stack { position: fixed; right: 14px; bottom: 14px; z-index: 2147483000; display: flex; flex-direction: column-reverse; gap: 8px; width: min(88vw, 308px); pointer-events: none; }
.fcax-toast { pointer-events: auto; position: relative; display: flex; align-items: flex-start; gap: 10px; padding: 11px 12px 12px 16px; border-radius: 14px;
  background: linear-gradient(160deg, rgba(23,21,38,.985), rgba(13,12,24,.985));
  border: 1px solid rgba(255,255,255,.09); border-left: none;
  box-shadow: 0 18px 44px rgba(0,0,0,.65), 0 2px 10px rgba(0,0,0,.4);
  color: #ececf4; font-family: 'Segoe UI Variable','Segoe UI',system-ui,sans-serif; font-size: 12px; font-weight: 600; line-height: 1.45;
  opacity: 0; transform: translateY(14px) scale(.97); transition: opacity .22s ease, transform .3s cubic-bezier(.16,1,.3,1); overflow: hidden; }
.fcax-toast.show { opacity: 1; transform: none; }
.fcax-toast::before { content: ''; position: absolute; left: 0; top: 8px; bottom: 8px; width: 4px; border-radius: 0 4px 4px 0; background: linear-gradient(180deg, #8b5cf6, #6366f1); }
.fcax-toast.fcax-success::before { background: linear-gradient(180deg, #34d399, #059669); }
.fcax-toast.fcax-error::before { background: linear-gradient(180deg, #fb7185, #e11d48); }
.fcax-toast.fcax-warn::before { background: linear-gradient(180deg, #fbbf24, #d97706); }
.fcax-icon { display: grid; place-items: center; width: 26px; height: 26px; flex: 0 0 auto; border-radius: 9px; margin-top: 1px; }
.fcax-icon svg { width: 13px; height: 13px; }
.fcax-body { flex: 1; min-width: 0; padding-right: 2px; }
.fcax-title { display: flex; align-items: center; gap: 5px; color: #fff; font-size: 12px; font-weight: 800; letter-spacing: .01em; }
.fcax-brand { display: inline-grid; place-items: center; width: 11px; height: 11px; color: #a78bfa; }
.fcax-brand svg { width: 11px; height: 11px; }
.fcax-msg { display: block; color: #a9adbf; font-size: 11.5px; margin-top: 2px; word-break: break-word; }
.fcax-close { flex: 0 0 auto; display: grid; place-items: center; width: 20px; height: 20px; margin: 0 -3px 0 0; border-radius: 7px; color: #6b6f82; cursor: pointer; background: transparent; }
.fcax-close:hover { color: #fff; background: rgba(255,255,255,.08); }
.fcax-close svg { width: 11px; height: 11px; }
.fcax-progress { position: absolute; left: 16px; right: 0; bottom: 0; height: 2.5px; border-radius: 3px 0 0 0; transform-origin: left; background: linear-gradient(90deg, #8b5cf6, #6366f1); }
.fcax-success .fcax-progress { background: linear-gradient(90deg, #34d399, #10b981); }
.fcax-error .fcax-progress { background: linear-gradient(90deg, #fb7185, #f43f5e); }
.fcax-warn .fcax-progress { background: linear-gradient(90deg, #fbbf24, #f59e0b); }
@keyframes fcaxShrink { from { transform: scaleX(1); } to { transform: scaleX(0); } }
@media (prefers-reduced-motion: reduce) { .fcax-toast { transition: opacity .15s ease; transform: none; } }
`;
  document.head.appendChild(style);
}

function ensureStack(): HTMLElement {
  ensureStyle();
  let stack = document.getElementById(STACK_ID);
  if (!stack) {
    stack = document.createElement('div');
    stack.id = STACK_ID;
    stack.setAttribute('aria-live', 'polite');
    document.body.appendChild(stack);
  }
  return stack;
}

export interface AgentToastOptions {
  /** Bold first line. Defaults to a per-type title. */
  title?: string;
  /** Auto-dismiss timeout in ms. 0 = sticky until closed. Default 3600. */
  durationMs?: number;
}

/** Show an agent-styled toast. Returns the toast element. */
export function showAgentToast(message: string, type: AgentToastType = 'info', options: AgentToastOptions = {}): HTMLElement | null {
  if (typeof document === 'undefined') return null;
  const stack = ensureStack();

  while (stack.children.length >= 4) {
    const first = stack.firstElementChild;
    if (first) first.remove();
  }

  const duration = options.durationMs ?? 3600;

  const toast = document.createElement('div');
  toast.className = `fcax-toast fcax-${type}`;
  toast.setAttribute('role', 'status');

  const icon = document.createElement('span');
  icon.className = 'fcax-icon';
  icon.innerHTML = ICONS[type] ?? ICONS.info;
  const iconBg: Record<AgentToastType, string> = {
    success: 'color:#34d399;background:rgba(16,185,129,.13);',
    error: 'color:#fb7185;background:rgba(244,63,94,.13);',
    warn: 'color:#fbbf24;background:rgba(245,158,11,.13);',
    info: 'color:#a78bfa;background:rgba(139,92,246,.14);',
  };
  icon.setAttribute('style', iconBg[type] ?? iconBg.info);

  const body = document.createElement('div');
  body.className = 'fcax-body';
  const titleText = options.title ?? TITLES[type];
  const titleEl = document.createElement('span');
  titleEl.className = 'fcax-title';
  titleEl.innerHTML = `<span class="fcax-brand">${BRAND_SVG}</span>`;
  const titleTxt = document.createElement('span');
  titleTxt.textContent = titleText;
  titleEl.appendChild(titleTxt);
  const msgEl = document.createElement('span');
  msgEl.className = 'fcax-msg';
  msgEl.textContent = message;
  body.appendChild(titleEl);
  if (message && message !== titleText) body.appendChild(msgEl);

  const close = document.createElement('button');
  close.className = 'fcax-close';
  close.setAttribute('aria-label', 'Закрити');
  close.innerHTML = CLOSE_SVG;
  close.addEventListener('click', () => dismiss());

  toast.appendChild(icon);
  toast.appendChild(body);
  toast.appendChild(close);
  if (duration > 0) {
    const bar = document.createElement('span');
    bar.className = 'fcax-progress';
    bar.style.animation = `fcaxShrink ${duration}ms linear forwards`;
    toast.appendChild(bar);
  }

  stack.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add('show'));

  let gone = false;
  function dismiss() {
    if (gone) return;
    gone = true;
    toast.classList.remove('show');
    window.setTimeout(() => toast.remove(), 280);
  }
  (toast as HTMLElement & { dismiss?: () => void }).dismiss = dismiss;
  if (duration > 0) window.setTimeout(dismiss, duration);

  return toast;
}

export const agentToast = {
  success: (msg: string, o?: AgentToastOptions) => showAgentToast(msg, 'success', o),
  error: (msg: string, o?: AgentToastOptions) => showAgentToast(msg, 'error', o),
  warn: (msg: string, o?: AgentToastOptions) => showAgentToast(msg, 'warn', o),
  info: (msg: string, o?: AgentToastOptions) => showAgentToast(msg, 'info', o),
};
