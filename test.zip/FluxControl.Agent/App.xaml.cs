﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace FluxControl.Agent;

public partial class App : System.Windows.Application
{
    private static Mutex? _singleInstanceMutex;

    protected override void OnStartup(System.Windows.StartupEventArgs e)
    {
        // Log FIRST, before anything can fail — every launch attempt must leave
        // a trace in %AppData%\FluxControl\agent.log so invisible startups are debuggable.
        try { Log($"App.OnStartup args=[{string.Join(" ", e.Args)}]"); } catch { }

        try
        {
            const string mutexName = "FluxControl_SingleInstance_Mutex_Blazix";
            _singleInstanceMutex = new Mutex(true, mutexName, out bool isNewInstance);

            if (!isNewInstance)
            {
                // Another (possibly hung or tray-hidden) instance already holds the mutex.
                try { Log("Single-instance mutex already held — exiting. Existing instance keeps running."); } catch { }
                System.Windows.MessageBox.Show(
                    "FluxControl вже запущено у фоновому режимі.\r\n\r\n" +
                    "• Перевірте приховані значки трею (стрілка ^ біля годинника)\r\n" +
                    "• Або завершіть старий процес у Диспетчері завдань (FluxControl.exe) і запустіть знову.",
                    "FluxControl", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
                Shutdown();
                return;
            }
            GC.KeepAlive(_singleInstanceMutex);
        }
        catch (Exception ex)
        {
            // Abandoned/broken mutex must never block the app from starting.
            try { Log($"Mutex check failed (continuing anyway): {ex.Message}"); } catch { }
        }

        // Surface ANY startup failure (XAML parse error, constructor crash, missing
        // runtime piece) as a visible dialog + log entry instead of a silent death.
        HookGlobalExceptionHandlers();

        try
        {
            base.OnStartup(e);
        }
        catch (Exception ex)
        {
            try { Log($"FATAL startup exception: {ex}"); } catch { }
            System.Windows.MessageBox.Show(
                "FluxControl не зміг запуститися. Деталі:\r\n\r\n" + ex,
                "FluxControl — помилка запуску", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
            Shutdown(-1);
            return;
        }

        // Запуск програми: спочатку bootstrap-встановлення (красивий
        // інсталятор довантажує відсутні файли з GitHub Releases),
        // потім головне вікно.
        StartAppAsync();
    }

    private async void StartAppAsync()
    {
        // Самодостатній EXE (ТЗ): інтерфейс і іконка вбудовані в збірку —
        // витягуємо їх у сховище %AppData%\FluxControl (WebView2 читає html
        // з диска; exe може лежати де завгодно і нічого поруч не створює).
        try { Services.RuntimeFiles.EnsureRuntimeFiles(); }
        catch (Exception ex) { try { Log($"RuntimeFiles failed: {ex.Message}"); } catch { } }

        // Bootstrap (ТЗ користувача): при відкритті програма ПЕРЕВІРЯЄ всі
        // файли; якщо якихось бракує — показує вікно відновлення (витягує
        // вбудовані файли з самої збірки, без мережі).
        try
        {
            var missing = Services.BootstrapService.FindMissingFiles();
            if (missing.Count > 0)
            {
                Log($"Bootstrap: missing {missing.Count} file(s): {string.Join(", ", missing)}");
                var installer = new Services.InstallerWindow(Services.InstallerWindow.InstallerMode.Install);
                var ok = await installer.RunInstallAsync(missing);
                if (!ok)
                {
                    Log("Bootstrap cancelled or failed — exiting.");
                    Shutdown();
                    return;
                }
            }
        }
        catch (Exception ex)
        {
            try { Log($"Bootstrap step failed (continuing startup): {ex.Message}"); } catch { }
        }

        // Фонова синхронізація робочих файлів з манифестом version.json
        // (main-гілка репозиторію релізів): UI/іконку можна оновити без
        // пересборки exe — звіряється sha256 і довантажуються змінені.
        _ = Task.Run(Services.BootstrapService.SyncExtraFilesFromManifest);

        // Вікно створюється вручну (StartupUri прибрано з App.xaml) — саме це
        // дає --minimized (автозапуск Windows) стартувати повністю невидимо.
        // MainWindow сам керує приховуванням (Opacity=0 + minimized + без
        // кнопки на панелі завдань), але проганяє весь стартовий пайплайн
        // у Loaded (WebView2, WebSocket-сервер на 5080, релей, FFmpeg).
        try
        {
            var window = new MainWindow();
            MainWindow = window;
            window.Show(); // при --minimized жодного кадру не буде видно
        }
        catch (Exception ex)
        {
            try { Log($"FATAL window creation exception: {ex}"); } catch { }
            System.Windows.MessageBox.Show(
                "FluxControl не зміг запуститися. Деталі:\r\n\r\n" + ex,
                "FluxControl — помилка запуску", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
            Shutdown(-1);
        }
    }

    private void HookGlobalExceptionHandlers()
    {
        // UI-thread + async void crashes (e.g. WebView2 init in MainWindow_Loaded).
        DispatcherUnhandledException += (s, args) =>
        {
            try { Log($"Dispatcher exception: {args.Exception}"); } catch { }
            try
            {
                System.Windows.MessageBox.Show(
                    "Помилка в інтерфейсі FluxControl:\r\n\r\n" + args.Exception.Message +
                    "\r\n\r\n(повний текст у %AppData%\\FluxControl\\agent.log)",
                    "FluxControl", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
            }
            catch { }
            args.Handled = true; // keep the app alive instead of vanishing
            if (MainWindow == null)
            {
                // Startup failed before any window was created (e.g. XAML parse error)
                // — a headless zombie process would be useless. Exit with the dialog above shown.
                try { Log("No MainWindow after dispatcher exception — shutting down."); } catch { }
                Shutdown(-1);
            }
        };

        // Background-thread fatal crashes — process is terminating, but leave a trace + visible reason.
        AppDomain.CurrentDomain.UnhandledException += (s, args) =>
        {
            try { Log($"AppDomain UNHANDLED (terminating={args.IsTerminating}): {args.ExceptionObject}"); } catch { }
            if (args.IsTerminating)
            {
                try
                {
                    System.Windows.MessageBox.Show(
                        "FluxControl аварійно завершився:\r\n\r\n" + args.ExceptionObject,
                        "FluxControl", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
                }
                catch { }
            }
        };

        // Unobserved task faults are logged only (finalizer thread — no dialogs here).
        System.Threading.Tasks.TaskScheduler.UnobservedTaskException += (s, args) =>
        {
            try { Log($"Unobserved task exception: {args.Exception}"); } catch { }
            args.SetObserved();
        };
    }

    protected override void OnExit(ExitEventArgs e)
    {
        try { Log($"App.OnExit code={e.ApplicationExitCode}"); } catch { }
        base.OnExit(e);
    }

    public static void Log(string message)
    {
        try
        {
            var logDir = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FluxControl");
            System.IO.Directory.CreateDirectory(logDir);
            var logFile = System.IO.Path.Combine(logDir, "agent.log");
            System.IO.File.AppendAllText(logFile, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff}] {message}\r\n");
        }
        catch { }
        System.Diagnostics.Debug.WriteLine($"[{DateTime.Now:HH:mm:ss}] {message}");
    }
}
