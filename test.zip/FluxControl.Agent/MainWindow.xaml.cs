﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Threading;
using FluxControl.Agent.Services;

namespace FluxControl.Agent;

public class UserSessionData
{
    public string id { get; set; } = string.Empty;
    public string name { get; set; } = string.Empty;
    public string email { get; set; } = string.Empty;
    public string picture { get; set; } = string.Empty;
    public string role { get; set; } = "user";
    public long? subscriptionExpiresAt { get; set; } = null;
}

public partial class MainWindow : Window
{
    [DllImport("user32.dll")]
    public static extern bool ReleaseCapture();

    [DllImport("user32.dll")]
    public static extern IntPtr SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);

    private const int WM_NCLBUTTONDOWN = 0xA1;
    private const int HTCAPTION = 0x2;

    // ---- Window corner rounding (opaque window; OS draws the corners) ----
    [DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);

    private const int DWMWA_USE_IMMERSIVE_DARK_MODE = 20;
    private const int DWMWA_BORDER_COLOR = 34;
    private const int DWMWA_WINDOW_CORNER_PREFERENCE = 33;
    private const int DWMWCP_ROUND = 2;          // preference value, not attribute
    private const int DWMWA_COLOR_NONE = unchecked((int)0xFFFFFFFE); // default system border

    [DllImport("gdi32.dll")]
    private static extern IntPtr CreateRoundRectRgn(int x1, int y1, int x2, int y2, int w, int h);

    [DllImport("user32.dll")]
    private static extern int SetWindowRgn(IntPtr hWnd, IntPtr hRgn, bool bRedraw);

    private bool _regionApplied;                 // Win10 fallback state
    private static readonly bool IsWin11OrNewer = Environment.OSVersion.Version.Build >= 22000;

    private readonly SystemService _systemService;
    private readonly InputService _inputService;
    private readonly ProcessManagerService _processService;
    private readonly FileManagerService _fileService;
    private readonly MediaService _mediaService;
    private readonly PairingService _pairingService;
    private readonly WebSocketServerService _serverService;
    private readonly RelayClientService _relayService;
    private readonly WinLockService _winLockService;

    private readonly NotifyIcon _notifyIcon;
    private System.Drawing.Icon? _appIcon;
    private bool _minimizeToTray = true;
    private bool _isExplicitExit = false;
    private bool _startedMinimized;   // запуск із --minimized (автозапуск Windows)
    private bool _startupHideDone;    // невидима фаза запуску завершена
    private readonly Dictionary<string, PairingRequest> _pendingRequests = new();

    private readonly string _userSessionFilePath;
    private UserSessionData? _currentUser;
    private static readonly HttpClient _authHttpClient = new() { Timeout = TimeSpan.FromSeconds(5) };
    private DispatcherTimer? _metricsTimer;
    private DispatcherTimer? _subscriptionTimer;

    // Startup dependency + speedtest state surfaced to the embedded UI
    private string _ffmpegStatus = "checking"; // checking | ready | missing | installing | error
    private string _ffmpegStage = "перевірка…";
    private int _ffmpegPercent;
    private string? _ffmpegError;
    private bool _dependencyPipelineStarted;
    private bool _overlayHidden;
    // QR generation is expensive (bitmap render + base64). It only depends on
    // the connect URL, so cache it instead of rebuilding every state tick.
    private string _cachedQrBase64 = string.Empty;
    private string _cachedQrUrl = string.Empty;

    public MainWindow()
    {
        App.Log("MainWindow constructor entering...");
        InitializeComponent();
        App.Log("InitializeComponent passed.");

        _systemService = new SystemService();
        _inputService = new InputService();
        _processService = new ProcessManagerService();
        _fileService = new FileManagerService();
        _mediaService = new MediaService();
        _pairingService = new PairingService();
        App.Log("Services instantiated.");

        var appData = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FluxControl");
        Directory.CreateDirectory(appData);
        _userSessionFilePath = Path.Combine(appData, "user_session.json");
        LoadUserSession();

        _serverService = new WebSocketServerService(
            _pairingService,
            _systemService,
            _inputService,
            _processService,
            _fileService,
            _mediaService,
            5080
        );

        _relayService = new RelayClientService(
            _pairingService,
            _systemService,
            _inputService,
            _processService,
            _fileService,
            _mediaService,
            "https://fluxcontrol-backend.onrender.com"
        );
        _relayService.OnConnectionStatusChanged += (isConnected) =>
        {
            Dispatcher.Invoke(SendStateToWebView);
        };
        _relayService.OnStateChanged += (status, err) =>
        {
            Dispatcher.Invoke(SendStateToWebView);
        };
        _relayService.SpeedTest.OnResult += (result) =>
        {
            try { Dispatcher.Invoke(SendStateToWebView); } catch { }
        };
        _winLockService = new WinLockService();
        _relayService.SetWinLockService(_winLockService);
        _relayService.Start();

        // System tray setup — фирменная иконка из внедрённого ресурса logo.ico
        _appIcon = LoadAppIcon();
        _notifyIcon = new NotifyIcon
        {
            Icon = _appIcon ?? SystemIcons.Shield,
            Text = "FluxControl",
            Visible = true
        };

        var contextMenu = new ContextMenuStrip();
        contextMenu.Items.Add("Відкрити FluxControl", null, (s, e) => ShowAndActivate());
        contextMenu.Items.Add("Скопіювати посилання для сайту", null, (s, e) => CopyWebLink());

        // Перемикач автозапуску прямо в треї: клік — і галочка в реєстрі
        // HKCU\...\Run або поставлена, або знята. Стан оновлюється щоразу
        // перед відкриттям меню, щоб завжди відповідати реєстру.
        var autoRunMenuItem = new ToolStripMenuItem("Автозапуск із Windows")
        {
            Checked = AutoRunService.IsAutoRunEnabled()
        };
        autoRunMenuItem.Click += (s, e) =>
        {
            bool enable = !AutoRunService.IsAutoRunEnabled();
            if (AutoRunService.SetAutoRun(enable))
            {
                autoRunMenuItem.Checked = enable;
                try
                {
                    _notifyIcon.ShowBalloonTip(1800, "FluxControl",
                        enable ? "Автозапуск із Windows увімкнено" : "Автозапуск із Windows вимкнено",
                        ToolTipIcon.Info);
                }
                catch { }
                SendStateToWebView();
            }
        };
        contextMenu.Items.Add(autoRunMenuItem);
        contextMenu.Items.Add("Перевірити оновлення", null, (s, e) => CheckUpdatesManually());
        contextMenu.Opening += (s, e) => autoRunMenuItem.Checked = AutoRunService.IsAutoRunEnabled();
        contextMenu.Items.Add("-");
        contextMenu.Items.Add("Вихід", null, (s, e) =>
        {
            _isExplicitExit = true;
            _notifyIcon.Visible = false;
            System.Windows.Application.Current.Shutdown();
        });
        _notifyIcon.ContextMenuStrip = contextMenu;
        _notifyIcon.DoubleClick += (s, e) => ShowAndActivate();

        // Запуск з --minimized (автозапуск Windows або інсталятор): вікно має
        // бути ПОВНІСТЮ невидимим — тільки іконка в треї, нічого на панелі
        // завдань, без перехоплення фокуса. StartupUri більше немає, тож нічого
        // не покаже вікно поверх цього. Одноразовий "показ" із Opacity=0 потрібен,
        // бо весь стартовий пайплайн (WebView2, WebSocket 5080, релей) живе в
        // Loaded — він відпрацює, поки вікно прозоре.
        var args = Environment.GetCommandLineArgs();
        _startedMinimized = args.Any(a =>
            a.Equals("--minimized", StringComparison.OrdinalIgnoreCase) ||
            a.Equals("--hidden", StringComparison.OrdinalIgnoreCase) ||
            a.Equals("--background", StringComparison.OrdinalIgnoreCase) ||
            a.Equals("--silent", StringComparison.OrdinalIgnoreCase) ||
            a.Equals("/minimized", StringComparison.OrdinalIgnoreCase));
        if (_startedMinimized)
        {
            ShowActivated = false;          // не крадемо фокус при вході в Windows
            ShowInTaskbar = false;          // жодної кнопки на панелі завдань
            Opacity = 0d;                   // невидимо навіть один кадр
            WindowState = WindowState.Minimized;
        }

        AutoRunService.EnsureFirstRunAutoRun();

        // Re-engage WinLock if the PC rebooted while locked (also fires with --minimized).
        _winLockService.TryRestoreOnStartup();

        // Re-arm (or execute) a power timer that was pending before the app exited.
        _relayService.ScheduledActions.TryRestore();

        // OS-level window chrome. The window is OPAQUE (#05050A); its corners
        // are rounded by the operating system: DWMWCP_ROUND on Windows 11
        // (anti-aliased, with the native shadow) or a GDI round region as the
        // Windows 10 fallback. No transparency is involved anywhere, so the
        // WebView2 HWND keeps normal mouse input and no «острые прозрачные
        // штуки» can appear — the page never draws window chrome itself.
        SourceInitialized += (s, e) =>
        {
            try
            {
                ApplyOsWindowRounding();
                CenterWindowOnScreen();
                PostChromeState();
            }
            catch { }
        };

        // Maximized state changes corner handling: DWM un-rounds maximized
        // windows by itself; the Win10 region must be removed/re-applied here.
        StateChanged += (s, e) =>
        {
            if (!IsWin11OrNewer) ApplyOrClearWin10Region();
            PostChromeState();
        };
        // One precise re-center once the real content size is known — fixes the
        // «окно чуть правее центра» на масштабах DPI, где встроенное центрирование
        // WPF считает позицию по устаревшим значениям.
        bool centeredOnce = false;
        ContentRendered += (s, e) =>
        {
            if (!centeredOnce)
            {
                centeredOnce = true;
                CenterWindowOnScreen();
            }
        };

        // Pairing events
        _pairingService.OnPairingRequested += (request) =>
        {
            Dispatcher.Invoke(() =>
            {
                _pendingRequests[request.RequestId] = request;
                if (!IsVisible)
                {
                    _notifyIcon.ShowBalloonTip(5000, "FluxControl", $"Запит на підключення від {request.DeviceName}", ToolTipIcon.Info);
                }
                PostJsonToWebView(new
                {
                    type = "pairing_request",
                    requestId = request.RequestId,
                    deviceName = request.DeviceName,
                    ip = request.IpAddress
                });
            });
        };

        _pairingService.OnClientsChanged += () =>
        {
            Dispatcher.Invoke(SendStateToWebView);
        };

        Loaded += MainWindow_Loaded;
    }

    /// <summary>
    /// Windows notification policy: ЛИБО всплывашка внутри программы (когда
    /// окно видно и активно — рисует WebView-тост), ЛИБО уведомление Windows
    /// (когда окно скрыто/свёрнуто/неактивно). Никогда оба сразу.
    /// </summary>
    private bool UserCanSeeWindow()
    {
        return IsVisible && WindowState != WindowState.Minimized && IsActive;
    }

    private void NotifyWindowsOnly(string title, string message)
    {
        try { _notifyIcon.ShowBalloonTip(2600, title, message, ToolTipIcon.Info); } catch { }
    }

    /// <summary>Балун только если пользователь сейчас НЕ смотрит на окно.</summary>
    private void NotifySmart(string title, string message)
    {
        if (!UserCanSeeWindow()) NotifyWindowsOnly(title, message);
    }

    private System.Drawing.Icon? LoadAppIcon()
    {
        try
        {
            var sri = System.Windows.Application.GetResourceStream(new Uri("pack://application:,,,/logo.ico"));
            if (sri != null) return new System.Drawing.Icon(sri.Stream);
        }
        catch { }
        return null;
    }

    /// <summary>
    /// Round the window corners using the OS. Win11+: DWM native rounding
    /// (anti-aliased, no artifacts, native shadow). Win10: GDI round region
    /// with a DPI-scaled radius. The window stays opaque in both cases.
    /// </summary>
    private void ApplyOsWindowRounding()
    {
        var hwnd = new WindowInteropHelper(this).Handle;
        if (hwnd == IntPtr.Zero) return;

        try
        {
            int dark = 1;
            DwmSetWindowAttribute(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE, ref dark, sizeof(int));
        }
        catch { }

        if (IsWin11OrNewer)
        {
            try
            {
                int pref = DWMWCP_ROUND;
                DwmSetWindowAttribute(hwnd, DWMWA_WINDOW_CORNER_PREFERENCE, ref pref, sizeof(int));
                // Subtle dark violet border (COLORREF 0x00BBGGRR = #251A38 RGB).
                int borderColor = 0x00381A25;
                DwmSetWindowAttribute(hwnd, DWMWA_BORDER_COLOR, ref borderColor, sizeof(int));
            }
            catch { }
        }
        else
        {
            ApplyOrClearWin10Region();
        }
    }

    /// <summary>Win10 fallback: GDI rounded region, re-applied on size changes.
    /// Removed while maximized/minimized so the full screen area is used.</summary>
    private void ApplyOrClearWin10Region()
    {
        try
        {
            var hwnd = new WindowInteropHelper(this).Handle;
            if (hwnd == IntPtr.Zero) return;

            if (WindowState != WindowState.Normal)
            {
                if (_regionApplied)
                {
                    SetWindowRgn(hwnd, IntPtr.Zero, true);
                    _regionApplied = false;
                }
                return;
            }

            var source = PresentationSource.FromVisual(this);
            double dpi = source?.CompositionTarget?.TransformToDevice.M11 ?? 1.0;
            if (double.IsNaN(dpi) || dpi <= 0) dpi = 1.0;

            int w = (int)Math.Ceiling(ActualWidth > 0 ? ActualWidth * dpi : Width * dpi);
            int h = (int)Math.Ceiling(ActualHeight > 0 ? ActualHeight * dpi : Height * dpi);
            if (w <= 0 || h <= 0) return;

            int r = (int)Math.Round(14 * dpi);
            var rgn = CreateRoundRectRgn(0, 0, w + 1, h + 1, r, r);
            SetWindowRgn(hwnd, rgn, true);
            _regionApplied = true;
        }
        catch { }
    }

    /// <summary>DPI-точное центрирование окна на рабочей области монитора.</summary>
    private void CenterWindowOnScreen()
    {
        try
        {
            if (WindowState != WindowState.Normal) return;
            var hwnd = new WindowInteropHelper(this).Handle;
            if (hwnd == IntPtr.Zero) return;

            var source = PresentationSource.FromVisual(this);
            double dpi = source?.CompositionTarget?.TransformToDevice.M11 ?? 1.0;
            if (double.IsNaN(dpi) || dpi <= 0) dpi = 1.0;

            var area = System.Windows.Forms.Screen.FromHandle(hwnd).WorkingArea; // device px
            double w = ActualWidth > 0 ? ActualWidth : Width;
            double h = ActualHeight > 0 ? ActualHeight : Height;
            if (w <= 0 || h <= 0) return;

            double devW = w * dpi, devH = h * dpi;
            double devLeft = area.Left + (area.Width - devW) / 2.0;
            double devTop = area.Top + (area.Height - devH) / 2.0;

            Left = devLeft / dpi;
            Top = devTop / dpi;
        }
        catch { }
    }

    private void LoadUserSession()
    {
        try
        {
            string? json = null;
            if (File.Exists(_userSessionFilePath))
            {
                json = File.ReadAllText(_userSessionFilePath);
            }

            if (string.IsNullOrWhiteSpace(json))
            {
                try
                {
                    using var reg = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"Software\FluxControl");
                    json = reg?.GetValue("UserSession")?.ToString();
                    if (!string.IsNullOrWhiteSpace(json))
                    {
                        File.WriteAllText(_userSessionFilePath, json);
                    }
                }
                catch { }
            }

            if (!string.IsNullOrWhiteSpace(json))
            {
                _currentUser = JsonSerializer.Deserialize<UserSessionData>(json);
            }
        }
        catch { }
    }

    private void SaveUserSession(UserSessionData user)
    {
        try
        {
            _currentUser = user;
            var json = JsonSerializer.Serialize(user, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(_userSessionFilePath, json);
            try
            {
                using var reg = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(@"Software\FluxControl");
                reg?.SetValue("UserSession", json);
            }
            catch { }
        }
        catch { }
    }

    private static string? FindEdgeWebViewRuntimePath()
    {
        try
        {
            var localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var userEdgeDir = Path.Combine(localAppData, "Microsoft", "EdgeWebView", "Application");
            if (Directory.Exists(userEdgeDir))
            {
                var versionDirs = Directory.GetDirectories(userEdgeDir)
                    .Where(d => File.Exists(Path.Combine(d, "msedgewebview2.exe")))
                    .OrderByDescending(d => Path.GetFileName(d))
                    .ToList();
                if (versionDirs.Count > 0)
                {
                    return versionDirs[0];
                }
            }
        }
        catch { }
        return null;
    }

    private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        App.Log("MainWindow_Loaded triggered.");

        if (_startedMinimized)
        {
            // Усі сервіси ініціалізуються в цьому обробнику; коли пайплайн
            // рендера добіг кінця (пріоритет ApplicationIdle) — ховаємо вікно
            // в трей назавжди, користувач нічого не побачив.
            Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, new Action(FinishStartupToTray));
        }
        try
        {
            App.Log("Initializing WebView2...");
            string? browserPath = FindEdgeWebViewRuntimePath();

            // Graceful-перевірка (bootstrap зазвичай встановлює WebView2 заздалегідь,
            // але якщо його знесли/блокує адмін — показуємо діалог з посиланням,
            // замість тихої аварії при CreateAsync).
            if (browserPath == null)
            {
                try { Microsoft.Web.WebView2.Core.CoreWebView2Environment.GetAvailableBrowserVersionString(); }
                catch (Exception notFound)
                {
                    App.Log($"WebView2 runtime missing: {notFound.Message}");
                    var choice = System.Windows.MessageBox.Show(
                        this,
                        "На цьому комп'ютері не знайдено Microsoft WebView2 Runtime — він потрібен для інтерфейсу FluxControl.\r\n\r\n" +
                        "Завантажити та встановити його зараз з офіційного сайту Microsoft?",
                        "FluxControl — WebView2", System.Windows.MessageBoxButton.YesNo, System.Windows.MessageBoxImage.Warning);
                    if (choice == System.Windows.MessageBoxResult.Yes)
                    {
                        try
                        {
                            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(
                                "https://go.microsoft.com/fwlink/?linkid=2099617") { UseShellExecute = true });
                        }
                        catch { }
                        System.Windows.MessageBox.Show(
                            this,
                            "Після встановлення WebView2 запусти FluxControl ще раз.",
                            "FluxControl", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
                    }
                    System.Windows.Application.Current.Shutdown();
                    return;
                }
            }

            string userDataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FluxControl", "WebView2");
            Directory.CreateDirectory(userDataDir);
            App.Log($"Using WebView2 runtime: {browserPath ?? "Default"}, UserData: {userDataDir}");
            var env = await Microsoft.Web.WebView2.Core.CoreWebView2Environment.CreateAsync(browserPath, userDataDir);
            await webView.EnsureCoreWebView2Async(env);
            // Непрозорий фон, точно в колір вікна: сторінка малює контент
            // edge-to-edge, а кути скруглює сама ОС (DWM/регіон).
            // Transparent here is FORBIDDEN: layered-window composition
            // breaks WebView2 input and shows «sharp transparent» artifacts.
            webView.DefaultBackgroundColor = System.Drawing.Color.FromArgb(0xFF, 0x05, 0x05, 0x0A);
            App.Log("WebView2 initialized successfully.");

            webView.CoreWebView2.Settings.IsZoomControlEnabled = false;
            webView.CoreWebView2.Settings.AreDevToolsEnabled = false;

            // Іконка вікна (панель задач / Alt-Tab) — той самий бренд-знак.
            try
            {
                var wicSri = System.Windows.Application.GetResourceStream(new Uri("pack://application:,,,/logo.ico"));
                if (wicSri != null) Icon = System.Windows.Media.Imaging.BitmapFrame.Create(wicSri.Stream);
            }
            catch { }

            webView.CoreWebView2.WebMessageReceived += CoreWebView2_WebMessageReceived;

            var hostedUrl = "https://fluxcontrol.pages.dev/agent-ui";
            // локальна копія інтерфейсу живе у сховищі %AppData%\FluxControl —
            // exe може лежати де завгодно (ТЗ: розтаутно-незалежний файл)
            var localHtmlPath = Services.RuntimeFiles.UiHtmlPath;

            webView.NavigationCompleted += (s, ev) =>
            {
                App.Log($"WebView2 navigation completed: {ev.IsSuccess}");
                if (!ev.IsSuccess)
                {
                    if (File.Exists(localHtmlPath) && !string.Equals(webView.Source?.LocalPath, localHtmlPath, StringComparison.OrdinalIgnoreCase))
                    {
                        App.Log("Falling back to local agent_ui.html");
                        webView.CoreWebView2.Navigate(localHtmlPath);
                        return;
                    }
                }
                Dispatcher.Invoke(SendStateToWebView);
                _ = Task.Delay(350).ContinueWith(_ => Dispatcher.Invoke(SendStateToWebView));
                _ = Task.Delay(120).ContinueWith(_ => Dispatcher.Invoke(PostChromeState));
                // The embedded browser finished rendering — the loading screen
                // can step aside. A safety timer guards against a hung page.
                _ = Task.Delay(400).ContinueWith(_ => Dispatcher.Invoke(HideLoadingOverlay));
            };

            // Navigate to hosted UI with local fallback
            try
            {
                webView.CoreWebView2.Navigate(hostedUrl);
            }
            catch
            {
                if (File.Exists(localHtmlPath))
                {
                    webView.CoreWebView2.Navigate(localHtmlPath);
                }
            }

            // Absolute safety: never trap the user behind the splash.
            var overlaySafety = new DispatcherTimer { Interval = TimeSpan.FromSeconds(8) };
            overlaySafety.Tick += (s, ev) => { HideLoadingOverlay(); overlaySafety.Stop(); };
            overlaySafety.Start();

            // Startup pipeline: dependency checks (FFmpeg) then the automatic
            // internet speed measurement requested for every program start.
            _ = RunStartupPipelineAsync();

            // ТЗ: перевірка оновлень при старті — тиха; якщо є нова версія,
            // за кілька секунд після завантаження з'явиться вікно-діалог.
            _ = CheckForUpdatesOnStartupAsync();

            // Periodic live hardware telemetry updates
            _metricsTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            _metricsTimer.Tick += (s, ev) => SendStateToWebView();
            _metricsTimer.Start();

            // Auto-refresh account / subscription status from the server every 20s
            _subscriptionTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(20) };
            _subscriptionTimer.Tick += (s, ev) => { _ = CheckUserSubscriptionAsync(silent: true); };
            _subscriptionTimer.Start();
            if (_currentUser != null) _ = CheckUserSubscriptionAsync(silent: true);

            App.Log("Starting WebSocket server in background...");
            _ = Task.Run(async () =>
            {
                try
                {
                    await _serverService.StartAsync();
                    App.Log("WebSocket server started on port 5080.");
                }
                catch (Exception ex)
                {
                    App.Log($"[WARN] WebSocket server start error: {ex.Message}");
                }
            });
        }
        catch (Exception ex)
        {
            App.Log($"[ERROR] in MainWindow_Loaded: {ex}");
            System.Windows.MessageBox.Show($"Помилка запуску: {ex.Message}", "FluxControl", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void CoreWebView2_WebMessageReceived(object? sender, Microsoft.Web.WebView2.Core.CoreWebView2WebMessageReceivedEventArgs e)
    {
        try
        {
            var jsonStr = e.WebMessageAsJson;
            var msg = JsonSerializer.Deserialize<JsonObject>(jsonStr);
            if (msg == null) return;

            var type = msg["type"]?.GetValue<string>() ?? "";

            switch (type)
            {
                case "ready":
                    SendStateToWebView();
                    break;

                case "retry_connection":
                    _relayService?.ForceReconnect();
                    SendStateToWebView();
                    break;

                case "login_via_browser":
                    _ = HandleLoginViaBrowserAsync();
                    break;

                case "logout":
                    _currentUser = null;
                    try
                    {
                        if (File.Exists(_userSessionFilePath)) File.Delete(_userSessionFilePath);
                        using var reg = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"Software\FluxControl", true);
                        reg?.DeleteValue("UserSession", false);
                    }
                    catch { }
                    Dispatcher.Invoke(SendStateToWebView);
                    break;

                case "check_subscription":
                    _ = CheckUserSubscriptionAsync();
                    break;

                case "window_drag":
                    Dispatcher.Invoke(() =>
                    {
                        try
                        {
                            var handle = new WindowInteropHelper(this).Handle;
                            if (handle != IntPtr.Zero)
                            {
                                ReleaseCapture();
                                SendMessage(handle, WM_NCLBUTTONDOWN, (IntPtr)HTCAPTION, IntPtr.Zero);
                            }
                        }
                        catch { }
                    });
                    break;

                case "window_maximize":
                    Dispatcher.Invoke(ToggleMaximize);
                    break;

                case "window_minimize":
                    Dispatcher.Invoke(() => WindowState = WindowState.Minimized);
                    break;

                case "window_close":
                    Dispatcher.Invoke(() =>
                    {
                        if (_minimizeToTray)
                        {
                            WindowState = WindowState.Minimized;
                            Hide();
                        }
                        else
                        {
                            _isExplicitExit = true;
                            _notifyIcon.Visible = false;
                            System.Windows.Application.Current.Shutdown();
                        }
                    });
                    break;

                case "regenerate_code":
                    _pairingService.RegenerateCode();
                    Dispatcher.Invoke(SendStateToWebView);
                    break;

                case "copy_link":
                    CopyWebLink();
                    break;

                case "respond_pairing":
                    var reqId = msg["requestId"]?.GetValue<string>() ?? "";
                    var allow = msg["allow"]?.GetValue<bool>() ?? false;
                    if (_pendingRequests.Remove(reqId, out var req))
                    {
                        req.CompletionSource.TrySetResult(allow);
                    }
                    break;

                case "set_autorun":
                    var auto = msg["enable"]?.GetValue<bool>() ?? false;
                    AutoRunService.SetAutoRun(auto);
                    SendStateToWebView();
                    break;

                case "set_tray":
                    _minimizeToTray = msg["enable"]?.GetValue<bool>() ?? true;
                    break;

                case "revoke_client":
                    var connId = msg["connectionId"]?.GetValue<string>();
                    if (!string.IsNullOrEmpty(connId))
                    {
                        _pairingService.RegisterClientDisconnected(connId);
                    }
                    break;

                case "install_ffmpeg":
                    _ = InstallFfmpegAsync();
                    break;

                case "retry_dependency_check":
                    CheckFfmpegDependency();
                    Dispatcher.Invoke(SendStateToWebView);
                    break;

                case "run_speedtest":
                    _ = Task.Run(() => _relayService.SpeedTest.RunAsync());
                    break;
            }
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"WebMessage error: {ex.Message}");
        }
    }

    private async Task CheckUserSubscriptionAsync(bool silent = false)
    {
        if (_currentUser == null || string.IsNullOrEmpty(_currentUser.id)) return;
        var prevExpiry = _currentUser.subscriptionExpiresAt;
        var prevRole = _currentUser.role;
        try
        {
            var payload = new { user = new { id = _currentUser.id, email = _currentUser.email } };
            var json = JsonSerializer.Serialize(payload);
            using var content = new StringContent(json, Encoding.UTF8, "application/json");

            HttpResponseMessage? res = null;
            try
            {
                res = await _authHttpClient.PostAsync("https://fluxcontrol.pages.dev/api/auth/profile", content);
            }
            catch { }

            if (res == null || !res.IsSuccessStatusCode)
            {
                res = await _authHttpClient.PostAsync("https://fluxcontrol-backend.onrender.com/api/auth/profile", content);
            }

            if (res != null && res.IsSuccessStatusCode)
            {
                var respStr = await res.Content.ReadAsStringAsync();
                var doc = JsonDocument.Parse(respStr);
                if (doc.RootElement.TryGetProperty("user", out var userEl))
                {
                    var updatedUser = JsonSerializer.Deserialize<UserSessionData>(userEl.GetRawText());
                    if (updatedUser != null)
                    {
                        SaveUserSession(updatedUser);
                        Dispatcher.Invoke(SendStateToWebView);
                        if (!silent || updatedUser.subscriptionExpiresAt != prevExpiry || updatedUser.role != prevRole)
                        {
                            // Дубля немає: якщо окно видно — вбудований тост малює сторінка;
                            // балун летит только когда окно скрыто/свёрнуто/неактивно.
                            NotifySmart("FluxControl", "Статус підписки оновлено!");
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            App.Log($"[SUB] Check error: {ex.Message}");
        }
    }

    private async Task HandleLoginViaBrowserAsync()
    {
        try
        {
            var payload = new
            {
                computerName = Environment.MachineName,
                hwid = _pairingService.HardwareId,
                code = _pairingService.DeviceCode
            };
            var json = JsonSerializer.Serialize(payload);
            using var content = new StringContent(json, Encoding.UTF8, "application/json");

            HttpResponseMessage? res = null;
            try
            {
                res = await _authHttpClient.PostAsync("https://fluxcontrol.pages.dev/api/auth/device-session/create", content);
            }
            catch { }

            if (res == null || !res.IsSuccessStatusCode)
            {
                res = await _authHttpClient.PostAsync("https://fluxcontrol-backend.onrender.com/api/auth/device-session/create", content);
            }

            if (res != null && res.IsSuccessStatusCode)
            {
                var respStr = await res.Content.ReadAsStringAsync();
                var doc = JsonDocument.Parse(respStr);
                if (doc.RootElement.TryGetProperty("token", out var tokenProp) &&
                    doc.RootElement.TryGetProperty("authUrl", out var authUrlProp))
                {
                    string token = tokenProp.GetString() ?? "";
                    string authUrl = authUrlProp.GetString() ?? "";

                    if (!string.IsNullOrEmpty(authUrl))
                    {
                        Process.Start(new ProcessStartInfo(authUrl) { UseShellExecute = true });
                        _ = PollAuthSessionAsync(token);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            App.Log($"[AUTH] HandleLoginViaBrowser error: {ex.Message}");
        }
    }

    private async Task PollAuthSessionAsync(string token)
    {
        var startTime = DateTime.UtcNow;
        while (DateTime.UtcNow - startTime < TimeSpan.FromMinutes(5))
        {
            await Task.Delay(1500);
            try
            {
                HttpResponseMessage? res = null;
                try
                {
                    res = await _authHttpClient.GetAsync($"https://fluxcontrol.pages.dev/api/auth/device-session/status?token={token}");
                }
                catch { }

                if (res == null || !res.IsSuccessStatusCode)
                {
                    res = await _authHttpClient.GetAsync($"https://fluxcontrol-backend.onrender.com/api/auth/device-session/status?token={token}");
                }

                if (res != null && res.IsSuccessStatusCode)
                {
                    var respStr = await res.Content.ReadAsStringAsync();
                    var doc = JsonDocument.Parse(respStr);
                    var status = doc.RootElement.GetProperty("status").GetString();

                    if (status == "approved" && doc.RootElement.TryGetProperty("user", out var userEl))
                    {
                        var user = JsonSerializer.Deserialize<UserSessionData>(userEl.GetRawText());
                        if (user != null)
                        {
                            SaveUserSession(user);
                            Dispatcher.Invoke(SendStateToWebView);
                            NotifySmart("FluxControl", $"Успішний вхід: {user.name} ({user.email})");
                            break;
                        }
                    }
                    else if (status == "rejected")
                    {
                        break;
                    }
                }
            }
            catch { }
        }
    }

    private string GetWebConnectUrl()
    {
        return $"https://fluxcontrol.pages.dev/device/{_pairingService.DeviceCode}";
    }

    // ================================================================
    // Startup dependency pipeline (FFmpeg) + auto speedtest
    // ================================================================

    private async Task RunStartupPipelineAsync()
    {
        if (_dependencyPipelineStarted) return;
        _dependencyPipelineStarted = true;

        CheckFfmpegDependency();
        Dispatcher.Invoke(SendStateToWebView);

        // The automatic speed measurement from the task description:
        // it runs once per program start and the result is stored.
        // The relay connection already triggers one as soon as it is up —
        // only run here as a fallback when that has not produced a result.
        await Task.Delay(TimeSpan.FromSeconds(10));
        if (_relayService.SpeedTest.Last == null)
        {
            await _relayService.SpeedTest.RunAsync(auto: true);
        }
    }

    private void CheckFfmpegDependency()
    {
        if (DependencyService.IsFfmpegAvailable())
        {
            _ffmpegStatus = "ready";
            _ffmpegStage = string.Empty;
            _ffmpegPercent = 0;
            _ffmpegError = null;
            return;
        }

        _ffmpegStatus = "missing";
        _ffmpegError = null;
        // Auto-install attempt right away, exactly as requested: the program
        // downloads FFmpeg by itself, and only falls back to the manual
        // installer screen when the download is impossible.
        _ = InstallFfmpegAsync();
    }

    private async Task InstallFfmpegAsync()
    {
        if (_ffmpegStatus is "installing" or "ready") return;
        _ffmpegStatus = "installing";
        _ffmpegStage = "завантаження…";
        _ffmpegPercent = 0;
        _ffmpegError = null;
        Dispatcher.Invoke(SendStateToWebView);

        try
        {
            await DependencyService.EnsureFfmpegAsync(progress =>
            {
                _ffmpegStage = progress.Stage;
                _ffmpegPercent = progress.Percent;
                Dispatcher.Invoke(SendStateToWebView);
            });
            _ffmpegStatus = "ready";
            _ffmpegStage = string.Empty;
            _ffmpegPercent = 0;
            NotifySmart("FluxControl", "FFmpeg встановлено — запис екрана й камери готові до роботи");
        }
        catch (Exception ex)
        {
            _ffmpegStatus = "error";
            _ffmpegStage = string.Empty;
            _ffmpegError = $"Автоматичне встановлення не вдалося: {ex.Message}. Завантажте FFmpeg вручну та натисніть «Перевірити ще раз».";
            App.Log($"[DEPS] FFmpeg install failed: {ex.Message}");
        }
        Dispatcher.Invoke(SendStateToWebView);
    }

    // ================================================================
    // Window chrome: loading overlay + native-style maximize
    // ================================================================

    private void HideLoadingOverlay()
    {
        if (_overlayHidden) return;
        _overlayHidden = true;
        try
        {
            LoadingOverlay.IsHitTestVisible = false;
            var fade = new System.Windows.Media.Animation.DoubleAnimation(0, TimeSpan.FromMilliseconds(220));
            fade.Completed += (s, e) => LoadingOverlay.Visibility = Visibility.Collapsed;
            LoadingOverlay.BeginAnimation(OpacityProperty, fade);
        }
        catch
        {
            LoadingOverlay.Visibility = Visibility.Collapsed;
        }
    }

    private void ToggleMaximize()
    {
        if (WindowState == WindowState.Maximized)
        {
            MaxHeight = double.PositiveInfinity;
            WindowState = WindowState.Normal;
        }
        else
        {
            // A borderless maximized WPF window covers the taskbar unless it
            // is constrained to the working area explicitly.
            MaxHeight = SystemParameters.WorkArea.Height;
            WindowState = WindowState.Maximized;
        }
        SendStateToWebView();
    }

    private void CopyWebLink()
    {
        try
        {
            var url = GetWebConnectUrl();
            System.Windows.Clipboard.SetText(url);
            // Копіювання зазвичай ініціюють кнопкою у вікні — там тост малює
            // сторінка; балун потрібен лише при виклику з трею, коли окно сховано.
            NotifySmart("FluxControl", "Посилання скопійовано у буфер обміну!");
        }
        catch { }
    }

    private void SendStateToWebView()
    {
        try
        {
            var webUrl = GetWebConnectUrl();
            if (_cachedQrUrl != webUrl || string.IsNullOrEmpty(_cachedQrBase64))
            {
                try
                {
                    _cachedQrBase64 = _pairingService.GenerateQrCodeDataUrl(webUrl);
                    _cachedQrUrl = webUrl;
                }
                catch (Exception qrx)
                {
                    App.Log($"[WARN] QR generation failed: {qrx.Message}");
                }
            }
            string qrBase64 = _cachedQrBase64;

            var isRelayConnected = _relayService?.IsConnected ?? false;
            var relayStatus = _relayService?.Status ?? (isRelayConnected ? "connected" : "connecting");
            var relayError = _relayService?.LastError;

            var metrics = _systemService.GetMetrics();

            var state = new
            {
                type = "state",
                computerName = Environment.MachineName,
                userName = Environment.UserName,
                // версія, зашита в exe (-p:Version при деплої) — для секції «Про програму»
                appVersion = Services.UpdateService.GetLocalVersion(),
                code = _pairingService.DeviceCode,
                deviceCode = _pairingService.DeviceCode,
                formattedCode = _pairingService.GetFormattedCode(),
                hwid = _pairingService.HardwareId,
                pin = _pairingService.CurrentPin,
                qrCode = qrBase64,
                qrBase64 = qrBase64,
                webUrl = webUrl,
                relayConnected = isRelayConnected,
                relayStatus = relayStatus,
                relayError = relayError,
                isAutoRun = AutoRunService.IsAutoRunEnabled(),
                autoRun = AutoRunService.IsAutoRunEnabled(),
                minimizeToTray = _minimizeToTray,
                activeClients = _pairingService.GetActiveClients().Count,
                user = _currentUser,
                ffmpeg = new { status = _ffmpegStatus, stage = _ffmpegStage, percent = _ffmpegPercent, error = _ffmpegError },
                dependencies = new { ffmpeg = new { status = _ffmpegStatus, stage = _ffmpegStage, percent = _ffmpegPercent, error = _ffmpegError } },
                speedTest = _relayService?.SpeedTest.Last,
                cpuName = metrics.CpuName,
                cpuPercent = Math.Round(metrics.CpuPercent, 1),
                gpuName = metrics.GpuName,
                gpuPercent = Math.Round(metrics.GpuUsage, 1),
                ramUsedGb = Math.Round(metrics.RamUsedGb, 1),
                ramTotalGb = Math.Round(metrics.RamTotalGb, 1),
                ramPercent = Math.Round(metrics.RamPercent, 0),
                osName = metrics.OsVersion,
                uptime = metrics.Uptime,
                data = new
                {
                    code = _pairingService.DeviceCode,
                    deviceCode = _pairingService.DeviceCode,
                    formattedCode = _pairingService.GetFormattedCode(),
                    pin = _pairingService.CurrentPin,
                    qrCode = qrBase64,
                    webUrl = webUrl,
                    relayConnected = isRelayConnected,
                    relayStatus = relayStatus,
                    relayError = relayError,
                    isAutoRun = AutoRunService.IsAutoRunEnabled(),
                    minimizeToTray = _minimizeToTray,
                    activeClients = _pairingService.GetActiveClients().Count,
                    user = _currentUser,
                    ffmpeg = new { status = _ffmpegStatus, stage = _ffmpegStage, percent = _ffmpegPercent, error = _ffmpegError },
                    speedTest = _relayService?.SpeedTest.Last
                }
            };

            PostJsonToWebView(state);
        }
        catch (Exception ex)
        {
            App.Log($"[ERROR] SendStateToWebView failed: {ex}");
        }
    }

    private void PostChromeState()
    {
        PostJsonToWebView(new { type = "chrome", maximized = WindowState == WindowState.Maximized });
    }

    private void PostJsonToWebView(object payload)
    {
        try
        {
            var json = JsonSerializer.Serialize(payload);
            webView.CoreWebView2?.PostWebMessageAsJson(json);
        }
        catch { }
    }

    /// <summary>
    /// ТЗ: перевірка оновлень при кожному старті. Через 6 секунд після
    /// завантаження (щоб не заважати стартовому пайплайну) питаємо GitHub;
    /// якщо є новіша версія — показуємо вікно оновлення з прогресом.
    /// </summary>
    private async Task CheckForUpdatesOnStartupAsync()
    {
        try
        {
            await Task.Delay(6000);
            var update = await UpdateService.CheckForUpdateAsync();
            if (update == null || !update.UpdateAvailable) return;
            await Dispatcher.InvokeAsync(() =>
            {
                try
                {
                    var win = new InstallerWindow(InstallerWindow.InstallerMode.UpdateConfirm);
                    win.SetUpdateInfo(update);
                    win.Owner = this;
                    win.Show();
                }
                catch (Exception ex) { App.Log($"Update window show failed: {ex.Message}"); }
            });
        }
        catch (Exception ex)
        {
            App.Log($"Startup update check failed: {ex.Message}");
        }
    }

    /// <summary>Пункт трея «Перевірити оновлення»: з балунами-статусами.</summary>
    private async void CheckUpdatesManually()
    {
        try
        {
            _notifyIcon.ShowBalloonTip(1500, "FluxControl", "Перевіряю оновлення…", ToolTipIcon.Info);
            var update = await UpdateService.CheckForUpdateAsync();
            if (update == null)
            {
                _notifyIcon.ShowBalloonTip(3500, "FluxControl",
                    "Не вдалося перевірити оновлення — немає зв'язку з GitHub", ToolTipIcon.Warning);
                return;
            }
            if (!update.UpdateAvailable)
            {
                _notifyIcon.ShowBalloonTip(3500, "FluxControl",
                    $"У вас остання версія {update.LocalVersion}", ToolTipIcon.Info);
                return;
            }
            var win = new InstallerWindow(InstallerWindow.InstallerMode.UpdateConfirm);
            win.SetUpdateInfo(update);
            win.Owner = this;
            win.Show();
        }
        catch (Exception ex)
        {
            App.Log($"Manual update check failed: {ex.Message}");
        }
    }

    /// <summary>
    /// Завершення запуску з --minimized: вікно виконало свій один невидимий
    /// показ (Loaded-пайплайн відпрацював) — тепер ховаємо його повністю.
    /// Користувач бачить: нічого на екрані, нічого на панелі завдань,
    /// лише іконка в треї + балун «працює у фоновому режимі».
    /// </summary>
    private void FinishStartupToTray()
    {
        if (_startupHideDone) return;
        _startupHideDone = true;
        try
        {
            Hide();
            Opacity = 1d;
            ShowInTaskbar = true;
            ShowActivated = true;
            _notifyIcon.ShowBalloonTip(2500, "FluxControl",
                "Програма запущена у фоновому режимі — іконка в треї біля годинника", ToolTipIcon.Info);
        }
        catch { }
    }

    private void ShowAndActivate()
    {
        // Скасовуємо невидиму фазу автозапуску — користувач попросив вікно,
        // воно має бути повністю видимим, навіть якщо клікнув у трей дуже рано.
        _startupHideDone = true;
        try
        {
            Opacity = 1d;
            ShowInTaskbar = true;
            ShowActivated = true;
        }
        catch { }
        Show();
        WindowState = WindowState.Normal;
        Activate();
    }

    protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
    {
        if (!_isExplicitExit && _minimizeToTray)
        {
            e.Cancel = true;
            WindowState = WindowState.Minimized;
            Hide();
            _notifyIcon.ShowBalloonTip(2000, "FluxControl", "Додаток згорнуто в трей і продовжує працювати", ToolTipIcon.Info);
        }
        else
        {
            _notifyIcon.Visible = false;
            _notifyIcon.Dispose();
            base.OnClosing(e);
        }
    }
}
