using System;
using System.Collections.Generic;
using System.Threading;
using LibreHardwareMonitor.Hardware;

namespace FluxControl.Agent.Services;

/// <summary>
/// Real CPU/GPU temperature and GPU usage/VRAM readings via LibreHardwareMonitor —
/// the same source HWiNFO/Open Hardware Monitor style tools use ("програма САМА
/// дізнавалась температуру процесора").
/// All public getters return 0 when a sensor is unavailable (WinRing0 driver
/// blocked by HVCI, unsupported board, …) so callers can fall back to WMI /
/// nvidia-smi / performance counters. Nothing here ever throws to a caller.
/// </summary>
public class SensorService : IDisposable
{
    private const double SensorFreshnessSeconds = 5;
    private const double HardwareUpdateThrottleSeconds = 2;

    private readonly object _sync = new();
    private readonly SemaphoreSlim _openLock = new(1, 1);
    // Update() per hardware at most once per 2 seconds.
    private readonly Dictionary<IHardware, DateTime> _lastHardwareUpdate = new();

    private Computer? _computer;
    private bool _opened; // true after the first open attempt (success OR failure)

    // Cached sensor values (0 = unavailable) with freshness timestamps.
    private double _cpuTemp;
    private DateTime _cpuTempAt = DateTime.MinValue;
    private double _gpuTemp;
    private DateTime _gpuTempAt = DateTime.MinValue;
    private double _gpuUsage;
    private DateTime _gpuUsageAt = DateTime.MinValue;
    private double _gpuVramUsedGb;
    private DateTime _gpuVramUsedAt = DateTime.MinValue;
    private double _gpuVramTotalGb;
    private DateTime _gpuVramTotalAt = DateTime.MinValue;

    public double GetCpuTemperature()
    {
        try
        {
            EnsureOpened();
            if (_computer == null) return 0;
            if (Stale(_cpuTempAt)) Refresh();
            return SanitizeTemp(_cpuTemp);
        }
        catch { return 0; }
    }

    public double GetGpuTemperature()
    {
        try
        {
            EnsureOpened();
            if (_computer == null) return 0;
            if (Stale(_gpuTempAt)) Refresh();
            return SanitizeTemp(_gpuTemp);
        }
        catch { return 0; }
    }

    public double GetGpuUsage()
    {
        try
        {
            EnsureOpened();
            if (_computer == null) return 0;
            if (Stale(_gpuUsageAt)) Refresh();
            return Math.Round(Math.Clamp(_gpuUsage, 0, 100), 1);
        }
        catch { return 0; }
    }

    public double GetGpuVramUsedGb()
    {
        try
        {
            EnsureOpened();
            if (_computer == null) return 0;
            if (Stale(_gpuVramUsedAt)) Refresh();
            return _gpuVramUsedGb > 0 ? Math.Round(_gpuVramUsedGb, 2) : 0;
        }
        catch { return 0; }
    }

    public double GetGpuVramTotalGb()
    {
        try
        {
            EnsureOpened();
            if (_computer == null) return 0;
            if (Stale(_gpuVramTotalAt)) Refresh();
            return _gpuVramTotalGb > 0 ? Math.Round(_gpuVramTotalGb, 2) : 0;
        }
        catch { return 0; }
    }

    // Lazy Computer.Open() on the first query (queries always arrive from
    // background threads: metrics loop / relay receive loop), guarded so the
    // heavy driver+WMI init runs exactly once. A failed attempt is remembered
    // and never retried — callers keep using their fallbacks.
    private void EnsureOpened()
    {
        if (Volatile.Read(ref _opened)) return;
        _openLock.Wait();
        try
        {
            if (_opened) return;
            try
            {
                var computer = new Computer
                {
                    IsCpuEnabled = true,
                    IsGpuEnabled = true,
                    IsMemoryEnabled = true,
                    IsStorageEnabled = false,
                    IsMotherboardEnabled = false
                };
                computer.Open();
                _computer = computer;
            }
            catch
            {
                _computer = null; // sensors unavailable → all getters return 0
            }
            Volatile.Write(ref _opened, true);
        }
        finally
        {
            _openLock.Release();
        }
    }

    /// <summary>
    /// One enumeration pass over CPU/GPU hardware: Update() (throttled 2s per
    /// hardware) then read the interesting sensors into the per-sensor caches.
    /// </summary>
    private void Refresh()
    {
        lock (_sync)
        {
            try
            {
                var computer = _computer;
                if (computer != null)
                {
                    foreach (var hardware in computer.Hardware)
                    {
                        if (hardware == null) continue;
                        try
                        {
                            bool isCpu = hardware.HardwareType == HardwareType.Cpu;
                            bool isGpu = hardware.HardwareType is HardwareType.GpuNvidia or HardwareType.GpuAmd or HardwareType.GpuIntel;
                            if (!isCpu && !isGpu) continue;

                            if (!_lastHardwareUpdate.TryGetValue(hardware, out DateTime last) ||
                                (DateTime.UtcNow - last).TotalSeconds >= HardwareUpdateThrottleSeconds)
                            {
                                hardware.Update();
                                _lastHardwareUpdate[hardware] = DateTime.UtcNow;
                            }

                            if (isCpu) ReadCpu(hardware);
                            else ReadGpu(hardware);
                        }
                        catch { }
                    }
                }
            }
            catch { }
            finally
            {
                // Mark the whole pass fresh even when a sensor was not found,
                // so missing sensors don't cause a re-enumeration on every call.
                var now = DateTime.UtcNow;
                _cpuTempAt = now;
                _gpuTempAt = now;
                _gpuUsageAt = now;
                _gpuVramUsedAt = now;
                _gpuVramTotalAt = now;
            }
        }
    }

    private void ReadCpu(IHardware cpu)
    {
        var sensors = cpu.Sensors;
        if (sensors == null) return;

        double? package = null, tctl = null, average = null, ccd1 = null, other = null;
        foreach (var sensor in sensors)
        {
            if (sensor == null || sensor.SensorType != SensorType.Temperature) continue;
            if (sensor.Value is not { } value || value <= 0f || value >= 120f) continue;

            var name = sensor.Name ?? string.Empty;
            if (name.Contains("Package", StringComparison.OrdinalIgnoreCase)) package ??= value;
            else if (name.Contains("Tctl/Tdie", StringComparison.OrdinalIgnoreCase)) tctl ??= value;
            else if (name.Contains("Average", StringComparison.OrdinalIgnoreCase)) average ??= value; // "Core(s) Average"
            else if (name.Contains("CCD1", StringComparison.OrdinalIgnoreCase)) ccd1 ??= value;
            else if (other == null || value > other) other = value; // highest "Core #N"
        }

        var best = package ?? tctl ?? average ?? ccd1 ?? other;
        if (best is > 0)
        {
            _cpuTemp = best.Value;
        }
    }

    private void ReadGpu(IHardware gpu)
    {
        var sensors = gpu.Sensors;
        if (sensors == null) return;

        double? coreTemp = null, hotSpot = null;
        double? coreLoad = null, d3dLoad = null;
        double? memUsedBytes = null, memTotalBytes = null;

        foreach (var sensor in sensors)
        {
            if (sensor == null) continue;
            if (sensor.Value is not { } value) continue;
            var name = sensor.Name ?? string.Empty;

            switch (sensor.SensorType)
            {
                case SensorType.Temperature when value > 0f && value < 120f:
                    if (name.Contains("GPU Core", StringComparison.OrdinalIgnoreCase)) coreTemp ??= value;
                    else if (name.Contains("Hot Spot", StringComparison.OrdinalIgnoreCase)) hotSpot ??= value;
                    break;

                case SensorType.Load when value >= 0f && value <= 100f:
                    if (name.Contains("GPU Core", StringComparison.OrdinalIgnoreCase)) coreLoad ??= value;
                    else if (name.Contains("D3D 3D", StringComparison.OrdinalIgnoreCase)) d3dLoad ??= value;
                    break;

                case SensorType.SmallData when value > 0f:
                    if (name.Contains("GPU Memory Used", StringComparison.OrdinalIgnoreCase)) memUsedBytes ??= value;
                    else if (name.Contains("GPU Memory Total", StringComparison.OrdinalIgnoreCase)) memTotalBytes ??= value;
                    break;
            }
        }

        var temp = coreTemp ?? hotSpot;
        if (temp is > 0) _gpuTemp = temp.Value;

        var load = coreLoad ?? d3dLoad;
        if (load is >= 0) _gpuUsage = load.Value;

        const double BytesPerGb = 1024.0 * 1024.0 * 1024.0;
        if (memUsedBytes is > 0) _gpuVramUsedGb = memUsedBytes.Value / BytesPerGb;
        if (memTotalBytes is > 0) _gpuVramTotalGb = memTotalBytes.Value / BytesPerGb;
    }

    private static bool Stale(DateTime at) => (DateTime.UtcNow - at).TotalSeconds >= SensorFreshnessSeconds;

    private static double SanitizeTemp(double value) => value > 0 && value < 120 ? Math.Round(value, 1) : 0;

    public void Dispose()
    {
        // Optional (app lifetime), best-effort only.
        try { _computer?.Close(); } catch { }
        _computer = null;
    }
}
