using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.IO;
using Microsoft.Win32;

namespace FluxControl.Agent.Services;

/// <summary>
/// WinLock: the PC owner can remotely lock her own PC from the web panel so nobody
/// else can use it while she is away. When locked, a fullscreen uncloseable window
/// covers the PC, Task Manager / Win-keys are disabled via HKCU policies and a
/// low-level keyboard hook swallows Alt+Tab / Alt+F4 / Win / Ctrl+Esc.
/// Unlock: correct code typed on the locked PC (mode "code") or — always, from the
/// owner's trusted web panel (<see cref="UnlockFromSite"/>). On reboot the lock
/// re-engages automatically from %AppData%\FluxControl\winlock.json.
/// </summary>
public class WinLockService
{
    public const string ModeNone = "none";
    public const string ModeCode = "code";
    public const string ModeSite = "site";

    private const string StateFileName = "winlock.json";
    private const string PolicySystemPath = @"Software\Microsoft\Windows\CurrentVersion\Policies\System";
    private const string PolicyExplorerPath = @"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer";

    // Low-level keyboard hook constants.
    private const int WH_KEYBOARD_LL = 13;
    private const int WM_KEYDOWN = 0x0100;
    private const int WM_KEYUP = 0x0101;
    private const int WM_SYSKEYDOWN = 0x0104;
    private const int WM_SYSKEYUP = 0x0105;
    private const uint LLKHF_ALTDOWN = 0x20;
    private const uint VK_TAB = 0x09;
    private const uint VK_F4 = 0x46;
    private const uint VK_ESCAPE = 0x1B;
    private const uint VK_LWIN = 0x5B;
    private const uint VK_RWIN = 0x5C;
    private const int VK_CONTROL = 0x11;

    private readonly object _sync = new();
    private bool _isLocked;
    private string _mode = ModeNone;
    private string _codeSalt = string.Empty;
    private string _codeHash = string.Empty;
    private long _lockedAt;
    private LockWindow? _window;

    // Hook state lives on the Dispatcher thread only (installed + removed there).
    private IntPtr _hookHandle = IntPtr.Zero;
    private readonly LowLevelKeyboardProc _hookProc;

    private static readonly JsonSerializerOptions StateJsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
    };

    public WinLockService()
    {
        // Keep the delegate instance referenced for the whole hook lifetime (GC protection).
        _hookProc = KeyboardHookProc;
    }

    public bool IsLocked { get { lock (_sync) { return _isLocked; } } }

    /// <summary>"none" when unlocked, otherwise "code" or "site".</summary>
    public string Mode { get { lock (_sync) { return _isLocked ? _mode : ModeNone; } } }

    /// <summary>Unix ms timestamp of the moment the lock was engaged (0 when unlocked).</summary>
    public long LockedAt { get { lock (_sync) { return _isLocked ? _lockedAt : 0; } } }

    public event Action<WinLockStateDto>? StateChanged;

    /// <summary>
    /// Engages the lock. Thread-safe (UI work is marshalled to the WPF Dispatcher).
    /// mode: "code" (unlock code required, non-empty) or "site" (only the web panel can unlock).
    /// </summary>
    public void Lock(string mode, string? code)
    {
        if (mode != ModeCode && mode != ModeSite)
            throw new ArgumentException($"Unknown WinLock mode '{mode}' (expected \"{ModeCode}\" or \"{ModeSite}\").", nameof(mode));

        if (mode == ModeCode && string.IsNullOrWhiteSpace(code))
            throw new ArgumentException($"A non-empty unlock code is required for mode \"{ModeCode}\".", nameof(code));

        lock (_sync)
        {
            if (_isLocked) return; // already locked — nothing to do
        }

        var salt = mode == ModeCode ? GenerateSalt() : string.Empty;
        var hash = mode == ModeCode ? ComputeCodeHash(salt, code!) : string.Empty;
        var lockedAt = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

        // 1) Persist state (survives reboot) — any thread, fully guarded.
        WriteStateFile(mode, salt, hash, lockedAt, active: true);

        // 2) OS policies (Task Manager off, Win keys off) — any thread, guarded.
        ApplyPolicies(locked: true);

        // 3) Hook + fullscreen window need a message pump → Dispatcher thread.
        var dispatcher = System.Windows.Application.Current?.Dispatcher;
        try
        {
            if (dispatcher == null || dispatcher.CheckAccess())
                EngageOnUi(mode, salt, hash, lockedAt);
            else
                dispatcher.Invoke(() => EngageOnUi(mode, salt, hash, lockedAt));
        }
        catch (Exception ex)
        {
            App.Log($"[WinLock] UI engage failed: {ex.Message}");
        }

        App.Log($"[WinLock] Lock engaged (mode={mode}).");
        RaiseStateChanged();
    }

    /// <summary>
    /// Local unlock from the lock window (or web with a code). Only works in "code" mode
    /// when the code matches the stored hash. For "site" mode use <see cref="UnlockFromSite"/>.
    /// </summary>
    public bool TryUnlock(string? code)
    {
        bool locked; string mode; string salt; string hash;
        lock (_sync)
        {
            locked = _isLocked;
            mode = _mode;
            salt = _codeSalt;
            hash = _codeHash;
        }

        if (!locked || mode != ModeCode || string.IsNullOrEmpty(code))
            return false;

        var candidate = ComputeCodeHash(salt, code);
        if (!string.Equals(candidate, hash, StringComparison.OrdinalIgnoreCase))
            return false;

        UnlockInternal();
        return true;
    }

    /// <summary>
    /// Trusted override: the owner's web panel may unlock regardless of mode.
    /// </summary>
    public void UnlockFromSite()
    {
        lock (_sync)
        {
            if (!_isLocked) return;
        }
        UnlockInternal();
    }

    /// <summary>
    /// Called on app start (also with --minimized): if winlock.json says the PC was locked,
    /// re-engage everything (policies, hook, fullscreen window).
    /// </summary>
    public void TryRestoreOnStartup()
    {
        try
        {
            var state = ReadStateFile();
            if (state == null || !state.Active) return;

            var mode = state.Mode == ModeSite ? ModeSite : ModeCode;
            if (mode == ModeCode && (string.IsNullOrWhiteSpace(state.Salt) || string.IsNullOrWhiteSpace(state.CodeHash)))
            {
                // Corrupted state file cannot be honoured — drop it instead of locking blind.
                App.Log("[WinLock] State file is incomplete — clearing instead of restoring.");
                ClearStateFile();
                return;
            }

            ApplyPolicies(locked: true);

            var dispatcher = System.Windows.Application.Current?.Dispatcher;
            if (dispatcher == null || dispatcher.CheckAccess())
                EngageOnUi(mode, state.Salt, state.CodeHash, state.LockedAt);
            else
                dispatcher.Invoke(() => EngageOnUi(mode, state.Salt, state.CodeHash, state.LockedAt));

            App.Log($"[WinLock] Lock restored on startup (mode={mode}).");
            RaiseStateChanged();
        }
        catch (Exception ex)
        {
            App.Log($"[WinLock] Restore on startup failed: {ex.Message}");
        }
    }

    // ---------------------------------------------------------------- internals

    private void UnlockInternal()
    {
        lock (_sync)
        {
            if (!_isLocked) return;
            _isLocked = false;
        }

        ClearStateFile();
        ApplyPolicies(locked: false);

        var dispatcher = System.Windows.Application.Current?.Dispatcher;
        try
        {
            if (dispatcher == null || dispatcher.CheckAccess())
                DisengageOnUi();
            else
                dispatcher.Invoke(DisengageOnUi);
        }
        catch (Exception ex)
        {
            App.Log($"[WinLock] UI disengage failed: {ex.Message}");
        }

        App.Log("[WinLock] Lock released.");
        RaiseStateChanged();
    }

    /// <summary>Must run on the Dispatcher thread.</summary>
    private void EngageOnUi(string mode, string salt, string hash, long lockedAt)
    {
        lock (_sync)
        {
            if (_isLocked) return;
            _mode = mode;
            _codeSalt = salt;
            _codeHash = hash;
            _lockedAt = lockedAt;
            _isLocked = true;
        }

        InstallHook();

        try
        {
            var win = new LockWindow(this, mode, lockedAt);
            _window = win;
            win.Show();
        }
        catch (Exception ex)
        {
            App.Log($"[WinLock] Lock window could not be shown: {ex.Message}");
        }
    }

    /// <summary>Must run on the Dispatcher thread.</summary>
    private void DisengageOnUi()
    {
        UninstallHook();

        var win = _window;
        _window = null;
        if (win != null)
        {
            try { win.ForceClose(); } catch { }
        }
    }

    // ------------------------------------------------------------------- policies

    private static RegistryKey? OpenWritable(string subKeyPath)
    {
        return Registry.CurrentUser.OpenSubKey(subKeyPath, writable: true)
            ?? Registry.CurrentUser.CreateSubKey(subKeyPath);
    }

    private void ApplyPolicies(bool locked)
    {
        try
        {
            using (var systemKey = OpenWritable(PolicySystemPath))
            {
                if (systemKey != null)
                {
                    if (locked) systemKey.SetValue("DisableTaskMgr", 1, RegistryValueKind.DWord);
                    else systemKey.DeleteValue("DisableTaskMgr", throwOnMissingValue: false);
                }
            }
            using (var explorerKey = OpenWritable(PolicyExplorerPath))
            {
                if (explorerKey != null)
                {
                    if (locked) explorerKey.SetValue("NoWinKeys", 1, RegistryValueKind.DWord);
                    else explorerKey.DeleteValue("NoWinKeys", throwOnMissingValue: false);
                }
            }
        }
        catch (Exception ex)
        {
            App.Log($"[WinLock] Registry policy update failed: {ex.Message}");
        }
    }

    // ------------------------------------------------------------------ state file

    private static string GetStateFilePath()
    {
        return Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "FluxControl", StateFileName);
    }

    private WinLockFileState? ReadStateFile()
    {
        var path = GetStateFilePath();
        if (!File.Exists(path)) return null;
        var json = File.ReadAllText(path);
        if (string.IsNullOrWhiteSpace(json)) return null;
        return JsonSerializer.Deserialize<WinLockFileState>(json, StateJsonOptions);
    }

    private void WriteStateFile(string mode, string salt, string hash, long lockedAt, bool active)
    {
        try
        {
            var path = GetStateFilePath();
            var dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
            var state = new WinLockFileState { Mode = mode, Salt = salt, CodeHash = hash, LockedAt = lockedAt, Active = active };
            File.WriteAllText(path, JsonSerializer.Serialize(state, StateJsonOptions));
        }
        catch (Exception ex)
        {
            App.Log($"[WinLock] Failed to persist lock state: {ex.Message}");
        }
    }

    private void ClearStateFile()
    {
        try
        {
            var path = GetStateFilePath();
            if (File.Exists(path)) File.Delete(path);
        }
        catch (Exception ex)
        {
            App.Log($"[WinLock] Failed to delete lock state file: {ex.Message}");
            // Fallback: leave an explicit inactive marker so a reboot never re-locks.
            try { WriteStateFile(ModeNone, string.Empty, string.Empty, 0, active: false); } catch { }
        }
    }

    // -------------------------------------------------------------------- hashing

    private static string GenerateSalt()
    {
        var salt = new byte[16];
        RandomNumberGenerator.Fill(salt);
        return Convert.ToHexString(salt).ToLowerInvariant();
    }

    private static string ComputeCodeHash(string salt, string code)
    {
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(salt + code))).ToLowerInvariant();
    }

    // -------------------------------------------------------------------- events

    private void RaiseStateChanged()
    {
        WinLockStateDto snapshot;
        lock (_sync)
        {
            snapshot = new WinLockStateDto
            {
                Locked = _isLocked,
                Mode = _isLocked ? _mode : ModeNone,
                LockedAt = _isLocked ? _lockedAt : 0
            };
        }
        StateChanged?.Invoke(snapshot);
    }

    // ---------------------------------------------------------- keyboard hooking

    private void InstallHook()
    {
        if (_hookHandle != IntPtr.Zero) return;
        try
        {
            var module = GetModuleHandleW(null);
            _hookHandle = SetWindowsHookExW(WH_KEYBOARD_LL, _hookProc, module, 0);
            if (_hookHandle == IntPtr.Zero)
                App.Log($"[WinLock] SetWindowsHookEx failed, Win32 error {Marshal.GetLastWin32Error()}.");
        }
        catch (Exception ex)
        {
            App.Log($"[WinLock] Keyboard hook install failed: {ex.Message}");
        }
    }

    private void UninstallHook()
    {
        if (_hookHandle == IntPtr.Zero) return;
        try
        {
            UnhookWindowsHookEx(_hookHandle);
        }
        catch { }
        _hookHandle = IntPtr.Zero;
    }

    private IntPtr KeyboardHookProc(int nCode, IntPtr wParam, IntPtr lParam)
    {
        try
        {
            if (nCode >= 0)
            {
                var info = Marshal.PtrToStructure<KBDLLHOOKSTRUCT>(lParam);
                var message = wParam.ToInt64();
                var isDown = message == WM_KEYDOWN || message == WM_SYSKEYDOWN;
                var isUp = message == WM_KEYUP || message == WM_SYSKEYUP;
                if (isDown || isUp)
                {
                    var altDown = (info.flags & LLKHF_ALTDOWN) != 0;
                    var ctrlDown = GetAsyncKeyState(VK_CONTROL) < 0;
                    var vk = info.vkCode;
                    var swallow =
                        vk == VK_LWIN || vk == VK_RWIN ||
                        (vk == VK_TAB && altDown) ||   // Alt+Tab
                        (vk == VK_F4 && altDown) ||    // Alt+F4
                        (vk == VK_ESCAPE && ctrlDown); // Ctrl+Esc
                    if (swallow) return (IntPtr)1;
                }
            }
        }
        catch { }
        return CallNextHookEx(_hookHandle, nCode, wParam, lParam);
    }

    private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

    [StructLayout(LayoutKind.Sequential)]
    private struct KBDLLHOOKSTRUCT
    {
        public uint vkCode;
        public uint scanCode;
        public uint flags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetWindowsHookExW(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool UnhookWindowsHookEx(IntPtr hhk);

    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern short GetAsyncKeyState(int vKey);

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr GetModuleHandleW(string? lpModuleName);

    // -------------------------------------------------------------------- DTOs

    private sealed class WinLockFileState
    {
        public string Mode { get; set; } = ModeNone;
        public string Salt { get; set; } = string.Empty;
        public string CodeHash { get; set; } = string.Empty;
        public long LockedAt { get; set; }
        public bool Active { get; set; }
    }
}

/// <summary>Snapshot of the WinLock state (serialized to the web panel as locked/mode/lockedAt).</summary>
public class WinLockStateDto
{
    public bool Locked { get; set; }
    public string Mode { get; set; } = "none";
    public long LockedAt { get; set; }
}
