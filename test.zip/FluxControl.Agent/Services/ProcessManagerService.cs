using System.Collections.Concurrent;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace FluxControl.Agent.Services;

public class ProcessItem
{
    public int Pid { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public double MemoryMb { get; set; }
    public float CpuPercent { get; set; }
    public string ExePath { get; set; } = string.Empty;
    /// <summary>"app" (має вікно) | "background" | "system" (сесія 0) — як у Task Manager.</summary>
    public string Category { get; set; } = "background";
}

public class ProcessManagerService
{
    private const int MaxIconExtractionsPerCall = 12;
    private const int IconPushDelayMs = 130;

    // exePath (lowercase) → PNG data URL; "" = extraction failed (negative cache, no retry spam)
    private readonly ConcurrentDictionary<string, string> _iconCache = new();
    private readonly HashSet<string> _sentIconKeys = new(StringComparer.Ordinal);
    private readonly object _sentIconLock = new();

    // Per-PID CPU sampling: TotalProcessorTime ticks + wall-clock ticks of the
    // previous GetProcesses() call. Real CPU% = Δcpu / Δwall × 100 / cores —
    // the same math Task Manager uses, without PerformanceCounter spam.
    private readonly ConcurrentDictionary<int, (long CpuTicks, long WallTicks)> _lastCpuSample = new();

    // Усі exe-шляхи останнього списку (для фонового добування іконок) + guard
    // від паралельного фонового пуша.
    private string[] _lastIconPaths = Array.Empty<string>();
    private int _iconPushRunning;

    public List<ProcessItem> GetProcesses()
    {
        var result = new List<ProcessItem>();
        var processes = Process.GetProcesses();
        long nowTicks = DateTime.UtcNow.Ticks;
        double coreCount = Math.Max(1, Environment.ProcessorCount);
        var alivePids = new HashSet<int>();

        foreach (var p in processes)
        {
            try
            {
                string exePath = string.Empty;
                try { exePath = p.MainModule?.FileName ?? string.Empty; }
                catch { exePath = string.Empty; } // access denied / exited / bitness mismatch

                var mem = Math.Round(p.WorkingSet64 / (1024.0 * 1024.0), 1);

                // ---- Category (Task Manager logic) ----
                string category = "background";
                try
                {
                    if (!string.IsNullOrEmpty(p.MainWindowTitle)) category = "app";
                    else if (p.SessionId == 0) category = "system";
                }
                catch { /* SessionId may throw for exited processes */ }

                // ---- Real CPU% (delta of TotalProcessorTime) ----
                float cpuPercent = 0f;
                try
                {
                    long cpuTicks = p.TotalProcessorTime.Ticks;
                    alivePids.Add(p.Id);
                    if (_lastCpuSample.TryGetValue(p.Id, out var prev))
                    {
                        long dWall = nowTicks - prev.WallTicks;
                        long dCpu = cpuTicks - prev.CpuTicks;
                        if (dWall > 0 && dCpu > 0)
                        {
                            cpuPercent = (float)Math.Clamp(dCpu / (dWall * coreCount) * 100.0, 0.0, 100.0);
                        }
                    }
                    _lastCpuSample[p.Id] = (cpuTicks, nowTicks);
                }
                catch { /* process may exit between calls */ }

                result.Add(new ProcessItem
                {
                    Pid = p.Id,
                    Name = p.ProcessName,
                    Title = p.MainWindowTitle,
                    MemoryMb = mem,
                    CpuPercent = cpuPercent,
                    ExePath = exePath,
                    Category = category
                });
            }
            catch
            {
                // Access denied or process exited
            }
        }

        // Drop samples of processes that no longer exist (PID reuse guard).
        foreach (var stalePid in _lastCpuSample.Keys)
        {
            if (!alivePids.Contains(stalePid))
            {
                _lastCpuSample.TryRemove(stalePid, out _);
            }
        }

        // Запам'ятовуємо всі exe-шляхи — фоновий пуш добуде іконки для всіх,
        // а не тільки для перших 12.
        _lastIconPaths = result
            .Where(p => !string.IsNullOrWhiteSpace(p.ExePath))
            .Select(p => p.ExePath)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToArray();

        // Sort by memory descending (the web applies its own sorting on top).
        return result.OrderByDescending(p => p.MemoryMb).Take(200).ToList();
    }

    /// <summary>
    /// ФОНОВЕ добування іконок для ВСІХ процесів останнього списку.
    /// Кеш уже містить перші 12 (з GetNewIcons) — цей метод добуде решту
    /// і надішле вебу окремими повідомленнями process_icons (партіями по 1),
    /// щоб списки іконок з'являлися поступово без перезапиту списку.
    /// </summary>
    public async Task PushIconsAsync(Func<Dictionary<string, string>, Task> sendBatch)
    {
        if (Interlocked.CompareExchange(ref _iconPushRunning, 1, 0) != 0) return;
        try
        {
            foreach (var path in _lastIconPaths)
            {
                var key = path.ToLowerInvariant();
                if (_iconCache.ContainsKey(key)) continue;

                var dataUrl = ExtractIconDataUrl(path);
                _iconCache[key] = dataUrl;
                if (string.IsNullOrEmpty(dataUrl)) continue; // негативний кеш — не шлемо

                bool alreadySent;
                lock (_sentIconLock)
                {
                    alreadySent = !_sentIconKeys.Add(key);
                }
                if (alreadySent) continue;

                try
                {
                    await sendBatch(new Dictionary<string, string>(StringComparer.Ordinal) { [key] = dataUrl });
                }
                catch
                {
                    break; // сокет мертвий — далі шлювати нікуди
                }
                await Task.Delay(IconPushDelayMs);
            }
        }
        catch { }
        finally
        {
            Interlocked.Exchange(ref _iconPushRunning, 0);
        }
    }

    /// <summary>
    /// Скидає множину «вже надісланих» іконок. Викликається при КОЖНОМУ новому
    /// підключенні релея: свіжа веб-панель не має іконок попередньої сесії,
    /// тому все треба надіслати заново (інакше після F5 список без іконок).
    /// </summary>
    public void ResetSentIcons()
    {
        lock (_sentIconLock)
        {
            _sentIconKeys.Clear();
        }
    }

    /// <summary>
    /// Returns { exePath (lowercase) → "data:image/png;base64,…" } for process
    /// icons not sent to the web yet. At most 12 new extractions per call (the
    /// rest stay in the cache and are returned by a later call). The web falls
    /// back to a letter avatar for processes without an icon.
    /// </summary>
    public Dictionary<string, string> GetNewIcons(List<ProcessItem> processes)
    {
        var newIcons = new Dictionary<string, string>();
        try
        {
            var presentKeys = new HashSet<string>(StringComparer.Ordinal);
            int extractions = 0;

            foreach (var process in processes)
            {
                if (string.IsNullOrWhiteSpace(process.ExePath)) continue;
                var key = process.ExePath.ToLowerInvariant();
                presentKeys.Add(key);
                if (_iconCache.ContainsKey(key)) continue;
                if (extractions >= MaxIconExtractionsPerCall) continue; // next call
                _iconCache[key] = ExtractIconDataUrl(process.ExePath);
                extractions++;
            }

            lock (_sentIconLock)
            {
                foreach (var key in presentKeys)
                {
                    if (_sentIconKeys.Contains(key)) continue;
                    if (_iconCache.TryGetValue(key, out string? dataUrl) && !string.IsNullOrEmpty(dataUrl))
                    {
                        newIcons[key] = dataUrl;
                        _sentIconKeys.Add(key);
                    }
                    // Empty cache values (failed extraction) are skipped silently.
                }
            }
        }
        catch { }
        return newIcons;
    }

    private static string ExtractIconDataUrl(string exePath)
    {
        // 1) Найкраща якість: SHDefExtractIcon у 48px (реальна іконка оболонки
        //    Windows — працює для практично ВСІХ застосунків, не тільки системних).
        try
        {
            // nIconSize = MAKELONG(48, 32): запитуємо 48px (у high word).
            if (Win32Api.SHDefExtractIcon(exePath, 0, 0, out IntPtr hIcon, out _, (48u << 16) | 32u) == 0 && hIcon != IntPtr.Zero)
            {
                using var bmp48 = Icon.FromHandle(hIcon).ToBitmap();
                Win32Api.DestroyIcon(hIcon);
                var png48 = ToPngDataUrl(bmp48, 48);
                if (png48 != null) return png48;
            }
        }
        catch { }

        // 2) Фолбек: ExtractAssociatedIcon (32px) — старий шлях.
        try
        {
            using var icon = Icon.ExtractAssociatedIcon(exePath);
            if (icon == null) return string.Empty;
            using var source = icon.ToBitmap();
            var png = ToPngDataUrl(source, 32);
            return png ?? string.Empty;
        }
        catch
        {
            // Icon extraction of some system processes throws — cache the
            // negative result so we never retry-spam it.
            return string.Empty;
        }
    }

    private static string? ToPngDataUrl(Bitmap source, int size)
    {
        try
        {
            using var bitmap = new Bitmap(size, size, PixelFormat.Format32bppArgb);
            using (var graphics = Graphics.FromImage(bitmap))
            {
                graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                graphics.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
                graphics.Clear(Color.Transparent);
                graphics.DrawImage(source, 0, 0, size, size);
            }
            using var stream = new MemoryStream();
            bitmap.Save(stream, ImageFormat.Png);
            return "data:image/png;base64," + Convert.ToBase64String(stream.ToArray());
        }
        catch
        {
            return null;
        }
    }

    public bool KillProcess(int pid)
    {
        try
        {
            var p = Process.GetProcessById(pid);
            p.Kill(entireProcessTree: true);
            return true;
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"Failed to kill process {pid}: {ex.Message}");
            return false;
        }
    }
}
