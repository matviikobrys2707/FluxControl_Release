using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;

namespace FluxControl.Agent.Services;

/// <summary>
/// Самоперевірка при старті (ТЗ користувача): програма перевіряє свої файли
/// у сховищі %AppData%\FluxControl. У самодостатньому single-file EXE
/// інтерфейс агента (UI/agent_ui.html) та іконка (logo.ico) вбудовані в
/// збірку — RuntimeFiles витягує їх у сховище при першому запуску (без мережі).
///
/// Оновлення цих файлів без пересборки exe: SyncExtraFilesFromManifest()
/// читає манифест version.json у main-гілці репозиторію релізів, звіряє
/// sha256 кожного файлу з files[] і довантажує змінені/відсутні з
/// raw.githubusercontent.com/.../main/files/{filename}.
/// </summary>
public static class BootstrapService
{
    private const string Repo = "matviikobrys2707/FluxControl_Release";
    private const string VersionJsonUrl =
        "https://raw.githubusercontent.com/" + Repo + "/main/version.json";
    private const string FilesBaseUrl =
        "https://raw.githubusercontent.com/" + Repo + "/main/files/";

    /// <summary>Файли, без яких програма не працює (шлях відносно %AppData%\FluxControl).</summary>
    private static readonly string[] RequiredFiles =
    {
        "UI/agent_ui.html", // інтерфейс агента
        "logo.ico"          // іконка вікна/трея/ярликів
    };

    /// <summary>Сховище програми: %AppData%\FluxControl (не залежить від розташування exe).</summary>
    public static string AppDir => RuntimeFiles.DataRoot;

    private static readonly HttpClient Http = new(new HttpClientHandler
    {
        AllowAutoRedirect = true // raw.githubusercontent.com може редіректити
    })
    {
        Timeout = TimeSpan.FromSeconds(30)
    };

    static BootstrapService()
    {
        Http.DefaultRequestHeaders.UserAgent.ParseAdd("FluxControl-Agent/1.0");
    }

    /// <summary>Список відсутніх критичних файлів (відносні шляхи з «/»).</summary>
    public static List<string> FindMissingFiles()
    {
        var missing = new List<string>();
        foreach (var rel in RequiredFiles)
        {
            var full = Path.Combine(AppDir, rel.Replace('/', Path.DirectorySeparatorChar));
            if (!File.Exists(full)) missing.Add(rel);
        }
        return missing;
    }

    /// <summary>
    /// Відновлення файлів: витягує вбудовані ресурси збірки у сховище
    /// (миттєво, без мережі). Повертає список файлів, яких БРАКУЄ ПІСЛЯ
    /// відновлення (порожній = успіх).
    /// </summary>
    public static async Task<List<string>> InstallMissingFilesAsync(
        IProgress<DownloadProgress>? downloadProgress,
        Action<string>? status,
        CancellationToken ct)
    {
        status?.Invoke("Відновлення вбудованих файлів…");
        await Task.Run(() => RuntimeFiles.EnsureRuntimeFiles(), ct);

        // вбудованих могло не вистачити (наприклад, файл додали в манифест
        // пізніше) — тоді тягнемо з репозиторію релізів
        var remaining = FindMissingFiles();
        if (remaining.Count > 0)
        {
            try
            {
                await SyncFilesFromManifestAsync(remaining, downloadProgress, status, ct);
            }
            catch (Exception ex)
            {
                App.Log($"Bootstrap sync from manifest failed: {ex.Message}");
            }
            remaining = FindMissingFiles();
        }

        status?.Invoke(remaining.Count == 0 ? "Готово" : "Частково встановлено");
        return remaining;
    }

    /// <summary>
    /// Фонова синхронізація робочих файлів з манифестом version.json
    /// (main-гілка репозиторію релізів): звіряє sha256 і довантажує тільки
    /// змінені/відсутні. Викликається після старту, не блокує інтерфейс.
    /// </summary>
    public static async Task SyncExtraFilesFromManifest()
    {
        try
        {
            await SyncFilesFromManifestAsync(null, null, null, CancellationToken.None);
        }
        catch (Exception ex)
        {
            App.Log($"Manifest sync skipped: {ex.Message}");
        }
    }

    private static async Task SyncFilesFromManifestAsync(
        List<string>? onlyThese,
        IProgress<DownloadProgress>? progress,
        Action<string>? status,
        CancellationToken ct)
    {
        var manifestUrl = VersionJsonUrl + "?t=" + DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        using var resp = await Http.GetAsync(manifestUrl, ct);
        resp.EnsureSuccessStatusCode();
        var body = await resp.Content.ReadAsStringAsync(ct);
        body = body.TrimStart('\uFEFF');
        var json = JsonSerializer.Deserialize<JsonObject>(body);
        if (json?["files"] is not JsonArray entries) return;

        foreach (var entry in entries)
        {
            var name = entry?["name"]?.GetValue<string>();
            var sha = entry?["sha256"]?.GetValue<string>();
            if (string.IsNullOrWhiteSpace(name)) continue;
            if (onlyThese != null && !onlyThese.Contains(name)) continue;

            var target = SafeTargetPath(AppDir, name);
            if (target == null)
            {
                App.Log($"Manifest sync: skip unsafe path {name}");
                continue;
            }

            bool need = !File.Exists(target) ||
                        (!string.IsNullOrEmpty(sha) && !Sha256Matches(target, sha));
            if (!need) continue;

            status?.Invoke($"Завантаження {name}…");
            var url = FilesBaseUrl + name.Replace('\\', '/').TrimStart('/') +
                      "?t=" + DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            var tmp = target + ".tmp";
            Directory.CreateDirectory(Path.GetDirectoryName(target)!);

            using (var src = await Http.GetStreamAsync(url, ct))
            using (var dst = new FileStream(tmp, FileMode.Create, FileAccess.Write, FileShare.None, 81920, useAsync: true))
                await src.CopyToAsync(dst, 81920, ct);

            if (File.Exists(target)) File.Delete(target);
            File.Move(tmp, target);
            App.Log($"Manifest sync: updated {name}");

            if (progress != null)
            {
                var len = new FileInfo(target).Length;
                progress.Report(new DownloadProgress { ReceivedBytes = len, TotalBytes = len });
            }
        }
    }

    private static string? SafeTargetPath(string root, string relName)
    {
        try
        {
            var full = Path.GetFullPath(Path.Combine(root,
                relName.Replace('/', Path.DirectorySeparatorChar)));
            if (!full.StartsWith(root, StringComparison.OrdinalIgnoreCase)) return null;
            return full;
        }
        catch { return null; }
    }

    private static bool Sha256Matches(string filePath, string expected)
    {
        try
        {
            using var sha = SHA256.Create();
            using var fs = File.OpenRead(filePath);
            var hash = Convert.ToHexString(sha.ComputeHash(fs));
            return string.Equals(hash, expected.Trim(), StringComparison.OrdinalIgnoreCase);
        }
        catch { return false; }
    }
}
