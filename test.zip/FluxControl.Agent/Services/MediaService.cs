using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace FluxControl.Agent.Services;

public class MediaService
{
    private readonly object _recordingLock = new();
    private Process? _recordingProcess;
    private CancellationTokenSource? _recordingCts;
    public string LastError { get; private set; } = string.Empty;

    private List<string>? _videoDevicesCache;
    private DateTime _videoDevicesAt = DateTime.MinValue;
    private static readonly TimeSpan VideoDevicesCacheTtl = TimeSpan.FromSeconds(60);

    public string CaptureScreenshotBase64(long quality = 80, int maxWidth = 0)
    {
        int left = Win32Api.GetSystemMetrics(Win32Api.SM_XVIRTUALSCREEN), top = Win32Api.GetSystemMetrics(Win32Api.SM_YVIRTUALSCREEN);
        int width = Win32Api.GetSystemMetrics(Win32Api.SM_CXVIRTUALSCREEN), height = Win32Api.GetSystemMetrics(Win32Api.SM_CYVIRTUALSCREEN);
        if (width <= 0 || height <= 0) { width = Win32Api.GetSystemMetrics(Win32Api.SM_CXSCREEN); height = Win32Api.GetSystemMetrics(Win32Api.SM_CYSCREEN); left = top = 0; }
        using var bitmap = new Bitmap(width, height, PixelFormat.Format32bppArgb);
        using (var graphics = Graphics.FromImage(bitmap)) graphics.CopyFromScreen(left, top, 0, 0, new Size(width, height), CopyPixelOperation.SourceCopy);
        using var output = maxWidth > 0 && width > maxWidth ? new Bitmap(maxWidth, Math.Max(1, height * maxWidth / width), PixelFormat.Format24bppRgb) : null;
        if (output != null) { using var graphics = Graphics.FromImage(output); graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBilinear; graphics.DrawImage(bitmap, 0, 0, output.Width, output.Height); }
        using var stream = new MemoryStream(); var encoder = GetEncoder(ImageFormat.Jpeg);
        if (encoder != null) { var parameters = new EncoderParameters(1); parameters.Param[0] = new EncoderParameter(Encoder.Quality, quality); (output ?? bitmap).Save(stream, encoder, parameters); }
        else (output ?? bitmap).Save(stream, ImageFormat.Jpeg);
        return Convert.ToBase64String(stream.ToArray());
    }

    /// <summary>
    /// All DirectShow video device names in enumeration order (ffmpeg based).
    /// Successful results are cached for 60s; an empty result (failure or no
    /// camera) is not cached so a freshly plugged camera is found quickly.
    /// </summary>
    public async Task<List<string>> ListVideoDevicesAsync()
    {
        if (_videoDevicesCache != null && DateTime.UtcNow - _videoDevicesAt < VideoDevicesCacheTtl)
        {
            return new List<string>(_videoDevicesCache);
        }

        var devices = new List<string>();
        var ffmpeg = ResolveFfmpeg();
        if (ffmpeg == null) { SetError("Не знайдено FFmpeg. Додайте ffmpeg.exe до папки FluxControl або PATH на віддаленому ПК."); return devices; }
        try
        {
            using var process = new Process { StartInfo = new ProcessStartInfo { FileName = ffmpeg, CreateNoWindow = true, UseShellExecute = false, RedirectStandardError = true } };
            process.StartInfo.ArgumentList.Add("-list_devices"); process.StartInfo.ArgumentList.Add("true"); process.StartInfo.ArgumentList.Add("-f"); process.StartInfo.ArgumentList.Add("dshow"); process.StartInfo.ArgumentList.Add("-i"); process.StartInfo.ArgumentList.Add("dummy");
            process.Start(); var output = await process.StandardError.ReadToEndAsync(); await process.WaitForExitAsync();
            var inVideoSection = false;
            foreach (var line in output.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None))
            {
                if (line.Contains("DirectShow video devices", StringComparison.OrdinalIgnoreCase)) { inVideoSection = true; continue; }
                if (line.Contains("DirectShow audio devices", StringComparison.OrdinalIgnoreCase)) break;
                if (!inVideoSection) continue;
                var first = line.IndexOf('"'); var second = first >= 0 ? line.IndexOf('"', first + 1) : -1;
                if (first >= 0 && second > first)
                {
                    var name = line[(first + 1)..second].Trim();
                    if (name.Length > 0 && !devices.Contains(name)) devices.Add(name);
                }
            }
        }
        catch (Exception ex) { SetError(ex.Message); }
        if (devices.Count > 0) { _videoDevicesCache = devices; _videoDevicesAt = DateTime.UtcNow; }
        return devices;
    }

    public async Task<string?> CaptureWebcamPhotoBase64Async(string? preferredDevice = null, int delaySeconds = 0, Action<int>? onCountdown = null)
    {
        LastError = string.Empty;

        int delay = Math.Clamp(delaySeconds, 0, 600);
        for (int secondsLeft = delay; secondsLeft > 0; secondsLeft--)
        {
            try { onCountdown?.Invoke(secondsLeft); } catch { }
            await Task.Delay(1000);
        }

        var devices = await ListVideoDevicesAsync();
        var order = new List<string>();
        if (!string.IsNullOrWhiteSpace(preferredDevice)) order.Add(preferredDevice);
        foreach (var device in devices) { if (!order.Contains(device)) order.Add(device); }

        // Up to 3 DirectShow attempts: preferred first, then enumeration order.
        var tried = new List<string>();
        for (int i = 0; i < Math.Min(3, order.Count); i++)
        {
            var candidate = order[i];
            tried.Add(candidate);
            var file = Path.Combine(Path.GetTempPath(), $"flux_cam_{Guid.NewGuid():N}.jpg");
            try
            {
                var result = await RunFfmpegAsync(new[] { "-y", "-f", "dshow", "-rtbufsize", "64M", "-i", $"video={candidate}", "-frames:v", "1", "-q:v", "2", file }, TimeSpan.FromSeconds(12));
                if (result.Success && File.Exists(file) && new FileInfo(file).Length > 0)
                {
                    return Convert.ToBase64String(await File.ReadAllBytesAsync(file));
                }
            }
            catch { }
            finally { TryDelete(file); }
        }

        // No DirectShow device answered at all → some cameras are MediaFoundation-only.
        if (devices.Count == 0)
        {
            var mfFile = Path.Combine(Path.GetTempPath(), $"flux_cam_{Guid.NewGuid():N}.jpg");
            try
            {
                var result = await RunFfmpegAsync(new[] { "-y", "-f", "mf", "-i", "video=0", "-frames:v", "1", "-q:v", "2", mfFile }, TimeSpan.FromSeconds(12));
                if (result.Success && File.Exists(mfFile) && new FileInfo(mfFile).Length > 0)
                {
                    return Convert.ToBase64String(await File.ReadAllBytesAsync(mfFile));
                }
            }
            catch { }
            finally { TryDelete(mfFile); }
        }

        SetError(tried.Count > 0
            ? "Камеру не знайдено або вона зайнята іншою програмою. Спробовані пристрої: " + string.Join("; ", tried)
            : "Камеру не знайдено або вона зайнята іншою програмою. DirectShow не виявив жодного відеопристрою.");
        return null;
    }

    public async Task<string?> RecordShortVideoBase64Async(string source = "screen", int seconds = 5, string? cameraDevice = null)
    {
        LastError = string.Empty;
        seconds = Math.Clamp(seconds, 5, 300);
        var file = Path.Combine(Path.GetTempPath(), $"flux_clip_{Guid.NewGuid():N}.mp4");
        CancellationTokenSource? cts = null;
        try
        {
            List<string> arguments;
            if (source.Equals("webcam", StringComparison.OrdinalIgnoreCase))
            {
                var device = !string.IsNullOrWhiteSpace(cameraDevice) ? cameraDevice : await GetFirstDshowVideoDeviceAsync();
                if (string.IsNullOrWhiteSpace(device)) { SetError("Камеру не знайдено. Перевірте дозволи Windows та підключення камери."); return null; }
                arguments = new() { "-y", "-f", "dshow", "-rtbufsize", "128M", "-t", seconds.ToString(), "-i", $"video={device}" };
            }
            else
            {
                // Do not force a capture size: fixed 1280x720 fails on some desktop layouts.
                arguments = new() { "-y", "-f", "gdigrab", "-framerate", "30", "-draw_mouse", "1", "-t", seconds.ToString(), "-i", "desktop" };
            }
            arguments.AddRange(new[] { "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-pix_fmt", "yuv420p", "-movflags", "+faststart", file });
            cts = new CancellationTokenSource(TimeSpan.FromSeconds(seconds + 20));
            var result = await RunFfmpegAsync(arguments, cts.Token, true);
            if (!result.Success || !File.Exists(file) || new FileInfo(file).Length == 0) { SetError(result.Error ?? "FFmpeg не створив відеофайл."); return null; }
            return Convert.ToBase64String(await File.ReadAllBytesAsync(file));
        }
        catch (OperationCanceledException) { SetError("Запис скасовано або перевищено час очікування."); return null; }
        catch (Exception ex) { SetError(ex.Message); return null; }
        finally { lock (_recordingLock) { _recordingProcess = null; _recordingCts?.Dispose(); _recordingCts = null; } cts?.Dispose(); TryDelete(file); }
    }

    public void CancelRecording() { lock (_recordingLock) { try { _recordingCts?.Cancel(); } catch { } try { if (_recordingProcess is { HasExited: false }) _recordingProcess.Kill(true); } catch { } } }

    private async Task<(bool Success, string? Error)> RunFfmpegAsync(IEnumerable<string> arguments, TimeSpan timeout) { using var cts = new CancellationTokenSource(timeout); return await RunFfmpegAsync(arguments, cts.Token, false); }
    private async Task<(bool Success, string? Error)> RunFfmpegAsync(IEnumerable<string> arguments, CancellationToken cancellationToken, bool recording)
    {
        var ffmpeg = ResolveFfmpeg();
        if (ffmpeg == null) return (false, "Не знайдено FFmpeg. Додайте ffmpeg.exe до папки FluxControl або PATH на віддаленому ПК.");
        using var process = new Process { StartInfo = new ProcessStartInfo { FileName = ffmpeg, CreateNoWindow = true, UseShellExecute = false, RedirectStandardError = true, RedirectStandardOutput = true } };
        foreach (var argument in arguments) process.StartInfo.ArgumentList.Add(argument);
        try
        {
            process.Start();
            var stderrTask = process.StandardError.ReadToEndAsync(); var stdoutTask = process.StandardOutput.ReadToEndAsync();
            if (recording) lock (_recordingLock) { _recordingProcess = process; _recordingCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken); }
            await process.WaitForExitAsync(cancellationToken); var stderr = await stderrTask; _ = await stdoutTask;
            return process.ExitCode == 0 ? (true, null) : (false, SimplifyFfmpegError(stderr));
        }
        catch (OperationCanceledException) { try { if (!process.HasExited) process.Kill(true); } catch { } throw; }
        catch (Exception ex) { return (false, ex.Message); }
    }

    private async Task<string?> GetFirstDshowVideoDeviceAsync()
    {
        var devices = await ListVideoDevicesAsync();
        return devices.FirstOrDefault();
    }

    private static string? ResolveFfmpeg() => DependencyService.ResolveFfmpeg();
    private void SetError(string error) { LastError = string.IsNullOrWhiteSpace(error) ? "Невідома помилка захоплення медіа." : error; Debug.WriteLine($"[Media] {LastError}"); }
    private static string SimplifyFfmpegError(string error) { var lines = error.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries); return lines.LastOrDefault(line => line.Contains("Error", StringComparison.OrdinalIgnoreCase) || line.Contains("failed", StringComparison.OrdinalIgnoreCase) || line.Contains("not found", StringComparison.OrdinalIgnoreCase))?.Trim() ?? "FFmpeg завершився з помилкою."; }
    private static void TryDelete(string path) { try { if (File.Exists(path)) File.Delete(path); } catch { } }
    private static ImageCodecInfo? GetEncoder(ImageFormat format) => ImageCodecInfo.GetImageDecoders().FirstOrDefault(codec => codec.FormatID == format.Guid);
}
