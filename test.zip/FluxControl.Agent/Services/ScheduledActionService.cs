using System;
using System.IO;
using System.Diagnostics;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;

namespace FluxControl.Agent.Services;

public class ScheduledActionStateDto
{
    [JsonPropertyName("active")]
    public bool Active { get; set; }

    /// <summary>shutdown | restart | sleep | hibernate | lock</summary>
    [JsonPropertyName("action")]
    public string Action { get; set; } = string.Empty;

    /// <summary>Unix ms — момент виконання дії (джерело правдивого відліку на сайті).</summary>
    [JsonPropertyName("endsAt")]
    public long EndsAt { get; set; }

    [JsonPropertyName("totalSeconds")]
    public int TotalSeconds { get; set; }

    [JsonPropertyName("secondsLeft")]
    public int SecondsLeft => Active
        ? Math.Max(0, (int)Math.Ceiling((EndsAt - DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()) / 1000.0))
        : 0;
}

/// <summary>
/// Real agent-side power timer. Unlike the previous "shutdown /t N" approach it
/// supports EVERY action (вимкнення / перезавантаження / сон / гібернація /
/// блокування), can always be cancelled, survives agent restarts (pending state
/// is persisted to %AppData%/FluxControl/timer.json) and broadcasts its state so
/// the web panel shows a live countdown ("Перезавантаження через 09:42").
/// The web panel computes the visible countdown from <see cref="ScheduledActionStateDto.EndsAt"/>,
/// so refreshing the page does not lose the pending timer.
/// </summary>
public class ScheduledActionService : IDisposable
{
    private static readonly string StatePath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FluxControl", "timer.json");

    public const string ActionShutdown = "shutdown";
    public const string ActionRestart = "restart";
    public const string ActionSleep = "sleep";
    public const string ActionHibernate = "hibernate";
    public const string ActionLock = "lock";

    private readonly object _sync = new();
    private System.Threading.Timer? _timer;
    private ScheduledActionStateDto _state = new();
    private bool _disposed;

    /// <summary>Raised on every state transition (start / cancel / tick push).</summary>
    public event Action<ScheduledActionStateDto>? StateChanged;

    public ScheduledActionStateDto GetState()
    {
        lock (_sync) return Clone(_state);
    }

    /// <summary>Starts (or replaces) the pending scheduled action.</summary>
    public void Start(string action, int seconds)
    {
        var normalized = NormalizeAction(action);
        if (normalized == null)
            throw new ArgumentException($"Невідома дія таймера: {action}");
        if (seconds < 5) seconds = 5;
        if (seconds > 24 * 60 * 60) seconds = 24 * 60 * 60; // 24 год максимум

        var now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        var newState = new ScheduledActionStateDto
        {
            Active = true,
            Action = normalized,
            EndsAt = now + seconds * 1000L,
            TotalSeconds = seconds
        };

        System.Threading.Timer? oldTimer;
        lock (_sync)
        {
            if (_disposed) return;
            oldTimer = _timer;
            _timer = null;
            _state = newState;
        }
        try { oldTimer?.Dispose(); } catch { }

        PersistLocked();
        App.Log($"[Timer] Scheduled '{normalized}' in {seconds}s (endsAt={newState.EndsAt})");
        RaiseChanged();

        var due = TimeSpan.FromSeconds(seconds);
        var fresh = new System.Threading.Timer(OnFired, null, due, Timeout.InfiniteTimeSpan);
        lock (_sync)
        {
            if (_disposed || !_state.Active || _state.EndsAt != newState.EndsAt)
            {
                // A newer Start/Cancel won the race — throw this timer away.
                try { fresh.Dispose(); } catch { }
                return;
            }
            _timer = fresh;
        }
    }

    /// <summary>Cancels any pending action. Aborts a legacy OS "shutdown /t" too.</summary>
    public void Cancel()
    {
        System.Threading.Timer? oldTimer;
        bool hadActive;
        lock (_sync)
        {
            if (_disposed) return;
            oldTimer = _timer;
            _timer = null;
            hadActive = _state.Active;
            _state = new ScheduledActionStateDto();
        }
        try { oldTimer?.Dispose(); } catch { }
        try { Process.Start(new ProcessStartInfo("shutdown", "/a") { CreateNoWindow = true, UseShellExecute = false }); } catch { }
        if (hadActive)
        {
            App.Log("[Timer] Cancelled");
            RaiseChanged();
        }
        PersistLocked();
    }

    /// <summary>
    /// Called once on agent startup: a timer persisted before the app exited is
    /// re-armed if it is still in the future, or executed right away if the
    /// deadline passed while the app was closed.
    /// </summary>
    public void TryRestore()
    {
        try
        {
            if (!File.Exists(StatePath)) return;
            ScheduledActionStateDto? saved;
            try
            {
                saved = JsonSerializer.Deserialize<ScheduledActionStateDto>(File.ReadAllText(StatePath));
            }
            catch
            {
                TryDeleteState();
                return;
            }
            if (saved == null || !saved.Active || saved.EndsAt <= 0)
            {
                TryDeleteState();
                return;
            }

            var action = NormalizeAction(saved.Action);
            if (action == null)
            {
                TryDeleteState();
                return;
            }

            long now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            int secondsLeft = (int)Math.Ceiling((saved.EndsAt - now) / 1000.0);
            if (secondsLeft > 0)
            {
                App.Log($"[Timer] Restored pending '{saved.Action}' ({secondsLeft}s left)");
                Start(saved.Action, secondsLeft);
            }
            else
            {
                // The deadline passed while the agent was not running.
                App.Log($"[Timer] Deadline for '{saved.Action}' passed while app was closed — executing now");
                lock (_sync) { _state = new ScheduledActionStateDto(); }
                TryDeleteState();
                Execute(action);
            }
        }
        catch (Exception ex)
        {
            App.Log($"[Timer] Restore failed: {ex.Message}");
        }
    }

    private void OnFired(object? state)
    {
        string action;
        lock (_sync)
        {
            if (_disposed || !_state.Active) return;
            action = _state.Action;
            _state = new ScheduledActionStateDto();
            _timer = null;
        }
        App.Log($"[Timer] Fired: {action}");
        RaiseChanged();
        TryDeleteState();
        Execute(action);
    }

    private static void Execute(string action)
    {
        try
        {
            switch (action)
            {
                case ActionShutdown:
                    Process.Start(new ProcessStartInfo("shutdown", "/s /t 0") { CreateNoWindow = true, UseShellExecute = false });
                    break;
                case ActionRestart:
                    Process.Start(new ProcessStartInfo("shutdown", "/r /t 0") { CreateNoWindow = true, UseShellExecute = false });
                    break;
                case ActionSleep:
                    System.Windows.Forms.Application.SetSuspendState(System.Windows.Forms.PowerState.Suspend, true, true);
                    break;
                case ActionHibernate:
                    System.Windows.Forms.Application.SetSuspendState(System.Windows.Forms.PowerState.Hibernate, true, true);
                    break;
                case ActionLock:
                    Process.Start(new ProcessStartInfo("rundll32.exe", "user32.dll,LockWorkStation") { CreateNoWindow = true, UseShellExecute = false });
                    break;
            }
        }
        catch (Exception ex)
        {
            App.Log($"[Timer] Execute '{action}' failed: {ex.Message}");
        }
    }

    private void RaiseChanged()
    {
        ScheduledActionStateDto snapshot;
        lock (_sync) snapshot = Clone(_state);
        try { StateChanged?.Invoke(snapshot); } catch { }
    }

    private void PersistLocked()
    {
        // Called with _sync NOT held (safe either way) — writes the current state.
        try
        {
            ScheduledActionStateDto snapshot;
            lock (_sync) snapshot = Clone(_state);
            Directory.CreateDirectory(Path.GetDirectoryName(StatePath)!);
            File.WriteAllText(StatePath, JsonSerializer.Serialize(snapshot, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch { }
    }

    private static void TryDeleteState()
    {
        try { if (File.Exists(StatePath)) File.Delete(StatePath); } catch { }
    }

    private static string? NormalizeAction(string? action)
    {
        var a = (action ?? "").Trim().ToLowerInvariant();
        return a switch
        {
            ActionShutdown => ActionShutdown,
            ActionRestart => ActionRestart,
            ActionSleep => ActionSleep,
            ActionHibernate or "hibernation" or "гибернація" => ActionHibernate,
            ActionLock or "lockscreen" => ActionLock,
            _ => null
        };
    }

    private static ScheduledActionStateDto Clone(ScheduledActionStateDto s) => new()
    {
        Active = s.Active,
        Action = s.Action,
        EndsAt = s.EndsAt,
        TotalSeconds = s.TotalSeconds
    };

    public void Dispose()
    {
        System.Threading.Timer? oldTimer;
        lock (_sync)
        {
            if (_disposed) return;
            _disposed = true;
            oldTimer = _timer;
            _timer = null;
        }
        try { oldTimer?.Dispose(); } catch { }
    }
}
