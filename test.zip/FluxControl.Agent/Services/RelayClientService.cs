using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace FluxControl.Agent.Services;

public class RelayClientService : IDisposable
{
    private readonly PairingService _pairingService;
    private readonly SystemService _systemService;
    private readonly InputService _inputService;
    private readonly ProcessManagerService _processService;
    private readonly FileManagerService _fileService;
    private readonly MediaService _mediaService;

    private readonly string _relayBaseUrl;
    private ClientWebSocket? _ws;
    private CancellationTokenSource? _cts;
    private CancellationTokenSource? _screenStreamCts;
    private readonly SemaphoreSlim _sendLock = new(1, 1);
    private int _screenStreamFps;
    private int _screenStreamQuality;
    private int _screenStreamMaxWidth;
    private bool _isDisposed;

    private static readonly HttpClient _httpClient = new() { Timeout = TimeSpan.FromSeconds(6) };
    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        DictionaryKeyPolicy = JsonNamingPolicy.CamelCase
    };

    public bool IsConnected => _ws != null && _ws.State == WebSocketState.Open;
    public string Status { get; private set; } = "connecting"; // "connecting", "connected", "error"
    public string? LastError { get; private set; } = null;
    public event Action<bool>? OnConnectionStatusChanged;
    public event Action<string, string?>? OnStateChanged;
    private bool _lastConnectionStatus = false;
    private readonly SpeedTestService _speedTestService = new();
    public SpeedTestService SpeedTest => _speedTestService;
    private readonly ScheduledActionService _scheduledActions = new();
    public ScheduledActionService ScheduledActions => _scheduledActions;
    private WinLockService? _winLockService;
    private bool _autoSpeedtestDone;
    private int _reconnectAttempt;

    public RelayClientService(
        PairingService pairingService,
        SystemService systemService,
        InputService inputService,
        ProcessManagerService processService,
        FileManagerService fileService,
        MediaService mediaService,
        string relayBaseUrl = "https://fluxcontrol-backend.onrender.com")
    {
        _pairingService = pairingService;
        _systemService = systemService;
        _inputService = inputService;
        _processService = processService;
        _fileService = fileService;
        _mediaService = mediaService;
        _relayBaseUrl = relayBaseUrl.TrimEnd('/');
        _speedTestService.OnResult += result => _ = SendSpeedTestResultAsync(result);
        _scheduledActions.StateChanged += state => { _ = SendTimerStateAsync(); };
    }

    private async Task SendSpeedTestResultAsync(SpeedTestResultDto result)
    {
        try { await SendJsonAsync(new { type = "speedtest_result", data = result }); } catch { }
    }

    private async Task SendTimerStateAsync()
    {
        try { await SendJsonAsync(new { type = "timer_state", data = _scheduledActions.GetState() }); } catch { }
    }

    public void SetWinLockService(WinLockService winLockService)
    {
        _winLockService = winLockService;
        _winLockService.StateChanged += state => { _ = SendWinLockStateAsync(); };
    }

    private async Task SendWinLockStateAsync()
    {
        var svc = _winLockService;
        if (svc == null) return;
        try
        {
            await SendJsonAsync(new
            {
                type = "winlock_state",
                data = new { locked = svc.IsLocked, mode = svc.Mode, lockedAt = svc.LockedAt }
            });
        }
        catch { }
    }

    public void Start()
    {
        _cts = new CancellationTokenSource();
        _ = ConnectLoopAsync(_cts.Token);
    }

    public void ForceReconnect()
    {
        try
        {
            _ws?.Dispose();
            _ws = null;
        }
        catch { }
    }

    private void NotifyConnectionStatus(bool isConnected, string? error = null)
    {
        Status = isConnected ? "connected" : "error";
        LastError = error;
        if (_lastConnectionStatus != isConnected)
        {
            _lastConnectionStatus = isConnected;
            OnConnectionStatusChanged?.Invoke(isConnected);
            OnStateChanged?.Invoke(Status, LastError);
            App.Log($"[Relay] Connection status changed: {(isConnected ? "ONLINE" : "OFFLINE")} (Error: {error ?? "None"})");
        }
    }

    private async Task ConnectLoopAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested && !_isDisposed)
        {
            try
            {
                await RegisterWithRelayHttpAsync();

                var wssUrl = _relayBaseUrl.Replace("https://", "wss://").Replace("http://", "ws://");
                var uri = new Uri($"{wssUrl}/ws?role=agent&code={_pairingService.DeviceCode}&hwid={_pairingService.HardwareId}");

                _ws = new ClientWebSocket();
                // Protocol-level ping/pong every 25s: Render's idle timeout was
                // silently killing the socket and the agent looked offline.
                _ws.Options.KeepAliveInterval = TimeSpan.FromSeconds(25);
                App.Log($"[Relay] Connecting to Render Relay: {uri}");
                using (var connectCts = CancellationTokenSource.CreateLinkedTokenSource(ct))
                {
                    connectCts.CancelAfter(TimeSpan.FromSeconds(6));
                    await _ws.ConnectAsync(uri, connectCts.Token);
                }
                App.Log("[Relay] Connected to Render Relay successfully!");
                NotifyConnectionStatus(true);
                _reconnectAttempt = 0;

                // Нова сесія веб-панелі (сторінка оновили / реконект) не має
                // іконок від попередньої сесії — скидання «вже надісланих»,
                // інакше після F5 список залишався БЕЗ іконок взагалі.
                _processService.ResetSentIcons();

                await SendInitialTelemetryAsync();

                // Push current WinLock state to every freshly (re)connected panel session.
                await SendWinLockStateAsync();

                // Push the pending power timer (if any) so a refreshed page or a
                // newly connected panel shows the real countdown immediately.
                await SendTimerStateAsync();

                // Push current master volume so the web slider initializes instantly.
                try
                {
                    if (AudioService.TryGetVolume(out int initVolume) && AudioService.TryGetMute(out bool initMuted))
                    {
                        await SendJsonAsync(new { type = "volume_state", data = new { value = initVolume, muted = initMuted, success = true } });
                    }
                }
                catch { }

                // One automatic speed measurement per agent lifetime, right after
                // the relay link is up — the site shows it on the device Info tab.
                if (!_autoSpeedtestDone && _speedTestService.Last == null)
                {
                    _autoSpeedtestDone = true;
                    _ = Task.Run(() => _speedTestService.RunAsync(auto: true));
                }

                using var streamCts = CancellationTokenSource.CreateLinkedTokenSource(ct);
                using var terminal = new TerminalService();
                terminal.OnOutputReceived += (s) => _ = SendJsonAsync(new { type = "terminal_output", data = s });
                terminal.OnErrorReceived += (s) => _ = SendJsonAsync(new { type = "terminal_output", data = s });

                var metricsTask = Task.Run(async () =>
                {
                    while (!streamCts.Token.IsCancellationRequested && _ws?.State == WebSocketState.Open)
                    {
                        try
                        {
                            var metrics = _systemService.GetMetrics();
                            await SendJsonAsync(new
                            {
                                type = "telemetry",
                                data = metrics,
                                speedTest = _speedTestService.Last,
                                isOnline = true,
                                lastSeen = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
                            });
                        }
                        catch { }
                        await Task.Delay(1000, streamCts.Token).ContinueWith(_ => { });
                    }
                }, streamCts.Token);

                var buffer = new byte[64 * 1024];
                while (_ws.State == WebSocketState.Open && !ct.IsCancellationRequested)
                {
                    var ms = new MemoryStream();
                    WebSocketReceiveResult result;
                    do
                    {
                        result = await _ws.ReceiveAsync(new ArraySegment<byte>(buffer), ct);
                        if (result.MessageType == WebSocketMessageType.Close)
                        {
                            await _ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "Closing", ct);
                            break;
                        }
                        ms.Write(buffer, 0, result.Count);
                    } while (!result.EndOfMessage);

                    if (result.MessageType == WebSocketMessageType.Close) break;

                    var jsonStr = Encoding.UTF8.GetString(ms.ToArray());
                    _ = HandleIncomingMessageAsync(jsonStr, terminal);
                }

                streamCts.Cancel();
                await metricsTask.ContinueWith(_ => { });
            }
            catch (Exception ex)
            {
                if (!ct.IsCancellationRequested)
                {
                    _reconnectAttempt++;
                    var delay = TimeSpan.FromSeconds(Math.Min(60, 4 * _reconnectAttempt));
                    App.Log($"[Relay] Disconnected: {ex.Message}. Reconnecting in {delay.TotalSeconds:F0}s...");
                    NotifyConnectionStatus(false, ex.Message);
                }
            }
            finally
            {
                _ws?.Dispose();
                _ws = null;
            }

            if (!ct.IsCancellationRequested && !_isDisposed)
            {
                var backoff = TimeSpan.FromSeconds(Math.Min(60, 4 * Math.Max(1, _reconnectAttempt)));
                await Task.Delay(backoff, ct).ContinueWith(_ => { });
            }
        }
    }

    private async Task RegisterWithRelayHttpAsync()
    {
        try
        {
            var payload = new
            {
                hwid = _pairingService.HardwareId,
                code = _pairingService.DeviceCode,
                name = Environment.MachineName,
                username = Environment.UserName,
                os = _systemService.OsName,
                cpu = _systemService.CpuName,
                ram = $"{_systemService.TotalRamGb:F0} GB",
                gpu = _systemService.GpuName,
                localUrl = "http://127.0.0.1:5080",
                activeUrl = $"{_relayBaseUrl}/ws?role=client&code={_pairingService.DeviceCode}"
            };
            var json = JsonSerializer.Serialize(payload, _jsonOptions);
            using var content1 = new StringContent(json, Encoding.UTF8, "application/json");
            using var content2 = new StringContent(json, Encoding.UTF8, "application/json");

            // Register with Render
            try { await _httpClient.PostAsync($"{_relayBaseUrl}/api/register", content1); } catch { }
            // Register with Cloudflare Pages D1
            try { await _httpClient.PostAsync("https://fluxcontrol.pages.dev/api/agent/register", content2); } catch { }
        }
        catch { }
    }

    private async Task SendInitialTelemetryAsync()
    {
        await SendJsonAsync(new
        {
            type = "telemetry",
            code = _pairingService.DeviceCode,
            pcUsername = Environment.UserName,
            machineName = Environment.MachineName,
            osName = _systemService.OsName,
            cpuName = _systemService.CpuName,
            gpuName = _systemService.GpuName,
            ramTotal = $"{_systemService.TotalRamGb:F0} GB",
            isOnline = true
        });
    }

    private async Task HandleIncomingMessageAsync(string jsonStr, TerminalService terminal)
    {
        JsonObject? msg = null;
        try { msg = JsonSerializer.Deserialize<JsonObject>(jsonStr); } catch { }
        if (msg == null) return;

        var type = msg["type"]?.GetValue<string>() ?? "";

        switch (type)
        {
            case "ping":
            case "health_check":
                await SendJsonAsync(new
                {
                    type = "pong",
                    timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                    machineName = Environment.MachineName,
                    userName = Environment.UserName,
                    pcUsername = Environment.UserName,
                    status = "ok",
                    cpuName = _systemService.CpuName,
                    gpuName = _systemService.GpuName
                });
                try
                {
                    var instantMetrics = _systemService.GetMetrics();
                    await SendJsonAsync(new
                    {
                        type = "telemetry",
                        data = instantMetrics,
                        speedTest = _speedTestService.Last,
                        isOnline = true,
                        lastSeen = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
                    });
                }
                catch { }
                break;

            case "mouse_move":
                _inputService.MoveMouse(msg["dx"]?.GetValue<int>() ?? 0, msg["dy"]?.GetValue<int>() ?? 0);
                break;

            case "mouse_move_abs":
                // AI-агент: абсолютні нормалізовані координати 0..1000.
                _inputService.MoveMouseAbsoluteNormalized(
                    msg["nx"]?.GetValue<double>() ?? 0,
                    msg["ny"]?.GetValue<double>() ?? 0);
                break;

            case "mouse_click":
                _inputService.MouseClick(msg["button"]?.GetValue<string>() ?? "left", msg["double"]?.GetValue<bool>() ?? false);
                break;

            case "mouse_down":
                _inputService.MouseDown(msg["button"]?.GetValue<string>() ?? "left");
                break;

            case "mouse_up":
                _inputService.MouseUp(msg["button"]?.GetValue<string>() ?? "left");
                break;

            case "mouse_scroll":
                _inputService.MouseScroll(msg["dx"]?.GetValue<int>() ?? 0, msg["dy"]?.GetValue<int>() ?? 0);
                break;

            case "key_press":
                string key = msg["key"]?.GetValue<string>() ?? "";
                var mods = msg["modifiers"]?.AsArray().Select(x => x?.ToString() ?? "").ToList();
                _inputService.KeyPress(key, mods);
                break;

            case "key_down":
                _inputService.KeyDown(msg["key"]?.GetValue<string>() ?? "");
                break;

            case "key_up":
                _inputService.KeyUp(msg["key"]?.GetValue<string>() ?? "");
                break;

            case "key_text":
                _inputService.SendText(msg["text"]?.GetValue<string>() ?? "");
                break;

            case "volume_get":
                {
                    bool gotVol = AudioService.TryGetVolume(out int curVolume);
                    bool gotMute = AudioService.TryGetMute(out bool curMuted);
                    await SendJsonAsync(new { type = "volume_state", data = new { value = curVolume, muted = curMuted, success = gotVol && gotMute } });
                }
                break;

            case "volume":
                {
                    string direction = msg["direction"]?.GetValue<string>() ?? "set";
                    int step = Math.Clamp(msg["step"]?.GetValue<int>() ?? 2, 1, 20);
                    int target = Math.Clamp(msg["value"]?.GetValue<int>() ?? 50, 0, 100);

                    bool ok;
                    if (direction == "set")
                    {
                        ok = AudioService.TrySetVolume(target);
                        if (!ok) _inputService.SetVolume(target);
                    }
                    else
                    {
                        ok = AudioService.TryGetVolume(out int cur)
                             && AudioService.TrySetVolume(Math.Clamp(cur + (direction == "up" ? step : -step), 0, 100));
                        if (!ok) _inputService.MediaControl(direction == "up" ? "volume_up" : "volume_down");
                    }

                    AudioService.TryGetVolume(out int finalVolume);
                    AudioService.TryGetMute(out bool finalMuted);
                    await SendJsonAsync(new { type = "volume_state", data = new { value = finalVolume, muted = finalMuted, success = ok } });
                }
                break;

            case "media":
            case "media_control":
                string mediaCmd = msg["command"]?.GetValue<string>() ?? "";
                _inputService.MediaControl(mediaCmd);
                break;

            case "shortcut":
                string sc = msg["shortcut"]?.GetValue<string>() ?? "";
                if (!string.IsNullOrWhiteSpace(sc))
                {
                    _inputService.ExecuteShortcut(sc);
                }
                break;

            case "get_network_info":
                {
                    var netMetrics = _systemService.GetMetrics();
                    await SendJsonAsync(new
                    {
                        type = "network_info",
                        data = new { lanIp = netMetrics.LanIp, wanIp = netMetrics.WanIp }
                    });
                }
                break;

            case "run_speedtest":
                _ = Task.Run(() => _speedTestService.RunAsync());
                await SendJsonAsync(new { type = "speedtest_progress", data = new { running = true, stage = "підготовка…" } });
                break;

            case "power":
                string action = msg["action"]?.GetValue<string>() ?? "";
                switch (action.ToLowerInvariant())
                {
                    case "shutdown": _systemService.Shutdown(); break;
                    case "restart": _systemService.Restart(); break;
                    case "sleep": _systemService.Sleep(); break;
                    case "hibernate": _systemService.Hibernate(); break;
                    case "monitor_off": _systemService.MonitorOff(); break;
                    case "lock": _systemService.LockScreen(); break;
                }
                break;

            case "winlock_lock":
                {
                    try
                    {
                        var lockMode = msg["mode"]?.GetValue<string>() ?? WinLockService.ModeCode;
                        var lockCode = msg["code"]?.GetValue<string>();
                        _winLockService?.Lock(lockMode, lockCode);
                    }
                    catch (ArgumentException ex)
                    {
                        App.Log($"[WinLock] Rejected lock request: {ex.Message}");
                    }
                    catch (Exception ex)
                    {
                        App.Log($"[WinLock] Lock request failed: {ex.Message}");
                    }
                    await SendWinLockStateAsync();
                }
                break;

            case "winlock_unlock":
                // The owner's web panel is trusted — explicit site override always unlocks.
                _winLockService?.UnlockFromSite();
                await SendWinLockStateAsync();
                break;

            case "winlock_get":
                await SendWinLockStateAsync();
                break;

            case "camera_list":
                {
                    var cams = await _mediaService.ListVideoDevicesAsync();
                    await SendJsonAsync(new { type = "camera_list", data = new { cameras = cams.Select(n => new { name = n }) } });
                }
                break;

            case "timer_start":
                {
                    // Unified power timer: ANY action (shutdown/restart/sleep/
                    // hibernate/lock) with minutes OR raw seconds from the site.
                    string timerAction = msg["action"]?.GetValue<string>() ?? "shutdown";
                    int seconds = msg["seconds"]?.GetValue<int>() ?? 0;
                    if (seconds <= 0)
                    {
                        double minutes = msg["minutes"]?.GetValue<double>() ?? 0;
                        seconds = (int)Math.Round(minutes * 60);
                    }
                    if (seconds <= 0) seconds = 60;
                    try
                    {
                        _scheduledActions.Start(timerAction, seconds);
                        await SendJsonAsync(new { type = "timer_ack", ok = true, action = timerAction, seconds });
                    }
                    catch (ArgumentException ex)
                    {
                        App.Log($"[Timer] Rejected start: {ex.Message}");
                        await SendJsonAsync(new { type = "timer_ack", ok = false, error = ex.Message });
                    }
                }
                break;

            case "timer_cancel":
                _scheduledActions.Cancel();
                break;

            case "timer_get":
                await SendTimerStateAsync();
                break;

            case "open_url":
                _systemService.OpenUrl(msg["url"]?.GetValue<string>() ?? "");
                break;

            case "get_processes":
            case "process_list":
                {
                    var procs = _processService.GetProcesses();
                    var icons = _processService.GetNewIcons(procs);
                    await SendJsonAsync(new { type = "process_list", data = new { processes = procs, icons = icons } });
                    // Фонове добування решти іконок (повідомлення process_icons):
                    // ВСІ процеси отримують свою іконку, а не тільки перші 12.
                    _ = _processService.PushIconsAsync(async batch =>
                        await SendJsonAsync(new { type = "process_icons", data = batch }));
                }
                break;

            case "kill_process":
            case "process_kill":
                int pid = msg["pid"]?.GetValue<int>() ?? 0;
                bool killed = _processService.KillProcess(pid);
                var updatedList = _processService.GetProcesses();
                await SendJsonAsync(new { type = "process_kill_result", pid, success = killed });
                await SendJsonAsync(new { type = "process_list", data = new { processes = updatedList, icons = _processService.GetNewIcons(updatedList) } });
                _ = _processService.PushIconsAsync(async batch =>
                    await SendJsonAsync(new { type = "process_icons", data = batch }));
                break;

            case "fs_drives":
                var drives = _fileService.GetDrives();
                await SendJsonAsync(new { type = "fs_drives", data = drives });
                break;

            case "fs_list":
                string pth = msg["path"]?.GetValue<string>() ?? "";
                try
                {
                    var listing = _fileService.ListDirectory(pth);
                    await SendJsonAsync(new { type = "fs_list", data = listing });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "fs_error", message = ex.Message });
                }
                break;

            case "fs_read_file":
                string rPath = msg["path"]?.GetValue<string>() ?? "";
                try
                {
                    string text = _fileService.ReadFileContent(rPath);
                    await SendJsonAsync(new { type = "fs_read_file_result", path = rPath, content = text, success = true });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "fs_read_file_result", path = rPath, success = false, error = ex.Message });
                }
                break;

            case "fs_save_file":
                string sPath = msg["path"]?.GetValue<string>() ?? "";
                string sContent = msg["content"]?.GetValue<string>() ?? "";
                try
                {
                    _fileService.SaveFileContent(sPath, sContent);
                    await SendJsonAsync(new { type = "fs_save_file_result", path = sPath, success = true });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "fs_save_file_result", path = sPath, success = false, error = ex.Message });
                }
                break;

            case "fs_delete":
                string delPath = msg["path"]?.GetValue<string>() ?? "";
                try
                {
                    bool deleted = _fileService.DeleteItem(delPath);
                    await SendJsonAsync(new { type = "fs_delete_result", path = delPath, success = deleted });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "fs_delete_result", path = delPath, success = false, error = ex.Message });
                }
                break;

            case "fs_folder_size":
                string fszPath = msg["path"]?.GetValue<string>() ?? "";
                _ = Task.Run(async () =>
                {
                    try
                    {
                        long sz = _fileService.GetDirectorySize(fszPath);
                        await SendJsonAsync(new { type = "fs_folder_size_result", path = fszPath, size = sz, success = true });
                    }
                    catch { }
                });
                break;

            case "fs_download_file":
                string dlFilePath = msg["path"]?.GetValue<string>() ?? "";
                _ = Task.Run(async () =>
                {
                    try
                    {
                        if (!File.Exists(dlFilePath)) throw new FileNotFoundException("Файл не знайдено.");
                        var fi = new FileInfo(dlFilePath);
                        var bytes = await File.ReadAllBytesAsync(dlFilePath);
                        var b64 = Convert.ToBase64String(bytes);
                        await SendJsonAsync(new
                        {
                            type = "fs_download_file_result",
                            name = fi.Name,
                            path = dlFilePath,
                            base64 = b64,
                            size = fi.Length,
                            success = true
                        });
                    }
                    catch (Exception ex)
                    {
                        await SendJsonAsync(new { type = "fs_download_file_result", path = dlFilePath, success = false, error = ex.Message });
                    }
                });
                break;

            case "fs_download_folder_zip":
                string dlFolderPath = msg["path"]?.GetValue<string>() ?? "";
                _ = Task.Run(async () =>
                {
                    string? zipPath = null;
                    try
                    {
                        zipPath = _fileService.CreateZipArchive(dlFolderPath);
                        var folderName = new DirectoryInfo(dlFolderPath).Name;
                        var bytes = await File.ReadAllBytesAsync(zipPath);
                        var b64 = Convert.ToBase64String(bytes);
                        await SendJsonAsync(new
                        {
                            type = "fs_download_file_result",
                            name = $"{folderName}.zip",
                            path = dlFolderPath,
                            base64 = b64,
                            isZip = true,
                            size = bytes.Length,
                            success = true
                        });
                    }
                    catch (Exception ex)
                    {
                        await SendJsonAsync(new { type = "fs_download_file_result", path = dlFolderPath, success = false, error = ex.Message });
                    }
                    finally
                    {
                        if (!string.IsNullOrEmpty(zipPath) && File.Exists(zipPath))
                        {
                            try { File.Delete(zipPath); } catch { }
                        }
                    }
                });
                break;

            case "fs_open_on_pc":
                string openTarget = msg["path"]?.GetValue<string>() ?? "";
                try
                {
                    Process.Start(new ProcessStartInfo(openTarget) { UseShellExecute = true });
                    await SendJsonAsync(new { type = "fs_open_on_pc_result", path = openTarget, success = true });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "fs_open_on_pc_result", path = openTarget, success = false, error = ex.Message });
                }
                break;

            case "fs_rename":
                string rOldPath = msg["oldPath"]?.GetValue<string>() ?? "";
                string rNewName = msg["newName"]?.GetValue<string>() ?? "";
                try
                {
                    bool renamed = _fileService.RenameItem(rOldPath, rNewName);
                    await SendJsonAsync(new { type = "fs_rename_result", oldPath = rOldPath, newName = rNewName, success = renamed });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "fs_rename_result", oldPath = rOldPath, newName = rNewName, success = false, error = ex.Message });
                }
                break;

            case "fs_create_file":
                string cfParent = msg["path"]?.GetValue<string>() ?? "";
                string cfName = msg["name"]?.GetValue<string>() ?? "";
                try
                {
                    _fileService.CreateNewFile(cfParent, cfName);
                    await SendJsonAsync(new { type = "fs_create_file_result", path = cfParent, name = cfName, success = true });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "fs_create_file_result", success = false, error = ex.Message });
                }
                break;

            case "fs_create_folder":
                string cfdParent = msg["path"]?.GetValue<string>() ?? "";
                string cfdName = msg["name"]?.GetValue<string>() ?? "";
                try
                {
                    _fileService.CreateNewFolder(cfdParent, cfdName);
                    await SendJsonAsync(new { type = "fs_create_folder_result", path = cfdParent, name = cfdName, success = true });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "fs_create_folder_result", success = false, error = ex.Message });
                }
                break;

            case "take_screenshot":
            case "capture_screenshot":
                try
                {
                    // AI-запрос может ужать картинку (payload WS ограничен);
                    // UI-запросы идут без параметров — как раньше.
                    long q = Math.Clamp(msg["quality"]?.GetValue<long>() ?? 80, 30, 95);
                    int mw = Math.Clamp(msg["maxWidth"]?.GetValue<int>() ?? 0, 0, 3840);
                    var shotB64 = _mediaService.CaptureScreenshotBase64(q, mw);
                    await SendJsonAsync(new { type = "screenshot_response", imageBase64 = shotB64 });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "media_error", message = ex.Message });
                }
                break;

            case "capture_webcam":
            case "webcam_snap":
                try
                {
                    string? preferredCamera = msg["camera"]?.GetValue<string>();
                    int delaySeconds = Math.Clamp(msg["delaySeconds"]?.GetValue<int>() ?? 0, 0, 600);
                    var webcamBase64 = await _mediaService.CaptureWebcamPhotoBase64Async(
                        preferredCamera,
                        delaySeconds,
                        secondsLeft => _ = SendJsonAsync(new { type = "webcam_status", data = new { secondsLeft = secondsLeft } }));
                    await SendJsonAsync(new
                    {
                        type = "webcam_response",
                        imageBase64 = webcamBase64,
                        success = webcamBase64 != null,
                        error = webcamBase64 == null ? _mediaService.LastError : null
                    });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "webcam_response", success = false, error = ex.Message });
                }
                break;

            case "record_capture":
                var recordingSource = msg["source"]?.GetValue<string>() ?? "screen";
                var recordingSeconds = msg["seconds"]?.GetValue<int>() ?? 5;
                var recordingCamera = msg["camera"]?.GetValue<string>();
                try
                {
                    var videoBase64 = await _mediaService.RecordShortVideoBase64Async(recordingSource, recordingSeconds, recordingCamera);
                    await SendJsonAsync(new
                    {
                        type = "recording_result",
                        source = recordingSource,
                        name = $"FluxControl_{recordingSource}_{DateTime.Now:yyyyMMdd_HHmmss}.mp4",
                        videoBase64,
                        success = videoBase64 != null,
                        error = videoBase64 == null ? _mediaService.LastError : null
                    });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "recording_result", source = recordingSource, success = false, error = ex.Message });
                }
                break;

            case "record_cancel":
                _mediaService.CancelRecording();
                await SendJsonAsync(new { type = "recording_cancelled", success = true });
                break;

            case "screen_stream_start":
                StartScreenStream(
                    msg["fps"]?.GetValue<int>() ?? 60,
                    msg["quality"]?.GetValue<int>() ?? 80,
                    msg["maxWidth"]?.GetValue<int>() ?? 1920);
                await SendJsonAsync(new
                {
                    type = "screen_stream_started",
                    fps = Volatile.Read(ref _screenStreamFps),
                    quality = Volatile.Read(ref _screenStreamQuality),
                    maxWidth = Volatile.Read(ref _screenStreamMaxWidth)
                });
                break;

            case "screen_stream_stop":
                StopScreenStream();
                break;

            case "screen_stream_feedback":
                ApplyScreenStreamFeedback(msg["fps"]?.GetValue<int>() ?? 0);
                break;

            case "ai_memory_get":
                {
                    // Пам'ять AI-агента: файл %APPDATA%\FluxControl\ai_memory.json.
                    // Фронт чекає ai_memory_data (таймаут 4с — старі exe просто мовчать,
                    // і цикл працює без пам'яті, як раніше).
                    try
                    {
                        string? memData = null;
                        var memReadPath = AiMemoryPath();
                        if (File.Exists(memReadPath))
                            memData = File.ReadAllText(memReadPath);
                        await SendJsonAsync(new { type = "ai_memory_data", data = memData });
                    }
                    catch (Exception ex)
                    {
                        await SendJsonAsync(new { type = "ai_memory_data", data = (string?)null, error = ex.Message });
                    }
                }
                break;

            case "ai_memory_set":
                {
                    try
                    {
                        var memSavePath = AiMemoryPath();
                        Directory.CreateDirectory(Path.GetDirectoryName(memSavePath)!);
                        var memData = msg["data"]?.GetValue<string>() ?? "";
                        if (memData.Length > 64 * 1024) memData = memData.Substring(0, 64 * 1024);
                        File.WriteAllText(memSavePath, memData);
                        await SendJsonAsync(new { type = "ai_memory_saved", success = true, bytes = memData.Length });
                    }
                    catch (Exception ex)
                    {
                        await SendJsonAsync(new { type = "ai_memory_saved", success = false, error = ex.Message });
                    }
                }
                break;

            case "terminal_start":
                string shellType = msg["shell"]?.GetValue<string>() ?? "powershell";
                terminal.StartSession(shellType);
                break;

            case "terminal_input":
                terminal.SendInput(msg["data"]?.GetValue<string>() ?? msg["input"]?.GetValue<string>() ?? "");
                break;

            case "terminal_kill":
                terminal.StopSession();
                break;
        }
    }

    private async Task SendJsonAsync(object data)
    {
        if (_ws == null || _ws.State != WebSocketState.Open) return;
        await _sendLock.WaitAsync();
        try
        {
            var json = JsonSerializer.Serialize(data, _jsonOptions);
            var bytes = Encoding.UTF8.GetBytes(json);
            await _ws.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, CancellationToken.None);
        }
        catch { }
        finally { _sendLock.Release(); }
    }

    /// <summary>Шлях до файлу пам'яті AI-агента (%APPDATA%\FluxControl\ai_memory.json).</summary>
    private static string AiMemoryPath()
    {
        return Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "FluxControl",
            "ai_memory.json");
    }

    private void StartScreenStream(int requestedFps, int requestedQuality, int requestedMaxWidth)
    {
        StopScreenStream();
        var streamCts = new CancellationTokenSource();
        _screenStreamCts = streamCts;
        // The relay carries text WebSocket messages, not a media transport.
        // Start with a sustainable profile; feedback below continuously reduces
        // it before a queue can form and increase latency on a phone.
        _screenStreamFps = Math.Clamp(requestedFps, 10, 30);
        _screenStreamQuality = Math.Clamp(requestedQuality, 50, 80);
        _screenStreamMaxWidth = Math.Clamp(requestedMaxWidth, 854, 1600);

        _ = Task.Run(async () =>
        {
            try
            {
                while (!streamCts.IsCancellationRequested && _ws?.State == WebSocketState.Open)
                {
                    var started = Stopwatch.GetTimestamp();
                    // JPEG capture adapts to the available CPU/network bandwidth:
                    // frames are dropped rather than queued, keeping latency low.
                    var imageBase64 = await Task.Run(() => _mediaService.CaptureScreenshotBase64(
                        Volatile.Read(ref _screenStreamQuality),
                        Volatile.Read(ref _screenStreamMaxWidth)), streamCts.Token);
                    await SendJsonAsync(new { type = "screen_frame", imageBase64, timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() });
                    var elapsed = Stopwatch.GetElapsedTime(started);
                    var frameInterval = TimeSpan.FromSeconds(1d / Volatile.Read(ref _screenStreamFps));
                    var delay = frameInterval - elapsed;
                    if (delay > TimeSpan.Zero) await Task.Delay(delay, streamCts.Token);
                }
            }
            catch (OperationCanceledException) { }
            catch (Exception ex)
            {
                await SendJsonAsync(new { type = "screen_stream_error", message = ex.Message });
            }
            finally
            {
                if (ReferenceEquals(_screenStreamCts, streamCts)) _screenStreamCts = null;
                streamCts.Dispose();
            }
        });
    }

    private void StopScreenStream()
    {
        var streamCts = Interlocked.Exchange(ref _screenStreamCts, null);
        if (streamCts != null) streamCts.Cancel();
    }

    private void ApplyScreenStreamFeedback(int receivedFps)
    {
        if (_screenStreamCts == null || receivedFps <= 0) return;
        var target = Volatile.Read(ref _screenStreamFps);
        if (receivedFps >= target * 0.8) return;

        // Reduce bytes first (resolution and JPEG quality); only then reduce the
        // capture rate. This preserves visual smoothness where the channel allows.
        if (Volatile.Read(ref _screenStreamMaxWidth) > 960)
            Interlocked.Exchange(ref _screenStreamMaxWidth, Math.Max(960, Volatile.Read(ref _screenStreamMaxWidth) * 3 / 4));
        else if (Volatile.Read(ref _screenStreamQuality) > 55)
            Interlocked.Add(ref _screenStreamQuality, -5);
        else
            Interlocked.Exchange(ref _screenStreamFps, Math.Max(12, Math.Min(target - 3, receivedFps + 3)));
    }

    public static string GetExactWindowsVersion()
    {
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
            if (key != null)
            {
                string productName = key.GetValue("ProductName")?.ToString() ?? "";
                string buildNumberStr = key.GetValue("CurrentBuildNumber")?.ToString() ?? "0";

                if (int.TryParse(buildNumberStr, out int build))
                {
                    if (build >= 22000) return "Windows 11 Pro";
                    if (build >= 10240) return "Windows 10 Pro";
                }

                if (!string.IsNullOrEmpty(productName)) return productName;
            }
        }
        catch { }
        return System.Runtime.InteropServices.RuntimeInformation.OSDescription;
    }

    public void Dispose()
    {
        if (_isDisposed) return;
        _isDisposed = true;
        StopScreenStream();
        _cts?.Cancel();
        _ws?.Dispose();
    }
}
