using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;

namespace FluxControl.Agent.Services;

/// <summary>
/// Красивий нативний вікно-інсталятор FluxControl. Два режими:
///  • Install       — bootstrap при першому/пошкодженому запуску: показує
///                    прогрес і довантажує відсутні файли з GitHub Releases;
///  • UpdateConfirm — «Доступна нова версія» з кнопкою «Оновити»;
///                    після завантаження запускає автономний updater-процес
///                    (ТЗ п.3) і коректно завершує програму.
/// </summary>
public partial class InstallerWindow : Window
{
    public enum InstallerMode { Install, UpdateConfirm }

    private readonly InstallerMode _mode;
    private CancellationTokenSource? _cts;
    private UpdateInfo? _update;
    private Func<Task<bool>>? _retryAction;

    public InstallerWindow(InstallerMode mode)
    {
        InitializeComponent();
        _mode = mode;
        SourceInitialized += (s, e) => TryRoundCorners();
        Closed += (s, e) => _cts?.Cancel();
        ApplyMode();
    }

    // ------------------------------------------------------------ режимы ---

    private void ApplyMode()
    {
        if (_mode == InstallerMode.Install)
        {
            TitleText.Text = "FluxControl — Встановлення";
            SubtitleText.Text = "Перевіряю файли програми…";
            HeadlineText.Text = "Готуємо файли програми";
            DetailText.Text = "Програма самостійно відновить вбудовані файли інтерфейсу. " +
                              "Це займе кілька секунд.";
            IcoGlyph.Text = "\uE896"; // Download
            PrimaryBtn.Visibility = Visibility.Collapsed;
            SecondaryText.Text = "Скасувати";
            VersionChips.Visibility = Visibility.Collapsed;
            ShowProgress(false);
        }
        else
        {
            TitleText.Text = "FluxControl — Оновлення";
            SubtitleText.Text = "Доступна нова версія";
            HeadlineText.Text = "Оновити FluxControl?";
            DetailText.Text = "Буде завантажено останній реліз із GitHub, файли замінено, " +
                              "і програма перезапуститься автоматично. Налаштування та код " +
                              "підключення залишаться незмінними.";
            IcoGlyph.Text = "\uE895"; // Sync
            PrimaryBtn.Visibility = Visibility.Visible;
            PrimaryText.Text = "Оновити";
            SecondaryText.Text = "Пізніше";
            VersionChips.Visibility = Visibility.Visible;
            ShowProgress(false);
        }
    }

    /// <summary>Заповнює чіпи версій у режимі оновлення.</summary>
    public void SetUpdateInfo(UpdateInfo info)
    {
        _update = info;
        LocalVerText.Text = info.LocalVersion;
        LatestVerText.Text = info.LatestVersion;
        SubtitleText.Text = $"Доступна нова версія {info.LatestVersion}";
    }

    // ------------------------------------------------- bootstrap install ---

    /// <summary>
    /// Режим Install: завантажує відсутні файли з GitHub Releases.
    /// true — файли встановлено і можна продовжувати запуск програми.
    /// </summary>
    public async Task<bool> RunInstallAsync(List<string> missingFiles)
    {
        Show();
        _cts = new CancellationTokenSource();
        _retryAction = () => RunInstallAsync(missingFiles);
        ShowProgress(true);
        var progress = new Progress<DownloadProgress>(SetProgress);
        try
        {
            StatusText.Text = "З'єднання з GitHub…";
            var remaining = await BootstrapService.InstallMissingFilesAsync(
                progress, s => StatusText.Text = s, _cts.Token);

            if (remaining.Count > 0)
            {
                Fail("Не вдалося встановити: " + string.Join(", ", remaining) +
                     ". Перевірте інтернет і натисніть «Повторити».");
                return false;
            }

            SetProgress(new DownloadProgress { ReceivedBytes = 1, TotalBytes = 1 });
            HeadlineText.Text = "Усе готово!";
            DetailText.Text = "Файли встановлено. Запускаю FluxControl…";
            StatusText.Text = "";
            await Task.Delay(900);
            CloseWindow();
            return true;
        }
        catch (OperationCanceledException)
        {
            return false; // користувач закрив вікно — App завершить роботу
        }
        catch (Exception ex)
        {
            App.Log($"Bootstrap install error: {ex}");
            Fail(ex.Message);
            return false;
        }
    }

    // ----------------------------------------------------------- update ---

    /// <summary>
    /// Режим UpdateConfirm: завантажує останній самодостатній FluxControl.exe
    /// у %TEMP% і запускає updater-процес, який чекатиме завершення програми,
    /// підмінить файл exe і перезапустить FluxControl (ТЗ, п.3).
    /// </summary>
    public async Task<bool> RunUpdateAsync()
    {
        if (_update == null) return false;
        _cts = new CancellationTokenSource();
        _retryAction = () => RunUpdateAsync();
        PrimaryBtn.Visibility = Visibility.Collapsed;
        SecondaryText.Text = "Скасувати";
        DetailText.Text = "Завантаження оновлення… не закривайте програму.";
        ShowProgress(true);
        try
        {
            var progress = new Progress<DownloadProgress>(SetProgress);
            StatusText.Text = "Завантаження оновлення…";
            var newExePath = await UpdateService.DownloadReleaseZipAsync(
                _update.DownloadUrl, _update.LatestVersion, progress, _cts.Token);

            // Новий формат релізу (bootstrap-архітектура) — FluxControl-app-vX.zip
            // з легким FluxControl.exe всередині: витягуємо exe в %TEMP% і
            // віддаємо updater'у. Голий .exe (легасі-релізи) — використовуємо як є.
            if (newExePath.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
            {
                StatusText.Text = "Розпакування оновлення…";
                newExePath = await Task.Run(() => ExtractAgentExeFromZip(newExePath));
            }

            StatusText.Text = "Запускаю оновлювач…";
            HeadlineText.Text = "Майже готово";
            DetailText.Text = "Програма зараз перезапуститься та встановить оновлення.";
            LaunchUpdater(newExePath);
            await Task.Delay(600);
            System.Windows.Application.Current.Shutdown(); // коректний вихід — updater чекає PID
            return true;
        }
        catch (OperationCanceledException)
        {
            ResetToConfirm();
            return false;
        }
        catch (Exception ex)
        {
            App.Log($"Update download error: {ex}");
            Fail(ex.Message);
            return false;
        }
    }

    private void ResetToConfirm()
    {
        ShowProgress(false);
        DetailText.Text = "Завантаження скасовано. Оновити зараз?";
        PrimaryBtn.Visibility = Visibility.Visible;
        PrimaryText.Text = "Оновити";
        SecondaryText.Text = "Пізніше";
    }

    private void Fail(string message)
    {
        ShowProgress(false);
        StatusText.Text = message;
        StatusText.Foreground = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0xFF, 0x6B, 0x8E));
        HeadlineText.Text = "Помилка";
        PrimaryBtn.Visibility = Visibility.Visible;
        PrimaryText.Text = "Повторити";
        SecondaryText.Text = "Закрити";
    }

    // ------------------------------------------------- updater process ---

    /// <summary>
    /// Автономний updater (ТЗ, п.3): cmd-скрипт у %TEMP%.
    /// Аргументи: шлях до нового exe, цільова папка програми, PID головного процесу.
    /// Логіка: чекає завершення FluxControl (до 12с, потім force-kill) → пауза 2с →
    /// прибирає старий .old → поточний exe перейменовує в .old → копіює новий exe
    /// на його місце → запуск оновленого exe → видалення завантаженого файла і
    /// старого .old → самовидалення скрипта. Якщо копіювання не вдалось — відкат
    /// до попереднього exe.
    /// </summary>
    private const string UpdaterScript =
@"@echo off
rem FluxControl silent updater (single-file exe swap). Args: <newExe> <targetDir> <mainPid> [dotnetRoot] [exeName]
setlocal EnableExtensions EnableDelayedExpansion
set ""NEW=%~1""
set ""DST=%~2""
set ""APP_PID=%~3""
rem Мінімальний .NET Runtime у %AppData%\FluxControl\runtime\dotnet (bootstrap):
rem якщо змінна DOTNET_ROOT була в процесі агента — передається 4-м аргументом,
rem інакше оновлений framework-dependent exe не знайде собі runtime.
set ""LOCAL_DOTNET=%~4""
if not ""%LOCAL_DOTNET%""=="""" set ""DOTNET_ROOT=%LOCAL_DOTNET%""
rem ім'я свого exe (FluxControl_Core.exe у новій схемі, FluxControl.exe у старій)
set ""APP=%DST%\FluxControl.exe""
if not ""%~5""=="""" set ""APP=%DST%\%~5""

set /a N=0
:waitloop
tasklist /FI ""PID eq %APP_PID%"" 2>nul | find /I ""%APP_PID%"" >nul
if errorlevel 1 goto donewait
set /a N+=1
if !N! GEQ 12 (
  taskkill /F /PID %APP_PID% >nul 2>&1
  goto donewait
)
ping -n 2 127.0.0.1 >nul
goto waitloop
:donewait

rem settle before touching files
ping -n 3 127.0.0.1 >nul

rem clean stale backup from a previous update
if exist ""%DST%\FluxControl.old.exe"" del /F /Q ""%DST%\FluxControl.old.exe"" >nul 2>&1

rem swap: current exe -> .old, new exe -> place of current
move /y ""%APP%"" ""%DST%\FluxControl.old.exe"" >nul 2>&1
copy /y ""%NEW%"" ""%APP%"" >nul 2>&1

if exist ""%APP%"" (
  rem success: new exe in place
  del /F /Q ""%DST%\FluxControl.old.exe"" >nul 2>&1
) else (
  rem failure: restore previous exe
  if exist ""%DST%\FluxControl.old.exe"" move /y ""%DST%\FluxControl.old.exe"" ""%APP%"" >nul 2>&1
)

del /F /Q ""%NEW%"" >nul 2>&1
start """" ""%APP%""
(goto) 2>nul & del ""%~f0""
";

    private void LaunchUpdater(string newExePath)
    {
        try
        {
            var bat = Path.Combine(Path.GetTempPath(), "FluxControl_updater.cmd");
            File.WriteAllText(bat, UpdaterScript, Encoding.ASCII);

            var target = AppContext.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            var pid = Environment.ProcessId;
            var dotnetRoot = Environment.GetEnvironmentVariable("DOTNET_ROOT") ?? string.Empty;
            // своє ім'я exe: FluxControl_Core.exe (нова схема) або як запущено
            var exeName = "FluxControl.exe";
            try
            {
                var main = System.Diagnostics.Process.GetCurrentProcess().MainModule?.FileName;
                if (!string.IsNullOrEmpty(main)) exeName = Path.GetFileName(main);
            }
            catch { }
            App.Log($"Update: updater bat={bat} newExe={newExePath} target={target} pid={pid} dotnetRoot={dotnetRoot} exe={exeName}");

            var psi = new System.Diagnostics.ProcessStartInfo
            {
                FileName = bat,
                Arguments = $"\"{newExePath}\" \"{target}\" {pid} \"{dotnetRoot}\" \"{exeName}\"",
                UseShellExecute = false,
                CreateNoWindow = true,
                WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden
            };
            System.Diagnostics.Process.Start(psi);
        }
        catch (Exception ex)
        {
            App.Log($"Update: failed to launch updater: {ex}");
        }
    }

    /// <summary>
    /// Новий формат релізу: FluxControl-app-vX.zip з легким framework-dependent
    /// FluxControl.exe всередині. Витягуємо exe в %TEMP% — його підміняє updater.
    /// </summary>
    private static string ExtractAgentExeFromZip(string zipPath)
    {
        var destDir = Path.Combine(Path.GetTempPath(), "FluxControl-update-" + Guid.NewGuid().ToString("N").Substring(0, 8));
        Directory.CreateDirectory(destDir);
        using (var fs = File.OpenRead(zipPath))
        using (var za = new ZipArchive(fs, ZipArchiveMode.Read))
        {
            // 1) точне ім'я в корені архіву, 2) будь-який *.exe у корені (фолбек)
            var entry = za.GetEntry("FluxControl.exe")
                       ?? za.Entries.FirstOrDefault(e =>
                            e.FullName.IndexOf('/') < 0 &&
                            e.FullName.EndsWith(".exe", StringComparison.OrdinalIgnoreCase));
            if (entry == null)
                throw new InvalidOperationException("В архіві оновлення не знайдено FluxControl.exe");

            var dest = Path.Combine(destDir, "FluxControl.exe");
            using (var es = entry.Open())
            using (var ofs = new FileStream(dest, FileMode.Create, FileAccess.Write, FileShare.None))
                es.CopyTo(ofs);

            App.Log($"Update: extracted agent exe from zip → {dest} ({new FileInfo(dest).Length} bytes)");
            return dest;
        }
    }

    // ------------------------------------------------------------- UI ---

    private void ShowProgress(bool show)
    {
        ProgressSection.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
        if (show)
            StatusText.Foreground = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0x8E, 0x89, 0xA8));
    }

    private void SetProgress(DownloadProgress p)
    {
        var pct = p.TotalBytes > 0 ? Math.Min(100, Math.Round(p.Percent)) : 0;
        FillCol.Width = new GridLength(pct, GridUnitType.Star);
        RestCol.Width = new GridLength(100 - pct, GridUnitType.Star);
        PercentText.Text = $"{pct:0}%";
        StatusText.Text = p.TotalBytes > 0
            ? $"Завантажено {p.ReceivedBytes / 1048576.0:0.0} з {p.TotalBytes / 1048576.0:0.0} МБ"
            : $"Завантажено {p.ReceivedBytes / 1048576.0:0.0} МБ";
    }

    // ---------------------------------------------------------- events ---

    private async void OnPrimaryClick(object sender, MouseButtonEventArgs e)
    {
        e.Handled = true; // не віддаємо клік вікну (інакше спрацює DragMove)
        if (_retryAction != null)
        {
            await _retryAction();
        }
        else if (_mode == InstallerMode.UpdateConfirm)
        {
            await RunUpdateAsync();
        }
    }

    private void OnSecondaryClick(object sender, MouseButtonEventArgs e)
    {
        e.Handled = true;
        _cts?.Cancel();
        CloseWindow();
    }

    private void OnCloseClick(object sender, MouseButtonEventArgs e)
    {
        e.Handled = true;
        _cts?.Cancel();
        CloseWindow();
    }

    private void CloseWindow()
    {
        try { if (IsLoaded) Close(); } catch { }
    }

    private void OnDragMove(object sender, MouseButtonEventArgs e)
    {
        try { DragMove(); } catch { }
    }

    // ------------------------------------------------ DWM округлення ---

    [DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);

    private void TryRoundCorners()
    {
        try
        {
            var hwnd = new WindowInteropHelper(this).Handle;
            if (hwnd == IntPtr.Zero) return;
            int pref = 2; // DWMWCP_ROUND
            DwmSetWindowAttribute(hwnd, 33, ref pref, 4);
        }
        catch { }
    }
}
