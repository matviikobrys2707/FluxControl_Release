using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Management;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace FluxControl.Agent.Services;

public class DiskInfo
{
    public string Name { get; set; } = string.Empty;
    public string Label { get; set; } = string.Empty;
    public double TotalGb { get; set; }
    public double FreeGb { get; set; }
    public double UsedGb { get; set; }
    public long TotalBytes { get; set; }
    public long FreeBytes { get; set; }
    public long UsedBytes { get; set; }
    public int PercentUsed { get; set; }
    public string DriveType { get; set; } = "fixed";
    /// Модель фізичного диска (Win32_DiskDrive.Model), напр. «Samsung SSD 870 EVO 1TB».
    public string Model { get; set; } = string.Empty;
    /// Тип носія: "SSD", "HDD", "NVMe", "USB" або "—".
    public string MediaType { get; set; } = string.Empty;
}

public class SystemMetricsDto
{
    public double CpuUsage { get; set; }
    public double CpuPercent { get; set; }
    public double RamUsage { get; set; }
    public double RamPercent { get; set; }
    public double RamUsedGb { get; set; }
    public double RamUsedMb { get; set; }
    public double RamTotalGb { get; set; }
    public double RamTotalMb { get; set; }
    public List<DiskInfo> Disks { get; set; } = new();
    public string Uptime { get; set; } = string.Empty;
    public string MachineName { get; set; } = string.Empty;
    public string UserName { get; set; } = string.Empty;
    public string OsVersion { get; set; } = string.Empty;
    public string CpuName { get; set; } = string.Empty;
    public string GpuName { get; set; } = string.Empty;
    public double GpuUsage { get; set; }
    public int GpuTemp { get; set; }
    public string GpuVram { get; set; } = string.Empty;
    public double GpuVramUsedGb { get; set; }
    public double GpuVramTotalGb { get; set; }
    public int GpuClockCoreMhz { get; set; }
    public int GpuClockMemMhz { get; set; }
    public int CpuCores { get; set; }
    public int CpuThreads { get; set; }
    public string RamSpeed { get; set; } = string.Empty;
    /// Тип пам’яті окремо: "DDR4", "DDR5"…
    public string RamType { get; set; } = string.Empty;
    /// Ефективна частота пам’яті окремо, МГц (ConfiguredClockSpeed).
    public int RamFreqMhz { get; set; }
    public double CpuTempC { get; set; }
    public string LanIp { get; set; } = string.Empty;
    public string WanIp { get; set; } = string.Empty;
    public double GpuSharedUsedGb { get; set; }
    public double GpuSharedTotalGb { get; set; }
}

public class SystemService
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    private class MEMORYSTATUSEX
    {
        public uint dwLength;
        public uint dwMemoryLoad;
        public ulong ullTotalPhys;
        public ulong ullAvailPhys;
        public ulong ullTotalPageFile;
        public ulong ullAvailPageFile;
        public ulong ullTotalVirtual;
        public ulong ullAvailVirtual;
        public ulong ullAvailExtendedVirtual;

        public MEMORYSTATUSEX()
        {
            dwLength = (uint)Marshal.SizeOf(typeof(MEMORYSTATUSEX));
        }
    }

    [return: MarshalAs(UnmanagedType.Bool)]
    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern bool GlobalMemoryStatusEx([In, Out] MEMORYSTATUSEX lpBuffer);

    [DllImport("user32.dll")]
    private static extern IntPtr SendMessage(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);

    private PerformanceCounter? _cpuCounter;
    private readonly SensorService _sensors = new();
    private readonly ConcurrentDictionary<string, PerformanceCounter> _gpuEngineCounters = new();
    private bool _nvidiaSmiAvailable;

    private string _cachedCpuName = string.Empty;
    private string _cachedGpuName = string.Empty;
    private string _cachedOsName = string.Empty;
    private double _cachedTotalRamGb = 0;
    private string _cachedRamSpeed = "DDR4";
    private string _cachedRamType = string.Empty;
    private int _cachedRamFreqMhz = 0;
    // letter ("C:") → (model, mediaType) — повільні WMI-запити дисків кешуємо назавжди.
    private readonly ConcurrentDictionary<string, (string Model, string Media)> _diskModels = new();
    private int _cachedCpuCores = 0;
    private int _cachedCpuThreads = 0;
    private string _cachedGpuVram = string.Empty;
    private double _cachedGpuUsage = 0;
    private int _cachedGpuTemp = 0;
    private double _cachedGpuVramUsedGb = 0;
    private double _cachedGpuVramTotalGb = 0;
    private int _cachedGpuClockCore = 0;
    private int _cachedGpuClockMem = 0;
    private double _cachedGpuSharedUsedGb = 0;
    private double _cachedGpuSharedTotalGb = 0;
    private DateTime _lastGpuQuery = DateTime.MinValue;
    private double _cachedCpuTempC = 0;
    private DateTime _lastCpuTempQuery = DateTime.MinValue;
    private string _cachedLanIp = string.Empty;
    private string _cachedWanIp = string.Empty;
    private DateTime _lastWanIpQuery = DateTime.MinValue;

    public string CpuName => !string.IsNullOrEmpty(_cachedCpuName) ? _cachedCpuName : (_cachedCpuName = GetCpuNameFast());
    public string GpuName => !string.IsNullOrEmpty(_cachedGpuName) ? _cachedGpuName : (_cachedGpuName = GetGpuNameFast());
    public string OsName => !string.IsNullOrEmpty(_cachedOsName) ? _cachedOsName : (_cachedOsName = GetFriendlyOsNameFast());
    public int CpuCores => _cachedCpuCores > 0 ? _cachedCpuCores : (_cachedCpuCores = QueryCpuCoresFast());
    public int CpuThreads => _cachedCpuThreads > 0 ? _cachedCpuThreads : (_cachedCpuThreads = Environment.ProcessorCount);
    public double TotalRamGb => _cachedTotalRamGb > 0 ? _cachedTotalRamGb : (_cachedTotalRamGb = GetTotalRamFast());

    public SystemService()
    {
        // 1. Instant sync initialization (takes < 2ms)
        _cachedCpuName = GetCpuNameFast();
        _cachedGpuName = GetGpuNameFast();
        _cachedOsName = GetFriendlyOsNameFast();
        _cachedTotalRamGb = GetTotalRamFast();

        // 2. Heavy performance counters & WMI initialized in background
        Task.Run(() =>
        {
            try
            {
                _cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
                _cpuCounter.NextValue();
            }
            catch { }

            // Warm up LibreHardwareMonitor (kernel driver + WMI) off the UI thread
            // so the first temperature query does not stall the telemetry loop.
            try { _sensors.GetCpuTemperature(); } catch { }

            try
            {
                _cachedGpuName = QueryGpuNameWmi();
            }
            catch
            {
                _cachedGpuName = "Відеокарта";
            }

            try
            {
                QueryRamDetailsWmi();
            }
            catch { }
        });
    }

    public SystemMetricsDto GetMetrics()
    {
        float cpu = 0;
        try { if (_cpuCounter != null) cpu = _cpuCounter.NextValue(); } catch { }

        UpdateGpuMetrics();

        GetRamInfoFast(out double totalRamGb, out double freeRamGb);
        double usedRamGb = Math.Max(0, totalRamGb - freeRamGb);
        double ramPct = totalRamGb > 0 ? (usedRamGb / totalRamGb) * 100 : 0;

        var uptime = TimeSpan.FromMilliseconds(Environment.TickCount64);
        string uptimeStr = $"{uptime.Days}d {uptime.Hours}h {uptime.Minutes}m";

        var cpuTemp = QueryCpuTempC();
        var lanIp = QueryLanIp();
        _ = Task.Run(() => QueryWanIpAsync());

        var disks = new List<DiskInfo>();
        try
        {
            foreach (var drive in DriveInfo.GetDrives())
            {
                if (drive.IsReady && (drive.DriveType == DriveType.Fixed || drive.DriveType == DriveType.Removable))
                {
                    long totalB = drive.TotalSize;
                    long freeB = drive.AvailableFreeSpace;
                    long usedB = Math.Max(0, totalB - freeB);
                    double totalG = totalB / (1024.0 * 1024.0 * 1024.0);
                    double freeG = freeB / (1024.0 * 1024.0 * 1024.0);
                    double usedG = usedB / (1024.0 * 1024.0 * 1024.0);

                    var (diskModel, diskMedia) = QueryDiskModel(drive.Name);
                    if (drive.DriveType == DriveType.Removable && string.IsNullOrEmpty(diskMedia)) diskMedia = "USB";
                    disks.Add(new DiskInfo
                    {
                        Name = drive.Name,
                        Label = string.IsNullOrWhiteSpace(drive.VolumeLabel) ? "Диск" : drive.VolumeLabel,
                        TotalGb = Math.Round(totalG, 2),
                        FreeGb = Math.Round(freeG, 2),
                        UsedGb = Math.Round(usedG, 2),
                        TotalBytes = totalB,
                        FreeBytes = freeB,
                        UsedBytes = usedB,
                        PercentUsed = totalB > 0 ? (int)Math.Round(((double)usedB / totalB) * 100) : 0,
                        DriveType = drive.DriveType == DriveType.Removable ? "removable" :
                                    drive.DriveType == DriveType.Network ? "network" : "fixed",
                        Model = diskModel,
                        MediaType = diskMedia
                    });
                }
            }
        }
        catch { }

        return new SystemMetricsDto
        {
            CpuUsage = Math.Round(cpu, 1),
            CpuPercent = Math.Round(cpu, 1),
            RamUsage = Math.Round(ramPct, 1),
            RamPercent = Math.Round(ramPct, 1),
            RamUsedGb = Math.Round(usedRamGb, 2),
            RamUsedMb = Math.Round(usedRamGb * 1024, 0),
            RamTotalGb = Math.Round(totalRamGb, 2),
            RamTotalMb = Math.Round(totalRamGb * 1024, 0),
            Disks = disks,
            Uptime = uptimeStr,
            MachineName = Environment.MachineName,
            UserName = Environment.UserName,
            OsVersion = OsName,
            CpuName = CpuName,
            GpuName = GpuName,
            GpuUsage = Math.Round(_cachedGpuUsage, 1),
            GpuTemp = _cachedGpuTemp,
            GpuVram = _cachedGpuVramTotalGb > 0 ? $"{_cachedGpuVramTotalGb:F0} GB" : QueryGpuVramFast(),
            GpuVramUsedGb = _cachedGpuVramUsedGb,
            GpuVramTotalGb = _cachedGpuVramTotalGb,
            GpuClockCoreMhz = _cachedGpuClockCore,
            GpuClockMemMhz = _cachedGpuClockMem,
            CpuCores = CpuCores,
            CpuThreads = CpuThreads,
            RamSpeed = _cachedRamSpeed,
            RamType = _cachedRamType,
            RamFreqMhz = _cachedRamFreqMhz,
            CpuTempC = cpuTemp,
            LanIp = lanIp,
            WanIp = _cachedWanIp,
            GpuSharedUsedGb = _cachedGpuSharedUsedGb,
            GpuSharedTotalGb = _cachedGpuSharedTotalGb
        };
    }

    private string GetCpuNameFast()
    {
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0");
            if (key != null)
            {
                var val = key.GetValue("ProcessorNameString")?.ToString();
                if (!string.IsNullOrWhiteSpace(val)) return val.Trim();
            }
        }
        catch { }
        return Environment.GetEnvironmentVariable("PROCESSOR_IDENTIFIER") ?? "AMD / Intel Processor";
    }

    private string GetFriendlyOsNameFast()
    {
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
            if (key != null)
            {
                var productName = key.GetValue("ProductName")?.ToString() ?? "";
                var displayVer = key.GetValue("DisplayVersion")?.ToString() ?? "";
                var buildStr = key.GetValue("CurrentBuild")?.ToString() ?? key.GetValue("CurrentBuildNumber")?.ToString() ?? "";
                if (string.IsNullOrEmpty(buildStr)) buildStr = Environment.OSVersion.Version.Build.ToString();

                if (int.TryParse(buildStr, out int build) && build >= 22000)
                {
                    if (productName.Contains("Windows 10"))
                    {
                        productName = productName.Replace("Windows 10", "Windows 11");
                    }
                    else if (!productName.Contains("Windows 11"))
                    {
                        productName = "Windows 11 Pro";
                    }
                }

                if (!string.IsNullOrEmpty(productName))
                {
                    return string.IsNullOrEmpty(displayVer) ? productName : $"{productName} ({displayVer})";
                }
            }
        }
        catch { }
        return RuntimeInformation.OSDescription;
    }

    private static string GetGpuNameFast()
    {
        try
        {
            using var classKey = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}");
            if (classKey != null)
            {
                string bestName = "";
                foreach (var subName in classKey.GetSubKeyNames())
                {
                    if (subName.Length == 4 && subName.All(char.IsDigit))
                    {
                        using var subKey = classKey.OpenSubKey(subName);
                        var driverDesc = subKey?.GetValue("DriverDesc")?.ToString();
                        if (!string.IsNullOrWhiteSpace(driverDesc))
                        {
                            var trimmed = driverDesc.Trim();
                            if (trimmed.Contains("NVIDIA", StringComparison.OrdinalIgnoreCase) ||
                                trimmed.Contains("GeForce", StringComparison.OrdinalIgnoreCase) ||
                                trimmed.Contains("Radeon", StringComparison.OrdinalIgnoreCase) ||
                                trimmed.Contains("RTX", StringComparison.OrdinalIgnoreCase) ||
                                trimmed.Contains("GTX", StringComparison.OrdinalIgnoreCase) ||
                                trimmed.Contains("Arc", StringComparison.OrdinalIgnoreCase))
                            {
                                return trimmed;
                            }
                            if (string.IsNullOrEmpty(bestName) && !trimmed.Contains("Basic Display", StringComparison.OrdinalIgnoreCase))
                            {
                                bestName = trimmed;
                            }
                        }
                    }
                }
                if (!string.IsNullOrEmpty(bestName)) return bestName;
            }
        }
        catch { }
        return "Графічний прискорювач";
    }

    private double GetTotalRamFast()
    {
        try
        {
            var mem = new MEMORYSTATUSEX();
            if (GlobalMemoryStatusEx(mem))
            {
                return Math.Round(mem.ullTotalPhys / (1024.0 * 1024.0 * 1024.0), 1);
            }
        }
        catch { }
        return 16.0;
    }

    private void GetRamInfoFast(out double totalGb, out double freeGb)
    {
        try
        {
            var mem = new MEMORYSTATUSEX();
            if (GlobalMemoryStatusEx(mem))
            {
                totalGb = mem.ullTotalPhys / (1024.0 * 1024.0 * 1024.0);
                freeGb = mem.ullAvailPhys / (1024.0 * 1024.0 * 1024.0);
                return;
            }
        }
        catch { }
        totalGb = 16.0;
        freeGb = 8.0;
    }

    private string QueryGpuNameWmi()
    {
        try
        {
            using var searcher = new ManagementObjectSearcher("Select Name from Win32_VideoController");
            foreach (var item in searcher.Get())
            {
                var name = item["Name"]?.ToString();
                if (!string.IsNullOrWhiteSpace(name)) return name.Trim();
            }
        }
        catch { }
        return "Графічний адаптер";
    }

    private void QueryRamDetailsWmi()
    {
        try
        {
            using var searcherRAM = new ManagementObjectSearcher("Select Speed, ConfiguredClockSpeed, MemoryType, SMBIOSMemoryType from Win32_PhysicalMemory");
            uint speed = 0;
            uint typeNum = 0;
            foreach (var item in searcherRAM.Get())
            {
                uint conf = 0;
                if (item["ConfiguredClockSpeed"] != null) conf = Convert.ToUInt32(item["ConfiguredClockSpeed"]);
                uint raw = 0;
                if (item["Speed"] != null) raw = Convert.ToUInt32(item["Speed"]);
                // ConfiguredClockSpeed is the active XMP/DOCP speed.  Read all
                // DIMMs and retain the highest valid configured value instead of
                // trusting the first module's JEDEC/SMBIOS fallback.
                var moduleSpeed = conf > 0 ? conf : raw;
                if (moduleSpeed > speed) speed = moduleSpeed;

                if (item["SMBIOSMemoryType"] != null) typeNum = Convert.ToUInt32(item["SMBIOSMemoryType"]);
                else if (item["MemoryType"] != null) typeNum = Convert.ToUInt32(item["MemoryType"]);
            }

            string ddrType = typeNum switch
            {
                20 => "DDR",
                21 => "DDR2",
                24 => "DDR3",
                26 => "DDR4",
                34 => "DDR5",
                _ => "DDR4"
            };

            _cachedRamSpeed = speed > 0 ? $"{ddrType} @ {speed} MHz" : ddrType;
            _cachedRamType = ddrType;
            _cachedRamFreqMhz = (int)speed;
        }
        catch { }
    }

    /// Модель фізичного диска та тип носія (SSD/HDD) для букви логічного диска.
    /// Ланцюг: Win32_LogicalDisk → Win32_LogicalDiskToPartition → Win32_DiskDriveToDiskPartition → Win32_DiskDrive,
    /// тип носія — MSFT_PhysicalDisk.MediaType (3=HDD, 4=SSD) за Index диска.
    private (string Model, string Media) QueryDiskModel(string driveName)
    {
        if (_diskModels.TryGetValue(driveName, out var cached)) return cached;
        var result = (string.Empty, string.Empty);
        try
        {
            string letter = driveName.TrimEnd('\\', '/'); // "C:" без хвостового слеша
            string deviceId = $"{letter}\\";               // WMI чекає "C:\\"
            // 1) логічний диск → розділ(и)
            string partitionId = null;
            using (var partSearcher = new ManagementObjectSearcher(
                $"ASSOCIATORS OF {{Win32_LogicalDisk.DeviceID='{deviceId.Replace("\\", "\\\\")}'}} WHERE AssocClass = Win32_LogicalDiskToPartition"))
            {
                foreach (var p in partSearcher.Get())
                {
                    partitionId = p["DeviceID"]?.ToString();
                    if (partitionId != null) break;
                }
            }
            // 2) розділ → фізичний диск
            if (partitionId != null)
            {
                using var driveSearcher = new ManagementObjectSearcher(
                    $"ASSOCIATORS OF {{Win32_DiskPartition.DeviceID='{partitionId.Replace("\\", "\\\\")}'}} WHERE AssocClass = Win32_DiskDriveToDiskPartition");
                foreach (var d in driveSearcher.Get())
                {
                    string model = d["Model"]?.ToString() ?? string.Empty;
                    string rawIndex = d["Index"]?.ToString() ?? string.Empty;
                    string media = string.Empty;
                    // 3) тип носія за MSFT_PhysicalDisk (Index == DeviceId)
                    if (uint.TryParse(rawIndex, out uint diskIdx))
                    {
                        try
                        {
                            using var physSearcher = new ManagementObjectSearcher(
                                "root\\microsoft\\windows\\storage", $"SELECT MediaType FROM MSFT_PhysicalDisk WHERE DeviceId = {diskIdx}");
                            foreach (var m in physSearcher.Get())
                            {
                                ushort mt = Convert.ToUInt16(m["MediaType"] ?? (ushort)0);
                                media = mt == 4 ? "SSD" : mt == 3 ? "HDD" : string.Empty;
                            }
                        }
                        catch { }
                    }
                    if (string.IsNullOrEmpty(media))
                    {
                        var up = model.ToUpperInvariant();
                        if (up.Contains("NVME") || up.Contains("SSD")) media = "SSD";
                        else if (up.Contains("HDD") || up.Contains("HARD DISK")) media = "HDD";
                    }
                    result = (model, media);
                    break;
                }
            }
        }
        catch { }
        _diskModels[driveName] = result; // кешуємо навіть порожній результат — більше не питаемо
        return result;
    }

    private int QueryCpuCoresFast()
    {
        try
        {
            using var searcher = new ManagementObjectSearcher("Select NumberOfCores, NumberOfLogicalProcessors from Win32_Processor");
            foreach (var item in searcher.Get())
            {
                if (item["NumberOfCores"] != null)
                    _cachedCpuCores = Convert.ToInt32(item["NumberOfCores"]);
                if (item["NumberOfLogicalProcessors"] != null)
                    _cachedCpuThreads = Convert.ToInt32(item["NumberOfLogicalProcessors"]);
                if (_cachedCpuCores > 0) return _cachedCpuCores;
            }
        }
        catch { }
        return Math.Max(1, Environment.ProcessorCount / 2);
    }

    private string QueryGpuVramFast()
    {
        if (!string.IsNullOrEmpty(_cachedGpuVram)) return _cachedGpuVram;

        try
        {
            // 1. Try registry 64-bit qwMemorySize
            using var classKey = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}");
            if (classKey != null)
            {
                foreach (var subName in classKey.GetSubKeyNames())
                {
                    if (subName.Length == 4 && subName.All(char.IsDigit))
                    {
                        using var subKey = classKey.OpenSubKey(subName);
                        var memObj = subKey?.GetValue("HardwareInformation.qwMemorySize");
                        if (memObj != null && long.TryParse(memObj.ToString(), out long bytes) && bytes > 0)
                        {
                            double gb = bytes / (1024.0 * 1024.0 * 1024.0);
                            return _cachedGpuVram = $"{Math.Round(gb)} GB";
                        }
                    }
                }
            }
        }
        catch { }

        try
        {
            // 2. Try WMI Win32_VideoController
            using var searcher = new ManagementObjectSearcher("Select AdapterRAM from Win32_VideoController");
            foreach (var item in searcher.Get())
            {
                if (item["AdapterRAM"] != null)
                {
                    long bytes = Convert.ToInt64(item["AdapterRAM"]);
                    if (bytes > 0)
                    {
                        double gb = bytes / (1024.0 * 1024.0 * 1024.0);
                        return _cachedGpuVram = $"{Math.Round(gb)} GB";
                    }
                }
            }
        }
        catch { }

        return _cachedGpuVram = "Недоступно";
    }

    private void UpdateGpuMetrics()
    {
        if ((DateTime.UtcNow - _lastGpuQuery).TotalSeconds < 1.5) return;
        _lastGpuQuery = DateTime.UtcNow;

        bool haveTemp = false;
        bool haveUsage = false;
        bool haveVramUsed = false;
        bool haveVramTotal = false;

        // (a) LibreHardwareMonitor — real sensors, works on NVIDIA/AMD/Intel.
        try
        {
            var lhmTemp = _sensors.GetGpuTemperature();
            if (lhmTemp > 0) { _cachedGpuTemp = (int)Math.Round(lhmTemp); haveTemp = true; }

            var lhmUsage = _sensors.GetGpuUsage();
            if (lhmUsage > 0) { _cachedGpuUsage = Math.Round(lhmUsage, 1); haveUsage = true; }

            var lhmVramUsed = _sensors.GetGpuVramUsedGb();
            if (lhmVramUsed > 0) { _cachedGpuVramUsedGb = Math.Round(lhmVramUsed, 1); haveVramUsed = true; }

            var lhmVramTotal = _sensors.GetGpuVramTotalGb();
            if (lhmVramTotal > 0) { _cachedGpuVramTotalGb = Math.Round(lhmVramTotal, 1); haveVramTotal = true; }
        }
        catch { }

        // (b) nvidia-smi — fills whatever LHM did not provide; it is also the
        // only source for the core/memory clocks.
        if (_nvidiaSmiAvailable || _cachedGpuClockCore <= 0 || !haveTemp || !haveUsage || !haveVramUsed || !haveVramTotal)
        {
            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = "nvidia-smi",
                    Arguments = "--query-gpu=utilization.gpu,temperature.gpu,memory.used,memory.total,clocks.gr,clocks.mem --format=csv,noheader,nounits",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    CreateNoWindow = true
                };
                using var proc = Process.Start(psi);
                if (proc != null)
                {
                    string output = proc.StandardOutput.ReadToEnd();
                    proc.WaitForExit(300);
                    if (!string.IsNullOrWhiteSpace(output))
                    {
                        var parts = output.Trim().Split(',', StringSplitOptions.TrimEntries);
                        if (parts.Length >= 2)
                        {
                            if (!haveUsage && double.TryParse(parts[0], out double util)) { _cachedGpuUsage = util; haveUsage = true; }
                            if (!haveTemp && int.TryParse(parts[1], out int temp)) { _cachedGpuTemp = temp; haveTemp = true; }
                        }
                        if (parts.Length >= 4)
                        {
                            if (!haveVramUsed && double.TryParse(parts[2], out double vramUsedMb)) { _cachedGpuVramUsedGb = Math.Round(vramUsedMb / 1024.0, 1); haveVramUsed = true; }
                            if (!haveVramTotal && double.TryParse(parts[3], out double vramTotMb)) { _cachedGpuVramTotalGb = Math.Round(vramTotMb / 1024.0, 1); haveVramTotal = true; }
                        }
                        if (parts.Length >= 6)
                        {
                            if (int.TryParse(parts[4], out int clkCore)) _cachedGpuClockCore = clkCore;
                            if (int.TryParse(parts[5], out int clkMem)) _cachedGpuClockMem = clkMem;
                        }
                        _nvidiaSmiAvailable = true;
                    }
                }
            }
            catch { }
        }

        // (c) GPU Engine counters — Task-Manager style sum over ALL current
        // instances. Integrated GPUs have no nvidia-smi and often no load
        // sensor, so this is the only honest usage source there.
        if (!haveUsage)
        {
            var engineUsage = QueryGpuEngineUsageSum();
            if (engineUsage >= 0) _cachedGpuUsage = Math.Round(engineUsage, 1);
        }

        // VRAM total for iGPUs: registry qwMemorySize → WMI AdapterRAM chain
        // (LHM usually reports VRAM totals for discrete cards only).
        if (!haveVramTotal && _cachedGpuVramTotalGb <= 0)
        {
            try
            {
                var vramText = QueryGpuVramFast();
                if (vramText.EndsWith("GB", StringComparison.OrdinalIgnoreCase) &&
                    double.TryParse(vramText.Replace("GB", "", StringComparison.OrdinalIgnoreCase).Trim(), out double totalGb) &&
                    totalGb > 0)
                {
                    _cachedGpuVramTotalGb = totalGb;
                }
            }
            catch { }
        }

        // (d) GPU Adapter Memory counters — shared/dedicated memory pressure.
        UpdateGpuMemoryCounters();
    }

    /// <summary>
    /// Sums "Utilization Percentage" over ALL current "GPU Engine" instances —
    /// exactly what Task Manager shows. GPU Engine instances come and go with
    /// D3D workloads, so counters are created on demand into a cache and pruned
    /// when their instance disappears (a single engtype_3D counter captured at
    /// startup returned 0 forever after that churn — the old 0% bug).
    /// Returns -1 when the category is unavailable.
    /// </summary>
    private double QueryGpuEngineUsageSum()
    {
        try
        {
            string[] instances;
            try { instances = new PerformanceCounterCategory("GPU Engine").GetInstanceNames(); }
            catch { return -1; }
            if (instances.Length == 0) return -1;

            double sum = 0;
            foreach (var instance in instances)
            {
                try
                {
                    var counter = _gpuEngineCounters.GetOrAdd(instance, static name => new PerformanceCounter("GPU Engine", "Utilization Percentage", name, readOnly: true));
                    sum += counter.NextValue();
                }
                catch { }
            }

            var cachedKeys = _gpuEngineCounters.Keys;
            if (cachedKeys.Count > instances.Length)
            {
                var live = new HashSet<string>(instances, StringComparer.Ordinal);
                foreach (var key in cachedKeys)
                {
                    if (!live.Contains(key) && _gpuEngineCounters.TryRemove(key, out PerformanceCounter? stale))
                    {
                        try { stale.Dispose(); } catch { }
                    }
                }
            }

            return Math.Clamp(sum, 0, 100);
        }
        catch { return -1; }
    }

    private void UpdateGpuMemoryCounters()
    {
        try
        {
            double dedicatedBytes = 0;
            double sharedBytes = 0;
            var category = new PerformanceCounterCategory("GPU Adapter Memory");
            foreach (var instance in category.GetInstanceNames())
            {
                foreach (var counterName in new[] { "Dedicated Usage", "Shared Usage" })
                {
                    try
                    {
                        using var counter = new PerformanceCounter("GPU Adapter Memory", counterName, instance, readOnly: true);
                        var value = counter.NextValue();
                        if (counterName == "Dedicated Usage") dedicatedBytes += value;
                        else sharedBytes += value;
                    }
                    catch { }
                }
            }

            if (dedicatedBytes > 0 && _cachedGpuVramUsedGb <= 0)
            {
                _cachedGpuVramUsedGb = Math.Round(dedicatedBytes / (1024.0 * 1024.0 * 1024.0), 2);
            }
            if (sharedBytes > 0)
            {
                _cachedGpuSharedUsedGb = Math.Round(sharedBytes / (1024.0 * 1024.0 * 1024.0), 2);
                // Shared GPU memory is capped by half of system RAM on Windows.
                _cachedGpuSharedTotalGb = Math.Round(TotalRamGb / 2, 1);
            }
        }
        catch { }
    }

    /// <summary>
    /// Best-effort CPU temperature. Prefers real core/package sensors from
    /// LibreHardwareMonitor (the same source dedicated monitoring tools use);
    /// falls back to the ACPI thermal zone (available on many boards) and
    /// honestly reports 0 when no sensor answers.
    /// </summary>
    private double QueryCpuTempC()
    {
        if ((DateTime.UtcNow - _lastCpuTempQuery).TotalSeconds < 10) return _cachedCpuTempC;
        _lastCpuTempQuery = DateTime.UtcNow;

        try
        {
            var lhmTemp = _sensors.GetCpuTemperature();
            if (lhmTemp > 0)
            {
                _cachedCpuTempC = Math.Round(lhmTemp, 1);
                return _cachedCpuTempC;
            }
        }
        catch { }

        try
        {
            using var searcher = new ManagementObjectSearcher("root\\WMI", "Select CurrentTemperature from MSAcpi_ThermalZoneTemperature");
            foreach (var item in searcher.Get())
            {
                if (item["CurrentTemperature"] != null)
                {
                    // Tenths of Kelvin → Celsius
                    var tempC = Convert.ToDouble(item["CurrentTemperature"]) / 10.0 - 273.15;
                    if (tempC is > 0 and < 120)
                    {
                        _cachedCpuTempC = Math.Round(tempC, 1);
                        break;
                    }
                }
            }
        }
        catch { }
        return _cachedCpuTempC;
    }

    private string QueryLanIp()
    {
        if (!string.IsNullOrEmpty(_cachedLanIp)) return _cachedLanIp;
        try
        {
            foreach (var nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
            {
                if (nic.OperationalStatus != System.Net.NetworkInformation.OperationalStatus.Up ||
                    nic.NetworkInterfaceType == System.Net.NetworkInformation.NetworkInterfaceType.Loopback) continue;
                var props = nic.GetIPProperties();
                if (props.GatewayAddresses.Count == 0) continue;
                foreach (var addr in props.UnicastAddresses)
                {
                    if (addr.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork &&
                        !System.Net.IPAddress.IsLoopback(addr.Address))
                    {
                        return _cachedLanIp = addr.Address.ToString();
                    }
                }
            }
        }
        catch { }
        return _cachedLanIp = string.Empty;
    }

    private async Task QueryWanIpAsync()
    {
        if (!string.IsNullOrEmpty(_cachedWanIp) && (DateTime.UtcNow - _lastWanIpQuery).TotalMinutes < 15) return;
        try
        {
            using var http = new System.Net.Http.HttpClient { Timeout = TimeSpan.FromSeconds(6) };
            var trace = await http.GetStringAsync("https://www.cloudflare.com/cdn-cgi/trace");
            foreach (var line in trace.Split('\n'))
            {
                if (line.StartsWith("ip="))
                {
                    var ip = line[3..].Trim();
                    if (ip.Length > 0) _cachedWanIp = ip;
                    break;
                }
            }
            _lastWanIpQuery = DateTime.UtcNow;
        }
        catch { }
    }

    public void Shutdown() => Process.Start("shutdown", "/s /t 0");
    public void Restart() => Process.Start("shutdown", "/r /t 0");
    public void Sleep() => System.Windows.Forms.Application.SetSuspendState(System.Windows.Forms.PowerState.Suspend, true, true);
    public void Hibernate() => System.Windows.Forms.Application.SetSuspendState(System.Windows.Forms.PowerState.Hibernate, true, true);

    public void MonitorOff()
    {
        try
        {
            SendMessage((IntPtr)0xFFFF /* HWND_BROADCAST */, 0x0112 /* WM_SYSCOMMAND */, (IntPtr)0xF170 /* SC_MONITORPOWER */, (IntPtr)2 /* off */);
        }
        catch { }
    }

    public void LockScreen() => Process.Start("rundll32.exe", "user32.dll,LockWorkStation");

    public void StartTimer(string action, int seconds)
    {
        string flag = action == "restart" ? "/r" : "/s";
        Process.Start("shutdown", $"{flag} /t {seconds}");
    }

    public void CancelTimer() => Process.Start("shutdown", "/a");

    public void OpenUrl(string url)
    {
        if (!url.StartsWith("http://") && !url.StartsWith("https://")) url = "https://" + url;
        Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
    }
}
