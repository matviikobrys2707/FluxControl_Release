using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace FluxControl.Agent.Services;

/// <summary>
/// Fullscreen uncloseable window shown while WinLock is engaged.
/// The user cannot close it: Alt+F4 and friends are swallowed by the service's
/// keyboard hook, and <see cref="OnClosingGuard"/> cancels any other close attempt.
/// Only <see cref="WinLockService"/> may dismiss it via <see cref="ForceClose"/>.
/// </summary>
public partial class LockWindow : Window
{
    private readonly WinLockService _service;
    private readonly DispatcherTimer _topmostTimer;
    private bool _forceCloseAllowed;

    public LockWindow(WinLockService service, string mode, long lockedAt)
    {
        InitializeComponent();

        _service = service;

        LockedAtText.Text = $"Заблоковано о {DateTimeOffset.FromUnixTimeMilliseconds(lockedAt).ToLocalTime():HH:mm}";

        var codeMode = mode == WinLockService.ModeCode;
        CodePanel.Visibility = codeMode ? Visibility.Visible : Visibility.Collapsed;
        SitePanel.Visibility = codeMode ? Visibility.Collapsed : Visibility.Visible;

        UnlockButton.Click += (_, _) => TryLocalUnlock();
        CodeBox.KeyDown += OnCodeBoxKeyDown;
        CodeBox.TextChanged += (_, _) => ErrorText.Visibility = Visibility.Collapsed;

        Loaded += OnLoaded;
        Deactivated += OnDeactivated;
        Closing += OnClosingGuard;

        // Re-assert Topmost periodically in case something stole it.
        _topmostTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
        _topmostTimer.Tick += (_, _) => AssertTopmost();
    }

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        AssertTopmost();
        if (CodePanel.Visibility == Visibility.Visible)
        {
            CodeBox.Focus();
            Keyboard.Focus(CodeBox);
        }
        _topmostTimer.Start();
    }

    private void OnDeactivated(object? sender, EventArgs e)
    {
        AssertTopmost();
    }

    private void AssertTopmost()
    {
        try
        {
            Topmost = true;
            Activate();
        }
        catch { }
    }

    private void OnClosingGuard(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        if (_forceCloseAllowed)
        {
            _topmostTimer.Stop();
            return;
        }
        e.Cancel = true; // this window is the lock surface — nothing external may close it
    }

    /// <summary>Service-initiated dismissal (unlock): bypasses the OnClosing guard.</summary>
    internal void ForceClose()
    {
        _forceCloseAllowed = true;
        try { Close(); } catch { }
    }

    private void OnCodeBoxKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
    {
        if (e.Key == Key.Enter)
        {
            e.Handled = true;
            TryLocalUnlock();
        }
    }

    private void TryLocalUnlock()
    {
        // Hash compare is instant — safe on the UI thread, never blocks.
        if (_service.TryUnlock(CodeBox.Text))
        {
            return; // service closes this window itself via ForceClose()
        }
        ShowWrongCodeFeedback();
    }

    private void ShowWrongCodeFeedback()
    {
        ErrorText.Visibility = Visibility.Visible;
        CodeBox.Clear();
        CodeBox.Focus();

        var shake = new TranslateTransform();
        CodePanel.RenderTransform = shake;

        var animation = new DoubleAnimationUsingKeyFrames();
        animation.KeyFrames.Add(new LinearDoubleKeyFrame(0, TimeSpan.Zero));
        animation.KeyFrames.Add(new LinearDoubleKeyFrame(-6, TimeSpan.FromMilliseconds(60)));
        animation.KeyFrames.Add(new LinearDoubleKeyFrame(6, TimeSpan.FromMilliseconds(120)));
        animation.KeyFrames.Add(new LinearDoubleKeyFrame(-6, TimeSpan.FromMilliseconds(180)));
        animation.KeyFrames.Add(new LinearDoubleKeyFrame(6, TimeSpan.FromMilliseconds(240)));
        animation.KeyFrames.Add(new LinearDoubleKeyFrame(0, TimeSpan.FromMilliseconds(300)));
        shake.BeginAnimation(TranslateTransform.XProperty, animation);
    }
}
