using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using QRCoder;

namespace FluxControl.Agent.Services;

public class PairedDevice
{
    [JsonPropertyName("id")]
    public string Id { get; set; } = Guid.NewGuid().ToString("N");

    [JsonPropertyName("deviceName")]
    public string DeviceName { get; set; } = "Unknown Device";

    [JsonPropertyName("token")]
    public string Token { get; set; } = string.Empty;

    [JsonPropertyName("pairedAt")]
    public DateTime PairedAt { get; set; } = DateTime.UtcNow;

    [JsonPropertyName("lastSeen")]
    public DateTime LastSeen { get; set; } = DateTime.UtcNow;

    [JsonPropertyName("ipAddress")]
    public string IpAddress { get; set; } = string.Empty;
}

public class PairingRequest
{
    public string RequestId { get; set; } = Guid.NewGuid().ToString("N");
    public string DeviceName { get; set; } = string.Empty;
    public string IpAddress { get; set; } = string.Empty;
    public string Pin { get; set; } = string.Empty;
    public TaskCompletionSource<bool> CompletionSource { get; set; } = new();
}

public class ConnectedClientInfo
{
    [JsonPropertyName("connectionId")]
    public string ConnectionId { get; set; } = string.Empty;

    [JsonPropertyName("deviceName")]
    public string DeviceName { get; set; } = string.Empty;

    [JsonPropertyName("ipAddress")]
    public string IpAddress { get; set; } = string.Empty;

    [JsonPropertyName("connectedAt")]
    public DateTime ConnectedAt { get; set; } = DateTime.UtcNow;
}

public class PairingService
{
    // Алфавіт для 16-символьного коду підключення (однозначні великі літери та цифри)
    private const string CodeAlphabet = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ";

    private readonly string _appDataFolder;
    private readonly string _devicesFilePath;
    private readonly string _hwidFilePath;    // 32-char HWID (незмінний)
    private readonly string _codeFilePath;    // 16-char код підключення (для сайту)
    private readonly List<PairedDevice> _devices = new();
    private readonly Dictionary<string, ConnectedClientInfo> _activeClients = new();
    private readonly object _lock = new();
    private static readonly HttpClient _httpClient = new() { Timeout = TimeSpan.FromSeconds(5) };

    /// <summary>
    /// HWID  незмінний 32-символьний UUID без дефісів.
    /// Генерується один раз і ніколи не змінюється.
    /// Використовується як computers.id в базі даних.
    /// </summary>
    public string HardwareId { get; private set; } = string.Empty;

    /// <summary>
    /// Код підключення  16 символів, показується в UI.
    /// Саме цей код вводить користувач на сайті щоб прив'язати ПК.
    /// Можна перегенерувати кнопкою.
    /// </summary>
    public string DeviceCode { get; private set; } = string.Empty;

    public string CurrentPin { get; private set; } = string.Empty;

    public event Action<PairingRequest>? OnPairingRequested;
    public event Action? OnClientsChanged;

    public PairingService()
    {
        _appDataFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FluxControl");
        Directory.CreateDirectory(_appDataFolder);

        _devicesFilePath = Path.Combine(_appDataFolder, "paired_devices.json");
        _hwidFilePath    = Path.Combine(_appDataFolder, "hardware_id.txt");  // HWID
        _codeFilePath    = Path.Combine(_appDataFolder, "device_code.txt");  // 16-char код

        EnsureHardwareId();   // Незмінний HWID (32 char)
        EnsureDeviceCode();   // Код для UI (16 char)
        LoadDevices();
        RegeneratePin();
    }

    private string ComputeDeterministicHardwareId()
    {
        try
        {
            string machineGuid = "";
            try
            {
                using var key = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Cryptography");
                machineGuid = key?.GetValue("MachineGuid")?.ToString() ?? "";
            }
            catch { }

            string cpuId = "";
            try
            {
                using var searcher = new System.Management.ManagementObjectSearcher("SELECT ProcessorId FROM Win32_Processor");
                foreach (var obj in searcher.Get())
                {
                    cpuId = obj["ProcessorId"]?.ToString() ?? "";
                    if (!string.IsNullOrEmpty(cpuId)) break;
                }
            }
            catch { }

            string motherboardSerial = "";
            try
            {
                using var searcher = new System.Management.ManagementObjectSearcher("SELECT SerialNumber FROM Win32_BaseBoard");
                foreach (var obj in searcher.Get())
                {
                    motherboardSerial = obj["SerialNumber"]?.ToString() ?? "";
                    if (!string.IsNullOrEmpty(motherboardSerial)) break;
                }
            }
            catch { }

            string raw = $"{machineGuid}|{cpuId}|{motherboardSerial}|FluxControl_HWID_Salt_2026";
            using var sha = SHA256.Create();
            byte[] hash = sha.ComputeHash(System.Text.Encoding.UTF8.GetBytes(raw));
            return Convert.ToHexString(hash, 0, 16).ToLowerInvariant();
        }
        catch
        {
            return Guid.NewGuid().ToString("N");
        }
    }

    /// <summary>
    /// Незмінний апаратний HWID із захистом від ручного редагування.
    /// Якщо користувач відредагує hardware_id.txt (наприклад напише "1 2 3"),
    /// програма миттєво відхилить підробку та відновить справжній апаратний HWID.
    /// </summary>
    private void EnsureHardwareId()
    {
        try
        {
            var genuineHwid = ComputeDeterministicHardwareId();
            HardwareId = genuineHwid;

            bool needsFix = true;
            if (File.Exists(_hwidFilePath))
            {
                var content = File.ReadAllText(_hwidFilePath).Trim();
                if (string.Equals(content, genuineHwid, StringComparison.OrdinalIgnoreCase))
                {
                    needsFix = false;
                }
            }

            if (needsFix)
            {
                File.WriteAllText(_hwidFilePath, genuineHwid);
            }

            // Також дублюємо в захищений розділ реєстру поточного користувача
            try
            {
                using var reg = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(@"Software\FluxControl");
                reg?.SetValue("HardwareId", genuineHwid);
            }
            catch { }
        }
        catch
        {
            HardwareId = Guid.NewGuid().ToString("N");
        }
    }

    /// <summary>
    /// Зчитує або генерує 16-значний код підключення з захистом від невалідного редагування.
    /// </summary>
    private void EnsureDeviceCode()
    {
        try
        {
            string? regCode = null;
            try
            {
                using var reg = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"Software\FluxControl");
                regCode = reg?.GetValue("DeviceCode")?.ToString()?.Trim()?.ToUpperInvariant();
            }
            catch { }

            string? fileCode = null;
            if (File.Exists(_codeFilePath))
            {
                fileCode = File.ReadAllText(_codeFilePath).Trim().ToUpperInvariant();
            }

            bool isFileValid = !string.IsNullOrEmpty(fileCode) && fileCode.Length == 16 && fileCode.All(c => CodeAlphabet.Contains(c));
            bool isRegValid = !string.IsNullOrEmpty(regCode) && regCode.Length == 16 && regCode.All(c => CodeAlphabet.Contains(c));

            if (isFileValid && isRegValid && fileCode == regCode)
            {
                DeviceCode = fileCode!;
                return;
            }

            // Якщо користувач зіпсував файл (наприклад ввів "1 2 3"), відновлюємо з реєстру!
            if (isRegValid && (!isFileValid || fileCode != regCode))
            {
                DeviceCode = regCode!;
                File.WriteAllText(_codeFilePath, DeviceCode);
                return;
            }

            // Якщо валідний у файлі — синхронізуємо в реєстр
            if (isFileValid)
            {
                DeviceCode = fileCode!;
                SaveDeviceCodeToRegistry(DeviceCode);
                return;
            }

            // Інакше генеруємо новий легітимний код та відновлюємо
            DeviceCode = GenerateAlphanumericCode(16);
            File.WriteAllText(_codeFilePath, DeviceCode);
            SaveDeviceCodeToRegistry(DeviceCode);
        }
        catch
        {
            DeviceCode = GenerateAlphanumericCode(16);
        }
    }

    private void SaveDeviceCodeToRegistry(string code)
    {
        try
        {
            using var reg = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(@"Software\FluxControl");
            reg?.SetValue("DeviceCode", code);
        }
        catch { }
    }

    private string GenerateAlphanumericCode(int length)
    {
        var chars = new char[length];
        for (int i = 0; i < length; i++)
        {
            chars[i] = CodeAlphabet[RandomNumberGenerator.GetInt32(0, CodeAlphabet.Length)];
        }
        return new string(chars);
    }

    /// <summary>
    /// Перегенерувати ЛИШЕ код підключення (не HWID!)
    /// </summary>
    public void RegenerateCode()
    {
        try
        {
            DeviceCode = GenerateAlphanumericCode(16);
            File.WriteAllText(_codeFilePath, DeviceCode);
            SaveDeviceCodeToRegistry(DeviceCode);
        }
        catch { }
    }

    /// <summary>
    /// Форматований код для відображення: XXXX-XXXX-XXXX-XXXX
    /// </summary>
    public string GetFormattedCode()
    {
        if (DeviceCode.Length == 16)
        {
            return $"{DeviceCode.Substring(0, 4)}-{DeviceCode.Substring(4, 4)}-{DeviceCode.Substring(8, 4)}-{DeviceCode.Substring(12, 4)}";
        }
        return DeviceCode;
    }

    public void RegeneratePin()
    {
        CurrentPin = RandomNumberGenerator.GetInt32(100000, 999999).ToString();
    }

    public string GenerateQrCodeDataUrl(string pairingPayload)
    {
        using var qrGenerator = new QRCodeGenerator();
        using var qrCodeData = qrGenerator.CreateQrCode(pairingPayload, QRCodeGenerator.ECCLevel.Q);
        var qrCode = new PngByteQRCode(qrCodeData);
        byte[] qrCodeBytes = qrCode.GetGraphic(10);
        return $"data:image/png;base64,{Convert.ToBase64String(qrCodeBytes)}";
    }

    /// <summary>
    /// Реєструє ПК у Cloudflare D1:
    /// - id = HardwareId (32-char, незмінний)
    /// - code = DeviceCode (16-char, для прив'язки)
    /// </summary>
    public async Task PublishRendezvousAsync(string? publicUrl, string? localUrl)
    {
        if (string.IsNullOrEmpty(publicUrl)) { return; }

        try
        {
            var payload = new
            {
                hwid      = HardwareId,       // 32-char незмінний UUID для БД
                id        = HardwareId,
                code      = DeviceCode,        // 16-char код для UI/прив'язки
                name      = Environment.MachineName,
                username  = Environment.UserName,
                activeUrl = publicUrl,
                localUrl  = localUrl ?? "",
                os        = RelayClientService.GetExactWindowsVersion(),
                osInfo    = RelayClientService.GetExactWindowsVersion(),
                cpu       = Environment.GetEnvironmentVariable("PROCESSOR_IDENTIFIER") ?? "CPU",
                cpuInfo   = Environment.GetEnvironmentVariable("PROCESSOR_IDENTIFIER") ?? "CPU"
            };
            var json = JsonSerializer.Serialize(payload);
            using var content1 = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
            using var content2 = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
            try { await _httpClient.PostAsync("https://fluxcontrol.pages.dev/api/agent/register", content1); } catch { }
            try { await _httpClient.PostAsync("https://fluxcontrol-backend.onrender.com/api/register", content2); } catch { }
        }
        catch { }
    }

    public async Task<(bool success, string? token, string message)> RequestPairingAsync(string deviceName, string pinOrCode, string ip)
    {
        string input = (pinOrCode ?? "").Trim().Replace("-", "");
        string cleanCode = DeviceCode.Replace("-", "");

        bool isAuthorized = input.Equals(CurrentPin, StringComparison.OrdinalIgnoreCase) ||
                            input.Equals(cleanCode, StringComparison.OrdinalIgnoreCase) ||
                            input.Equals(HardwareId, StringComparison.OrdinalIgnoreCase);

        var request = new PairingRequest
        {
            DeviceName = string.IsNullOrWhiteSpace(deviceName) ? "Пристрій" : deviceName,
            IpAddress = ip,
            Pin = input
        };

        bool approved = false;

        if (isAuthorized)
        {
            approved = true;
        }
        else
        {
            OnPairingRequested?.Invoke(request);
            var completedTask = await Task.WhenAny(request.CompletionSource.Task, Task.Delay(30000));
            if (completedTask == request.CompletionSource.Task)
            {
                approved = await request.CompletionSource.Task;
            }
        }

        if (!approved)
            return (false, null, "Підключення відхилено.");

        var token = "flux_" + Convert.ToHexString(RandomNumberGenerator.GetBytes(24)).ToLowerInvariant();
        lock (_lock)
        {
            _devices.Add(new PairedDevice
            {
                DeviceName = request.DeviceName,
                Token = token,
                IpAddress = ip,
                PairedAt = DateTime.UtcNow,
                LastSeen = DateTime.UtcNow
            });
            SaveDevices();
        }

        return (true, token, "Успішно!");
    }

    public bool ValidateToken(string token, string ip, out PairedDevice? device)
    {
        lock (_lock)
        {
            device = _devices.FirstOrDefault(d => d.Token == token);
            if (device != null)
            {
                device.LastSeen = DateTime.UtcNow;
                device.IpAddress = ip;
                return true;
            }
        }
        return false;
    }

    public void RegisterClientConnected(string connectionId, string deviceName, string ip)
    {
        lock (_lock)
        {
            _activeClients[connectionId] = new ConnectedClientInfo
            {
                ConnectionId = connectionId,
                DeviceName = string.IsNullOrWhiteSpace(deviceName) ? "Клієнт" : deviceName,
                IpAddress = ip,
                ConnectedAt = DateTime.UtcNow
            };
        }
        OnClientsChanged?.Invoke();
    }

    public void RegisterClientDisconnected(string connectionId)
    {
        lock (_lock) { _activeClients.Remove(connectionId); }
        OnClientsChanged?.Invoke();
    }

    public List<ConnectedClientInfo> GetActiveClients()
    {
        lock (_lock) { return _activeClients.Values.ToList(); }
    }

    public List<PairedDevice> GetPairedDevices()
    {
        lock (_lock) { return _devices.ToList(); }
    }

    public void RevokeDevice(string deviceId)
    {
        lock (_lock)
        {
            _devices.RemoveAll(d => d.Id == deviceId);
            SaveDevices();
        }
        OnClientsChanged?.Invoke();
    }

    private void LoadDevices()
    {
        try
        {
            if (File.Exists(_devicesFilePath))
            {
                var json = File.ReadAllText(_devicesFilePath);
                var loaded = JsonSerializer.Deserialize<List<PairedDevice>>(json);
                if (loaded != null) _devices.AddRange(loaded);
            }
        }
        catch { }
    }

    private void SaveDevices()
    {
        try
        {
            var json = JsonSerializer.Serialize(_devices, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(_devicesFilePath, json);
        }
        catch { }
    }
}
