using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace FluxControl.Agent.Services;

public class TerminalService : IDisposable
{
    private Process? _terminalProcess;
    private StreamWriter? _stdinWriter;
    private string _currentShell = "powershell";
    private readonly object _lock = new();

    // cd-подібні команди: після них оболонка ПОВИННА надрукувати новий
    // промпт (наш маркер FLUX_CWD::…), але іноді промпт губиться/клеється
    // з виводом — тоді сайт не бачить зміну папки. Тому після cd ми
    // ПРИМУСОВО надсилаємо порожній рядок, який змушує оболонку надрукувати
    // свіжий промпт з актуальним шляхом.
    private static readonly Regex CdLikeRegex = new(
        @"^\s*(cd|chdir|set-location|sl|pushd|popd)\b|^\s*[a-zA-Z]:\s*$",
        RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

    public event Action<string>? OnOutputReceived;
    public event Action<string>? OnErrorReceived;
    public event Action? OnExited;

    public void StartSession(string shellType = "powershell")
    {
        lock (_lock)
        {
            StopSession();

            _currentShell = shellType.ToLowerInvariant() == "cmd" ? "cmd" : "powershell";

            string fileName = _currentShell == "cmd" ? "cmd.exe" : "powershell.exe";
            // cmd: /Q = echo off (piped commands are NOT echoed back, so the web
            // does not see the typed command twice), and the custom prompt makes
            // cmd print "FLUX_CWD::<cwd>>" to stdout after EVERY completed
            // command — the web updates its cwd immediately after "cd".
            // powershell: the prompt function emits "FLUX_CWD::<path>::END" the
            // same way. Both markers are replaced by the fresh shell prompt.
            string arguments = _currentShell == "cmd"
                ? "/Q /K chcp 65001 >nul & prompt FLUX_CWD::$P$G"
                : "-NoLogo -NoProfile -NoExit -ExecutionPolicy Bypass -Command \"[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; function prompt { 'FLUX_CWD::' + (Get-Location).Path + '::END' }\"";

            string workDir = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            if (string.IsNullOrWhiteSpace(workDir) || !Directory.Exists(workDir))
            {
                workDir = Environment.GetFolderPath(Environment.SpecialFolder.System);
            }

            var psi = new ProcessStartInfo
            {
                FileName = fileName,
                Arguments = arguments,
                WorkingDirectory = workDir,
                UseShellExecute = false,
                RedirectStandardInput = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8
            };

            _terminalProcess = new Process { StartInfo = psi, EnableRaisingEvents = true };

            _terminalProcess.OutputDataReceived += (sender, args) =>
            {
                if (args.Data != null)
                {
                    OnOutputReceived?.Invoke(args.Data + "\n");
                }
            };

            _terminalProcess.ErrorDataReceived += (sender, args) =>
            {
                if (args.Data != null)
                {
                    OnErrorReceived?.Invoke(args.Data + "\n");
                }
            };

            _terminalProcess.Exited += (sender, args) =>
            {
                OnExited?.Invoke();
            };

            _terminalProcess.Start();
            _stdinWriter = new StreamWriter(_terminalProcess.StandardInput.BaseStream, new UTF8Encoding(false)) { AutoFlush = true };

            _terminalProcess.BeginOutputReadLine();
            _terminalProcess.BeginErrorReadLine();

            // One manual initial marker so the web can render the prompt
            // instantly (UserProfile IS the real current user); the real shell
            // prompt in the same format follows shortly after initialization.
            OnOutputReceived?.Invoke(_currentShell == "cmd" ? $"FLUX_CWD::{workDir}>\n" : $"FLUX_CWD::{workDir}::END\n");
        }
    }

    public void SendInput(string input)
    {
        bool isCdLike;
        lock (_lock)
        {
            if (_terminalProcess == null || _terminalProcess.HasExited || _stdinWriter == null)
            {
                StartSession(_currentShell);
            }

            try
            {
                _stdinWriter?.WriteLine(input);
            }
            catch (Exception ex)
            {
                OnErrorReceived?.Invoke($"[Terminal Error] {ex.Message}\n");
            }
            isCdLike = CdLikeRegex.IsMatch(input ?? string.Empty);
        }

        // Поза lock: примусовий «свіжий» промпт після зміни каталогу.
        if (isCdLike)
        {
            ScheduleCwdFlush();
        }
    }

    /// <summary>
    /// Через 700 мс після cd-подібної команди надсилаємо порожній рядок:
    /// оболонка виконує «ніщо» і друкує свіжий промпт FLUX_CWD::шлях —
    /// сайт гарантовано бачить нову робочу папку (фікс «cd працює,
    /// але шлях на сайті не змінюється»).
    /// </summary>
    private void ScheduleCwdFlush()
    {
        _ = Task.Run(async () =>
        {
            try
            {
                await Task.Delay(700);
                lock (_lock)
                {
                    if (_terminalProcess != null && !_terminalProcess.HasExited && _stdinWriter != null)
                    {
                        _stdinWriter.WriteLine("");
                    }
                }
            }
            catch { }
        });
    }

    public void StopSession()
    {
        lock (_lock)
        {
            if (_terminalProcess != null)
            {
                try
                {
                    if (!_terminalProcess.HasExited)
                    {
                        _terminalProcess.Kill(entireProcessTree: true);
                    }
                }
                catch { }
                finally
                {
                    _terminalProcess.Dispose();
                    _terminalProcess = null;
                    _stdinWriter = null;
                }
            }
        }
    }

    public void Dispose()
    {
        StopSession();
    }
}
