using System;
using System.IO;
using System.Windows;

namespace FluxControl.Agent.Services;

/// <summary>
/// Розтаутно-незалежний EXE (ТЗ користувача): програма може лежати де завгодно
/// (робочий стіл, Downloads…) — всі робочі файли вона тримає у своєму
/// сховищі %AppData%\FluxControl. Інтерфейс агента (UI/agent_ui.html) та
/// іконка (logo.ico) вбудовані в збірку як ресурси і витягуються в це сховище
/// при першому запуску (WebView2 читає html саме з диска).
///
/// Оновлені версії цих файлів (без пересборки exe) підтягує
/// BootstrapService.SyncExtraFilesFromManifest — звіряючи sha256 з манифестом
/// version.json у main-гілці репозиторію релізів.
/// </summary>
public static class RuntimeFiles
{
    /// <summary>Кореневе сховище програми: %AppData%\FluxControl.</summary>
    public static string DataRoot { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FluxControl");

    /// <summary>Повний шлях до agent_ui.html у сховищі (після EnsureRuntimeFiles).</summary>
    public static string UiHtmlPath { get; private set; } =
        Path.Combine(DataRoot, "UI", "agent_ui.html");

    /// <summary>Повний шлях до logo.ico у сховищі (після EnsureRuntimeFiles).</summary>
    public static string LogoIcoPath { get; private set; } =
        Path.Combine(DataRoot, "logo.ico");

    /// <summary>Витягує вбудовані файли, яких бракує у сховищі. Ідемпотентно.</summary>
    public static void EnsureRuntimeFiles()
    {
        Directory.CreateDirectory(DataRoot);
        UiHtmlPath = ExtractIfNeeded("UI/agent_ui.html", "pack://application:,,,/UI/agent_ui.html");
        LogoIcoPath = ExtractIfNeeded("logo.ico", "pack://application:,,,/logo.ico");
    }

    private static string ExtractIfNeeded(string relPath, string packUri)
    {
        var dest = Path.Combine(DataRoot, relPath.Replace('/', Path.DirectorySeparatorChar));
        try
        {
            if (File.Exists(dest)) return dest; // вже витягнуто або синхронізовано

            var sri = System.Windows.Application.GetResourceStream(new Uri(packUri, UriKind.Absolute));
            if (sri == null)
            {
                App.Log($"RuntimeFiles: resource not found: {packUri}");
                return dest;
            }

            Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
            using (var input = sri.Stream)
            using (var output = new FileStream(dest, FileMode.Create, FileAccess.Write, FileShare.Read))
            {
                input.CopyTo(output);
            }
            App.Log($"RuntimeFiles: extracted {relPath} ({new FileInfo(dest).Length} bytes)");
        }
        catch (Exception ex)
        {
            App.Log($"RuntimeFiles: extract {relPath} failed: {ex.Message}");
        }
        return dest;
    }
}
