namespace FluxControl.Agent.Services;

public class InputService
{
    private static readonly Dictionary<string, byte> KeyMap = new(StringComparer.OrdinalIgnoreCase)
    {
        { "backspace", Win32Api.VK_BACK },
        { "tab", Win32Api.VK_TAB },
        { "enter", Win32Api.VK_RETURN },
        { "return", Win32Api.VK_RETURN },
        { "shift", Win32Api.VK_SHIFT },
        { "control", Win32Api.VK_CONTROL },
        { "ctrl", Win32Api.VK_CONTROL },
        { "alt", Win32Api.VK_MENU },
        { "pause", Win32Api.VK_PAUSE },
        { "capslock", Win32Api.VK_CAPITAL },
        { "numlock", 0x90 },
        { "scrolllock", 0x91 },
        { "escape", Win32Api.VK_ESCAPE },
        { "esc", Win32Api.VK_ESCAPE },
        { "space", Win32Api.VK_SPACE },
        { "pageup", Win32Api.VK_PRIOR },
        { "pagedown", Win32Api.VK_NEXT },
        { "end", Win32Api.VK_END },
        { "home", Win32Api.VK_HOME },
        { "left", Win32Api.VK_LEFT },
        { "up", Win32Api.VK_UP },
        { "right", Win32Api.VK_RIGHT },
        { "down", Win32Api.VK_DOWN },
        { "printscreen", Win32Api.VK_SNAPSHOT },
        { "prtsc", Win32Api.VK_SNAPSHOT },
        { "insert", Win32Api.VK_INSERT },
        { "apps", Win32Api.VK_APPS },
        { "divide", 0x6F },
        { "multiply", 0x6A },
        { "subtract", 0x6D },
        { "add", 0x6B },
        { "decimal", 0x6E },
        { "delete", Win32Api.VK_DELETE },
        { "del", Win32Api.VK_DELETE },
        { "win", Win32Api.VK_LWIN },
        { "meta", Win32Api.VK_LWIN },
        { "cmd", Win32Api.VK_LWIN },
        { "super", Win32Api.VK_LWIN },
        { "volup", Win32Api.VK_VOLUME_UP },
        { "voldown", Win32Api.VK_VOLUME_DOWN },
        { "mute", Win32Api.VK_VOLUME_MUTE },
        { "playpause", Win32Api.VK_MEDIA_PLAY_PAUSE },
        { "nexttrack", Win32Api.VK_MEDIA_NEXT_TRACK },
        { "prevtrack", Win32Api.VK_MEDIA_PREV_TRACK }
    };

    static InputService()
    {
        // 0-9
        for (int i = 0; i <= 9; i++)
        {
            KeyMap[i.ToString()] = (byte)(0x30 + i);
        }
        // A-Z
        for (char c = 'a'; c <= 'z'; c++)
        {
            KeyMap[c.ToString()] = (byte)(0x41 + (c - 'a'));
        }
        // F1-F12
        for (int f = 1; f <= 12; f++)
        {
            KeyMap[$"f{f}"] = (byte)(0x70 + (f - 1));
        }
        for (int n = 0; n <= 9; n++) KeyMap[$"num{n}"] = (byte)(0x60 + n);
    }

    public void MoveMouse(int deltaX, int deltaY)
    {
        Win32Api.mouse_event(Win32Api.MOUSEEVENTF_MOVE, (uint)deltaX, (uint)deltaY, 0, 0);
    }

    public void SetMousePosition(int x, int y)
    {
        Win32Api.SetCursorPos(x, y);
    }

    /// <summary>
    /// Абсолютне позиціювання для AI-агента: nx/ny у діапазоні 0..1000
    /// мапляться на віртуальний екран (усі монітори). Нормалізовані
    /// координати дозволяють моделі цілитися по скриншоту, не знаючи
    /// реальної роздільної здатності ПК.
    /// </summary>
    public void MoveMouseAbsoluteNormalized(double nx, double ny)
    {
        nx = Math.Clamp(nx, 0, 1000) / 1000.0;
        ny = Math.Clamp(ny, 0, 1000) / 1000.0;
        int vx = Win32Api.GetSystemMetrics(Win32Api.SM_XVIRTUALSCREEN);
        int vy = Win32Api.GetSystemMetrics(Win32Api.SM_YVIRTUALSCREEN);
        int vw = Win32Api.GetSystemMetrics(Win32Api.SM_CXVIRTUALSCREEN);
        int vh = Win32Api.GetSystemMetrics(Win32Api.SM_CYVIRTUALSCREEN);
        if (vw <= 0) vw = Win32Api.GetSystemMetrics(Win32Api.SM_CXSCREEN);
        if (vh <= 0) vh = Win32Api.GetSystemMetrics(Win32Api.SM_CYSCREEN);
        int px = vx + (int)Math.Round(nx * (vw - 1));
        int py = vy + (int)Math.Round(ny * (vh - 1));
        Win32Api.SetCursorPos(px, py);
    }

    public void MouseClick(string button = "left", bool isDoubleClick = false)
    {
        uint downFlag = Win32Api.MOUSEEVENTF_LEFTDOWN;
        uint upFlag = Win32Api.MOUSEEVENTF_LEFTUP;

        if (button.Equals("right", StringComparison.OrdinalIgnoreCase))
        {
            downFlag = Win32Api.MOUSEEVENTF_RIGHTDOWN;
            upFlag = Win32Api.MOUSEEVENTF_RIGHTUP;
        }
        else if (button.Equals("middle", StringComparison.OrdinalIgnoreCase))
        {
            downFlag = Win32Api.MOUSEEVENTF_MIDDLEDOWN;
            upFlag = Win32Api.MOUSEEVENTF_MIDDLEUP;
        }

        Win32Api.mouse_event(downFlag, 0, 0, 0, 0);
        Win32Api.mouse_event(upFlag, 0, 0, 0, 0);

        if (isDoubleClick)
        {
            Thread.Sleep(50);
            Win32Api.mouse_event(downFlag, 0, 0, 0, 0);
            Win32Api.mouse_event(upFlag, 0, 0, 0, 0);
        }
    }

    public void MouseDown(string button = "left")
    {
        uint flag = button.ToLowerInvariant() switch
        {
            "right" => Win32Api.MOUSEEVENTF_RIGHTDOWN,
            "middle" => Win32Api.MOUSEEVENTF_MIDDLEDOWN,
            _ => Win32Api.MOUSEEVENTF_LEFTDOWN
        };
        Win32Api.mouse_event(flag, 0, 0, 0, 0);
    }

    public void MouseUp(string button = "left")
    {
        uint flag = button.ToLowerInvariant() switch
        {
            "right" => Win32Api.MOUSEEVENTF_RIGHTUP,
            "middle" => Win32Api.MOUSEEVENTF_MIDDLEUP,
            _ => Win32Api.MOUSEEVENTF_LEFTUP
        };
        Win32Api.mouse_event(flag, 0, 0, 0, 0);
    }

    public void MouseScroll(int deltaX, int deltaY)
    {
        if (deltaY != 0)
        {
            Win32Api.mouse_event(Win32Api.MOUSEEVENTF_WHEEL, 0, 0, (uint)deltaY, 0);
        }
        if (deltaX != 0)
        {
            Win32Api.mouse_event(Win32Api.MOUSEEVENTF_HWHEEL, 0, 0, (uint)deltaX, 0);
        }
    }

    public void KeyPress(string key, List<string>? modifiers = null)
    {
        var pressedModifiers = new List<byte>();

        if (modifiers != null)
        {
            foreach (var mod in modifiers)
            {
                if (TryGetVirtualKey(mod, out var modVk))
                {
                    SendVirtualKey(modVk, false);
                    pressedModifiers.Add(modVk);
                }
            }
        }

        if (TryGetVirtualKey(key, out var vk))
        {
            SendVirtualKey(vk, false);
            Thread.Sleep(10);
            SendVirtualKey(vk, true);
        }
        else if (key.Length == 1)
        {
            SendUnicodeChar(key[0]);
        }

        // Release modifiers in reverse order
        for (int i = pressedModifiers.Count - 1; i >= 0; i--)
        {
            SendVirtualKey(pressedModifiers[i], true);
        }
    }

    public void KeyDown(string key)
    {
        if (TryGetVirtualKey(key, out var vk))
        {
            SendVirtualKey(vk, false);
        }
    }

    public void KeyUp(string key)
    {
        if (TryGetVirtualKey(key, out var vk))
        {
            SendVirtualKey(vk, true);
        }
    }

    public void SendText(string text)
    {
        foreach (char c in text)
        {
            SendUnicodeChar(c);
        }
    }

    private void SendUnicodeChar(char c)
    {
        var inputs = new Win32Api.INPUT[2];
        inputs[0] = new Win32Api.INPUT
        {
            type = Win32Api.INPUT_KEYBOARD,
            u = new Win32Api.INPUTUNION
            {
                ki = new Win32Api.KEYBDINPUT
                {
                    wVk = 0,
                    wScan = c,
                    dwFlags = Win32Api.KEYEVENTF_UNICODE,
                    time = 0,
                    dwExtraInfo = IntPtr.Zero
                }
            }
        };

        inputs[1] = new Win32Api.INPUT
        {
            type = Win32Api.INPUT_KEYBOARD,
            u = new Win32Api.INPUTUNION
            {
                ki = new Win32Api.KEYBDINPUT
                {
                    wVk = 0,
                    wScan = c,
                    dwFlags = Win32Api.KEYEVENTF_UNICODE | Win32Api.KEYEVENTF_KEYUP,
                    time = 0,
                    dwExtraInfo = IntPtr.Zero
                }
            }
        };

        Win32Api.SendInput((uint)inputs.Length, inputs, System.Runtime.InteropServices.Marshal.SizeOf(typeof(Win32Api.INPUT)));
    }

    public void SetVolume(int percent)
    {
        Win32Api.SetMasterVolumePercent(percent);
    }

    public void MediaControl(string command)
    {
        var cmd = command.ToLowerInvariant().Trim();

        if (cmd == "mute" || cmd == "volume_mute")
        {
            Win32Api.ToggleMasterMute();
            return;
        }

        if (cmd.StartsWith("volume_") && int.TryParse(cmd.Replace("volume_", ""), out int volVal))
        {
            Win32Api.SetMasterVolumePercent(volVal);
            return;
        }

        byte vk = cmd switch
        {
            "volup" or "volume_up" => Win32Api.VK_VOLUME_UP,
            "voldown" or "volume_down" => Win32Api.VK_VOLUME_DOWN,
            "playpause" or "play_pause" or "play" or "pause" => Win32Api.VK_MEDIA_PLAY_PAUSE,
            "next" or "nexttrack" => Win32Api.VK_MEDIA_NEXT_TRACK,
            "prev" or "prevtrack" => Win32Api.VK_MEDIA_PREV_TRACK,
            "stop" => Win32Api.VK_MEDIA_STOP,
            _ => 0
        };

        if (vk != 0)
        {
            SendVirtualKey(vk, false);
            Thread.Sleep(15);
            SendVirtualKey(vk, true);
        }
    }

    public void ExecuteShortcut(string shortcut)
    {
        // e.g. "ctrl+c", "ctrl+v", "alt+tab", "win+r", "win+d", "alt+f4", "ctrl+shift+esc"
        var parts = shortcut.Split('+', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (parts.Length == 0) return;

        // Modifier-only sequences ("ctrl+ctrl+ctrl") mean N physical presses
        // of that key — some apps/games require toggling a modifier several
        // times. Execute them as sequential down/up cycles.
        bool allModifiers = true;
        foreach (var part in parts)
        {
            if (TryGetVirtualKey(part, out var vkAll) && IsModifierVk(vkAll)) continue;
            allModifiers = false;
            break;
        }
        if (allModifiers)
        {
            foreach (var part in parts)
            {
                if (TryGetVirtualKey(part, out var vkSeq))
                {
                    SendVirtualKey(vkSeq, false);
                    Thread.Sleep(20);
                    SendVirtualKey(vkSeq, true);
                    Thread.Sleep(20);
                }
            }
            return;
        }

        // Mixed combination: hold each modifier once (repeats of the same
        // modifier collapse into a single hold), tap the final key, release.
        var modifiers = new List<byte>();
        for (int i = 0; i < parts.Length - 1; i++)
        {
            if (TryGetVirtualKey(parts[i], out var modVk) && IsModifierVk(modVk))
            {
                if (modifiers.Contains(modVk)) continue;
                SendVirtualKey(modVk, false);
                modifiers.Add(modVk);
            }
        }

        var lastKey = parts[^1];
        if (TryGetVirtualKey(lastKey, out var mainVk))
        {
            if (IsModifierVk(mainVk))
            {
                // Combo ended on a modifier (e.g. "ctrl+shift+ctrl"): tap it.
                SendVirtualKey(mainVk, false);
                Thread.Sleep(25);
                SendVirtualKey(mainVk, true);
            }
            else
            {
                SendVirtualKey(mainVk, false);
                Thread.Sleep(25);
                SendVirtualKey(mainVk, true);
            }
        }

        for (int i = modifiers.Count - 1; i >= 0; i--)
        {
            SendVirtualKey(modifiers[i], true);
        }
    }

    private static bool IsModifierVk(byte vk)
    {
        return vk is Win32Api.VK_SHIFT or Win32Api.VK_CONTROL or Win32Api.VK_MENU or Win32Api.VK_LWIN;
    }

    private static bool TryGetVirtualKey(string key, out byte vk)
    {
        return KeyMap.TryGetValue(key, out vk);
    }

    private static void SendVirtualKey(byte virtualKey, bool keyUp)
    {
        uint flags = keyUp ? Win32Api.KEYEVENTF_KEYUP : 0;
        // Windows treats Win, navigation and consumer/media keys as extended.
        if (virtualKey is Win32Api.VK_LWIN or Win32Api.VK_RWIN or Win32Api.VK_LEFT or Win32Api.VK_RIGHT
            or Win32Api.VK_UP or Win32Api.VK_DOWN or Win32Api.VK_INSERT or Win32Api.VK_DELETE
            or Win32Api.VK_VOLUME_MUTE or Win32Api.VK_VOLUME_DOWN or Win32Api.VK_VOLUME_UP
            or Win32Api.VK_MEDIA_NEXT_TRACK or Win32Api.VK_MEDIA_PREV_TRACK or Win32Api.VK_MEDIA_STOP
            or Win32Api.VK_MEDIA_PLAY_PAUSE)
        {
            flags |= Win32Api.KEYEVENTF_EXTENDEDKEY;
        }

        var inputs = new[]
        {
            new Win32Api.INPUT
            {
                type = Win32Api.INPUT_KEYBOARD,
                u = new Win32Api.INPUTUNION { ki = new Win32Api.KEYBDINPUT { wVk = virtualKey, dwFlags = flags } }
            }
        };
        Win32Api.SendInput(1, inputs, System.Runtime.InteropServices.Marshal.SizeOf<Win32Api.INPUT>());
    }
}
