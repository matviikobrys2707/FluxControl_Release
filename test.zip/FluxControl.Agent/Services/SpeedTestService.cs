using System;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace FluxControl.Agent.Services;

public class SpeedTestResultDto
{
    [JsonPropertyName("downloadMbps")]
    public double? DownloadMbps { get; set; }

    [JsonPropertyName("uploadMbps")]
    public double? UploadMbps { get; set; }

    [JsonPropertyName("pingMs")]
    public double? PingMs { get; set; }

    [JsonPropertyName("timestamp")]
    public long Timestamp { get; set; }

    [JsonPropertyName("running")]
    public bool Running { get; set; }

    [JsonPropertyName("stage")]
    public string Stage { get; set; } = string.Empty;

    [JsonPropertyName("error")]
    public string? Error { get; set; }

    /// <summary>"auto" — запущено автоматично при підключенні, "manual" — користувач натиснув кнопку.</summary>
    [JsonPropertyName("mode")]
    public string Mode { get; set; } = string.Empty;

    /// <summary>Тривалість завершеного тесту, мс (0 поки тест триває).</summary>
    [JsonPropertyName("durationMs")]
    public long DurationMs { get; set; }
}

/// <summary>
/// Lightweight internet speed measurement built on Cloudflare's public speed
/// endpoints. Runs once when the desktop agent starts and afterwards on demand
/// from the web panel ("Запустити Speedtest"). The last result is persisted to
/// %AppData%/FluxControl/speedtest.json so it survives restarts.
/// </summary>
public class SpeedTestService
{
    private const string DownUrl = "https://speed.cloudflare.com/__down?bytes={0}";
    private const string UpUrl = "https://speed.cloudflare.com/__up";
    private static readonly string ResultPath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FluxControl", "speedtest.json");

    private readonly SemaphoreSlim _runLock = new(1, 1);
    private SpeedTestResultDto? _last;
    public event Action<SpeedTestResultDto>? OnResult;

    public SpeedTestService()
    {
        LoadLast();
    }

    public SpeedTestResultDto? Last => _last;

    private void LoadLast()
    {
        try
        {
            if (File.Exists(ResultPath))
            {
                _last = JsonSerializer.Deserialize<SpeedTestResultDto>(File.ReadAllText(ResultPath));
            }
        }
        catch { }
    }

    private void Publish(SpeedTestResultDto result, bool persist)
    {
        _last = result.Running ? _last : result;
        try
        {
            if (persist)
            {
                Directory.CreateDirectory(Path.GetDirectoryName(ResultPath)!);
                File.WriteAllText(ResultPath, JsonSerializer.Serialize(_last, new JsonSerializerOptions { WriteIndented = true }));
            }
        }
        catch { }
        try { OnResult?.Invoke(result); } catch { }
    }

    /// <summary>Runs the full test. Safe to call concurrently — extra callers are dropped.</summary>
    public async Task RunAsync(bool auto = false)
    {
        if (!_runLock.Wait(0)) return;
        long startedAt = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        try
        {
            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(90));
            var ct = cts.Token;
            using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(60) };

            var result = new SpeedTestResultDto
            {
                Running = true,
                Stage = "пінг",
                Timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                // The run mode is recorded on EVERY publish so the web panel can
                // always tell a manual button press from the automatic startup test.
                Mode = auto ? "auto" : "manual"
            };
            Publish(result, persist: false);

            // 1. Latency: a few small probes
            double ping = 0;
            try
            {
                var sw = Stopwatch.StartNew();
                for (int i = 0; i < 6; i++)
                {
                    sw.Restart();
                    await http.GetAsync(string.Format(DownUrl, 10), ct);
                    sw.Stop();
                    ping = i == 0 ? sw.Elapsed.TotalMilliseconds : (ping * i + sw.Elapsed.TotalMilliseconds) / (i + 1);
                }
                result.PingMs = Math.Round(ping, 1);
            }
            catch { }

            // 2. Download: 20 MB in chunks with a 12 s ceiling
            try
            {
                result.Stage = "завантаження";
                Publish(result, persist: false);
                var sw = Stopwatch.StartNew();
                long totalBytes = 0;
                var buffer = new byte[65536];
                await using (var stream = await http.GetStreamAsync(string.Format(DownUrl, 20_000_000), ct))
                {
                    int read;
                    while ((read = await stream.ReadAsync(buffer, ct)) > 0)
                    {
                        totalBytes += read;
                        if (sw.ElapsedMilliseconds > 12000) break;
                    }
                }
                sw.Stop();
                if (totalBytes > 0 && sw.Elapsed.TotalSeconds > 0.3)
                {
                    result.DownloadMbps = Math.Round(totalBytes * 8 / sw.Elapsed.TotalSeconds / 1_000_000, 2);
                }
            }
            catch { }

            // 3. Upload: 8 MB with a 12 s ceiling
            try
            {
                result.Stage = "віддача";
                Publish(result, persist: false);
                var payload = new byte[8_000_000];
                new Random(1234).NextBytes(payload);
                var sw = Stopwatch.StartNew();
                using var content = new ByteArrayContent(payload);
                await http.PostAsync(UpUrl, content, ct);
                sw.Stop();
                if (sw.Elapsed.TotalSeconds > 0.3)
                {
                    result.UploadMbps = Math.Round(payload.Length * 8 / sw.Elapsed.TotalSeconds / 1_000_000, 2);
                }
            }
            catch { }

            result.Running = false;
            result.Stage = string.Empty;
            result.Timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            result.DurationMs = Math.Max(0, result.Timestamp - startedAt);
            if (result.DownloadMbps == null && result.UploadMbps == null && result.PingMs == null)
            {
                result.Error = "Не вдалося виміряти швидкість (немає доступу до тестових серверів).";
            }
            Publish(result, persist: true);
        }
        catch (Exception ex)
        {
            var ts = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            Publish(new SpeedTestResultDto
            {
                Running = false,
                Error = $"Помилка тесту швидкості: {ex.Message}",
                Timestamp = ts,
                DurationMs = Math.Max(0, ts - startedAt),
                Mode = auto ? "auto" : "manual"
            }, persist: true);
        }
        finally
        {
            _runLock.Release();
        }
    }
}
