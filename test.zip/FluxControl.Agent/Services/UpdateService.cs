using System;
using System.Linq;
using System.Net.Http;
using System.IO;
using System.Reflection;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;

namespace FluxControl.Agent.Services;

/// <summary>Результат перевірки оновлень (ТЗ: version.json у репозиторії релізів).</summary>
public sealed class UpdateInfo
{
    public string LocalVersion { get; init; } = "";
    public string LatestVersion { get; init; } = "";
    public string DownloadUrl { get; init; } = "";
    public bool UpdateAvailable { get; init; }
}

/// <summary>Прогрес завантаження архіву.</summary>
public sealed class DownloadProgress
{
    public long ReceivedBytes { get; init; }
    public long TotalBytes { get; init; }
    public double Percent => TotalBytes > 0 ? Math.Min(100d, ReceivedBytes * 100d / TotalBytes) : 0d;
}

/// <summary>
/// Система автоматичних оновлень через GitHub Releases
/// (репозиторій: github.com/matviikobrys2707/FluxControl_Release).
///
/// ТЗ, п.1: локальна версія — з version.txt поруч із exe (фолбек — константа),
/// віддалена — GET raw.githubusercontent.com/.../main/version.json?t={timestamp}
/// (timestamp обходить кеш GitHub). Порівняння — System.Version.
///
/// ТЗ, п.2: завантаження .zip у %TEMP%; HTTP-клієнт ОБОВ'ЯЗКОВО ходить за
/// 302-редиректами, бо GitHub Releases перенаправляє на
/// objects.githubusercontent.com (AllowAutoRedirect = true).
/// </summary>
public static class UpdateService
{
    public const string ReleasesRepoUrl =
        "https://github.com/matviikobrys2707/FluxControl_Release";
    public const string VersionJsonUrl =
        "https://raw.githubusercontent.com/matviikobrys2707/FluxControl_Release/main/version.json";
    public const string LatestReleaseApiUrl =
        "https://api.github.com/repos/matviikobrys2707/FluxControl_Release/releases/latest";

    /// <summary>Константа-фолбек, якщо version.txt відсутній (ТЗ, п.1.1).</summary>
    public const string CurrentVersion = "1.0.0";

    private static readonly HttpClient CheckClient = new(new HttpClientHandler
    {
        // ТЗ: follow redirects — і raw, і api, і release-asset посилання
        AllowAutoRedirect = true
    })
    {
        Timeout = TimeSpan.FromSeconds(12)
    };

    private static readonly HttpClient DownloadClient = new(new HttpClientHandler
    {
        // GitHub Releases -> 302 -> objects.githubusercontent.com
        AllowAutoRedirect = true,
        AutomaticDecompression = System.Net.DecompressionMethods.None
    })
    {
        // Стрім великого архіву: таймаут не обмежуємо, скасування — через CancellationToken.
        Timeout = Timeout.InfiniteTimeSpan
    };

    static UpdateService()
    {
        // raw.githubusercontent.com та api.github.com вимагають User-Agent.
        foreach (var client in new[] { CheckClient, DownloadClient })
        {
            client.DefaultRequestHeaders.UserAgent.ParseAdd("FluxControl-Updater/1.0");
            client.DefaultRequestHeaders.Accept.ParseAdd("*/*");
        }
    }

    /// <summary>
    /// Локальна версія: 1) version.txt поруч із exe (легасі, якщо десь ще лежить),
    /// 2) версія збірки AssemblyInformationalVersion — задається деплой-скриптом
    /// через -p:Version і завжди є всередині самодостатнього EXE, 3) константа.
    /// </summary>
    public static string GetLocalVersion()
    {
        try
        {
            var file = Path.Combine(AppContext.BaseDirectory, "version.txt");
            if (File.Exists(file))
            {
                var v = File.ReadAllText(file).Trim();
                if (!string.IsNullOrEmpty(v)) return v;
            }
        }
        catch { }
        try
        {
            var entry = Assembly.GetEntryAssembly();
            var attr = entry?.GetCustomAttribute<AssemblyInformationalVersionAttribute>();
            var info = attr?.InformationalVersion;
            if (!string.IsNullOrEmpty(info))
            {
                var v = info.Split('+')[0].Trim();
                if (v.Length > 0) return v;
            }
        }
        catch { }
        return CurrentVersion;
    }

    /// <summary>Порівняння версій "1.0.1" / "v1.0.1" — System.Version.</summary>
    public static bool IsNewerVersion(string? remote, string? local)
    {
        remote = remote?.Trim().TrimStart('v', 'V') ?? "";
        local = local?.Trim().TrimStart('v', 'V') ?? "";
        if (!Version.TryParse(remote, out var rv)) return false;
        if (!Version.TryParse(local, out var lv)) return true; // локальну не прочитали — оновлюємось
        return rv > lv;
    }

    /// <summary>
    /// ТЗ, п.1.2-1.3: GET version.json?t={timestamp}; повертає info з прапорцем
    /// UpdateAvailable. null = мережа/формат недоступні (тихий пропуск).
    /// </summary>
    public static async Task<UpdateInfo?> CheckForUpdateAsync()
    {
        try
        {
            var url = VersionJsonUrl + "?t=" + DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            using var resp = await CheckClient.GetAsync(url);
            resp.EnsureSuccessStatusCode();
            var body = await resp.Content.ReadAsStringAsync();
            // захист від BOM, якщо version.json редагували через веб-GitHub
            body = body.TrimStart('\uFEFF');
            var json = JsonSerializer.Deserialize<JsonObject>(body);
            var latest = json?["latest_version"]?.GetValue<string>();
            var download = json?["download_url"]?.GetValue<string>();

            if (string.IsNullOrWhiteSpace(latest) || string.IsNullOrWhiteSpace(download))
            {
                App.Log("Update check: version.json has empty fields");
                return null;
            }

            var local = GetLocalVersion();
            return new UpdateInfo
            {
                LocalVersion = local,
                LatestVersion = latest.Trim(),
                DownloadUrl = download.Trim(),
                UpdateAvailable = IsNewerVersion(latest, local)
            };
        }
        catch (Exception ex)
        {
            App.Log($"Update check failed: {ex.Message}");
            return null;
        }
    }

    /// <summary>
    /// Адреса останнього реліз-асета: спочатку download_url з version.json
    /// (вказує на files/FluxControl.exe у main-гілці), потім — GitHub API
    /// /releases/latest (асет FluxControl.exe релізу — це саме приложение).
    /// </summary>
    public static async Task<string?> GetLatestReleaseZipUrlAsync()
    {
        try
        {
            var info = await CheckForUpdateAsync();
            if (info != null && !string.IsNullOrEmpty(info.DownloadUrl)) return info.DownloadUrl;
        }
        catch { }

        try
        {
            using var resp = await CheckClient.GetAsync(LatestReleaseApiUrl);
            resp.EnsureSuccessStatusCode();
            var body = await resp.Content.ReadAsStringAsync();
            var json = JsonSerializer.Deserialize<JsonObject>(body);
            if (json?["assets"] is JsonArray assets)
            {
                // два проходи: спершу ассет FluxControl.exe (само приложение —
                // єдиний файл релізу), потім будь-який .zip зі старих релізів
                foreach (var preferExe in new[] { true, false })
                {
                    foreach (var asset in assets)
                    {
                        var name = asset?["name"]?.GetValue<string>();
                        var url = asset?["browser_download_url"]?.GetValue<string>();
                        if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(url)) continue;
                        if (preferExe &&
                            name.Equals("FluxControl.exe", StringComparison.OrdinalIgnoreCase))
                        {
                            return url;
                        }
                        if (!preferExe && name.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
                        {
                            return url;
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            App.Log($"GitHub latest-release lookup failed: {ex.Message}");
        }
        return null;
    }

    /// <summary>
    /// ТЗ, п.2: завантаження реліз-асета (самодостатній FluxControl.exe або
    /// zip старого формату) у %TEMP% зі стрімінгом прогресу.
    /// Редиректи проходить автоматично (AllowAutoRedirect = true).
    /// </summary>
    public static async Task<string> DownloadReleaseZipAsync(
        string url, string versionTag, IProgress<DownloadProgress>? progress, CancellationToken ct)
    {
        // raw.githubusercontent.com кешує файли — ?t={timestamp} гарантує свіжий exe
        var busted = url + (url.IndexOf('?') >= 0 ? "&t=" : "?t=") +
            DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        using var resp = await DownloadClient.GetAsync(busted, HttpCompletionOption.ResponseHeadersRead, ct);
        resp.EnsureSuccessStatusCode();

        long total = resp.Content.Headers.ContentLength ?? 0;
        var safeTag = string.Concat(versionTag.Where(char.IsLetterOrDigit)).Replace(" ", "");
        if (safeTag.Length == 0) safeTag = "update";
        // реліз-асет тепер самодостатній EXE; zip — фолбек старих релізів
        var ext = url.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) ? ".exe" : ".zip";
        var tmpPath = Path.Combine(Path.GetTempPath(), $"FluxControl-{safeTag}{ext}");

        await using (var fs = new FileStream(tmpPath, FileMode.Create, FileAccess.Write, FileShare.None, 81920, useAsync: true))
        {
            await using (var net = await resp.Content.ReadAsStreamAsync(ct))
            {
                var buffer = new byte[81920];
                long received = 0;
                int read;
                while ((read = await net.ReadAsync(buffer, ct)) > 0)
                {
                    await fs.WriteAsync(buffer.AsMemory(0, read), ct);
                    received += read;
                    progress?.Report(new DownloadProgress { ReceivedBytes = received, TotalBytes = total });
                }
            }
        }
        App.Log($"Update: downloaded {tmpPath} ({total} bytes)");
        return tmpPath;
    }
}
