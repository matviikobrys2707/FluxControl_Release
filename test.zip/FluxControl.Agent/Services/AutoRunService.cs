using System.Diagnostics;
using Microsoft.Win32;

namespace FluxControl.Agent.Services;

public static class AutoRunService
{
    private const string RunRegistryKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
    private const string AppName = "FluxControl";

    public static bool IsAutoRunEnabled()
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(RunRegistryKey, false);
            var value = key?.GetValue(AppName) as string;
            return !string.IsNullOrEmpty(value);
        }
        catch
        {
            return false;
        }
    }

    public static bool SetAutoRun(bool enable)
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(RunRegistryKey, true);
            if (key == null) return false;

            if (enable)
            {
                var exePath = Environment.ProcessPath ?? Process.GetCurrentProcess().MainModule?.FileName;
                if (string.IsNullOrEmpty(exePath)) return false;

                key.SetValue(AppName, $"\"{exePath}\" --minimized");
            }
            else
            {
                key.DeleteValue(AppName, false);
            }
            return true;
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"Failed to set autorun: {ex.Message}");
            return false;
        }
    }

    public static void EnsureFirstRunAutoRun()
    {
        // If not already configured, set autorun by default on first launch
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(RunRegistryKey, false);
            if (key?.GetValue(AppName) == null)
            {
                SetAutoRun(true);
            }
        }
        catch { }
    }
}
