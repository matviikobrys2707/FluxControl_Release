using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace FluxControl.Agent.Services;
/// <summary>
/// Startup dependency checks. Screen recording and webcam capture require
/// FFmpeg. It is downloaded ONCE and installed into a PERSISTENT location
/// (%AppData%\FluxControl\ffmpeg), so it survives rebuilds, re-extracts and
/// app updates. Every launch validates the existing copy (file exists → the
/// exe actually runs → version readable) and reuses it; a download happens
/// only when nothing valid is found.
/// </summary>
public static class DependencyService
{
    public sealed class DownloadProgress
    {
        public string Stage { get; set; } = "завантаження";
        public long BytesReceived { get; set; }
        public long? TotalBytes { get; set; }
        public int Percent => TotalBytes is > 0 ? (int)Math.Min(100, BytesReceived * 100 / TotalBytes.Value) : 0;
    }

    /// <summary>Persistent install dir: %AppData%\FluxControl\ffmpeg.
    /// Chosen because it is user-writable and lives OUTSIDE the build output
    /// (bin\Release), which is destroyed by rebuilds/re-extracts/updates —
    /// that was the reason FFmpeg used to be downloaded again and again.</summary>
    private static readonly string PersistentDir = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FluxControl", "ffmpeg");

    /// <summary>Where a valid ffmpeg.exe may already live, in priority order.
    /// Locations 2-3 are legacy install spots kept for migration/back-compat.</summary>
    private static readonly string[] FfmpegCandidates =
    {
        Path.Combine(PersistentDir, "ffmpeg.exe"),
        Path.Combine(AppContext.BaseDirectory, "ffmpeg.exe"),
        Path.Combine(AppContext.BaseDirectory, "tools", "ffmpeg.exe")
    };

    private static readonly object Sync = new();
    private static string? _cachedValidPath;
    private static bool _cacheValid;

    public static bool IsFfmpegAvailable() => ResolveFfmpeg() != null;

    /// <summary>Returns a WORKING ffmpeg (file probed with -version), or null.
    /// The validated result is cached for the process lifetime, so repeated
    /// calls (media capture, UI state) never spawn extra processes.</summary>
    public static string? ResolveFfmpeg()
    {
        lock (Sync)
        {
            if (_cacheValid) return _cachedValidPath;
        }
        var found = ResolveCore();
        lock (Sync)
        {
            _cachedValidPath = found;
            _cacheValid = true;
        }
        return found;
    }

    /// <summary>Drops the cached resolution so the next call re-probes the disk.</summary>
    public static void InvalidateCache()
    {
        lock (Sync)
        {
            _cacheValid = false;
            _cachedValidPath = null;
        }
    }

    private static string? ResolveCore()
    {
        App.Log("[FFmpeg] Перевірка встановлення…");

        foreach (var candidate in FfmpegCandidates)
        {
            if (!File.Exists(candidate))
            {
                App.Log($"[FFmpeg] Не знайдено: {candidate}");
                continue;
            }

            var version = ProbeVersion(candidate, timeoutMs: 6000);
            if (version != null)
            {
                App.Log($"[FFmpeg] Знайдено існуючий FFmpeg: {candidate}");
                App.Log($"[FFmpeg] Версія: {version}");
                App.Log("[FFmpeg] Перевірка успішна. Завантаження не потрібне.");
                TryMigrateToPersistentDir(candidate);
                return candidate;
            }

            App.Log($"[FFmpeg] Файл є, але не запускається (пошкоджений або заблокований антивірусом): {candidate}");
            // A broken copy in the persistent dir would block re-installation
            // there later — remove it so the installer can write a fresh one.
            if (candidate.StartsWith(PersistentDir, StringComparison.OrdinalIgnoreCase))
            {
                try { File.Delete(candidate); App.Log("[FFmpeg] Пошкоджений файл видалено з постійної папки."); } catch { }
            }
        }

        // Last resort: an ffmpeg that is already on the system PATH.
        var pathVersion = ProbeVersion("ffmpeg", timeoutMs: 5000);
        if (pathVersion != null)
        {
            App.Log($"[FFmpeg] Використовується системний FFmpeg зі змінної PATH. Версія: {pathVersion}");
            return "ffmpeg";
        }

        App.Log("[FFmpeg] Робочий FFmpeg не знайдено. Потрібна первинна установка.");
        return null;
    }

    /// <summary>Runs "<path> -version" and returns the first output line
    /// (e.g. "ffmpeg version 7.1-essentials_build …") when the binary really
    /// works; null otherwise. Never throws.</summary>
    private static string? ProbeVersion(string exe, int timeoutMs)
    {
        try
        {
            var psi = new ProcessStartInfo
            {
                FileName = exe,
                Arguments = "-version",
                CreateNoWindow = true,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };
            using var process = Process.Start(psi);
            if (process == null) return null;
            // stderr is read async to rule out a pipe-buffer deadlock.
            var stderrTask = process.StandardError.ReadToEndAsync();
            string stdout = process.StandardOutput.ReadToEnd();
            if (!process.WaitForExit(timeoutMs)) { try { process.Kill(true); } catch { } return null; }
            if (process.ExitCode != 0) return null;

            string combined = stdout + stderrTask.GetAwaiter().GetResult();
            if (combined.IndexOf("ffmpeg version", StringComparison.OrdinalIgnoreCase) < 0) return null;

            foreach (var line in combined.Split('\n'))
            {
                var t = line.Trim();
                if (t.Length > 0) return t.Length > 120 ? t[..120] : t;
            }
            return "невідома версія";
        }
        catch { return null; }
    }

    /// <summary>Legacy locations (next to the app) are wiped by rebuilds, so a
    /// working copy found there is quietly duplicated into the persistent dir
    /// — after that, updates/rebuilds can no longer take FFmpeg away.</summary>
    private static void TryMigrateToPersistentDir(string workingPath)
    {
        try
        {
            if (workingPath.StartsWith(PersistentDir, StringComparison.OrdinalIgnoreCase)) return;
            if (!workingPath.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)) return; // "ffmpeg" from PATH — nothing to migrate

            var target = Path.Combine(PersistentDir, "ffmpeg.exe");
            if (File.Exists(target)) return;

            Directory.CreateDirectory(PersistentDir);
            File.Copy(workingPath, target, overwrite: false);
            App.Log($"[FFmpeg] Копію збережено в постійну папку: {target} (переживе пересборку та оновлення програми).");
        }
        catch (Exception ex)
        {
            App.Log($"[WARN] [FFmpeg] Міграція в постійну папку не вдалася (не критично): {ex.Message}");
        }
    }

    /// <summary>
    /// Makes sure a working FFmpeg exists: validates any existing installation
    /// first and returns immediately when it is fine. Downloads the official
    /// build ONLY when nothing valid was found, extracts it into the
    /// persistent dir, validates the result and records version metadata.
    /// Reports stage/percent progress through the callback (background thread).
    /// </summary>
    public static async Task<string?> EnsureFfmpegAsync(Action<DownloadProgress>? progress = null, CancellationToken ct = default)
    {
        var existing = ResolveFfmpeg();
        if (existing != null)
        {
            App.Log("[FFmpeg] Використовується існуюча установка — нічого не завантажуємо.");
            return existing;
        }

        InvalidateCache();
        Report(progress, "перевірка…", 0, null);
        Directory.CreateDirectory(PersistentDir);
        var targetExe = Path.Combine(PersistentDir, "ffmpeg.exe");
        // Stable temp path: a partially downloaded zip survives between
        // attempts and is resumed via HTTP Range, not thrown away.
        var zipPath = Path.Combine(Path.GetTempPath(), "flux_ffmpeg_download.zip");

        try
        {
            using var http = new HttpClient { Timeout = TimeSpan.FromMinutes(15) };
            http.DefaultRequestHeaders.UserAgent.ParseAdd("FluxControl-Agent/1.0");
            string url = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip";
            string? lastError = null;

            for (int attempt = 0; attempt < 2; attempt++)
            {
                try
                {
                    App.Log($"[FFmpeg] Первинна установка: завантаження {url} (спроба {attempt + 1}/2)…");
                    await DownloadWithResumeAsync(http, url, zipPath, progress, ct);
                    App.Log("[FFmpeg] Завантаження завершено.");

                    Report(progress, "розпакування…", 0, null);
                    App.Log("[FFmpeg] Розпакування…");
                    using (var archive = ZipFile.OpenRead(zipPath))
                    {
                        // Prefer the packaged bin/ffmpeg.exe, fall back to any
                        // ffmpeg.exe entry inside the archive.
                        var entry = archive.Entries.FirstOrDefault(e =>
                            e.FullName.EndsWith("ffmpeg.exe", StringComparison.OrdinalIgnoreCase) &&
                            e.FullName.Contains("/bin/", StringComparison.OrdinalIgnoreCase))
                            ?? archive.Entries.FirstOrDefault(e => e.FullName.EndsWith("ffmpeg.exe", StringComparison.OrdinalIgnoreCase));
                        if (entry == null) throw new InvalidOperationException("ffmpeg.exe не знайдено в архіві");
                        entry.ExtractToFile(targetExe, overwrite: true);
                    }

                    // Never trust a fresh file blindly: prove it runs before
                    // telling the user the install succeeded.
                    var version = ProbeVersion(targetExe, timeoutMs: 8000);
                    if (version == null)
                    {
                        try { File.Delete(targetExe); } catch { }
                        throw new InvalidOperationException("встановлений файл не пройшов перевірку запуском (можливо, його заблокував антивірус)");
                    }

                    App.Log($"[FFmpeg] Версія: {version}");
                    App.Log("[FFmpeg] Перевірка успішна. Встановлення збережено в постійну папку.");
                    WriteInstallMeta(version);
                    InvalidateCache();
                    return targetExe;
                }
                catch (Exception ex)
                {
                    lastError = ex.Message;
                    App.Log($"[FFmpeg] Спроба {attempt + 1} не вдалася: {ex.Message}");
                    // A corrupt partial file must not poison the next attempt/mirror.
                    try { if (File.Exists(zipPath)) File.Delete(zipPath); } catch { }
                    // Secondary mirror: BtbN automated builds
                    url = "https://github.com/BtbN/FFmpeg-Builds/releases/latest/download/ffmpeg-master-latest-win64-gpl.zip";
                }
            }

            throw new InvalidOperationException(lastError ?? "не вдалося завантажити FFmpeg");
        }
        finally
        {
            try { if (File.Exists(zipPath)) File.Delete(zipPath); } catch { }
        }
    }

    /// <summary>Small diagnostics marker next to the installed exe.</summary>
    private static void WriteInstallMeta(string version)
    {
        try
        {
            var meta = Path.Combine(PersistentDir, "ffmpeg.json");
            File.WriteAllText(meta, $"{{\"version\":\"{version.Replace("\"", "'")}\",\"installedAt\":\"{DateTime.Now:yyyy-MM-dd HH:mm:ss}\"}}");
        }
        catch { }
    }

    /// <summary>
    /// Streams the archive to disk with HTTP Range resume support. Existing
    /// partial data is kept when the server answers 206; otherwise the file
    /// restarts. Progress reports include live download speed.
    /// </summary>
    private static async Task DownloadWithResumeAsync(HttpClient http, string url, string zipPath, Action<DownloadProgress>? progress, CancellationToken ct)
    {
        long existingBytes = 0;
        try { if (File.Exists(zipPath)) existingBytes = new FileInfo(zipPath).Length; } catch { }

        using var request = new HttpRequestMessage(HttpMethod.Get, url);
        if (existingBytes > 0)
        {
            request.Headers.Range = new System.Net.Http.Headers.RangeHeaderValue(existingBytes, null);
            Report(progress, "продовження завантаження…", existingBytes, null);
        }
        else
        {
            Report(progress, "завантаження…", 0, null);
        }

        using var response = await http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);
        response.EnsureSuccessStatusCode();

        bool resumed = existingBytes > 0 &&
                       response.StatusCode == System.Net.HttpStatusCode.PartialContent;
        long startOffset = resumed ? existingBytes : 0;
        long? total = null;
        if (response.Content.Headers.ContentLength.HasValue)
        {
            long remaining = response.Content.Headers.ContentLength.Value;
            total = startOffset + remaining;
        }

        await using var source = await response.Content.ReadAsStreamAsync(ct);
        await using var file = new FileStream(
            zipPath, resumed ? FileMode.Append : FileMode.Create, FileAccess.Write, FileShare.None, 81920, useAsync: true);

        var buffer = new byte[81920];
        long received = startOffset;
        int read;
        var lastReport = DateTime.UtcNow;
        long lastReportBytes = received;
        var sw = System.Diagnostics.Stopwatch.StartNew();

        while ((read = await source.ReadAsync(buffer, ct)) > 0)
        {
            await file.WriteAsync(buffer.AsMemory(0, read), ct);
            received += read;
            var sinceReport = (DateTime.UtcNow - lastReport).TotalMilliseconds;
            if (sinceReport > 300)
            {
                lastReport = DateTime.UtcNow;
                long delta = Math.Max(0, received - lastReportBytes);
                lastReportBytes = received;
                double bps = delta / Math.Max(0.05, sinceReport / 1000.0);
                string speed = bps > 0 ? $" {FormatSpeed(bps)}" : string.Empty;
                Report(progress, $"завантаження…{speed}", received, total);
            }
        }

        sw.Stop();
        if (total.HasValue && received < total.Value - 1024)
        {
            throw new IOException($"завантаження перервано: {received}/{total.Value} байт");
        }
    }

    private static string FormatSpeed(double bytesPerSecond)
    {
        return bytesPerSecond >= 1024 * 1024
            ? $"{bytesPerSecond / 1024 / 1024:F1} МБ/с"
            : $"{bytesPerSecond / 1024:F0} КБ/с";
    }

    private static void Report(Action<DownloadProgress>? progress, string stage, long received, long? total)
    {
        try { progress?.Invoke(new DownloadProgress { Stage = stage, BytesReceived = received, TotalBytes = total }); } catch { }
    }
}
