using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading.Tasks;

namespace FluxControl.Agent.Services;

public class FileItem
{
    public string Name { get; set; } = string.Empty;
    public string Path { get; set; } = string.Empty;
    public bool IsDirectory { get; set; }
    public long Size { get; set; }
    public DateTime LastModified { get; set; }
    public string Extension { get; set; } = string.Empty;
    public bool IsHidden { get; set; }
}

public class DirectoryContentResult
{
    public string CurrentPath { get; set; } = string.Empty;
    public string? ParentPath { get; set; }
    public List<FileItem> Items { get; set; } = new();
}

public class FileManagerService
{
    public List<DiskInfo> GetDrives()
    {
        var list = new List<DiskInfo>();
        foreach (var drive in DriveInfo.GetDrives())
        {
            if (drive.IsReady)
            {
                var total = drive.TotalSize / (1024.0 * 1024.0 * 1024.0);
                var free = drive.AvailableFreeSpace / (1024.0 * 1024.0 * 1024.0);
                var used = total - free;
                list.Add(new DiskInfo
                {
                    Name = drive.Name,
                    Label = string.IsNullOrWhiteSpace(drive.VolumeLabel) ? "Локальний диск" : drive.VolumeLabel,
                    TotalGb = Math.Round(total, 2),
                    FreeGb = Math.Round(free, 2),
                    UsedGb = Math.Round(used, 2),
                    PercentUsed = total > 0 ? (int)Math.Round((used / total) * 100) : 0
                });
            }
        }
        return list;
    }

    public DirectoryContentResult ListDirectory(string path)
    {
        if (string.IsNullOrWhiteSpace(path))
        {
            var firstDrive = DriveInfo.GetDrives().FirstOrDefault(d => d.IsReady);
            path = firstDrive?.Name ?? Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        }

        var dirInfo = new DirectoryInfo(path);
        if (!dirInfo.Exists)
        {
            throw new DirectoryNotFoundException($"Папку '{path}' не знайдено.");
        }

        var result = new DirectoryContentResult
        {
            CurrentPath = dirInfo.FullName,
            ParentPath = dirInfo.Parent?.FullName
        };

        try
        {
            foreach (var dir in dirInfo.GetDirectories())
            {
                bool isHidden = (dir.Attributes & FileAttributes.Hidden) != 0;
                result.Items.Add(new FileItem
                {
                    Name = dir.Name,
                    Path = dir.FullName,
                    IsDirectory = true,
                    Size = 0,
                    LastModified = dir.LastWriteTime,
                    Extension = "",
                    IsHidden = isHidden
                });
            }
        }
        catch { }

        try
        {
            foreach (var file in dirInfo.GetFiles())
            {
                bool isHidden = (file.Attributes & FileAttributes.Hidden) != 0;
                result.Items.Add(new FileItem
                {
                    Name = file.Name,
                    Path = file.FullName,
                    IsDirectory = false,
                    Size = file.Length,
                    LastModified = file.LastWriteTime,
                    Extension = file.Extension.TrimStart('.').ToLowerInvariant(),
                    IsHidden = isHidden
                });
            }
        }
        catch { }

        result.Items = result.Items
            .OrderByDescending(i => i.IsDirectory)
            .ThenBy(i => i.Name)
            .ToList();

        return result;
    }

    public string ReadFileContent(string path)
    {
        if (!File.Exists(path))
        {
            throw new FileNotFoundException("Файл не знайдено.", path);
        }
        return File.ReadAllText(path);
    }

    public void SaveFileContent(string path, string content)
    {
        var dir = Path.GetDirectoryName(path);
        if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
        {
            Directory.CreateDirectory(dir);
        }
        File.WriteAllText(path, content);
        InvalidateFolderSize(Path.GetDirectoryName(path));
    }

    public bool DeleteItem(string path)
    {
        if (File.Exists(path))
        {
            File.Delete(path);
            InvalidateFolderSize(Path.GetDirectoryName(path));
            return true;
        }

        if (Directory.Exists(path))
        {
            Directory.Delete(path, recursive: true);
            InvalidateFolderSize(Path.GetDirectoryName(path));
            return true;
        }

        throw new FileNotFoundException("Файл або папку не знайдено.");
    }

    private readonly System.Collections.Concurrent.ConcurrentDictionary<string, (long size, DateTime timestamp)> _folderSizeCache = new();

    public long GetDirectorySize(string path)
    {
        if (string.IsNullOrWhiteSpace(path) || !Directory.Exists(path)) return 0;
        if (_folderSizeCache.TryGetValue(path, out var cached) && (DateTime.UtcNow - cached.timestamp).TotalMinutes < 5)
        {
            return cached.size;
        }

        long totalSize = 0;
        try
        {
            var dirInfo = new DirectoryInfo(path);
            // Deliberately run in the request's background task. A depth cap makes
            // Explorer report incorrect values for ordinary nested directories.
            totalSize = CalculateDirSizeSafe(dirInfo);
            _folderSizeCache[path] = (totalSize, DateTime.UtcNow);
        }
        catch { }

        return totalSize;
    }

    private static long CalculateDirSizeSafe(DirectoryInfo dir)
    {
        long size = 0;
        try
        {
            foreach (var file in dir.EnumerateFiles())
            {
                try { size += file.Length; } catch { }
            }
            foreach (var subDir in dir.EnumerateDirectories())
            {
                try
                {
                    if ((subDir.Attributes & FileAttributes.ReparsePoint) == 0)
                    {
                        size += CalculateDirSizeSafe(subDir);
                    }
                }
                catch { }
            }
        }
        catch { }
        return size;
    }

    public string CreateZipArchive(string directoryPath)
    {
        if (!Directory.Exists(directoryPath))
        {
            throw new DirectoryNotFoundException($"Папка '{directoryPath}' не існує.");
        }

        var dirName = new DirectoryInfo(directoryPath).Name;
        var tempZip = Path.Combine(Path.GetTempPath(), $"{dirName}_{Guid.NewGuid():N}.zip");
        ZipFile.CreateFromDirectory(directoryPath, tempZip, CompressionLevel.Fastest, includeBaseDirectory: false);
        return tempZip;
    }

    public bool CreateNewFile(string parentDir, string fileName)
    {
        if (!Directory.Exists(parentDir)) Directory.CreateDirectory(parentDir);
        var target = Path.Combine(parentDir, fileName);
        if (!File.Exists(target))
        {
            File.WriteAllText(target, "");
            InvalidateFolderSize(parentDir);
            return true;
        }
        return true;
    }

    public bool CreateNewFolder(string parentDir, string folderName)
    {
        if (!Directory.Exists(parentDir)) Directory.CreateDirectory(parentDir);
        var target = Path.Combine(parentDir, folderName);
        Directory.CreateDirectory(target);
        InvalidateFolderSize(parentDir);
        return true;
    }

    public async Task<string> SaveAndProcessUploadAsync(string targetDir, string fileName, Stream fileStream)
    {
        if (!Directory.Exists(targetDir))
        {
            Directory.CreateDirectory(targetDir);
        }

        var destinationPath = Path.Combine(targetDir, fileName);

        await using (var output = File.Create(destinationPath))
        {
            await fileStream.CopyToAsync(output);
        }

        if (fileName.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
        {
            try
            {
                ZipFile.ExtractToDirectory(destinationPath, targetDir, overwriteFiles: true);
                File.Delete(destinationPath);
                return $"ZIP-архів розархівовано в '{targetDir}'.";
            }
            catch (Exception ex)
            {
                return $"Завантажено, але помилка розархівації: {ex.Message}";
            }
        }

        return $"Файл '{fileName}' успішно завантажено!";
    }

    public bool RenameItem(string oldPath, string newName)
    {
        if (string.IsNullOrWhiteSpace(oldPath) || string.IsNullOrWhiteSpace(newName)) return false;

        var dir = Path.GetDirectoryName(oldPath);
        if (string.IsNullOrWhiteSpace(dir)) return false;

        var newPath = Path.Combine(dir, newName);

        if (File.Exists(oldPath))
        {
            File.Move(oldPath, newPath, overwrite: true);
            InvalidateFolderSize(dir);
            return true;
        }

        if (Directory.Exists(oldPath))
        {
            Directory.Move(oldPath, newPath);
            InvalidateFolderSize(dir);
            return true;
        }

        throw new FileNotFoundException("Елемент для перейменування не знайдено.");
    }

    private void InvalidateFolderSize(string? changedDirectory)
    {
        if (string.IsNullOrWhiteSpace(changedDirectory)) return;
        foreach (var key in _folderSizeCache.Keys)
        {
            if (key.StartsWith(changedDirectory, StringComparison.OrdinalIgnoreCase) ||
                changedDirectory.StartsWith(key, StringComparison.OrdinalIgnoreCase))
            {
                _folderSizeCache.TryRemove(key, out _);
            }
        }
    }
}
