# FluxControl Relay Server (Render.com Deployment)

Легкий та швидкий ретранслятор для віддаленого керування ПК (FluxControl) без необхідності використання Cloudflare тунелів.

---

## 🚀 Як розгорнути на Render.com за 2 хвилини (Безкоштовно)

1. Завантажте папку `FluxControl.Server` до вашого GitHub репозиторію (або створи окремий репозиторій `fluxcontrol-server`).
2. Перейдіть на [dashboard.render.com](https://dashboard.render.com/) та натисніть **New +** -> **Web Service**.
3. Виберіть ваш GitHub репозиторій.
4. Вкажіть наступні налаштування:
   - **Name**: `fluxcontrol-backend` (або будь-яке інше бажане ім'я)
   - **Runtime**: `Node`
   - **Build Command**: `npm install`
   - **Start Command**: `node server.js`
   - **Instance Type**: `Free`
5. Натисніть **Deploy Web Service**.
6. Render видасть вам постійний HTTPS/WSS домен, наприклад:
   `https://fluxcontrol-backend.onrender.com`

---

## 🔌 Ендпоінти

- `GET /` — Перевірка працездатності та статус активних кімнат
- `GET /health` — Статус 200 OK для моніторингу
- `GET /api/resolve?code=A1B2-C3D4` — Перевірка онлайну та адреси комп'ютера
- `POST /api/register` — Реєстрація ПК в базі
- `WebSocket /ws` — Двостороннє потокове з'єднання:
  - Для ПК: `wss://<домен>/ws?role=agent&code=A1B2-C3D4`
  - Для Телефону: `wss://<домен>/ws?role=client&code=A1B2-C3D4`

---

## 💡 Особливість для безкоштовного тарифу Render
Сервер має вбудований Keep-Alive ping кожні 20 секунд. Поки агент на ПК або телефон підключені до сокету, сервер **ніколи не засне**!

