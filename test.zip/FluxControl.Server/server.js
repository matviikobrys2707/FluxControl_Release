/**
 * FluxControl Render Backend Server
 * Integrated with Cloudflare D1 Database (Single Source of Truth),
 * High-speed WebSocket Relay with Instant Disconnect Handling, HWID/Code DB,
 * License Keys, Subscriptions, Admin API, and Web-Device OAuth.
 */

const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const app = express();

app.use(cors());
// ВАЖЛИВО: AI-зріс надсилає скриншоти екрана в base64 (сотні КБ на кадр).
// Дефолтний ліміт express.json() — 100KB, через що будь-який запит зі
// скриншотом падав із HTTP 413 Payload Too Large («Помилка з’єднання» у чаті).
app.use(express.json({ limit: '30mb' }));
app.use(express.urlencoded({ extended: true, limit: '30mb' }));

// Cloudflare D1 Credentials
const CLOUDFLARE_D1_CONFIG = {
  accountId: '959f0a3b73e2617a7204d8f6dc1dc8aa',
  databaseId: '7c290aee-b48e-463d-8b97-d8d571c2d986',
  authToken: 'cfut_jgPntIOZrQEpH6ZDcC3ilNnSJw7hF43tvEhHWLBO3f856805',
  endpoint: 'https://api.cloudflare.com/client/v4/accounts/959f0a3b73e2617a7204d8f6dc1dc8aa/d1/database/7c290aee-b48e-463d-8b97-d8d571c2d986/query'
};

async function queryD1(sql, params = []) {
  try {
    const postData = JSON.stringify({ sql, params });
    const response = await fetch(CLOUDFLARE_D1_CONFIG.endpoint, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${CLOUDFLARE_D1_CONFIG.authToken}`,
        'Content-Type': 'application/json'
      },
      body: postData
    });
    const data = await response.json();
    if (!data.success) {
      console.error('[D1 Error]', data.errors);
      return [];
    }
    return data.result?.[0]?.results || [];
  } catch (e) {
    console.error('[D1 Query Error]', e.message);
    return [];
  }
}

// In-memory fast cache
const usersDb = new Map();
const computersDb = new Map();
const userComputersDb = new Map();
// Персональні назви ПК (custom_name). Ключ `${userId}||${computerId}`.
// БЕЗ ЦЬОГО була публічна помилка: користувач перейменовував ПК, за секунди
// назва поверталася — GET /api/devices віддавав hostname з таблиці computers,
// який агент перезаписує при кожному heartbeat/register, а custom_name з
// users_computers не застосовувався. Тепер custom_name ПЕРЕМОЖЄ hostname.
const userCustomNames = new Map();
const licenseKeysDb = new Map();
const authSessionsDb = new Map();
const webClients = new Map();
const AGENT_HEARTBEAT_INTERVAL_MS = 4000;
const AGENT_STALE_AFTER_MS = 12000;

// Персональна назва ПК (custom_name) з кешу або D1.
async function getCustomName(userId, computerId) {
  const key = `${userId}||${computerId}`;
  if (userCustomNames.has(key)) return userCustomNames.get(key);
  let name = null;
  try {
    const nm = await queryD1(`SELECT custom_name FROM users_computers WHERE user_id = ? AND computer_id = ? LIMIT 1;`, [userId, computerId]);
    name = nm?.[0]?.custom_name || null;
  } catch {}
  userCustomNames.set(key, name);
  return name;
}

// Admin guard: якщо запит передає x-fc-user-id — перевіряємо, що це адмін.
// Відсутній заголовок (старі клієнти) — пропускаємо для зворотної сумісності.
function isAdminRequest(req) {
  const uid = String(req.headers['x-fc-user-id'] || '').trim();
  if (!uid) return true;
  const u = usersDb.get(uid);
  return Boolean(u && (u.role === 'admin' || (u.email || '').includes('blazix')));
}

function adminGuard(req, res) {
  if (!isAdminRequest(req)) {
    res.status(403).json({ success: false, error: 'Тільки для адміністраторів' });
    return false;
  }
  return true;
}

// Runtime reachability belongs to the relay, not D1. D1 contains device
// metadata and survives restarts, but it cannot know whether an agent socket
// is answering right now.
function isComputerOnline(comp, now = Date.now()) {
  return Boolean(comp && now - Number(comp.lastSeen || 0) <= AGENT_STALE_AFTER_MS);
}

function uniqueComputers() {
  return Array.from(new Set(computersDb.values()));
}

// Helper to generate key: FC-XXXX-XXXX-XXXX-XXXX
function generateLicenseKeyCode() {
  const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
  const getChunk = (len) => {
    let res = '';
    for (let i = 0; i < len; i++) {
      res += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return res;
  };
  return `FC-${getChunk(4)}-${getChunk(4)}-${getChunk(4)}-${getChunk(4)}`;
}

// Convert duration string to milliseconds
function getDurationMs(type) {
  switch (type) {
    case '1m': return 60 * 1000;
    case '5m': return 5 * 60 * 1000;
    case '1h': return 60 * 60 * 1000;
    case '1d': return 24 * 60 * 60 * 1000;
    case '7d': return 7 * 24 * 60 * 60 * 1000;
    case '30d': return 30 * 24 * 60 * 60 * 1000;
    case '90d': return 90 * 24 * 60 * 60 * 1000;
    case '1y': return 365 * 24 * 60 * 60 * 1000;
    case 'lifetime': return 0;
    default: return 30 * 24 * 60 * 60 * 1000;
  }
}

// Initialize and sync cache from Cloudflare D1
async function syncFromCloudflareD1() {
  console.log('[D1] Syncing cache from Cloudflare D1 Database...');
  try {
    const users = await queryD1('SELECT * FROM users;');
    for (const u of users) {
      usersDb.set(u.id, {
        id: u.id,
        email: u.email,
        name: u.name,
        picture: u.picture,
        role: u.role || 'user',
        subscriptionExpiresAt: u.subscription_expires_at,
        // access_enabled: 1 = повний доступ, 0 = заблокований (нові акаунти).
        // undefined/null у старих записах трактується як доступ відкрито.
        accessEnabled: u.access_enabled === 0 ? false : true,
        createdAt: u.created_at
      });
    }

    const keys = await queryD1('SELECT * FROM license_keys;');
    for (const k of keys) {
      const keyObj = {
        id: k.id,
        keyCode: k.key,
        key: k.key,
        durationType: k.type,
        durationMs: k.duration_ms,
        createdAt: k.created_at,
        expiresAt: k.expires_at,
        isUsed: Boolean(k.used),
        used: Boolean(k.used),
        usedBy: k.used_by_user_id,
        usedByEmail: k.used_by_user_name,
        usedAt: k.used_at
      };
      licenseKeysDb.set(k.id, keyObj);
      licenseKeysDb.set(k.key, keyObj);
    }

    const comps = await queryD1('SELECT * FROM computers;');
    for (const c of comps) {
      // Mutate an existing live record instead of replacing it. Replacing this
      // object used to discard agentWs/lastSeen every 30 seconds while the
      // original WebSocket closure kept forwarding commands.
      const compObj = computersDb.get(c.id) || computersDb.get(c.hwid) || computersDb.get(c.code) || {};
      Object.assign(compObj, {
        id: c.id,
        hwid: c.hwid || c.id,
        code: c.code,
        connection_code: c.code,
        name: c.name,
        os: c.os_info,
        cpu: c.cpu_info,
        gpu: c.gpu,
        ram: c.ram_info,
        activeUrl: c.active_url,
        localUrl: c.local_url,
        status: c.status || 'offline',
        // A current socket's heartbeat is always newer and authoritative.
        lastSeen: compObj.lastSeen || (c.last_seen ? new Date(c.last_seen).getTime() : 0),
        isOnline: isComputerOnline(compObj)
      });
      computersDb.set(c.id, compObj);
      if (c.code) computersDb.set(c.code, compObj);
    }

    const links = await queryD1('SELECT * FROM users_computers;');
    for (const l of links) {
      const userList = userComputersDb.get(l.user_id) || [];
      if (!userList.includes(l.computer_id)) {
        userList.push(l.computer_id);
      }
      userComputersDb.set(l.user_id, userList);
    }

    console.log(`[D1] Cache primed: ${users.length} users, ${keys.length} keys, ${comps.length} computers.`);
  } catch (e) {
    console.error('[D1] Sync error:', e.message);
  }
}

// Background sync every 30 seconds
setInterval(syncFromCloudflareD1, 30000);
syncFromCloudflareD1();

app.get('/', (req, res) => {
  res.json({
    service: 'FluxControl Relay Backend',
    status: 'online',
    version: '5.7.0',
    ai: true,
    database: 'Cloudflare D1 SQL (fluxcontrol)',
    users: usersDb.size,
    computers: computersDb.size,
    keys: licenseKeysDb.size,
    uptime: Math.floor(process.uptime())
  });
});

app.get('/health', (req, res) => res.status(200).send('OK'));

// 1. Auth Endpoint: Google & Email login (GET & POST)
app.get(['/api/auth/profile', '/api/auth/google'], async (req, res) => {
  const userId = req.query.id || req.query.userId;
  const email = (req.query.email || '').trim().toLowerCase();

  let user = null;
  if (userId) user = usersDb.get(userId);
  if (!user && email) {
    for (const u of usersDb.values()) {
      if (u.email === email) {
        user = u;
        break;
      }
    }
  }

  if (!user && (userId || email)) {
    const rows = await queryD1('SELECT * FROM users WHERE id = ? OR email = ? LIMIT 1;', [userId || '', email || '']);
    if (rows && rows.length > 0) {
      const u = rows[0];
      user = {
        id: u.id,
        uid: u.id,
        email: u.email,
        name: u.name,
        displayName: u.name,
        picture: u.picture,
        photoURL: u.picture,
        role: u.role || 'user',
        subscriptionExpiresAt: u.subscription_expires_at,
        accessEnabled: u.access_enabled === 0 ? false : true,
        createdAt: u.created_at
      };
      usersDb.set(u.id, user);
    }
  }

  if (!user) {
    return res.status(404).json({ success: false, error: 'User not found' });
  }

  res.json({ success: true, user });
});

app.post(['/api/auth/google', '/api/auth/profile'], async (req, res) => {
  const body = req.body || {};
  const u = body.user || body;
  const uid = String(u.sub || u.id || u.uid || '').trim();
  const email = String(u.email || '').trim().toLowerCase();

  if (!uid && !email) {
    return res.status(400).json({ error: 'User ID or Email missing' });
  }

  const finalId = uid || `usr_${Buffer.from(email).toString('hex').slice(0, 16)}`;
  let existingUser = usersDb.get(finalId);

  if (!existingUser && email) {
    for (const usr of usersDb.values()) {
      if (usr.email === email) {
        existingUser = usr;
        break;
      }
    }
  }

  // Determine initial role: if blazix or admin@, grant admin
  let defaultRole = 'user';
  if (usersDb.size === 0 || email.includes('blazix') || email.includes('admin@')) {
    defaultRole = 'admin';
  }

  const role = existingUser?.role || (u.role || defaultRole);
  const subscriptionExpiresAt = role === 'admin' 
    ? -1 
    : (existingUser?.subscriptionExpiresAt !== undefined && existingUser?.subscriptionExpiresAt !== null
        ? existingUser.subscriptionExpiresAt 
        : (u.subscriptionExpiresAt !== undefined ? u.subscriptionExpiresAt : null));

  // НОВІ акаунти починають заблокованими: функціонал сайту відкривається
  // адміністратором або активацією ключа доступу. Існуючі користувачі
  // (existingUser) зберігають свій попередній стан.
  const accessEnabled = existingUser
    ? (existingUser.accessEnabled !== false)
    : (role === 'admin' ? true : false);

  const userData = {
    id: existingUser ? existingUser.id : finalId,
    uid: existingUser ? existingUser.id : finalId,
    email: email || (existingUser ? existingUser.email : ''),
    name: u.name || u.displayName || (existingUser ? existingUser.name : (email ? email.split('@')[0] : 'Користувач')),
    displayName: u.name || u.displayName || (existingUser ? existingUser.name : 'Користувач'),
    picture: u.picture || u.photoURL || (existingUser ? existingUser.picture : ''),
    photoURL: u.picture || u.photoURL || (existingUser ? existingUser.picture : ''),
    role,
    subscriptionExpiresAt,
    accessEnabled,
    updatedAt: Date.now(),
    createdAt: existingUser ? existingUser.createdAt : Date.now()
  };

  usersDb.set(userData.id, userData);

  // Write to Cloudflare D1 (access_enabled оновлюємо лише для нових записів,
  // щоб повторні логіни не перетирали рішення адміністратора)
  queryD1(`
    INSERT INTO users (id, email, name, picture, role, subscription_expires_at, access_enabled)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      email=excluded.email,
      name=excluded.name,
      picture=excluded.picture,
      role=COALESCE(users.role, excluded.role),
      subscription_expires_at=COALESCE(users.subscription_expires_at, excluded.subscription_expires_at);
  `, [userData.id, userData.email, userData.name, userData.picture, userData.role, userData.subscriptionExpiresAt, userData.accessEnabled ? 1 : 0]);

  console.log(`[AUTH] User verified: ${userData.email || userData.id} (Role: ${userData.role})`);
  res.json({ success: true, user: userData });
});

// 2. Register Computer from Desktop Agent
app.post(['/api/register', '/api/agent/register'], async (req, res) => {
  const body = req.body || {};
  const hwid = String(body.hwid || body.id || '').trim();
  const code = String(body.code || '').replace(/[^A-Za-z0-9]/g, '').trim().toUpperCase();
  const name = String(body.name || body.machineName || 'Мій ПК').trim();
  const username = String(body.username || '').trim();
  const os = String(body.os || body.osInfo || 'Windows').trim();
  const cpu = String(body.cpu || body.cpuInfo || 'CPU').trim();
  const ram = String(body.ram || body.ramInfo || '').trim();
  const gpu = String(body.gpu || body.gpuInfo || '').trim();
  const localUrl = String(body.localUrl || '').trim();
  const activeUrl = String(body.activeUrl || body.publicUrl || '').trim();

  if (!hwid && !code) {
    return res.status(400).json({ error: 'HWID or code required' });
  }

  const primaryKey = hwid || `hwid_${code}`;
  const existing = computersDb.get(primaryKey) || {};

  const compData = existing;
  Object.assign(compData, {
    id: primaryKey,
    hwid: primaryKey,
    connection_code: code || existing.connection_code,
    code: code || existing.code,
    name: name || existing.name,
    username: username || existing.username,
    os: os || existing.os,
    cpu: cpu || existing.cpu,
    ram: ram || existing.ram,
    gpu: gpu || existing.gpu,
    localUrl: localUrl || existing.localUrl,
    activeUrl: activeUrl || existing.activeUrl,
    lastSeen: Date.now(),
    isOnline: isComputerOnline(existing)
  });

  computersDb.set(primaryKey, compData);
  if (code) {
    computersDb.set(code, compData);
  }

  // Save to Cloudflare D1
  queryD1(`
    INSERT INTO computers (id, hwid, code, name, os_info, cpu_info, gpu, ram_info, status, active_url, local_url, last_seen)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'online', ?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(id) DO UPDATE SET
      code=excluded.code,
      name=excluded.name,
      os_info=excluded.os_info,
      cpu_info=excluded.cpu_info,
      gpu=excluded.gpu,
      ram_info=excluded.ram_info,
      status='online',
      active_url=excluded.active_url,
      local_url=excluded.local_url,
      last_seen=CURRENT_TIMESTAMP;
  `, [compData.hwid, compData.hwid, compData.code, compData.name, compData.os, compData.cpu, compData.gpu, compData.ram, compData.activeUrl, compData.localUrl]);

  res.json({ success: true, hwid: primaryKey, code });
});

// 3. Verify 16-character connection code
app.get('/api/devices/verify-code', async (req, res) => {
  const rawCode = String(req.query.code || '').replace(/[^A-Za-z0-9]/g, '').trim().toUpperCase();
  if (!rawCode) {
    return res.status(400).json({ success: false, message: 'Введіть код підключення' });
  }

  let found = computersDb.get(rawCode);
  if (!found) {
    for (const comp of computersDb.values()) {
      const c1 = String(comp.connection_code || '').toUpperCase();
      const c2 = String(comp.code || '').toUpperCase();
      const c3 = String(comp.hwid || '').toUpperCase();
      if (c1 === rawCode || c2 === rawCode || c3 === rawCode) {
        found = comp;
        break;
      }
    }
  }

  // If not in cache, check Cloudflare D1 directly
  if (!found) {
    const rows = await queryD1(`SELECT * FROM computers WHERE code = ? OR hwid = ? OR id = ?;`, [rawCode, rawCode, rawCode]);
    if (rows && rows.length > 0) {
      const c = rows[0];
      found = {
        id: c.id,
        hwid: c.hwid || c.id,
        code: c.code,
        connection_code: c.code,
        name: c.name,
        os: c.os_info,
        cpu: c.cpu_info,
        gpu: c.gpu,
        ram: c.ram_info,
        activeUrl: c.active_url,
        localUrl: c.local_url,
        status: c.status || 'offline',
        lastSeen: c.last_seen ? new Date(c.last_seen).getTime() : 0,
        isOnline: false
      };
      computersDb.set(c.id, found);
      if (c.code) computersDb.set(c.code, found);
    }
  }

  if (!found) {
    return res.status(404).json({
      success: false,
      message: 'Комп\'ютер з таким кодом не знайдено в базі даних'
    });
  }

  const isOnline = isComputerOnline(found);

  res.json({
    success: true,
    data: {
      hwid: found.hwid || rawCode,
      code: found.connection_code || found.code || rawCode,
      name: found.name || 'Мій ПК',
      os: found.os || 'Windows',
      cpu: found.cpu || 'Невідомий процесор',
      gpu: found.gpu || 'Невідома відеокарта',
      ram: found.ram || '8 GB',
      isOnline
    }
  });
});

// 4. Link Computer to User
app.post(['/api/user/computers/link', '/api/devices'], async (req, res) => {
  const { userId, hwid, code, computerId, connectionCode, customName, name } = req.body || {};
  const finalUserId = userId;
  const targetId = hwid || computerId || code || connectionCode;
  const finalName = customName || name;

  if (!finalUserId || !targetId) {
    return res.status(400).json({ success: false, message: 'User ID and HWID/Code required' });
  }

  // Заблокований акаунт (нові користувачі без доступу) не може прив'язувати ПК.
  let linkUser = usersDb.get(finalUserId);
  if (linkUser && linkUser.accessEnabled === false) {
    return res.status(403).json({ success: false, message: 'Функціонал заблоковано: зверніться до адміністратора, щоб отримати доступ' });
  }

  const list = userComputersDb.get(finalUserId) || [];
  if (!list.includes(targetId)) {
    list.push(targetId);
    userComputersDb.set(finalUserId, list);
  }

  // Персональна назва одразу в кеш — GET /api/devices віддає її миттєво.
  userCustomNames.set(`${finalUserId}||${targetId}`, finalName || null);

  // Save to Cloudflare D1 (safe upsert: read-then-write, works without UNIQUE constraints)
  (async () => {
    try {
      const existing = await queryD1(
        `SELECT rowid FROM users_computers WHERE user_id = ? AND computer_id = ? LIMIT 1;`,
        [finalUserId, targetId]
      );
      if (existing && existing.length > 0) {
        await queryD1(
          `UPDATE users_computers SET custom_name = ? WHERE user_id = ? AND computer_id = ?;`,
          [finalName || null, finalUserId, targetId]
        );
      } else {
        await queryD1(
          `INSERT INTO users_computers (user_id, computer_id, custom_name) VALUES (?, ?, ?);`,
          [finalUserId, targetId, finalName || null]
        );
      }
    } catch (e) {
      console.error('[D1] Link computer error:', e.message);
    }
  })();

  res.json({ success: true, message: 'Пристрій успішно додано до вашого акаунту' });
});

// 4.1 Get User Computers
app.get(['/api/user/computers', '/api/devices'], async (req, res) => {
  const userId = req.query.userId;
  if (!userId) return res.status(400).json({ error: 'Missing userId' });

  let compIds = userComputersDb.get(userId) || [];
  // Always refresh the link list straight from D1 so nothing is lost between restarts
  try {
    const rows = await queryD1(`SELECT computer_id FROM users_computers WHERE user_id = ?;`, [userId]);
    if (rows && rows.length > 0) {
      const d1Ids = rows.map(r => r.computer_id);
      compIds = Array.from(new Set([...d1Ids, ...compIds]));
      userComputersDb.set(userId, d1Ids);
    }
  } catch {}

  const result = [];
  for (const cid of compIds) {
    let comp = computersDb.get(cid);
    if (!comp) {
      const rows = await queryD1(`SELECT * FROM computers WHERE id = ? OR hwid = ? OR code = ?;`, [cid, cid, cid]);
      if (rows && rows.length > 0) {
        const c = rows[0];
        comp = {
          id: c.id,
          hwid: c.hwid || c.id,
          code: c.code,
          name: c.name,
          os: c.os_info,
          cpu: c.cpu_info,
          gpu: c.gpu,
          ram: c.ram_info,
          username: c.username || 'Адміністратор',
          lastSeen: c.last_seen ? new Date(c.last_seen).getTime() : 0,
          isOnline: false
        };
      }
    }
    if (!comp) {
      // Linked, but the computer row is not in DB yet — still show the device
      let customName = null;
      try {
        const nm = await queryD1(`SELECT custom_name FROM users_computers WHERE user_id = ? AND computer_id = ? LIMIT 1;`, [userId, cid]);
        customName = nm?.[0]?.custom_name || null;
      } catch {}
      result.push({
        id: cid,
        hwid: cid,
        code: cid,
        name: customName || 'Мій ПК',
        os: 'Windows',
        osInfo: 'Windows',
        cpu: '',
        cpuInfo: '',
        gpu: '',
        gpuInfo: '',
        ram: '',
        ramInfo: '',
        username: 'Адміністратор',
        lastSeen: 0,
        isOnline: false
      });
      continue;
    }
    if (comp) {
      const isOnline = isComputerOnline(comp);
      // ФИКС ПЕРЕЙМЕНУВАННЯ: персональна назва користувача ПЕРЕМОЖЄ hostname,
      // який агент перезаписує в таблиці computers при кожному heartbeat.
      // machineName зберігає оригінальне ім'я машини для довідки.
      const custom = await getCustomName(userId, cid);
      result.push({ 
        ...comp, 
        isOnline,
        machineName: comp.machineName || comp.name,
        name: custom || comp.name,
        username: comp.username || 'Адміністратор',
        osInfo: comp.os,
        cpuInfo: comp.cpu,
        gpuInfo: comp.gpu,
        ramInfo: comp.ram
      });
    }
  }

  res.json({ success: true, devices: result, computers: result });
});

// 4.2 Delete User Computer
app.delete('/api/devices', async (req, res) => {
  const { userId, computerId, deviceId } = req.body || {};
  const targetId = computerId || deviceId;
  if (!userId || !targetId) {
    return res.status(400).json({ success: false, message: 'User ID and Computer ID required' });
  }

  const list = userComputersDb.get(userId) || [];
  const updated = list.filter(id => id !== targetId);
  userComputersDb.set(userId, updated);
  userCustomNames.delete(`${userId}||${targetId}`);

  queryD1(`DELETE FROM users_computers WHERE user_id = ? AND (computer_id = ? OR computer_id LIKE ?);`, [userId, targetId, `%${targetId}%`]);
  res.json({ success: true, message: 'Пристрій від\'єднано' });
});

// 4.3 Rename User Computer
app.patch(['/api/devices', '/api/devices/rename'], async (req, res) => {
  const { userId, computerId, deviceId, newName, name, customName } = req.body || {};
  const targetId = computerId || deviceId;
  const targetName = (newName || name || customName || '').trim();

  if (!userId || !targetId || !targetName) {
    return res.status(400).json({ success: false, message: 'User ID, Computer ID, and newName required' });
  }

  queryD1(`
    UPDATE users_computers 
    SET custom_name = ? 
    WHERE user_id = ? AND (computer_id = ? OR computer_id LIKE ?);
  `, [targetName, userId, targetId, `%${targetId}%`]);

  // Прописуємо нову назву для ВСІХ можливих ключів (hwid/code/link-id), щоб
  // наступний GET /api/devices віддав її одразу, до відповіді D1.
  userCustomNames.set(`${userId}||${targetId}`, targetName);
  try {
    const rows = await queryD1(`SELECT computer_id FROM users_computers WHERE user_id = ? AND (computer_id = ? OR computer_id LIKE ?);`, [userId, targetId, `%${targetId}%`]);
    for (const r of rows || []) userCustomNames.set(`${userId}||${r.computer_id}`, targetName);
  } catch {}

  const comp = computersDb.get(targetId);
  if (comp) {
    // hostname зберігаємо окремо: machines.json повертає його як machineName,
    // а name лишається персональною назвою користувача.
    comp.machineName = comp.machineName || comp.name;
    comp.name = targetName;
  }

  res.json({ success: true, message: 'Назву оновлено', name: targetName });
});

// ==========================================
// 5. LICENSE KEYS & SUBSCRIPTION API
// ==========================================

// 5.1 Admin: List License Keys
app.get('/api/admin/keys', async (req, res) => {
  const rows = await queryD1('SELECT * FROM license_keys ORDER BY created_at DESC;');
  const keys = rows.map(k => ({
    id: k.id,
    keyCode: k.key,
    key: k.key,
    durationType: k.type,
    durationMs: k.duration_ms,
    createdAt: k.created_at,
    expiresAt: k.expires_at,
    isUsed: Boolean(k.used),
    used: Boolean(k.used),
    usedBy: k.used_by_user_id,
    usedByEmail: k.used_by_user_name,
    usedAt: k.used_at
  }));
  res.json({ success: true, keys });
});

// 5.2 Admin: Generate License Keys
app.post('/api/admin/keys/generate', async (req, res) => {
  const { durationType, count = 1, customLabel } = req.body || {};
  const validTypes = ['1m', '5m', '1h', '1d', '7d', '30d', '90d', '1y', 'lifetime'];
  const type = validTypes.includes(durationType) ? durationType : '30d';
  const durationMs = getDurationMs(type);

  const generated = [];
  for (let i = 0; i < Math.min(Math.max(Number(count) || 1, 1), 50); i++) {
    const keyId = `key_${crypto.randomBytes(8).toString('hex')}`;
    const keyCode = generateLicenseKeyCode();
    const createdAt = Date.now();

    const keyItem = {
      id: keyId,
      keyCode,
      key: keyCode,
      durationType: type,
      durationMs,
      createdAt,
      expiresAt: null,
      isUsed: false,
      used: false,
      usedBy: null,
      usedByEmail: null,
      usedAt: null
    };

    licenseKeysDb.set(keyId, keyItem);
    licenseKeysDb.set(keyCode, keyItem);
    generated.push(keyItem);

    // Insert into Cloudflare D1
    queryD1(`
      INSERT INTO license_keys (id, key, type, duration_ms, created_at, expires_at, used)
      VALUES (?, ?, ?, ?, ?, ?, 0);
    `, [keyId, keyCode, type, durationMs, createdAt, null]);
  }

  res.json({ success: true, count: generated.length, keys: generated });
});

// 5.3 Admin: Delete License Key
app.delete('/api/admin/keys/:id', async (req, res) => {
  const idOrCode = req.params.id;
  licenseKeysDb.delete(idOrCode);
  queryD1(`DELETE FROM license_keys WHERE id = ? OR key = ?;`, [idOrCode, idOrCode]);
  res.json({ success: true });
});

// 5.4 Activate License Key (User)
app.post('/api/license/activate', async (req, res) => {
  const body = req.body || {};
  const userId = String(body.userId || '').trim();
  const rawKey = String(body.keyCode || body.key || '').trim().toUpperCase();

  if (!userId || !rawKey) {
    return res.status(400).json({ success: false, message: 'Вкажіть ID користувача та ліцензійний ключ' });
  }

  let cleanKey = rawKey.replace(/[^A-Za-z0-9]/g, '');
  let foundKey = licenseKeysDb.get(rawKey);

  if (!foundKey) {
    const rows = await queryD1(`SELECT * FROM license_keys WHERE key = ? OR key = ?;`, [rawKey, `FC-${cleanKey}`]);
    if (rows && rows.length > 0) {
      const k = rows[0];
      foundKey = {
        id: k.id,
        keyCode: k.key,
        key: k.key,
        durationType: k.type,
        durationMs: k.duration_ms,
        createdAt: k.created_at,
        isUsed: Boolean(k.used),
        usedBy: k.used_by_user_id
      };
    }
  }

  if (!foundKey) {
    return res.status(404).json({ success: false, message: 'Ліцензійний ключ не знайдено або він недійсний' });
  }

  if (foundKey.isUsed) {
    return res.status(400).json({ success: false, message: 'Цей ключ вже був активований раніше' });
  }

  let user = usersDb.get(userId);
  if (!user) {
    const uRows = await queryD1(`SELECT * FROM users WHERE id = ?;`, [userId]);
    if (uRows && uRows.length > 0) {
      const u = uRows[0];
      user = {
        id: u.id,
        email: u.email,
        name: u.name,
        role: u.role || 'user',
        subscriptionExpiresAt: u.subscription_expires_at
      };
      usersDb.set(user.id, user);
    }
  }

  if (!user) {
    return res.status(404).json({ success: false, message: 'Користувача не знайдено' });
  }

  const now = Date.now();
  let newExpiresAt = null;

  if (foundKey.durationType === 'lifetime' || foundKey.durationMs === 0) {
    newExpiresAt = -1; // -1 denotes lifetime PRO
  } else {
    const currentExpiry = user.subscriptionExpiresAt && user.subscriptionExpiresAt > now 
      ? user.subscriptionExpiresAt 
      : now;
    newExpiresAt = currentExpiry + foundKey.durationMs;
  }

  foundKey.isUsed = true;
  foundKey.usedBy = user.id;
  foundKey.usedByEmail = user.email || user.name;
  foundKey.usedAt = now;

  licenseKeysDb.set(foundKey.id, foundKey);
  licenseKeysDb.set(foundKey.keyCode, foundKey);

  user.subscriptionExpiresAt = newExpiresAt;
  user.updatedAt = now;
  // Активація ключа = ключ доступу: відкриває функціонал заблокованим акаунтам.
  user.accessEnabled = true;
  usersDb.set(user.id, user);

  // Update in Cloudflare D1
  queryD1(`UPDATE license_keys SET used = 1, used_by_user_id = ?, used_by_user_name = ?, used_at = ? WHERE id = ? OR key = ?;`, [user.id, user.email, now, foundKey.id, foundKey.keyCode]);
  queryD1(`UPDATE users SET subscription_expires_at = ?, access_enabled = 1 WHERE id = ?;`, [newExpiresAt, user.id]);

  console.log(`[KEY] Activated key ${foundKey.keyCode} for ${user.email} until ${newExpiresAt}`);
  res.json({
    success: true,
    message: 'Підписку успішно активовано!',
    user,
    expiresAt: newExpiresAt,
    durationType: foundKey.durationType
  });
});

// 5.5 List Users & Manage Roles (Admin)
app.get('/api/admin/users', async (req, res) => {
  if (!adminGuard(req, res)) return;
  const rows = await queryD1('SELECT * FROM users ORDER BY created_at DESC;');
  const list = rows.map(u => ({
    id: u.id,
    email: u.email,
    name: u.name,
    picture: u.picture,
    role: u.role || 'user',
    subscriptionExpiresAt: u.subscription_expires_at,
    accessEnabled: u.access_enabled === 0 ? false : true,
    createdAt: u.created_at
  }));
  res.json({ success: true, users: list });
});

app.post('/api/admin/users/role', async (req, res) => {
  if (!adminGuard(req, res)) return;
  const { userId, role, subscriptionExpiresAt } = req.body || {};
  if (!userId) return res.status(400).json({ error: 'Missing userId' });

  let user = usersDb.get(userId);
  if (!user) {
    const rows = await queryD1('SELECT * FROM users WHERE id = ?;', [userId]);
    if (rows && rows.length > 0) {
      user = rows[0];
      usersDb.set(userId, user);
    }
  }

  if (!user) return res.status(404).json({ error: 'User not found' });

  if (role) user.role = role;
  if (subscriptionExpiresAt !== undefined) user.subscriptionExpiresAt = subscriptionExpiresAt;
  user.updatedAt = Date.now();

  usersDb.set(user.id, user);
  queryD1(`UPDATE users SET role = ?, subscription_expires_at = ? WHERE id = ?;`, [user.role, user.subscriptionExpiresAt, userId]);

  res.json({ success: true, user });
});

// 5.6 Admin: повне керування користувачем одним запитом.
// Тіло: { userId, role?, accessEnabled?, subscriptionExpiresAt? (ms | -1 lifetime | null забрати), addDays? }
app.post('/api/admin/users/update', async (req, res) => {
  if (!adminGuard(req, res)) return;
  const { userId, role, accessEnabled, subscriptionExpiresAt, addDays, name } = req.body || {};
  if (!userId) return res.status(400).json({ success: false, error: 'Missing userId' });

  let user = usersDb.get(userId);
  if (!user) {
    const rows = await queryD1('SELECT * FROM users WHERE id = ?;', [userId]);
    if (rows && rows.length > 0) {
      const u = rows[0];
      user = {
        id: u.id,
        email: u.email,
        name: u.name,
        picture: u.picture,
        role: u.role || 'user',
        subscriptionExpiresAt: u.subscription_expires_at,
        accessEnabled: u.access_enabled === 0 ? false : true
      };
      usersDb.set(user.id, user);
    }
  }
  if (!user) return res.status(404).json({ success: false, error: 'User not found' });

  if (role === 'admin' || role === 'user') user.role = role;
  if (accessEnabled === true || accessEnabled === false) user.accessEnabled = accessEnabled;
  if (typeof name === 'string' && name.trim()) user.name = name.trim();

  const now = Date.now();
  if (subscriptionExpiresAt !== undefined) {
    user.subscriptionExpiresAt = subscriptionExpiresAt === null ? null : Number(subscriptionExpiresAt);
  }
  if (addDays !== undefined && addDays !== null && Number.isFinite(Number(addDays))) {
    const base = (user.subscriptionExpiresAt && Number(user.subscriptionExpiresAt) > now)
      ? Number(user.subscriptionExpiresAt)
      : now;
    user.subscriptionExpiresAt = Math.round(base + Number(addDays) * 86400000);
  }
  if (user.role === 'admin') user.subscriptionExpiresAt = -1;

  user.updatedAt = now;
  usersDb.set(user.id, user);
  queryD1(`UPDATE users SET role = ?, subscription_expires_at = ?, access_enabled = ?, name = ? WHERE id = ?;`, [
    user.role,
    user.subscriptionExpiresAt === undefined ? null : user.subscriptionExpiresAt,
    user.accessEnabled === false ? 0 : 1,
    user.name,
    user.id
  ]);

  console.log(`[ADMIN] User updated: ${user.email} role=${user.role} access=${user.accessEnabled} sub=${user.subscriptionExpiresAt}`);
  res.json({ success: true, user });
});

// 5.7 Admin: видалити користувача (разом із прив'язками пристроїв)
app.delete('/api/admin/users/:id', async (req, res) => {
  if (!adminGuard(req, res)) return;
  const id = req.params.id;
  const user = usersDb.get(id);
  usersDb.delete(id);
  await queryD1(`DELETE FROM users WHERE id = ?;`, [id]);
  await queryD1(`DELETE FROM users_computers WHERE user_id = ?;`, [id]);
  console.log(`[ADMIN] User deleted: ${user?.email || id}`);
  res.json({ success: true });
});

// 5.8 Admin: список усіх комп'ютерів + онлайн-статус
app.get('/api/admin/computers', async (req, res) => {
  if (!adminGuard(req, res)) return;
  const rows = await queryD1('SELECT * FROM computers;');
  const owners = await queryD1('SELECT computer_id, user_id FROM users_computers;');
  const ownerMap = new Map();
  for (const o of owners) {
    if (!ownerMap.has(o.computer_id)) ownerMap.set(o.computer_id, []);
    ownerMap.get(o.computer_id).push(o.user_id);
  }
  const seen = new Set();
  const list = [];
  for (const c of rows) {
    if (seen.has(c.id)) continue;
    seen.add(c.id);
    const live = findComputer(c.hwid || c.id || c.code);
    list.push({
      id: c.id,
      hwid: c.hwid || c.id,
      code: c.code,
      name: c.name,
      os: c.os_info,
      cpu: c.cpu_info,
      gpu: c.gpu,
      ram: c.ram_info,
      lastSeen: c.last_seen,
      isOnline: isComputerOnline(live || {}),
      ownerIds: ownerMap.get(c.id) || ownerMap.get(c.hwid) || []
    });
  }
  res.json({ success: true, computers: list });
});

// ==========================================
// 5.9 AI PROXY (Gemini) — агент-помічник для вкладки «Штучний інтелект»
// ==========================================

const GEMINI_API_KEY = process.env.GEMINI_API_KEY || 'AQ.Ab8RN6JyX3nou0fvgILSiuH6WMBfpdRDtD2YO5aKPpcWchTnwA';
// Основна модель — за вимогою власника. Якщо вона ще не доступна на акаунті,
// проксі автоматично пробує сумісні flash-моделі, щоб функція не лежала.
const GEMINI_MODEL_CHAIN = [
  process.env.GEMINI_MODEL || 'gemini-3.5-flash-lite',
  'gemini-3.6-flash',
  'gemini-3.5-flash'
];
let geminiWorkingModel = null;

async function callGemini(modelName, contents, systemText) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent`;
  const body = {
    contents,
    systemInstruction: systemText ? { parts: [{ text: systemText }] } : undefined,
    generationConfig: {
      temperature: 0.4,
      // 8192: модель пише відповіді-JSON із ВБУДОВАНИМИ скриптами (напр. python-файл
      // всередині "command"). Стара стеля 2048 обрізала JSON посеред рядка →
      // парсинг падав → цикл «думав і зупинявся», нічого не виконавши.
      maxOutputTokens: 8192,
      responseMimeType: 'application/json'
    }
  };
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 45000);
  try {
    const r = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': GEMINI_API_KEY
      },
      body: JSON.stringify(body),
      signal: ctrl.signal
    });
    const data = await r.json().catch(() => null);
    if (!r.ok) {
      const err = new Error(data?.error?.message || `Gemini HTTP ${r.status}`);
      err.status = r.status;
      throw err;
    }
    const parts = data?.candidates?.[0]?.content?.parts || [];
    const text = parts.map(p => p.text || '').join('').trim();
    return { ok: true, text };
  } finally {
    clearTimeout(t);
  }
}

// Швидка перевірка готовності AI з фронтенду: чи бекенд оновлений і чи приймає
// великі тіла (скриншоти). 404 на цей роут означає, що на Render старий server.js.
app.get('/api/ai/status', (req, res) => {
  res.json({
    success: true,
    ai: true,
    model: GEMINI_MODEL_CHAIN[0],
    fallbacks: GEMINI_MODEL_CHAIN.slice(1),
    maxBodyMb: 30,
    maxOutputTokens: 8192,
    version: '5.7.0'
  });
});

app.post('/api/ai/chat', async (req, res) => {
  const { messages } = req.body || {};
  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ success: false, error: 'messages required' });
  }

  // Кожне повідомлення може нести зображення (скриншот екрана ПК) —
  // тоді формуємо parts із inline_data, щоб Gemini бачив екран (vision).
  const contents = messages.slice(-24).map(m => {
    const parts = [];
    if (m.image) {
      let b64 = String(m.image);
      const dataUrl = b64.match(/^data:image\/(\w+);base64,(.+)$/);
      if (dataUrl) { b64 = dataUrl[2]; }
      if (b64.length > 40) {
        parts.push({ inline_data: { mime_type: 'image/jpeg', data: b64 } });
      }
    }
    parts.push({ text: String(m.text || '').slice(0, 12000) });
    return { role: m.role === 'model' ? 'model' : 'user', parts };
  });
  const systemText = req.body.system || '';

  const chain = geminiWorkingModel
    ? [geminiWorkingModel, ...GEMINI_MODEL_CHAIN.filter(m => m !== geminiWorkingModel)]
    : GEMINI_MODEL_CHAIN;

  let lastErr = '';
  for (const model of chain) {
    try {
      const out = await callGemini(model, contents, systemText);
      geminiWorkingModel = model;
      return res.json({ success: true, text: out.text, model });
    } catch (e) {
      lastErr = e.message;
      // Моделі, якої немає на акаунті, — пробуємо наступну; інші помилки теж
      // логуємо, але спробуємо всю лінійку, щоб знайти робочу.
      console.warn(`[AI] ${model} failed: ${e.message}`);
    }
  }

  res.status(502).json({ success: false, error: `Gemini недоступний: ${lastErr}` });
});

// ==========================================
// 6. DESKTOP APP WEB OAUTH / LOGIN FLOW
// ==========================================

// 6.1 Agent initiates auth request
app.post('/api/auth/device-session/create', async (req, res) => {
  const { computerName, hwid, code } = req.body || {};
  const token = `auth_req_${crypto.randomBytes(12).toString('hex')}`;
  const now = Date.now();
  const expiresAt = now + 15 * 60 * 1000;

  const session = {
    token,
    computerName: computerName || 'Комп\'ютер',
    hwid: hwid || '',
    code: code || '',
    status: 'pending',
    userId: null,
    user: null,
    createdAt: now,
    expiresAt
  };

  authSessionsDb.set(token, session);

  // Write immediately to Cloudflare D1
  queryD1(`
    INSERT INTO auth_sessions (token, computer_name, hwid, code, status, created_at, expires_at)
    VALUES (?, ?, ?, ?, 'pending', ?, ?);
  `, [token, session.computerName, session.hwid, session.code, now, expiresAt]);

  res.json({
    success: true,
    token,
    authUrl: `https://fluxcontrol.pages.dev/auth/device?token=${token}&pc=${encodeURIComponent(session.computerName)}`
  });
});

// 6.2 Agent polls session status
app.get('/api/auth/device-session/status', async (req, res) => {
  const token = req.query.token;
  if (!token) return res.status(400).json({ error: 'Missing token' });

  let session = authSessionsDb.get(token);

  // If not in cache or pending, check Cloudflare D1
  if (!session || session.status === 'pending') {
    const rows = await queryD1(`SELECT * FROM auth_sessions WHERE token = ?;`, [token]);
    if (rows && rows.length > 0) {
      const row = rows[0];
      session = {
        token: row.token,
        computerName: row.computer_name,
        hwid: row.hwid,
        code: row.code,
        status: row.status,
        userId: row.user_id,
        user: row.user_json ? JSON.parse(row.user_json) : null,
        createdAt: row.created_at
      };
      authSessionsDb.set(token, session);
    }
  }

  if (!session) return res.status(404).json({ error: 'Session not found' });

  res.json({
    success: true,
    status: session.status,
    computerName: session.computerName,
    user: session.user
  });
});

// 6.3 Website approves device session
app.post('/api/auth/device-session/approve', async (req, res) => {
  const { token, userId, user: providedUser, action } = req.body || {};
  if (!token) return res.status(400).json({ error: 'Missing token' });

  let session = authSessionsDb.get(token);
  if (!session) {
    const rows = await queryD1(`SELECT * FROM auth_sessions WHERE token = ?;`, [token]);
    if (rows && rows.length > 0) {
      const row = rows[0];
      session = {
        token: row.token,
        computerName: row.computer_name,
        hwid: row.hwid,
        code: row.code,
        status: row.status,
        createdAt: row.created_at
      };
    }
  }

  if (!session) return res.status(404).json({ error: 'Session not found' });

  if (action === 'reject') {
    session.status = 'rejected';
    authSessionsDb.set(token, session);
    queryD1(`UPDATE auth_sessions SET status = 'rejected' WHERE token = ?;`, [token]);
    return res.json({ success: true, status: 'rejected' });
  }

  // Resolve user info from memory, provided payload, or D1
  let user = providedUser || usersDb.get(userId);
  if (!user && userId) {
    const uRows = await queryD1(`SELECT * FROM users WHERE id = ?;`, [userId]);
    if (uRows && uRows.length > 0) {
      user = uRows[0];
    }
  }

  if (!user && !userId) {
    return res.status(400).json({ error: 'User info required to approve' });
  }

  const approvedUser = {
    id: user?.id || userId,
    email: user?.email || '',
    name: user?.name || 'Користувач',
    picture: user?.picture || user?.photoURL || '',
    role: user?.role || 'user',
    subscriptionExpiresAt: user?.subscriptionExpiresAt !== undefined ? user.subscriptionExpiresAt : null
  };

  session.status = 'approved';
  session.userId = approvedUser.id;
  session.user = approvedUser;

  authSessionsDb.set(token, session);

  // Update in Cloudflare D1 immediately
  queryD1(`
    UPDATE auth_sessions 
    SET status = 'approved', user_id = ?, user_json = ? 
    WHERE token = ?;
  `, [approvedUser.id, JSON.stringify(approvedUser), token]);

  // Ensure user is also upserted in D1 users table
  queryD1(`
    INSERT INTO users (id, email, name, picture, role, subscription_expires_at)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      email=excluded.email,
      name=excluded.name,
      picture=excluded.picture,
      role=excluded.role,
      subscription_expires_at=excluded.subscription_expires_at;
  `, [approvedUser.id, approvedUser.email, approvedUser.name, approvedUser.picture, approvedUser.role, approvedUser.subscriptionExpiresAt]);

  console.log(`[AUTH] Device session approved for ${approvedUser.email} on ${session.computerName}`);
  res.json({ success: true, status: 'approved', user: approvedUser });
});

// ==========================================
// 7. WEBSOCKET SERVER RELAY
// ==========================================

const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// One relay-owned heartbeat for all agents. It is intentionally modest: a
// health check every four seconds, and Offline only after three missed slots.
setInterval(() => {
  const now = Date.now();
  for (const comp of uniqueComputers()) {
    const wasOnline = Boolean(comp.isOnline);
    const online = isComputerOnline(comp, now);
    comp.isOnline = online;

    if (comp.agentWs?.readyState === WebSocket.OPEN) {
      try { comp.agentWs.send(JSON.stringify({ type: 'health_check', timestamp: now })); } catch { }
    }

    if (wasOnline && !online) {
      // Persist the honest offline state so the Cloudflare D1 fallback
      // endpoint can never report this PC as online after the relay dies.
      const id = comp.hwid || comp.id;
      if (id) {
        queryD1('UPDATE computers SET status = ? WHERE id = ? OR hwid = ? OR code = ?;', ['offline', id, id, comp.code || '']).catch(() => {});
      }
      for (const clientWs of getClientsForComp(comp, comp.code, comp.hwid)) {
        if (clientWs.readyState === WebSocket.OPEN) {
          try { clientWs.send(JSON.stringify({ type: 'agent_status', status: 'offline' })); } catch { }
        }
      }
    }
  }
}, AGENT_HEARTBEAT_INTERVAL_MS);

// Mirror live agent heartbeats into D1 every 30 seconds. The relay memory is
// the single source of truth, but the D1 tables are what the Cloudflare Pages
// fallback reads while Render is cold-starting — without this refresh the
// fallback sees a stale last_seen and honest devices flip to offline there.
setInterval(() => {
  const online = uniqueComputers().filter(c => c.isOnline && c.hwid);
  for (const comp of online) {
    queryD1(
      `UPDATE computers SET last_seen = CURRENT_TIMESTAMP, status = 'online'
       WHERE id = ? OR hwid = ?;`,
      [comp.hwid, comp.hwid]
    ).catch(() => {});
  }
}, 30000);

wss.on('connection', (ws, req) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const role = url.searchParams.get('role');
  const code = (url.searchParams.get('code') || '').toUpperCase().trim();
  const hwid = url.searchParams.get('hwid') || '';

  if (role === 'agent') {
    handleAgentConnection(ws, code, hwid);
  } else if (role === 'client') {
    handleClientConnection(ws, code, hwid);
  } else {
    // Default identification via handshake message
    ws.on('message', (data) => {
      try {
        const msg = JSON.parse(data.toString());
        if (msg.type === 'register_agent') {
          handleAgentConnection(ws, (msg.code || '').toUpperCase().trim(), msg.hwid || '');
        } else if (msg.type === 'register_client') {
          handleClientConnection(ws, (msg.code || '').toUpperCase().trim(), msg.hwid || '');
        }
      } catch (e) {}
    });
  }
});

function findComputer(key) {
  if (!key) return null;
  const clean = String(key).replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  let found = computersDb.get(key) || computersDb.get(clean);
  if (found) return found;
  for (const comp of computersDb.values()) {
    const c1 = String(comp.code || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
    const c2 = String(comp.hwid || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
    const c3 = String(comp.id || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
    if (c1 === clean || c2 === clean || c3 === clean) {
      return comp;
    }
  }
  return null;
}

function getClientsForComp(comp, code, hwid) {
  const cleanCode = (code || comp?.code || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  const cleanHwid = (hwid || comp?.hwid || comp?.id || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  const cleanCompId = (comp?.id || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();

  const result = new Set();
  for (const clientWs of wss.clients) {
    if (clientWs.readyState === WebSocket.OPEN && clientWs.isClient) {
      const target = (clientWs.clientTargetKey || '').toUpperCase();
      if (target && (target === cleanCode || target === cleanHwid || target === cleanCompId)) {
        result.add(clientWs);
      }
    }
  }
  return Array.from(result);
}

function handleAgentConnection(ws, code, hwid) {
  const cleanCode = (code || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  const primaryKey = hwid || cleanCode || code;
  if (!primaryKey) {
    console.warn('[RELAY] [AGENT REJECTED] Missing HWID and Code');
    ws.close(1008, 'HWID or Code required');
    return;
  }

  ws.isAgent = true;
  ws.agentCode = cleanCode;
  ws.agentHwid = hwid || primaryKey;

  const existing = findComputer(primaryKey) || computersDb.get(primaryKey) || {};
  const comp = {
    ...existing,
    id: primaryKey,
    hwid: hwid || existing.hwid || primaryKey,
    code: cleanCode || existing.code || code,
    connection_code: cleanCode || existing.connection_code || code,
    agentWs: ws,
    lastSeen: Date.now(),
    isOnline: true
  };

  computersDb.set(primaryKey, comp);
  if (cleanCode) computersDb.set(cleanCode, comp);
  if (comp.hwid) computersDb.set(comp.hwid, comp);

  console.log(`[RELAY] [AGENT CONNECTED] HWID=${comp.hwid}, Code=${cleanCode}, PC Name=${comp.name || 'ПК'}`);

  // Notify any waiting web clients that the PC is online
  const waitingClients = getClientsForComp(comp, cleanCode, hwid);
  console.log(`[RELAY] [AGENT ONLINE NOTIFY] Notifying ${waitingClients.length} waiting client(s)`);
  for (const clientWs of waitingClients) {
    clientWs.send(JSON.stringify({ type: 'agent_status', status: 'online', computerName: comp.name || 'ПК' }));
  }

  ws.on('message', (msg) => {
    // Resolve the canonical record every time. This makes a D1 refresh unable
    // to leave the agent message handler updating a detached old object.
    const currentComp = findComputer(comp.hwid) || findComputer(comp.code) || comp;
    currentComp.agentWs = ws;
    currentComp.lastSeen = Date.now();
    currentComp.isOnline = true;
    const textMsg = typeof msg === 'string' ? msg : msg.toString('utf8');
    
    let msgType = 'unknown';
    try {
      const parsed = JSON.parse(textMsg);
      msgType = parsed.type || 'unknown';
      if (parsed && (parsed.type === 'telemetry' || parsed.type === 'pong')) {
        currentComp.lastTelemetry = parsed;
      }
    } catch {}

    const clients = getClientsForComp(currentComp, cleanCode, hwid);
    if (clients.length > 0) {
      if (msgType !== 'telemetry') {
        console.log(`[RELAY] [AGENT -> CLIENT] Type: ${msgType} -> forwarding to ${clients.length} client(s)`);
      }
      for (const clientWs of clients) {
        if (clientWs.readyState === WebSocket.OPEN) {
          try { clientWs.send(textMsg); } catch (err) {
            console.error(`[RELAY] Error sending to client: ${err.message}`);
          }
        }
      }
    }
  });

  ws.on('close', (codeNum, reason) => {
    console.log(`[RELAY] [AGENT DISCONNECTED] HWID=${comp.hwid}, Code=${cleanCode} (Code: ${codeNum})`);
    comp.isOnline = false;
    if (comp.agentWs === ws) comp.agentWs = null;
    // Do not broadcast Offline immediately: the desktop agent reconnects in
    // four seconds. The health monitor below confirms a real 12s timeout.
  });

  ws.on('error', (err) => {
    console.error(`[RELAY] [AGENT WS ERROR] HWID=${comp.hwid}: ${err.message}`);
  });
}

function handleClientConnection(ws, code, hwid) {
  const targetKey = (code || hwid || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  if (!targetKey) {
    console.warn('[RELAY] [CLIENT REJECTED] Missing target Code or HWID');
    ws.close(1008, 'Target code or HWID required');
    return;
  }

  ws.isClient = true;
  ws.clientTargetKey = targetKey;

  const currentList = webClients.get(targetKey) || [];
  currentList.push(ws);
  webClients.set(targetKey, currentList);

  const comp = findComputer(targetKey) || computersDb.get(targetKey);

  // Find active agent WebSocket
  let activeAgentWs = (comp?.agentWs && comp.agentWs.readyState === WebSocket.OPEN) ? comp.agentWs : null;
  if (!activeAgentWs) {
    for (const clientSocket of wss.clients) {
      if (clientSocket.readyState === WebSocket.OPEN && clientSocket.isAgent) {
        if (clientSocket.agentCode === targetKey || clientSocket.agentHwid === targetKey || (comp && (clientSocket.agentCode === comp.code || clientSocket.agentHwid === comp.hwid))) {
          activeAgentWs = clientSocket;
          if (comp) comp.agentWs = clientSocket;
          break;
        }
      }
    }
  }

  const isAgentOnline = isComputerOnline(comp);
  console.log(`[RELAY] [CLIENT CONNECTED] Target PC: ${targetKey}, Agent Online: ${isAgentOnline}`);

  // Send status immediately to client
  ws.send(JSON.stringify({
    type: 'agent_status',
    status: isAgentOnline ? 'online' : 'offline',
    computerName: comp?.name || 'ПК'
  }));

  // Ask the agent for an actual response. Do not fabricate a pong here: a
  // cached socket can be OPEN while the machine is no longer reachable.
  if (isAgentOnline) {
    if (comp?.lastTelemetry) {
      console.log(`[RELAY] [CLIENT FAST-START] Sending cached telemetry to client for ${targetKey}`);
      try {
        ws.send(JSON.stringify(comp.lastTelemetry));
      } catch {}
    }

    // Request instant fresh telemetry from desktop agent
    try {
      activeAgentWs.send(JSON.stringify({ type: 'health_check' }));
      activeAgentWs.send(JSON.stringify({ type: 'telemetry' }));
    } catch {}
  }

  ws.on('message', (msg) => {
    const textMsg = typeof msg === 'string' ? msg : msg.toString('utf8');
    let msgType = 'unknown';
    try {
      const parsed = JSON.parse(textMsg);
      msgType = parsed.type || 'unknown';
    } catch {}

    console.log(`[RELAY] [CLIENT -> AGENT] Target: ${targetKey}, Type: ${msgType}`);

    let liveAgentWs = (comp?.agentWs && comp.agentWs.readyState === WebSocket.OPEN) ? comp.agentWs : activeAgentWs;
    if (!liveAgentWs || liveAgentWs.readyState !== WebSocket.OPEN) {
      for (const clientSocket of wss.clients) {
        if (clientSocket.readyState === WebSocket.OPEN && clientSocket.isAgent) {
          if (clientSocket.agentCode === targetKey || clientSocket.agentHwid === targetKey || (comp && (clientSocket.agentCode === comp.code || clientSocket.agentHwid === comp.hwid))) {
            liveAgentWs = clientSocket;
            if (comp) comp.agentWs = clientSocket;
            break;
          }
        }
      }
    }

    if (liveAgentWs && liveAgentWs.readyState === WebSocket.OPEN) {
      try {
        liveAgentWs.send(textMsg);
      } catch (err) {
        console.error(`[RELAY] Error sending command to agent: ${err.message}`);
      }
    } else {
      console.warn(`[RELAY] [AGENT NOT REACHABLE] Cannot forward ${msgType} to ${targetKey}`);
      ws.send(JSON.stringify({ type: 'agent_status', status: 'offline' }));
    }
  });

  ws.on('close', (codeNum) => {
    for (const [k, list] of webClients.entries()) {
      const idx = list.indexOf(ws);
      if (idx !== -1) list.splice(idx, 1);
    }
    console.log(`[RELAY] [CLIENT DISCONNECTED] Target PC: ${targetKey} (Code: ${codeNum})`);
  });

  ws.on('error', (err) => {
    console.error(`[RELAY] [CLIENT WS ERROR] Target PC ${targetKey}: ${err.message}`);
  });
}

server.listen(PORT, () => {
  console.log(`[FluxControl] Relay server v5.4.0 running on port ${PORT}`);
  console.log(`[FluxControl] Cloudflare D1 database: ${CLOUDFLARE_D1_CONFIG.databaseId}`);
});
