@echo off
rem ============================================================
rem  FluxControl - Deploy Manager v2.2
rem  Colorful menu: build / release / deploy
rem  Requires: Windows 10/11 (truecolor ANSI), .NET 8 SDK, git
rem  Agent release flow: Installer\Auto-Deploy.ps1
rem
rem  Architecture:
rem    Release vX contains ONE file:
rem      FluxControl.exe            - the app itself (single-file, location-independent)
rem    Repo main branch contains:
rem      files\FluxControl.exe      - same exe for self-update
rem      files\UI\agent_ui.html     - working files, live in %AppData%\FluxControl
rem      files\logo.ico
rem      version.json               - manifest (latest_version + files + sha256)
rem    %AppData%\FluxControl on user machine - working files live here
rem ============================================================
setlocal EnableExtensions
chcp 65001 >nul
title FluxControl - Deploy Manager
color 0F
cd /d "%~dp0"

rem ---- ANSI truecolor engine (Windows 10+) ----
for /f %%a in ('echo prompt $E ^| cmd') do set "ESC=%%a"
set "R=%ESC%[0m"
set "B=%ESC%[1m"
set "D=%ESC%[2m"
set "W=%ESC%[38;2;236;238;255m"
set "G=%ESC%[38;2;52;211;153m"
set "E1=%ESC%[38;2;248;113;113m"
set "Y=%ESC%[38;2;251;191;36m"
set "C1=%ESC%[38;2;86;214;255m"
set "P1=%ESC%[38;2;183;156;255m"
set "P2=%ESC%[38;2;159;123;255m"
set "P3=%ESC%[38;2;134;105;255m"
set "P4=%ESC%[38;2;109;91;255m"
set "P5=%ESC%[38;2;86;120;255m"
set "GR=%ESC%[38;2;124;132;158m"

rem ---- Paths ----
set "AUTOD=%~dp0Installer\Auto-Deploy.ps1"
set "RELURL=https://github.com/matviikobrys2707/FluxControl_Release/releases"

rem ==== PS_RUN <extra args...> :: runs Auto-Deploy.ps1 with fixed encoding ====
rem Windows PowerShell 5.1 під chcp 65001 ламає вивід (рядки склеюються
rem пробілами, кирилиця -> ????? на растрових шрифтах). Тому на час роботи
rem powershell перемикаємось на OEM 866 і повертаємось назад.

:MENU
cd /d "%~dp0"
title FluxControl - Deploy Manager
cls
call :banner

call :tool "dotnet SDK   - compiles the agent" dotnet
call :tool "git          - updates Release repo main" git
call :tool "node + npm   - builds Web frontend" npm
call :tool "GitHub CLI   - auto-publish releases" gh
if not exist "%AUTOD%" goto MENU_NOAUTOD
echo    %G%[+]%R%  %GR%Installer\Auto-Deploy.ps1%R%
goto MENU_TOOLS_DONE
:MENU_NOAUTOD
echo    %E1%[-]%R%  %GR%Installer\Auto-Deploy.ps1  NOT FOUND - release mode disabled%R%
:MENU_TOOLS_DONE

echo    %D% -----------------------------------------------------------------%R%
echo.
echo    %B%%P4%[1]%R%  Build Agent release files      %GR%(local, no deploy)%R%
echo    %B%%P4%[2]%R%  Build + Publish GitHub release %GR%(release = 1 exe, full auto)%R%
echo    %B%%P4%[3]%R%  Deploy Web + Server            %GR%(pages.dev + render)%R%
echo    %B%%P4%[4]%R%  %B%FULL DEPLOY%R%                   %GR%(release + web + server)%R%
echo    %B%%P4%[5]%R%  Check current version          %GR%(version.json on GitHub)%R%
echo    %B%%P4%[6]%R%  Push Agent source backup       %GR%(FluxControl-Agent.git)%R%
echo    %B%%GR%[0]%R%  Exit
echo.
echo    %D%release: 1 exe (the app)  +  working files + manifest in repo main%R%
echo.
choice /C 1234560 /N /M "   Select: "

if errorlevel 7 goto EXIT
if errorlevel 6 goto PUSH_SOURCE
if errorlevel 5 goto CHECK_VERSION
if errorlevel 4 goto FULL_DEPLOY
if errorlevel 3 goto WEB_SERVER_DEPLOY
if errorlevel 2 goto RELEASE_DEPLOY
if errorlevel 1 goto BUILD_AGENT

:BUILD_AGENT
title FluxControl - Building release files
call :head "BUILD AGENT - LOCAL RELEASE FILES"
where dotnet >nul 2>&1
if errorlevel 1 goto NO_DOTNET
if not exist "%AUTOD%" goto NO_AUTOD
call :step "Agent single-file exe + working files + manifest"
call :step "You will be asked for the new version number"
echo.
chcp 866 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%AUTOD%" -NoDeploy
set "PS_RC=%errorlevel%"
chcp 65001 >nul
if not "%PS_RC%"=="0" goto BUILD_FAIL
call :ok "Release files ready:"
echo    %D%  Installer\_deploy\FluxControl.exe   - THE release file (the app itself)%R%
echo    %D%  Installer\_deploy\files\             - goes to repo main (files/)%R%
echo    %D%  Installer\_deploy\version.json       - manifest for auto-update%R%
call :step "Run option 2 to publish everything to GitHub"
echo.
pause
goto MENU

:BUILD_FAIL
call :err "Build failed - read the compiler output above"
echo.
pause
goto MENU

:RELEASE_DEPLOY
title FluxControl - Build + GitHub Release
call :head "BUILD + PUBLISH GITHUB RELEASE"
where dotnet >nul 2>&1
if errorlevel 1 goto NO_DOTNET
where git >nul 2>&1
if errorlevel 1 goto NO_GIT
if not exist "%AUTOD%" goto NO_AUTOD
call :step "Flow: version check, build, release (1 exe) + files in repo main"
call :step "If gh is not logged in, browser login will start automatically"
echo.
chcp 866 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%AUTOD%"
set "PS_RC=%errorlevel%"
chcp 65001 >nul
if not "%PS_RC%"=="0" goto REL_FAIL
call :ok "Release published to GitHub"
echo    %D%Page  : %RELURL%%R%
echo.
pause
goto MENU

:REL_FAIL
call :err "Release failed - read the output above"
echo.
pause
goto MENU

:WEB_SERVER_DEPLOY
title FluxControl - Deploy Web + Server
call :head "DEPLOY WEB + SERVER"
call :do_web
echo.
pause
goto MENU

:FULL_DEPLOY
title FluxControl - Full Deploy
call :head "FULL DEPLOY - AGENT RELEASE + WEB + SERVER"
where dotnet >nul 2>&1
if errorlevel 1 goto NO_DOTNET
where git >nul 2>&1
if errorlevel 1 goto NO_GIT
if not exist "%AUTOD%" goto NO_AUTOD
call :step "Part 1/2: Agent - build + GitHub release"
echo.
chcp 866 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%AUTOD%"
set "PS_RC=%errorlevel%"
chcp 65001 >nul
if not "%PS_RC%"=="0" goto FULL_RELWARN
goto FULL_RELOK
:FULL_RELWARN
call :warn "Agent release failed - continuing with Web + Server"
goto FULL_PART2
:FULL_RELOK
call :ok "Agent release done"
:FULL_PART2
call :step "Part 2/2: Web + Server"
call :do_web
echo.
echo    %G%[OK]%R% %B%FULL DEPLOY finished%R%
echo    %D%Agent  : %RELURL%%R%
echo    %D%Web    : https://fluxcontrol.pages.dev%R%
echo    %D%Server : https://fluxcontrol-backend.onrender.com%R%
echo.
pause
goto MENU

:CHECK_VERSION
title FluxControl - Version Check
call :head "CURRENT VERSION ON GITHUB"
call :step "Reading version.json"
set "GHV=unavailable"
chcp 866 >nul
for /f "usebackq delims=" %%v in (`powershell -NoProfile -Command "try{(Invoke-RestMethod 'https://raw.githubusercontent.com/matviikobrys2707/FluxControl_Release/main/version.json?t=%RANDOM%').latest_version}catch{'unavailable'}"`) do set "GHV=%%v"
chcp 65001 >nul
echo    %D%Latest release :%R% %W%%B%%GHV%%R%
if exist "Installer\_deploy\version.json" call :step "Local last build info: Installer\_deploy\version.json"
echo    %D%Releases page  :%R% %C1%%RELURL%%R%
echo.
pause
goto MENU

:PUSH_SOURCE
title FluxControl - Agent source backup
call :head "PUSH AGENT SOURCE - BACKUP REPO"
where git >nul 2>&1
if errorlevel 1 goto NO_GIT
if not exist "FluxControl.Agent" goto NO_AGENTDIR
pushd FluxControl.Agent
if not exist ".git" git init -b main >nul 2>&1
git remote remove origin >nul 2>&1
git remote add origin https://github.com/matviikobrys2707/FluxControl-Agent.git
git add -A
git commit -m "Agent source backup" >nul 2>&1
call :step "Force-push to FluxControl-Agent.git"
git push -u origin main --force
if errorlevel 1 goto PUSH_FAIL
popd
call :ok "Agent source pushed"
echo.
pause
goto MENU

:PUSH_FAIL
popd
call :err "Push failed - check git auth, try: gh auth login"
echo.
pause
goto MENU

:NO_GIT
call :err "git not found - install: winget install Git.Git"
echo.
pause
goto MENU

:NO_AGENTDIR
call :err "FluxControl.Agent folder not found - run this script from the project root"
echo.
pause
goto MENU

:NO_DOTNET
call :err "dotnet SDK not found - install: winget install Microsoft.DotNet.SDK.8"
echo.
pause
goto MENU

:NO_AUTOD
call :err "Installer\Auto-Deploy.ps1 not found - run this script from the project root"
echo.
pause
goto MENU

:EXIT
endlocal
exit /b 0

rem ============================ helpers ============================

:do_web
where git >nul 2>&1
if errorlevel 1 goto dw_nogit
where npm >nul 2>&1
if errorlevel 1 goto dw_nonpm
if not exist "FluxControl.Web" goto dw_noweb
call :step "Web: npm run build"
pushd FluxControl.Web
call npm run build
if errorlevel 1 goto dw_buildfail
if not exist "dist" goto dw_nodist
call :ok "Web built"
call :step "Web: force-push dist to FluxControl.git"
pushd dist
if not exist ".git" git init -b main >nul 2>&1
git remote remove origin >nul 2>&1
git remote add origin https://github.com/matviikobrys2707/FluxControl.git
git add -A
git commit -m "Deploy Web" >nul 2>&1
git push -u origin main --force
if errorlevel 1 goto dw_webpushfail
popd
popd
call :ok "Web live: https://fluxcontrol.pages.dev"
if not exist "FluxControl.Server" goto dw_noserver
call :step "Server: force-push to FluxControl-Backend.git"
pushd FluxControl.Server
if not exist ".git" git init -b main >nul 2>&1
git remote remove origin >nul 2>&1
git remote add origin https://github.com/matviikobrys2707/FluxControl-Backend.git
git add -A
git commit -m "Deploy Server" >nul 2>&1
git push -u origin main --force
if errorlevel 1 goto dw_srvpushfail
popd
call :ok "Server live: https://fluxcontrol-backend.onrender.com"
exit /b 0

:dw_webpushfail
popd
popd
call :err "Web push failed - check git auth, try: gh auth login"
exit /b 1

:dw_srvpushfail
popd
call :err "Server push failed - check git auth, try: gh auth login"
exit /b 1

:dw_buildfail
popd
call :err "Web build failed - read npm output above"
exit /b 1

:dw_nodist
popd
call :err "dist folder missing after build"
exit /b 1

:dw_nogit
call :err "git not found - install: winget install Git.Git"
exit /b 1

:dw_nonpm
call :err "npm not found - install Node.js LTS"
exit /b 1

:dw_noweb
call :err "FluxControl.Web folder not found - run this script from the project root"
exit /b 1

:dw_noserver
call :warn "FluxControl.Server folder not found - Web deployed, Server skipped"
exit /b 0

:banner
echo.
echo    %P1%███████╗██╗   ██╗██╗   ██╗██╗  ██╗%R%   %W%%B%FluxControl%R%
echo    %P2%██╔════╝██║   ██║██║   ██║╚██╗██╔╝%R%   %D%DEPLOY MANAGER v2.2%R%
echo    %P3%█████╗  ██║   ██║██║   ██║ ╚███╔╝%R%   %C1%github.com/matviikobrys2707%R%
echo    %P4%██╔══╝  ╚██╗ ██╔╝██║   ██║ ██╔██╗%R%   %D%1 exe + auto-download + auto-update%R%
echo    %P5%██║      ╚████╔╝ ╚██████╔╝██╔╝ ██╗%R%
echo    %C1%╚═╝       ╚═══╝   ╚═════╝ ╚═╝  ╚═╝%R%
echo    %P5%██%P4%██%P3%██%P2%██%P1%██%C1%██%R% %D%Windows 10/11 required for colors%R%
echo.
goto :eof

:head
echo.
echo    %B%%P4%  %~1%R%
echo    %D%  ------------------------------------------------------------------%R%
goto :eof

:step
echo    %C1%»%R% %~1
goto :eof

:ok
echo    %G%[OK]%R% %~1
goto :eof

:err
echo    %E1%[X]%R% %~1
goto :eof

:warn
echo    %Y%[!]%R% %~1
goto :eof

:tool
where %~2 >nul 2>&1
if errorlevel 1 goto tool_no
echo    %G%[+]%R%  %GR%%~1%R%
goto :eof
:tool_no
echo    %E1%[-]%R%  %GR%%~1%R%
goto :eof
